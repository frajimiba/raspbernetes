import { Directive } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';

/**
 * Directiva para uso de mat-dialog con lazy loading
 *
 * @example Integración extendiendo en un servicio la directiva:
 *
 *   export class ConfirmationDialogService extends AsyncDialog<ConfirmationDialogComponent, ConfirmationDialogDataModel, boolean> {
 *     async open(data: ConfirmationDialogDataModel): Promise<MatDialogRef<ConfirmationDialogComponent, boolean>> {
 *       const {ConfirmationDialogModule} = await import('../confirmation-dialog.module');
 *
 *       return this.matDialog.open(ConfirmationDialogModule.getComponent(), {data});
 *     }
 *
 *     open$(data: ConfirmationDialogDataModel): Observable<boolean> {
 *       return fromPromise(this.open(data))
 *         .pipe(
 *           switchMap(dialogRef => dialogRef.afterClosed()),
 *         );
 *     }
 *   }
 *
 */
@Directive()
export abstract class AsyncDialog<ComponentType, DataType, ReturnType = unknown> {
  constructor(protected matDialog: MatDialog) {}

  public abstract open(data: DataType): Promise<MatDialogRef<ComponentType, ReturnType>>;
}
