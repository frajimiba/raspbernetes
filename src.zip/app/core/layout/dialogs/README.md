# Custom Lazy Loading forn Angular Material Dialog Service Component

- Utilizar importando el servicio y configurando el mat-dialog con la función que expone el servicio "menu-creation-edition-dialog.service"

### Example of use:

    private readonly stopSubscriptionsNotifier = new Subject<void>();

    constructor(private readonly dialogService: MenuCreationEditionDialogService) {}

    public async showComponentInDialog(): Promise<void> {

      const dialogRef = await this.showComponentInDialogUi();
      if (!dialogRef) {
        return;
      }

      this.setDialogCloseActions(dialogRef);
    }

      private async showComponentInDialogUi(): Promise<MatDialogRef<YourComponentToShowInDialogUi>> {

      const yourComponentInputDataConfig = { demo: 'demo'};

      const modalUiConfig = {
        panelClass: 'default-modal',
        data: yourComponentInputDataConfig
      };
      return this.dialogService.open(modalUiConfig);
    }

      private setDialogCloseActions(creationEditionDialogRef: MatDialogRef<YourComponentToShowInDialogUi, number>): void {
      creationEditionDialogRef
        .afterClosed()
        .pipe(takeUntil(this.stopSubscriptionsNotifier))
        .subscribe({
          next: modalClosedResult => {
            if (modalClosedResult !== MAT_DIALOG_CLOSE_WITH_OK) {
              return;
            }
            // your component actions when dialog close with ok result
          }
        });
    }

    public ngOnDestroy(): void {
      this.stopSubscriptionsNotifier.next();
      this.stopSubscriptionsNotifier.complete();
    }