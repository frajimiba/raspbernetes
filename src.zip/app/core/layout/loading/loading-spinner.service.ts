import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LoadingService {
  private isLoading: boolean = false;

  public setLoadingState(isLoading: boolean): void {
    this.isLoading = isLoading;
  }

  public isAppLoading(): boolean {
    return this.isLoading;
  }
}
