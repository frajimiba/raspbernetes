import { KeycloakService } from 'keycloak-angular';

import { Injectable } from '@angular/core';

import { AuthService, FrontMenuEntry, MenuFrontService } from '../../../../app/core';
import { KeyCloakGroupService } from '../../../../app/shared/components/assignment-selector/shared';

export const DEFAULT_MENU_CONFIG = [];

@Injectable({
  providedIn: 'root'
})
export class HeaderService {
  constructor(
    private readonly authService: AuthService,
    private readonly keycloakGroupService: KeyCloakGroupService,
    private readonly menuFrontService: MenuFrontService
  ) {}

  public async getHeaderMenuConfiguration(): Promise<FrontMenuEntry[]> {
    console.log('HeaderService', 'getHeaderMenuConfiguration');

    return this.menuFrontService
      .getMenuFrontConfigurations()
      .then(menusFront => menusFront)
      .catch(error => {
        console.error(error);
        return [];
      });
  }

  public userHasRole(rol: string): boolean {
    return this.authService.hasRoleFromString(rol);
  }

  public userHasRoleAdminSre(): boolean {
    return this.authService.hasSomeRoleFromList(['admin', 'sre']);
  }

  public userHasRoleAdmin(): boolean {
    return this.authService.hasRole('admin');
  }

  public async logout(): Promise<void> {
    this.keycloakGroupService.clearUserData();
    this.authService.logout();
  }

  public async isLoggedIn(): Promise<boolean> {
    return this.authService
      .isLoggedIn()
      .then(isLoggedIn => isLoggedIn)
      .catch(error => {
        console.error('HeaderService', 'isLoggedIn', 'KO', error);
        return false;
      });
  }

  public async getUserName(): Promise<string> {
    return this.authService.getUserName();
  }
}
