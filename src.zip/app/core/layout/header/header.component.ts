import { Component, OnInit } from '@angular/core';

import { DEFAULT_USERNAME } from '../../auth/auth.service';
import { DEFAULT_MENU_CONFIG, HeaderService } from './header.service';

import { FrontMenuEntry } from '../../../../app/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  public userName: string = DEFAULT_USERNAME;
  public menusFront: FrontMenuEntry[] = DEFAULT_MENU_CONFIG;
  public isLoggedIn = false;

  constructor(public headerService: HeaderService) {}

  ngOnInit(): void {
    void this.initializeHeader();
  }

  public logout(): void {
    void this.headerService.logout();
  }

  private async initializeHeader(): Promise<void> {
    await this.getUserIsLoggedIn();
    if (this.isLoggedIn) {
      await this.getUserName();
      await this.getHeaderMenuConfiguration();
    }
  }

  private async getUserName(): Promise<void> {
    this.userName = await this.headerService.getUserName();
  }

  private async getHeaderMenuConfiguration(): Promise<void> {
    this.menusFront = await this.headerService.getHeaderMenuConfiguration();
  }

  private async getUserIsLoggedIn(): Promise<void> {
    this.isLoggedIn = await this.headerService.isLoggedIn();
  }
}
