import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { MatDialogModule } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { RouterModule } from '@angular/router';

import { FooterComponent } from './footer/footer.component';
import { HeaderComponent } from './header/header.component';
import { LoadingSpinnerComponent } from './loading/loading-spinner.component';

const DEPENDENCIES = [CommonModule, MatIconModule, MatDialogModule, RouterModule];
const DECLARATIONS = [LoadingSpinnerComponent, HeaderComponent, FooterComponent];

@NgModule({
  imports: DEPENDENCIES,
  declarations: DECLARATIONS,
  exports: [DECLARATIONS, DEPENDENCIES]
})
export class AppLayoutModule {}
