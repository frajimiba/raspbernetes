import { Component } from '@angular/core';

import { environment } from '../../../../environments/environment';
import { FooterItem } from './footer-item.model';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})
export class FooterComponent {
  public license = 'Copyright 2021 Viewnext :';
  public footerItems: FooterItem[];
  public version = environment.version;

  constructor() {
    this.initializeFooterLinks();
  }

  private initializeFooterLinks(): void {
    this.footerItems = [
      {
        url: '#',
        title: 'Aviso Legal'
      },
      {
        url: '#',
        title: 'Política de Privacidad'
      },
      {
        url: '#',
        title: 'Política de Cookies'
      }
    ];

    if (this.isSpaUrlForProduction()) {
      return;
    }
    this.footerItems.push({
      url: '/demo',
      title: 'UI Demo'
    });
  }

  private isSpaUrlForProduction(): boolean {
    return !document.URL.includes('localhost') && !document.URL.includes('spa-dev.appops');
  }
}
