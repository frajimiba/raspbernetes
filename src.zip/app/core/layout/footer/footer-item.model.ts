export interface FooterItem {
  url: string;
  title: string;
}
