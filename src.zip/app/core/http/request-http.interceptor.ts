/* eslint-disable @typescript-eslint/restrict-template-expressions */
import { Observable, TimeoutError } from 'rxjs';
import swal from 'sweetalert2';

import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Inject, Injectable, InjectionToken } from '@angular/core';
import { Router } from '@angular/router';

import { catchError, timeout } from 'rxjs/operators';

import { AuthService } from '../../../app/core';

export const DEFAULT_HTTP_TIMEOUT = new InjectionToken<number>('defaultHttpTimeout');
const HTTP_STATUS_401 = 401;
const HTTP_STATUS_403 = 403;
const HTTP_STATUS_404 = 404;
const HTTP_STATUS_500 = 500;

@Injectable()
export class RequestHttpInterceptor implements HttpInterceptor {
  constructor(
    private readonly authService: AuthService,
    private readonly router: Router,
    @Inject(DEFAULT_HTTP_TIMEOUT) protected defaultHttpTimeout: number
  ) {}

  public intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    const modified = req.clone({
      setHeaders: { 'X-Request-Timeout': `${this.defaultHttpTimeout}` }
    });

    return next.handle(req).pipe(
      timeout(this.defaultHttpTimeout),
      catchError(e => {
        this.processTimeout(e, req);
        throw new Error(e);
      })
    );
  }

  private processTimeout(e: any, req: HttpRequest<any>): void {
    if (e instanceof TimeoutError) {
      void swal.fire('Timeout el recuperar el recurso', `Resource: ${req.url}`, 'error');
    } else if (e.status === HTTP_STATUS_401) {
      this.checkAuthError(req);
    } else if (e.status === HTTP_STATUS_403) {
      void swal.fire(
        'Acceso denegado al recurso, enviando a home',
        `Status: ${e.status} - Text: ${e.statusText}`,
        'warning'
      );
      this.router.navigate(['/home']);
    } else if (e.status === HTTP_STATUS_404) {
      void swal.fire('Página no encontrada', `Status: ${e.status} - Text: ${e.statusText}`, 'warning');
      this.router.navigate(['/404']);
    } else if (e.status >= HTTP_STATUS_500) {
      void swal.fire('Error de servidor', `Status: ${e.status} - Text: ${e.statusText}`, 'error');
    } else {
      if (typeof e.status === 'number') {
        void swal.fire('Error desconocido', `Status: ${e.status} - Message: ${e.message}`, 'error');
      } else {
        void swal.fire('Error no controlado', `Message: ${e}`, 'error');
      }
    }
  }

  private async checkAuthError(req: HttpRequest<any>): Promise<void> {
    try {
      const isLogged = await this.authService.isLoggedIn();

      if (!isLogged) {
        this.authService.logout();
      }

      await this.router.navigate(['/home']);
      void swal.fire('Usuario sin permisos', `Resource: ${req.url}`, 'error');
    } catch (error) {
      console.error(error);
    }
  }
}
