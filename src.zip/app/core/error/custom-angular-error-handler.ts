import { ErrorHandler, Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CustomAngularErrorHandler implements ErrorHandler {
  /**
   * Centraliza la captura de errores no controlados del el software que hace el framework
   */
  public handleError(error): void {
    console.error('CustomAngularErrorHandler:', error);
  }
}
