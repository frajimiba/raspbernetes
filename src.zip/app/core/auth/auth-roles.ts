export type AuthRole = 'ftr' | 'sre' | 'dev' | 'admin' | 'auto' | 'operador';

export const ALL_AVAILABLE_ROLES: AuthRole[] = ['ftr', 'sre', 'dev', 'admin', 'auto', 'operador'];
