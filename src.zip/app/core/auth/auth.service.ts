import { KeycloakService } from 'keycloak-angular';
import { KeycloakProfile, KeycloakTokenParsed } from 'keycloak-js';

import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { AuthRole } from './auth-roles';

export const DEFAULT_USERNAME = '-';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  constructor(public readonly keycloakService: KeycloakService, private readonly http: HttpClient) {}

  public getLoggedUser(): KeycloakTokenParsed | undefined {
    try {
      const userDetails = this.keycloakService.getKeycloakInstance().idTokenParsed;
      return userDetails;
    } catch (e) {
      console.error('getLoggedUser Exception', e);
      return undefined;
    }
  }

  public getIdLoggedUser(): string {
    try {
      const userDetails = this.keycloakService.getKeycloakInstance().idTokenParsed;
      return String(userDetails?.preferred_username) ?? '';
    } catch (e) {
      console.error('getLoggedUser Exception', e);
      return '';
    }
  }

  public logout(): void {
    void this.keycloakService.logout();
  }

  public redirectToProfile(): void {
    void this.keycloakService.getKeycloakInstance().accountManagement();
  }

  public getSessionRoles(): string[] {
    return this.keycloakService.getUserRoles();
  }

  public async isLoggedIn(): Promise<boolean> {
    return this.keycloakService.isLoggedIn();
  }

  public hasSomeRoleFromList(roles: AuthRole[]): boolean {
    for (const rol of roles) {
      if (this.hasRole(rol)) {
        return true;
      }
    }
    return false;
  }

  public hasRoleFromString(role: string): boolean {
    const roles: AuthRole[] = role.split(',') as AuthRole[];

    let encontrado: boolean = false;
    roles.forEach(role => {
      if (this.hasRole(role)) {
        encontrado = true;
      }
    });
    return encontrado;
  }

  public hasRole(role: AuthRole): boolean {
    return this.getSessionRoles().some(sessionRole => sessionRole === role);
  }

  public async getUserName(): Promise<string> {
    try {
      const userDetails: any = this.keycloakService.getKeycloakInstance().idTokenParsed;
      // eslint-disable-next-line @typescript-eslint/restrict-template-expressions
      return `${userDetails.given_name ?? ''} ${userDetails.family_name ?? ''}`;
    } catch (error) {
      console.error(error);
      const userId = await this.getIdLoggedUser();
      return userId;
    }
  }
}
