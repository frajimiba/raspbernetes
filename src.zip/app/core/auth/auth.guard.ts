import { KeycloakAuthGuard, KeycloakService } from 'keycloak-angular';
import swal2 from 'sweetalert2';

import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Router, RouterStateSnapshot, UrlTree } from '@angular/router';

import { AppRouteIds } from '../routes';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard extends KeycloakAuthGuard {
  constructor(protected readonly router: Router, protected readonly keycloakAngular: KeycloakService) {
    super(router, keycloakAngular);
  }

  public async isAccessAllowed(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Promise<boolean | UrlTree> {
    if (!this.authenticated) {
      console.log('AuthGuard', 'isAccessAllowed', 'user not autheticated');
      await this.keycloakAngular.login();
    }

    const rolesWithGrantedAccessToRoute = (route.data.roles as string[]) ?? [];

    const roleHasAccessAllowed = rolesWithGrantedAccessToRoute.some(roleWithGrantedAccessToRoute =>
      this.roles.includes(roleWithGrantedAccessToRoute)
    );

    if (!roleHasAccessAllowed) {
      void swal2.fire(
        'Acceso denegado',
        'No tienes acceso a este recurso, se redirige a la página principal',
        'warning'
      );

      if (route?.routeConfig?.path !== AppRouteIds.home) {
        void this.router.navigate([AppRouteIds.home]);
      }
    }

    console.log(
      'AuthGuard',
      'isAccessAllowed',
      roleHasAccessAllowed,
      'roles with granted access to route',
      rolesWithGrantedAccessToRoute,
      'sessionRoles',
      this.roles
    );
    return Promise.resolve(roleHasAccessAllowed);
  }
}
