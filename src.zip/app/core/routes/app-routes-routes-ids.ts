/**
 * Identificadores de rutas principales de la aplicaicón
 */
export enum AppRouteIds {
  home = 'home',
  dashboard = 'dashboard',
  demo = 'demo',
  error = 'pagina-no-encontrada',
  error5xx = 'uups-pagina-no-disponible',
  error404 = '404',
  admin = 'admin',
  bookmarks = 'bookmarks',
  selfservice = 'self-service',
  issues = 'issues',
  procedures = 'procedures',
  feedbacks = 'feedbacks',
  aichat = 'ai-chat'
}

export type AppRouteId = `${AppRouteIds}`;
