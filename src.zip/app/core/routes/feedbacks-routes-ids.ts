/**
 * Identificadores de subrutas para la funcionalidad de '/feedbacks'
 */
export enum FeedbacksRoutesIds {
  creationEdition = 'creation-edition'
}

export type FeedbacksRouteId = `${FeedbacksRoutesIds}`;
