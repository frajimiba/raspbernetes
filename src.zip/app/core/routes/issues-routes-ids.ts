/**
 * Identificadores de subrutas para la funcionalidad de '/issues' Gestión de incidencias
 */
export enum IssuesRoutesIds {
  myIssues = 'my-issues',
  pendingIssues = 'pending-issues',
  myGroupIssues = 'my-groups-issues',
  issue = 'issue',
  creationEdition = 'creation-edition'
}

export type IssuesRouteId = `${IssuesRoutesIds}`;
