/**
 * Identificadores de subrutas para la funcionalidad de '/admin' Dashboard de administrador
 */
export enum AdminDashboardRoutesIds {
  home = 'home',
  bookmarksCategories = 'bookmarks-categories',
  bookmarksLinks = 'bookmarks-links',
  menusManagement = 'menus-management',
  submenusManagement = 'submenus-management',
  notificationsManagement = 'notifications-management',
  chatbotLiteralsManagement = 'chatbotliterals-management',
  dashboardManagement = 'dashboard-management',
  aiqueriesManagement = 'aiqueries-management',
  usersManagement = 'users-management',
  proceduresManagement = 'procedures-management'
}

export type AdminDashboardRouteId = `${AdminDashboardRoutesIds}`;
