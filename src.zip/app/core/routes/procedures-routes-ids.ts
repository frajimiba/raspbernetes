/**
 * Identificadores de subrutas para la funcionalidad de '/procedures' Procedimientos/Operativas
 */
export enum ProceduresRoutesIds {
  creationEdition = 'creation-edition'
}

export type ProceduresRouteId = `${ProceduresRoutesIds}`;
