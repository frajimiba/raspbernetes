import { Injectable } from '@angular/core';
import { Event, NavigationCancel, NavigationEnd, NavigationError, NavigationStart, Router } from '@angular/router';

import { LoadingService } from '../layout';

const LOG_TAG = 'RouterChangesInterceptorService';

@Injectable({
  providedIn: 'root'
})
export class RouterChangesInterceptorService {
  constructor(private readonly router: Router, private readonly loadingService: LoadingService) {}

  public initializeOnRouterChangeUi(): void {
    console.log(`${LOG_TAG}`, 'initializeOnRouterChangeUi');

    this.router.events.subscribe((event: Event) => {
      if (this.isRouterEventForEnableLoadingUi(event)) {
        this.loadingService.setLoadingState(true);
      } else if (this.isRouterEventForDisableLoadingUi(event)) {
        this.loadingService.setLoadingState(false);
      }
    });
  }

  private isRouterEventForDisableLoadingUi(event: Event): boolean {
    return event instanceof NavigationEnd || event instanceof NavigationCancel || event instanceof NavigationError;
  }

  private isRouterEventForEnableLoadingUi(event: Event): boolean {
    return event instanceof NavigationStart;
  }
}
