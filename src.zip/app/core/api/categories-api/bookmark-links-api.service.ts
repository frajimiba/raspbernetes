import { lastValueFrom } from 'rxjs';

import { Injectable } from '@angular/core';

import {
  AppopsXplplataformaV0AdminLinksPaginatedPost200Response,
  ClassificationsGroupsClientsEntry,
  LinkEntry,
  LinkResourceService
} from '../../../../app/core';
import { PaginatorModel } from '../../../../app/shared';

@Injectable({
  providedIn: 'root'
})
export class BookmarkLinkService {
  constructor(private readonly linkResourceService: LinkResourceService) {
    this.linkResourceService.configuration.basePath = '';
  }

  public async getAllLinks(
    paginatorModel: PaginatorModel,
    classificationsGroupsClientsEntry?: ClassificationsGroupsClientsEntry
  ): Promise<AppopsXplplataformaV0AdminLinksPaginatedPost200Response> {
    return lastValueFrom(
      this.linkResourceService.appopsXplplataformaV0AdminLinksPaginatedPost(
        paginatorModel.ascending,
        paginatorModel.pageIndex,
        paginatorModel.size,
        paginatorModel.sortCol,
        classificationsGroupsClientsEntry
      )
    )
      .then((pagedLinks: AppopsXplplataformaV0AdminLinksPaginatedPost200Response) => {
        if (!pagedLinks || !pagedLinks.content) {
          console.error('BookmarkLinkService getAllLinks OK error', 'error data', pagedLinks);
          throw new Error('Datos recibidos no válidos.');
        }
        return pagedLinks;
      })
      .catch(error => {
        console.error('BookmarkLinkService getAllLinks KO error', 'error data', error);
        throw new Error('Error al recuperar los enlaces de categoría.');
      });
  }

  public async deleteBookmarkLink(linkId: number): Promise<void> {
    return lastValueFrom(this.linkResourceService.appopsXplplataformaV0AdminLinksIdDelete(linkId))
      .then(response => {
        console.log('deleteBookmarkLink response', response);
        void Promise.resolve();
      })
      .catch(error => {
        console.error('BookmarkLinkService deleteCategory KO error', 'error data', error);
        throw new Error('Error al borrar el enlace de cateoría.');
      });
  }

  public async createBookmarkLink(linkEntry: any): Promise<void> {
    return lastValueFrom(this.linkResourceService.appopsXplplataformaV0AdminLinksPost(linkEntry))
      .then((link: LinkEntry) => {
        if (!link) {
          throw new Error('Ha habido un error al crear el nuevo enlace de categoría.');
        }
        void Promise.resolve();
      })
      .catch(error => {
        console.error('BookmarkLinkService createBookmarkLink KO error', 'error data', error);
        throw new Error('Error al crear el nuevo enlace de categoría.');
      });
  }

  public async updateBookmarkLink(linkId: number, linkEntry: any): Promise<void> {
    return lastValueFrom(this.linkResourceService.appopsXplplataformaV0AdminLinksIdPut(linkId, linkEntry))
      .then((link: LinkEntry) => {
        if (!link) {
          throw new Error('Ha habido un error al actualziar el nuevo enlace de categoría.');
        }
        void Promise.resolve();
      })
      .catch(error => {
        console.error('BookmarkLinkService updateBookmarkLink KO error', 'error data', error);
        throw new Error('Error al actualziar el nuevo enlace de categoría.');
      });
  }
}
