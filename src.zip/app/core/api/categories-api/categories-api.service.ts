import { lastValueFrom } from 'rxjs';

import { Injectable } from '@angular/core';

import {
  AppopsXplplataformaV0AdminLinksCategoriesPaginatedPost200Response,
  CategoryLinkEntry,
  CategoryLinkResourceService,
  ClassificationsGroupsClientsEntry
} from '../../../../app/core';
import { PaginatorModel } from '../../../../app/shared';

@Injectable({
  providedIn: 'root'
})
export class CategoryLinkService {
  constructor(private readonly categoryLinkResourceService: CategoryLinkResourceService) {
    this.categoryLinkResourceService.configuration.basePath = '';
  }

  public async getAllCategories(
    paginatorModel: PaginatorModel,
    classificationsGroupsClientsEntry: ClassificationsGroupsClientsEntry
  ): Promise<AppopsXplplataformaV0AdminLinksCategoriesPaginatedPost200Response> {
    return lastValueFrom(
      this.categoryLinkResourceService.appopsXplplataformaV0AdminLinksCategoriesPaginatedPost(
        paginatorModel.ascending,
        paginatorModel.pageIndex,
        paginatorModel.size,
        paginatorModel.sortCol,
        classificationsGroupsClientsEntry
      )
    )
      .then((pagedCategories: AppopsXplplataformaV0AdminLinksCategoriesPaginatedPost200Response) => {
        if (!pagedCategories || !pagedCategories.content) {
          console.error('CategoryLinkService getAllCategories OK error', 'error data', pagedCategories);
          throw new Error('Datos recibidos no válidos.');
        }
        return pagedCategories;
      })
      .catch(error => {
        console.error('CategoryLinkService getAllCategories KO error', 'error data', error);
        throw new Error('Error al recuperar las categorías favoritas.');
      });
  }

  public async deleteCategory(categoryId: number): Promise<void> {
    return lastValueFrom(this.categoryLinkResourceService.appopsXplplataformaV0AdminLinksCategoriesIdDelete(categoryId))
      .then(response => {
        console.log('deleteCategory response', { response });
        void Promise.resolve();
      })
      .catch(error => {
        console.error('CategoryLinkService deleteCategory KO error', 'error data', error);
        throw new Error('Error al crear la nueva categoría favorita.');
      });
  }

  public async createCategory(categoryLinkEntry: any): Promise<void> {
    return lastValueFrom(
      this.categoryLinkResourceService.appopsXplplataformaV0AdminLinksCategoriesPost(categoryLinkEntry)
    )
      .then((category: CategoryLinkEntry) => {
        if (!category) {
          throw new Error('Ha habido un error al crear la nueva catergoría.');
        }
        void Promise.resolve();
      })
      .catch(error => {
        console.error('CategoryLinkService createCategory KO error', 'error data', error);
        throw new Error('Error al crear la nueva categoría favorita.');
      });
  }

  public async updateCategory(categoryId: number, categoryLinkEntry: any): Promise<void> {
    return lastValueFrom(
      this.categoryLinkResourceService.appopsXplplataformaV0AdminLinksCategoriesIdPut(categoryId, categoryLinkEntry)
    )
      .then((category: CategoryLinkEntry) => {
        if (!category) {
          throw new Error('Ha habido un error al borrar la catergoría.');
        }
        void Promise.resolve();
      })
      .catch(error => {
        console.error('CategoryLinkService updateCategory KO error', 'error data', error);
        throw new Error('Error al borrar la categoría favorita.');
      });
  }
}
