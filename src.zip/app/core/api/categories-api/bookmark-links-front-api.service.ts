import { lastValueFrom } from 'rxjs';

import { Injectable } from '@angular/core';

import { FrontLinkEntry, FrontLinkResourceService, LinkEntry } from '../api-client-library';
import { validateApiResponse } from '../validate-api-response';

@Injectable({
  providedIn: 'root'
})
export class BookmarkLinksFrontService {
  constructor(private readonly frontLinkResourceService: FrontLinkResourceService) {
    this.frontLinkResourceService.configuration.basePath = '';
  }

  public async getAll(): Promise<LinkEntry[]> {
    return lastValueFrom(this.frontLinkResourceService.appopsXplplataformaV0FrontLinksGet())
      .then((linksFrontConfig: FrontLinkEntry[]) => validateApiResponse(linksFrontConfig))
      .catch(error => {
        console.error('BookmarkLinksFrontService getMenuFrontConfigurations KO error', 'error data', error);
        throw new Error('Error al recuperar la configuración de front-menus.');
      });
  }
}
