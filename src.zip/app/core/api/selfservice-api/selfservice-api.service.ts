import { lastValueFrom } from 'rxjs';

import { Injectable } from '@angular/core';

import { SelfServiceResourceService } from '../api-client-library';

@Injectable({
  providedIn: 'root'
})
export class SelfServiceApiService {
  constructor(private readonly selfServiceResourceService: SelfServiceResourceService) {
    this.selfServiceResourceService.configuration.basePath = '';
  }

  public async submitForm(id: number, jsonForm: string): Promise<number> {
    return lastValueFrom(
      this.selfServiceResourceService.appopsXplplataformaV0SelfServiceSubmitTemplateIdPost(id, jsonForm)
    ).catch(error => {
      console.error('SelfServiceApiService submitForm KO error', 'error data', error);
      throw new Error('Error al enviar formulario.');
    });
  }
}
