import { lastValueFrom } from 'rxjs';

import { Injectable } from '@angular/core';

import {
  ClassificationsGroupsClientsEntry,
  DashboardEntry,
  DashboardResourceService,
  PagedResultDashboardEntry
} from '../../../../app/core';
import { PaginatorModel } from '../../../../app/shared';

@Injectable({
  providedIn: 'root'
})
export class DashboardApiService {
  constructor(private readonly dashboardResourceService: DashboardResourceService) {
    this.dashboardResourceService.configuration.basePath = '';
  }

  public async getAllPages(
    paginatorModel: PaginatorModel,
    classificationsGroupsClientsEntry: ClassificationsGroupsClientsEntry
  ): Promise<PagedResultDashboardEntry> {
    return lastValueFrom(
      this.dashboardResourceService.appopsXplplataformaV0AdminDashboardPaginatedPost(
        paginatorModel.ascending,
        paginatorModel.pageIndex,
        paginatorModel.size,
        paginatorModel.sortCol,
        classificationsGroupsClientsEntry
      )
    )
      .then((paged: PagedResultDashboardEntry) => {
        if (!paged || !paged.content) {
          console.error('DashboardApiService getAllPages OK error', 'error data', paged);
          throw new Error('Datos recibidos no válidos.');
        }
        return paged;
      })
      .catch(error => {
        console.error('DashboardApiService getAllPages KO error', 'error data', error);
        throw new Error('Error al recuperar las páginas de dashboard.');
      });
  }

  public async deleteDashboardPage(categoryId: number): Promise<void> {
    return lastValueFrom(this.dashboardResourceService.appopsXplplataformaV0AdminDashboardIdDelete(categoryId))
      .then(response => {
        console.log('deleteDashboardPage response', { response });
        void Promise.resolve();
      })
      .catch(error => {
        console.error('DashboardApiService deleteDashboardPage KO error', 'error data', error);
        throw new Error('Error al crear la nueva categoría favorita.');
      });
  }

  public async createDashboardPage(dashboardEntry: any): Promise<void> {
    return lastValueFrom(this.dashboardResourceService.appopsXplplataformaV0AdminDashboardPost(dashboardEntry))
      .then((category: DashboardEntry) => {
        if (!category) {
          throw new Error('Ha habido un error al crear la nueva página de dashboard.');
        }
        void Promise.resolve();
      })
      .catch(error => {
        console.error('DashboardApiService createDashboardPage KO error', 'error data', error);
        throw new Error('Error al crear la nueva categoría favorita.');
      });
  }

  public async updateDashboardPage(categoryId: number, dashboardEntry: any): Promise<void> {
    return lastValueFrom(
      this.dashboardResourceService.appopsXplplataformaV0AdminDashboardIdPut(categoryId, dashboardEntry)
    )
      .then((category: DashboardEntry) => {
        if (!category) {
          throw new Error('Ha habido un error al borrar la página de dashboard.');
        }
        void Promise.resolve();
      })
      .catch(error => {
        console.error('DashboardApiService updateDashboardPage KO error', 'error data', error);
        throw new Error('Error al borrar la categoría favorita.');
      });
  }
}
