import { lastValueFrom, Observable } from 'rxjs';

import { Injectable } from '@angular/core';

import {
  KeycloakGroup,
  KeycloakGroupEntry,
  KeycloakGroupResourceService,
  KeycloakUserEntry,
  MassiveCustomerUsers
} from '../../../../app/core';
import { validateApiResponse } from '../validate-api-response';

@Injectable({
  providedIn: 'root'
})
export class KeycloakApiService {
  private rawGroupsList: KeycloakGroupEntry[] = [];
  private groupsMapList: Map<string, KeycloakGroupEntry>;

  constructor(private readonly keycloakGroupResourceService: KeycloakGroupResourceService) {
    this.keycloakGroupResourceService.configuration.basePath = '';
  }

  public getGroupsList(): KeycloakGroupEntry[] {
    return structuredClone(this.rawGroupsList);
  }

  public getMapGroupByName(groupName: string): KeycloakGroupEntry | null {
    if (!this.groupsMapList.has(groupName)) {
      console.error(
        'KeycloakApiService',
        ' getMapGroupByName',
        ' No hay datos en el objeto con esta clave: ',
        groupName
      );
      throw new Error(`No hay datos en el objeto con esta clave: ${groupName}`);
    }
    return this.groupsMapList.get(groupName) ?? null;
  }

  public async getAllGroups(key: string, value: KeycloakGroup): Promise<KeycloakGroupEntry[]> {
    return lastValueFrom(this.keycloakGroupResourceService.appopsXplplataformaV0AdminKeycloakGroupsGet(key, value))
      .then((keycloakGroupList: KeycloakGroupEntry[]) => validateApiResponse(keycloakGroupList))
      .then((keycloakGroupList: KeycloakGroupEntry[]) => this.validateKeycloakGroupEntry(keycloakGroupList))
      .catch(error => {
        console.error('KeycloakApiService getGroups KO error', 'error data', error);
        throw new Error('Error al recuperar los grupos.');
      });
  }

  public async getAuthUserGroups(
    key: string,
    value: KeycloakGroup,
    filterSubgroups: boolean
  ): Promise<KeycloakGroupEntry[]> {
    return lastValueFrom(
      this.keycloakGroupResourceService.appopsXplplataformaV0AdminKeycloakAuthUserGroupsGet(key, filterSubgroups, value)
    )
      .then((keycloakGroupList: KeycloakGroupEntry[]) => validateApiResponse(keycloakGroupList))
      .then((keycloakGroupList: KeycloakGroupEntry[]) => this.validateKeycloakGroupEntry(keycloakGroupList))
      .catch(error => {
        console.error('KeycloakApiService getAuthUserGroups KO error', 'error data', error);
        throw new Error('Error al recuperar los grupos del usuario.');
      });
  }

  public async getNamedGroup(name: string): Promise<KeycloakGroupEntry> {
    return lastValueFrom(this.keycloakGroupResourceService.appopsXplplataformaV0AdminKeycloakGroupGet(name))
      .then((keycloakGroupList: KeycloakGroupEntry) => validateApiResponse(keycloakGroupList))
      .catch(error => {
        console.error('KeycloakApiService getNamedGroup KO error', 'error data', error);
        throw new Error('Error al recuperar los grupos del usuario.');
      });
  }

  public async getUsersByGroup(id: string): Promise<KeycloakUserEntry[]> {
    return lastValueFrom(
      this.keycloakGroupResourceService.appopsXplplataformaV0AdminKeycloakGroupsIdMembersGet(id)
    ).catch(error => {
      console.error('KeycloakApiService getUsersByGroup KO error', 'error data', error);
      throw new Error('Error al recuperar los usuarios de un grupo.');
    });
  }

  public async getAllUsers(): Promise<KeycloakUserEntry[]> {
    return lastValueFrom(this.keycloakGroupResourceService.appopsXplplataformaV0AdminKeycloakUsersGet()).catch(
      error => {
        console.error('KeycloakApiService getAllUsers KO error', 'error data', error);
        throw new Error('Error al recuperar los usuarios de un grupo.');
      }
    );
  }

  public async postMassiveCustomerUsers(users: MassiveCustomerUsers): Promise<void> {
    return lastValueFrom(this.keycloakGroupResourceService.appopsXplplataformaV0AdminKeycloakMassivePost(users)).catch(
      error => {
        console.error('KeycloakApiService postMassiveCustomerUsers KO error', 'error data', error);
        throw new Error('Error al enviar los usuarios de un grupo.');
      }
    );
  }

  private validateKeycloakGroupEntry(keycloakGroupList: KeycloakGroupEntry[]): KeycloakGroupEntry[] {
    this.rawGroupsList = keycloakGroupList;
    this.mapKeycloakList(keycloakGroupList);
    return keycloakGroupList;
  }

  private mapKeycloakList(keycloakGroupList: KeycloakGroupEntry[]): void {
    this.groupsMapList = new Map<string, KeycloakGroupEntry>();
    keycloakGroupList.forEach(group => {
      if (group?.name) {
        this.groupsMapList.set(group.name, group);
      }
    });
  }
}
