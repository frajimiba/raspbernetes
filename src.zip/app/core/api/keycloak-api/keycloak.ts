export type KeycloakGroup = 'customer';
export type KeycloakSubgroup = 'buzonexterno' | 'classification';
