export interface KeycloakGroupModel {
  id: string;
  name: string;
  externalMailbox?: KeycloakGroupModel[];
  classification?: KeycloakGroupModel[];
}
