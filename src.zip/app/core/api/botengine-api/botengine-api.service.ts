import { lastValueFrom } from 'rxjs';

import { Injectable } from '@angular/core';

import { BotEngineResourceService } from './../api-client-library/api/botEngineResource.service';

import { ConversationEngineRequest } from '../api-client-library/model/conversationEngineRequest';
import { ConversationEngineResponse } from '../api-client-library/model/conversationEngineResponse';

@Injectable({
  providedIn: 'root'
})
export class BotEngineApiService {
  constructor(private readonly botEngineResourceService: BotEngineResourceService) {
    this.botEngineResourceService.configuration.basePath = '';
  }

  public async sendMessage(conversationEngineRequest?: ConversationEngineRequest): Promise<ConversationEngineResponse> {
    return Promise.resolve({
      output: {
        items: [
          {
            simpleResponse: {
              displayText: 'No puedo darle respuesta ahora mismo a su consulta'
            }
          }
        ]
      }
    });

    /*return lastValueFrom(
      this.botEngineResourceService.appopsXplplataformaV0BotengineSendPost(conversationEngineRequest)
    )
      .then((value: ConversationEngineResponse) => {
        if (!value) {
          console.error('BookmarkLinkService appopsXplplataformaV0BotengineSendPost OK error', 'error data', value);
          throw new Error('Datos recibidos no válidos.');
        }
        return value;
      })
      .catch(error => {
        console.error('BookmarkLinkService sendMessage KO error', 'error data', error);
        return {
          output: {
            items: [
              {
                simpleResponse: {
                  displayText: 'No puedo darle respuesta ahora mismo a su consulta'
                }
              }
            ]
          }
        };
        // throw new Error('Error al recuperar la respuesta a la conversación.');
      });*/
  }
}
