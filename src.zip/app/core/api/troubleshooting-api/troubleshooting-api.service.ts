import { lastValueFrom } from 'rxjs';

import { Injectable } from '@angular/core';

import { TroubleshootingEntry, TroubleshootingResourceService } from '../../../../app/core';
import { TroubleshootingDTO } from '../api-client-library/model/troubleshootingDTO';
import { validateApiResponse } from '../validate-api-response';

@Injectable({
  providedIn: 'root'
})
export class TroubleshootingApiService {
  constructor(private readonly troubleshootingResourceService: TroubleshootingResourceService) {
    this.troubleshootingResourceService.configuration.basePath = '';
  }

  public async getTroubleshootingsByIssueId(issueId: string): Promise<TroubleshootingDTO[]> {
    return lastValueFrom(
      this.troubleshootingResourceService.appopsXplplataformaV0TroubleshootingsIssueIdGet(issueId)
    ).catch(error => {
      console.error('TroubleshootingsService getTroubleshootingByName KO error', 'error data', error);
      throw new Error('Error al recuperar los troubleshootings.');
    });
  }

  public async addTroubleshooting(
    issueId: string,
    troublueshootingEntry: TroubleshootingEntry
  ): Promise<TroubleshootingDTO> {
    return lastValueFrom(
      this.troubleshootingResourceService.appopsXplplataformaV0TroubleshootingsIssueIdPost(
        issueId,
        troublueshootingEntry
      )
    )
      .then(data => validateApiResponse(data))
      .catch(error => {
        console.error('TroubleshootingsService addTroubleshooting KO error', 'error data', error);
        throw new Error(`Error al crear el troubleshooting.`);
      });
  }

  public async editTroubleshooting(
    issueId: string,
    id: number,
    troublueshootingEntry: TroubleshootingEntry
  ): Promise<TroubleshootingDTO> {
    return lastValueFrom(
      this.troubleshootingResourceService.appopsXplplataformaV0TroubleshootingsIssueIdTIdPut(
        issueId,
        id,
        troublueshootingEntry
      )
    )
      .then(data => validateApiResponse(data))
      .catch(error => {
        console.error('TroubleshootingsService editTroubleshooting KO error', 'error data', error);
        throw new Error(`Error al editar el troubleshooting id: ${id}`);
      });
  }

  public async deleteTroubleshooting(issueId: string, id: number): Promise<void> {
    return lastValueFrom(
      this.troubleshootingResourceService.appopsXplplataformaV0TroubleshootingsIssueIdTIdDelete(issueId, id)
    )
      .then(() => console.log('TroubleshootingsService deleteTroubleshooting OK'))
      .catch(error => {
        console.error('TroubleshootingsService exectuteTroubleshooting KO error', 'error data', error);
        throw new Error(`Error al borrar el procedimiento: ${id}.`);
      });
  }
}
