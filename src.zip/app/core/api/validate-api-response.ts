import { NO_VALID_DATA_RECEIVED } from '../utils';

export function validateApiResponse<T>(apiResponse: T): T {
  if (!apiResponse) {
    throw new Error(NO_VALID_DATA_RECEIVED);
  }
  return apiResponse;
}
