import { lastValueFrom } from 'rxjs';

import { Injectable } from '@angular/core';

import {
  ExecutionTemplateDTO,
  ExecutionTemplateEntry,
  ExecutionTemplateResourceService,
  PagedResultExecutionTemplateDTO,
  PagedResultLiteralDTO
} from '../api-client-library';

@Injectable({
  providedIn: 'root'
})
export class ExecutionTemplateApiService {
  constructor(private readonly executionTemplateApi: ExecutionTemplateResourceService) {
    this.executionTemplateApi.configuration.basePath = '';
  }

  public async getExecutionTemplates({
    page = 0,
    size = 1,
    sort = 'asc',
    ascending = false
  }: {
    page?: number;
    size?: number;
    sort?: string;
    ascending?: boolean;
  } = {}): Promise<PagedResultExecutionTemplateDTO> {
    return lastValueFrom(
      this.executionTemplateApi.appopsXplplataformaV0ExecutionTemplateGet(ascending, page, size, sort)
    ).catch(error => {
      console.error('ExecutionTemplateApiService getExecutionTemplates KO error', 'error data', error);
      throw new Error('Error al recuperar literals.');
    });
  }

  public async createExecutionTemplate(item: ExecutionTemplateEntry): Promise<ExecutionTemplateDTO> {
    return lastValueFrom(this.executionTemplateApi.appopsXplplataformaV0ExecutionTemplatePost(item)).catch(error => {
      console.error('ExecutionTemplateApiService createExecutionTemplate KO error', 'error data', error);
      throw new Error('Error al crear literal.');
    });
  }

  public async deleteExecutionTemplate(id: number): Promise<any> {
    return lastValueFrom(this.executionTemplateApi.appopsXplplataformaV0ExecutionTemplateIdPost(id)).catch(error => {
      console.error('ExecutionTemplateApiService deleteExecutionTemplate KO error', 'error data', error);
      throw new Error('Error al crear literal.');
    });
  }

  public async updateExecutionTemplate(id: number, item: ExecutionTemplateEntry): Promise<ExecutionTemplateDTO> {
    return lastValueFrom(this.executionTemplateApi.appopsXplplataformaV0ExecutionTemplateIdPut(id, item)).catch(
      error => {
        console.error('ExecutionTemplateApiService updateExecutionTemplate KO error', 'error data', error);
        throw new Error(`Error al actualizar: ${id ?? ''}.`);
      }
    );
  }
}
