import { lastValueFrom } from 'rxjs';

import { Injectable } from '@angular/core';

import {
  ExecutionDTO,
  ExecutionEntry,
  NO_VALID_DATA_RECEIVED,
  PagedResultExecutionDTO,
  PagedResultProcedureDTO,
  PagedResultProcedureRatingDTO,
  ProcedureDTO,
  ProcedureEntry,
  ProcedureResourceService
} from '../../../../app/core';
import { validateApiResponse } from '../validate-api-response';
import { ProcedureRatingDTO } from './../api-client-library/model/procedureRatingDTO';
import {
  DEFAULT_PROCEDURE_ID,
  GetByClasificationWithRatingsRequestConfig,
  GetProcedureExecutionsByIdRequestConfig,
  GetProcedureFeedbacksByIdRequestConfig
} from './procedures-api.config';

@Injectable({
  providedIn: 'root'
})
export class ProceduresApiService {
  constructor(private readonly procedureResourceService: ProcedureResourceService) {
    this.procedureResourceService.configuration.basePath = '';
  }

  public async getProcedureByClassificationName(classificationName: string): Promise<ProcedureDTO> {
    const page = 0;
    const size = 1;
    const sort = 'asc';
    const ascending = false;

    return lastValueFrom(
      this.procedureResourceService.appopsXplplataformaV0ProceduresByClassificationsPost(ascending, page, size, sort, [
        classificationName
      ])
    )
      .then(procedurePage => validateApiResponse<PagedResultProcedureDTO>(procedurePage))
      .then(procedurePage => this.validateProcedureFromPage(procedurePage))
      .then(procedurePage => this.mapFirstProcedure(procedurePage.list as ProcedureDTO[]))
      .catch(error => {
        console.error('ProceduresService getProcedureByName KO error', 'error data', error);
        throw new Error('Error al recuperar el procedimiento.');
      });
  }

  public async getByClassificationsWithRaitings(
    config: GetByClasificationWithRatingsRequestConfig
  ): Promise<PagedResultProcedureRatingDTO> {
    return lastValueFrom(
      this.procedureResourceService.appopsXplplataformaV0ProceduresProceduresByClassificationWithRatingPost(
        config.ascending,
        config.page,
        config.size,
        config.sort,
        config.classifications
      )
    );
  }

  public async addProcedure(procedure: ProcedureEntry): Promise<ProcedureDTO> {
    return lastValueFrom(this.procedureResourceService.appopsXplplataformaV0ProceduresPost(procedure))
      .then(data => validateApiResponse(data))
      .catch(error => {
        console.error('ProceduresService addProcedure KO error', 'error data', error);
        throw new Error(`Error al crear el procedimiento: ${procedure?.title ?? '-'}.`);
      });
  }

  public async editProcedure(id: number, procedureEntry: ProcedureEntry): Promise<ProcedureDTO> {
    return lastValueFrom(
      this.procedureResourceService.appopsXplplataformaV0ProceduresProcedureIdPut(id, procedureEntry)
    )
      .then(data => validateApiResponse(data))
      .catch(error => {
        console.error('ProceduresService editProcedure KO error', 'error data', error);
        throw new Error(`Error al editar el procedimiento id: ${id} title: ${procedureEntry?.title ?? '-'}`);
      });
  }

  public async deleteProcedure(procedure: ProcedureRatingDTO): Promise<void> {
    const procedureId = procedure.id ?? DEFAULT_PROCEDURE_ID;

    return lastValueFrom(this.procedureResourceService.appopsXplplataformaV0ProceduresProcedureIdPost(procedureId))
      .then(() => console.log('ProceduresService deleteProcedure OK'))
      .catch(error => {
        console.error('ProceduresService exectuteProcedure KO error', 'error data', error);
        throw new Error(`Error al borrar el procedimiento: ${procedureId}.`);
      });
  }

  public async getProcedureRatingById(id: number): Promise<number> {
    return lastValueFrom(this.procedureResourceService.appopsXplplataformaV0ProceduresIdRatingGet(id)).catch(error => {
      console.error('ProceduresService getProcedureRatingById KO error', 'error data', error);
      throw new Error(`Error al obtener la valoración del procedimiento: ${id}.`);
    });
  }

  public async executeProcedure(id: number, executionEntry: ExecutionEntry): Promise<string> {
    return lastValueFrom(
      this.procedureResourceService.appopsXplplataformaV0ProceduresIdRundeckExecutePost(id, executionEntry)
    )
      .then(executionIssueProcedure => validateApiResponse<ExecutionDTO>(executionIssueProcedure))
      .then((url: ExecutionDTO) => url.urlJob ?? '')
      .catch(error => {
        console.error('ProceduresService exectuteProcedure KO error', 'error data', error);
        throw new Error('Error al ejecutar el procedimiento de resolución de una issue.');
      });
  }

  public async finishExecution(id: number, executionEntry: ExecutionEntry): Promise<ExecutionDTO> {
    return lastValueFrom(
      this.procedureResourceService.appopsXplplataformaV0ProceduresIdFinishExecutionPost(id, executionEntry)
    )
      .then(executionIssueProcedure => validateApiResponse<ExecutionDTO>(executionIssueProcedure))
      .catch(error => {
        console.error('ProceduresService finishExecution KO error', 'error data', error);
        throw new Error('Error al ejecutar la finalización de la resolución de una issue.');
      });
  }

  public async getProcedureExecutionsById(
    config: GetProcedureExecutionsByIdRequestConfig
  ): Promise<PagedResultExecutionDTO> {
    return lastValueFrom(
      this.procedureResourceService.appopsXplplataformaV0ProceduresIdExecutionsGet(
        config.procedureId,
        config.ascending,
        config.page,
        config.size,
        config.sort
      )
    )
      .then(executionResultPage => validateApiResponse<PagedResultExecutionDTO>(executionResultPage))
      .catch(error => {
        console.error('ProceduresService getProcedureExecutionsById KO error', 'error data', error);
        throw new Error('Error aobtener las ejecuciones de procedimiento por id de procedimiento - operativa.');
      });
  }

  public async getProcedureFeedbacksById(
    config: GetProcedureFeedbacksByIdRequestConfig
  ): Promise<PagedResultExecutionDTO> {
    return lastValueFrom(
      this.procedureResourceService.appopsXplplataformaV0ProceduresProcedureIdFeedbacksGet(
        config.procedureId,
        config.ascending,
        config.page,
        config.size,
        config.sort
      )
    )
      .then(executionResultPage => validateApiResponse<PagedResultExecutionDTO>(executionResultPage))
      .catch(error => {
        console.error('ProceduresService getProcedureFeedbacksById KO error', 'error data', error);
        throw new Error('Error aobtener los feedbacks por id de procedimiento - operativa.');
      });
  }

  private validateProcedureFromPage(frontMenuConfigurations: PagedResultProcedureDTO): PagedResultProcedureDTO {
    if (!frontMenuConfigurations?.list) {
      throw new Error(NO_VALID_DATA_RECEIVED + 'frontMenuConfigurations.list null');
    }
    return frontMenuConfigurations;
  }

  private mapFirstProcedure(proceduresInPage: ProcedureDTO[]): ProcedureDTO {
    const emptyProcedureList = 0;
    if (proceduresInPage.length <= emptyProcedureList) {
      throw new Error(NO_VALID_DATA_RECEIVED + 'frontMenuConfigurations.list null');
    }
    return proceduresInPage[emptyProcedureList];
  }
}
