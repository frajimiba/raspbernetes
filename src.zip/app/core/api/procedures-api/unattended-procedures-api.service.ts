import { lastValueFrom } from 'rxjs';

import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { validateApiResponse } from '../validate-api-response';
import { UnattendedProceduresConfig } from './unattended-procedures-api.config';

@Injectable({
  providedIn: 'root'
})
export class UnattendedProceduresApiService {
  constructor(private readonly http: HttpClient) {}

  public async getUnnatendedPrcedure(urlUnattendedProcedure: string): Promise<string> {
    return lastValueFrom(this.http.get(`${urlUnattendedProcedure}`))
      .then((config: UnattendedProceduresConfig) => validateApiResponse<UnattendedProceduresConfig>(config))
      .then((config: UnattendedProceduresConfig) => this.validateUrlFromResponse(config))
      .catch(error => {
        console.error('UnattendedProceduresApiService getUnnatendedPrcedure KO error', 'error data', error);
        throw new Error(`Error al obtener el enlace del procedimiento desde: ${urlUnattendedProcedure}.`);
      });
  }

  private validateUrlFromResponse(config: UnattendedProceduresConfig): string {
    return '';
  }
}
