export interface UnattendedProceduresConfig {
  task: {
    url: string;
  };
}
