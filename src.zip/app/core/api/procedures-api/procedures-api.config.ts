export const DEFAULT_PROCEDURE_ID = -1;

export interface GetByClasificationWithRatingsRequestConfig {
  classifications: string[];
  page: number;
  size: number;
  sort?: string;
  ascending?: boolean;
}

export interface GetProcedureFeedbacksByIdRequestConfig {
  procedureId: number;
  page: number;
  size: number;
  sort?: string;
  ascending?: boolean;
}

export interface GetProcedureExecutionsByIdRequestConfig {
  procedureId: number;
  page: number;
  size: number;
  sort?: string;
  ascending?: boolean;
}
