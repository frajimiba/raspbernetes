import { lastValueFrom } from 'rxjs';

import { Injectable } from '@angular/core';

import { ElasticSearchResourceService, SeekerElasticDTO } from '../api-client-library';

@Injectable({
  providedIn: 'root'
})
export class ElasticSearchApiService {
  constructor(private readonly elasticSearchResourceService: ElasticSearchResourceService) {
    this.elasticSearchResourceService.configuration.basePath = '';
  }

  public async getRelatedTickets(query: string): Promise<SeekerElasticDTO> {
    return lastValueFrom(this.elasticSearchResourceService.appopsXplplataformaV0ElasticsearchSearchPost(query)).catch(
      error => {
        console.error('ElasticSearchApiService getRelatedTickets KO error', 'error data', error);
        throw new Error('Error al recuperar literals.');
      }
    );
  }
}
