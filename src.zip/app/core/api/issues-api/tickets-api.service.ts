import { lastValueFrom } from 'rxjs';

import { Injectable } from '@angular/core';

import { OutputTicketData, TicketDTO, TicketEntry, TicketResourceService } from '../../../../app/core';
import { validateApiResponse } from '../validate-api-response';

@Injectable({
  providedIn: 'root'
})
export class TicketsApiService {
  constructor(private readonly ticketResourceService: TicketResourceService) {
    this.ticketResourceService.configuration.basePath = '';
  }

  public async getTicketDetailsByIssueId(issueId: string): Promise<OutputTicketData> {
    return lastValueFrom(this.ticketResourceService.appopsXplplataformaV0TicketsTicketIdNotesGet(issueId))
      .then(ticketDetails => validateApiResponse<OutputTicketData>(ticketDetails))
      .catch(error => {
        console.error('TicketsService getTicketDetailsByIssueId KO error', 'error data', error);
        throw new Error('Error al recuperar el detalle de ticket.');
      });
  }

  public async createOrUpdateIssueTicket(classify: boolean, ticketEntry: TicketEntry): Promise<TicketDTO> {
    return lastValueFrom(this.ticketResourceService.appopsXplplataformaV0TicketsTicketPost(classify, ticketEntry))
      .then(ticketDetails => validateApiResponse<TicketDTO>(ticketDetails))
      .catch(error => {
        console.error('TicketsService createIssueTicket KO error', 'error data', error);
        throw new Error('Error en la creación de un nuevo ticket para una issue.');
      });
  }
}
