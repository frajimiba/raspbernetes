import { FullIssueEntry } from '../api-client-library';

interface IssuesCommon {
  page: number;
  size: number;
  sortCol: string;
  ascending: boolean;
}

export interface IssuesApiModel extends IssuesCommon {
  fullIssueEntry: FullIssueEntry;
}
