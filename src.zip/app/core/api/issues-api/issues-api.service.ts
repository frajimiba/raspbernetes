import { lastValueFrom } from 'rxjs';

import { Injectable } from '@angular/core';

import {
  AssignamentDTO,
  AssignmentEntry,
  AssignmentsResourceService,
  AuthService,
  ClassificationResourceService,
  ExecutionDTO,
  FullIssueViewDTO,
  IssueResourceService,
  ManualClassificationEntry,
  PagedResultFullIssueViewDTO,
  StatusesResourceService,
  StatusTrackingDTO
} from '../../../../app/core';
import { validateApiResponse } from '../validate-api-response';
import { IssuesApiModel } from './issues.model';

@Injectable({
  providedIn: 'root'
})
export class IssuesApiService {
  constructor(
    private readonly authService: AuthService,
    private readonly issueResourceService: IssueResourceService,
    private readonly assignmentsResourceService: AssignmentsResourceService,
    private readonly classificationResourceService: ClassificationResourceService,
    private readonly statusesResourceService: StatusesResourceService
  ) {
    this.issueResourceService.configuration.basePath = '';
    this.assignmentsResourceService.configuration.basePath = '';
    this.classificationResourceService.configuration.basePath = '';
    this.statusesResourceService.configuration.basePath = '';
  }

  public async getAssignaments(issueId: string): Promise<AssignamentDTO[]> {
    return lastValueFrom(this.issueResourceService.appopsXplplataformaV0IssuesIssueIdAssignamentsGet(issueId))
      .then((items: AssignamentDTO[]) => validateApiResponse<AssignamentDTO[]>(items))
      .catch(error => {
        console.error('IssuesService getIssuesAmout KO error', 'error data', error);
        throw new Error('Error al obtener el numero total de issues');
      });
  }

  public async getStatuses(issueId: string): Promise<StatusTrackingDTO[]> {
    return lastValueFrom(this.issueResourceService.appopsXplplataformaV0IssuesIssueIdStatusesGet(issueId))
      .then((items: StatusTrackingDTO[]) => validateApiResponse<StatusTrackingDTO[]>(items))
      .catch(error => {
        console.error('IssuesService getIssuesAmout KO error', 'error data', error);
        throw new Error('Error al obtener el numero total de issues');
      });
  }

  public async getIssuesAmout(statuses: string[]): Promise<number> {
    return lastValueFrom(this.issueResourceService.appopsXplplataformaV0IssuesAmountPost(statuses))
      .then((numberOfIssues: number) => validateApiResponse<number>(numberOfIssues))
      .catch(error => {
        console.error('IssuesService getIssuesAmout KO error', 'error data', error);
        throw new Error('Error al obtener el numero total de issues');
      });
  }

  public async getIssuesExecutions(issueId: string): Promise<ExecutionDTO[]> {
    return lastValueFrom(this.issueResourceService.appopsXplplataformaV0IssuesIssueIdExecutionsGet(issueId))
      .then((issue: ExecutionDTO[]) => validateApiResponse<ExecutionDTO[]>(issue))
      .catch(error => {
        console.error('IssuesService getIssuesExecutions KO error', 'error data', error);
        throw new Error('Error al recuperar las ejecuciones de una issue resuelta');
      });
  }

  public async getMyAssignedIssues(ownedIssuesApiModel: IssuesApiModel): Promise<PagedResultFullIssueViewDTO> {
    return lastValueFrom(
      this.issueResourceService.appopsXplplataformaV0IssuesOwnedPost(
        ownedIssuesApiModel.ascending,
        ownedIssuesApiModel.page,
        ownedIssuesApiModel.size,
        ownedIssuesApiModel.sortCol,
        ownedIssuesApiModel.fullIssueEntry
      )
    )
      .then((issues: PagedResultFullIssueViewDTO) => validateApiResponse<PagedResultFullIssueViewDTO>(issues))
      .catch(error => {
        console.error('IssuesService getMyAssignedIssues KO error', 'error data', error);
        throw new Error('Error al recuperar las issues asignadas del usuario.');
      });
  }

  public async getIssuesByGroupsClassifications(issuesApiModel: IssuesApiModel): Promise<PagedResultFullIssueViewDTO> {
    return lastValueFrom(
      this.issueResourceService.appopsXplplataformaV0IssuesAdminGroupsPost(
        issuesApiModel.ascending,
        issuesApiModel.page,
        issuesApiModel.size,
        issuesApiModel.sortCol,
        issuesApiModel.fullIssueEntry
      )
    )
      .then((issues: PagedResultFullIssueViewDTO) => validateApiResponse<PagedResultFullIssueViewDTO>(issues))
      .catch(error => {
        console.error('IssuesService getIssuesByGroupsClassifications KO error', 'error data', error);
        throw new Error('Error al recuperar las issues por grupos y clasificaciones');
      });
  }

  public async getPendingIssuesByGroupsClassifications(
    pendingIssuesApiModel: IssuesApiModel
  ): Promise<PagedResultFullIssueViewDTO> {
    return lastValueFrom(
      this.issueResourceService.appopsXplplataformaV0IssuesPendingPost(
        pendingIssuesApiModel.ascending,
        pendingIssuesApiModel.page,
        pendingIssuesApiModel.size,
        pendingIssuesApiModel.sortCol,
        pendingIssuesApiModel.fullIssueEntry
      )
    )
      .then((issues: PagedResultFullIssueViewDTO) => validateApiResponse<PagedResultFullIssueViewDTO>(issues))
      .catch(error => {
        console.error('IssuesService getPendingIssuesByGroupsClassifications KO error', 'error data', error);
        throw new Error('Error al recuperar las issues pendientes del usuario');
      });
  }

  public async getMyGroupsIssues(issuesApiModel: IssuesApiModel): Promise<PagedResultFullIssueViewDTO> {
    return lastValueFrom(
      this.issueResourceService.appopsXplplataformaV0IssuesGroupsPost(
        issuesApiModel.ascending,
        issuesApiModel.page,
        issuesApiModel.size,
        issuesApiModel.sortCol,
        issuesApiModel.fullIssueEntry
      )
    )
      .then((issues: PagedResultFullIssueViewDTO) => validateApiResponse<PagedResultFullIssueViewDTO>(issues))
      .catch(error => {
        console.error('IssuesService getMyGroupsIssues KO error', 'error data', error);
        throw new Error('Error al recuperar las issues asignadas a los grupos del usuario');
      });
  }

  public async getIssueById(issueId: string): Promise<FullIssueViewDTO> {
    return lastValueFrom(this.issueResourceService.appopsXplplataformaV0IssuesIssueIdGet(issueId))
      .then((issue: FullIssueViewDTO) => validateApiResponse<FullIssueViewDTO>(issue))
      .catch(error => {
        console.error('IssuesService getIssueById KO error', 'error data', error);
        throw new Error('Error al recuperar una issue a partir de su identificador');
      });
  }

  public async assignIssue(issueId: string, user: string, groupName: string): Promise<AssignamentDTO> {
    const assignmentEntry: AssignmentEntry = {
      userName: user,
      groupName,
      text: ''
    };
    return lastValueFrom(
      this.assignmentsResourceService.appopsXplplataformaV0AssignmentsAssignIssueIdPost(issueId, assignmentEntry)
    )
      .then((assignedIssue: AssignamentDTO) => validateApiResponse<AssignamentDTO>(assignedIssue))
      .catch(error => {
        console.error('IssuesService assignIssue KO error', 'error data', error);
        throw new Error('Error al asignar una issue a un usuario');
      });
  }

  public async classifyIssue(id: string, classificationName: string): Promise<void> {
    const idUser = this.authService.getIdLoggedUser();
    const manualClassificationEntry: ManualClassificationEntry = {
      classification: classificationName,
      userName: idUser
    };

    return lastValueFrom(
      this.classificationResourceService.appopsXplplataformaV0ClassificationManualClassifyIssueIdPost(
        id,
        manualClassificationEntry
      )
    )
      .then(async () => Promise.resolve())
      .catch(error => {
        console.error('IssuesService classifyIssue KO error', 'error data', error);
        throw new Error('Error al clasificar una issue');
      });
  }

  public async assignIssueStatus(issueId: string, status: string): Promise<StatusTrackingDTO> {
    return lastValueFrom(this.statusesResourceService.appopsXplplataformaV0StatusesStatusIssueIdPost(issueId, status))
      .then((statusTrackingDTO: StatusTrackingDTO) => validateApiResponse<StatusTrackingDTO>(statusTrackingDTO))
      .catch(error => {
        console.error('IssuesService assignIssueStatus KO error', 'error data', error);
        throw new Error('Error al asignar un nuevo estado a una issue');
      });
  }
}
