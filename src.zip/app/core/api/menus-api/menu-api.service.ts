import { lastValueFrom } from 'rxjs';

import { Injectable } from '@angular/core';

import {
  AppopsXplplataformaV0AdminMenusPaginatedPost200Response,
  ClassificationsGroupsClientsEntry,
  MenuEntry,
  MenuResourceService
} from '../../../../app/core';
import { validateApiResponse } from '../validate-api-response';

@Injectable({
  providedIn: 'root'
})
export class MenuService {
  constructor(private readonly menuResourceService: MenuResourceService) {
    this.menuResourceService.configuration.basePath = '';
  }

  public async getMenuConfigurations(
    ascending: boolean,
    page: number,
    size: number,
    sort: string,
    classificationsGroupsClientsEntry: ClassificationsGroupsClientsEntry
  ): Promise<AppopsXplplataformaV0AdminMenusPaginatedPost200Response> {
    return lastValueFrom(
      this.menuResourceService.appopsXplplataformaV0AdminMenusPaginatedPost(
        ascending,
        page,
        size,
        sort,
        classificationsGroupsClientsEntry
      )
    )
      .then((menusConfiguration: AppopsXplplataformaV0AdminMenusPaginatedPost200Response) =>
        validateApiResponse(menusConfiguration)
      )
      .catch(error => {
        console.error('MenuService getMenuConfigurations KO error', 'error data', error);
        throw new Error('Error al recuperar la configuración de menus.');
      });
  }

  public async deleteMenuConfigurationById(menuConfigurationId: number): Promise<void> {
    return lastValueFrom(this.menuResourceService.appopsXplplataformaV0AdminMenusIdDelete(menuConfigurationId))
      .then(async () => Promise.resolve())
      .catch(error => {
        console.error('MenuService deleteMenuConfigurationById KO error', 'error data', error);
        throw new Error(`Error al borrar la configuración de menu: ${menuConfigurationId}`);
      });
  }

  public async updateMenuConfigurationById(menuConfigurationId: number, updatedMenuConfig: MenuEntry): Promise<void> {
    return lastValueFrom(
      this.menuResourceService.appopsXplplataformaV0AdminMenusIdPut(menuConfigurationId, updatedMenuConfig)
    )
      .then(async () => Promise.resolve())
      .catch(error => {
        console.error('MenuService updateMenuConfigurationById KO error', 'error data', error);
        throw new Error(`Error al actualizar la configuración de menu: ${menuConfigurationId}`);
      });
  }

  public async createMenuConfiguration(newMenuConfig: MenuEntry): Promise<void> {
    return lastValueFrom(this.menuResourceService.appopsXplplataformaV0AdminMenusPost(newMenuConfig))
      .then(async () => Promise.resolve())
      .catch(error => {
        console.error('MenuService createMenuConfiguration KO error', 'error data', error);
        throw new Error(`Error al crear la configuración de menu`);
      });
  }
}
