import { lastValueFrom } from 'rxjs';

import { Injectable } from '@angular/core';

import { FrontMenuEntry, FrontMenuResourceService } from '../../../../app/core';
import '../../utils';
import { validateApiResponse } from '../validate-api-response';

@Injectable({
  providedIn: 'root'
})
export class MenuFrontService {
  constructor(private readonly frontMenuResourceService: FrontMenuResourceService) {
    this.frontMenuResourceService.configuration.basePath = '';
  }

  public async getMenuFrontConfigurations(): Promise<FrontMenuEntry[]> {
    return lastValueFrom(this.frontMenuResourceService.appopsXplplataformaV0FrontMenusGet())
      .then((frontMenuConfigs: FrontMenuEntry[]) => validateApiResponse(frontMenuConfigs))
      .catch(error => {
        console.error('MenuFrontService getMenuFrontConfigurations KO error', 'error data', error);
        throw new Error('Error al recuperar la configuración de front-menus.');
      });
  }
}
