import { lastValueFrom } from 'rxjs';

import { Injectable } from '@angular/core';

import {
  AppopsXplplataformaV0AdminSubmenusPaginatedPost200Response,
  ClassificationsGroupsClientsEntry,
  SubmenuEntry,
  SubmenuResourceService
} from '../../../../app/core';
import { validateApiResponse } from '../validate-api-response';

@Injectable({
  providedIn: 'root'
})
export class SubmenuService {
  constructor(private readonly submenuResourceService: SubmenuResourceService) {
    this.submenuResourceService.configuration.basePath = '';
  }

  public async getSubMenusConfigurations(
    ascending: boolean,
    page: number,
    size: number,
    sort: string,
    classificationsGroupsClientsEntry: ClassificationsGroupsClientsEntry
  ): Promise<AppopsXplplataformaV0AdminSubmenusPaginatedPost200Response> {
    return lastValueFrom(
      this.submenuResourceService.appopsXplplataformaV0AdminSubmenusPaginatedPost(
        ascending,
        page,
        size,
        sort,
        classificationsGroupsClientsEntry
      )
    )
      .then((menusConfiguration: AppopsXplplataformaV0AdminSubmenusPaginatedPost200Response) =>
        validateApiResponse(menusConfiguration)
      )
      .catch(error => {
        console.error('SubmenuService getSubMenusConfigurations KO error', 'error data', error);
        throw new Error('Error al recuperar la configuración de submenús.');
      });
  }

  public async deleteSubMenuConfigurationById(subMenuConfigurationId: number): Promise<void> {
    return lastValueFrom(this.submenuResourceService.appopsXplplataformaV0AdminSubmenusIdDelete(subMenuConfigurationId))
      .then(async () => Promise.resolve())
      .catch(error => {
        console.error('SubmenuService deleteSubMenuConfigurationById KO error', 'error data', error);
        throw new Error(`Error al borrar la configuración de submenú: ${subMenuConfigurationId}`);
      });
  }

  public async updateSubMenuConfigurationById(
    subMenuConfigurationId: number,
    updatedSubMenuConfig: SubmenuEntry
  ): Promise<void> {
    return lastValueFrom(
      this.submenuResourceService.appopsXplplataformaV0AdminSubmenusIdPut(subMenuConfigurationId, updatedSubMenuConfig)
    )
      .then(async () => Promise.resolve())
      .catch(error => {
        console.error('SubmenuService updateSubMenuConfigurationById KO error', 'error data', error);
        throw new Error(`Error al actualizar la configuración de submenú: ${subMenuConfigurationId}`);
      });
  }

  public async createSubMenuConfiguration(newSubMenuConfig: SubmenuEntry): Promise<void> {
    return lastValueFrom(this.submenuResourceService.appopsXplplataformaV0AdminSubmenusPost(newSubMenuConfig))
      .then(async () => Promise.resolve())
      .catch(error => {
        console.error('SubmenuService createSubMenuConfiguration KO error', 'error data', error);
        throw new Error(`Error al crear la configuración de submenú`);
      });
  }
}
