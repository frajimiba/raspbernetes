import { lastValueFrom } from 'rxjs';

import { Injectable } from '@angular/core';

import { ChatRequest, CompletionsCreate200Response, OpenAIResourceService } from '../api-client-library';

@Injectable({
  providedIn: 'root'
})
export class OpenAIApiService {
  constructor(private readonly openAIResourceService: OpenAIResourceService) {
    this.openAIResourceService.configuration.basePath = '';
  }

  public async sendMessage(conversationEngineRequest?: ChatRequest): Promise<CompletionsCreate200Response> {
    return lastValueFrom(this.openAIResourceService.appopsXplplataformaV0OpenaiSendPost(conversationEngineRequest))
      .then((value: CompletionsCreate200Response) => {
        if (!value) {
          console.error('OpenAIApiService appopsXplplataformaV0BotengineSendPost OK error', 'error data', value);
          throw new Error('Datos recibidos no válidos.');
        }
        return value;
      })
      .catch(error => {
        console.error('OpenAIApiService sendMessage KO error', 'error data', error);
        throw new Error('Error al recuperar la respuesta a la conversación.');
      });
  }
}
