import { HttpClient } from '@angular/common/http';
import { ModuleWithProviders, NgModule, Optional, SkipSelf } from '@angular/core';

import { AssignmentsResourceService } from './api/assignmentsResource.service';
import { BotEngineResourceService } from './api/botEngineResource.service';
import { CategoryLinkResourceService } from './api/categoryLinkResource.service';
import { ClassificationResourceService } from './api/classificationResource.service';
import { DashboardResourceService } from './api/dashboardResource.service';
import { ElasticSearchResourceService } from './api/elasticSearchResource.service';
import { ExecutionResourceService } from './api/executionResource.service';
import { ExecutionTemplateResourceService } from './api/executionTemplateResource.service';
import { FeedbackResourceService } from './api/feedbackResource.service';
import { FrontLinkResourceService } from './api/frontLinkResource.service';
import { FrontMenuResourceService } from './api/frontMenuResource.service';
import { GiteaResourceService } from './api/giteaResource.service';
import { IssueResourceService } from './api/issueResource.service';
import { KeycloakGroupResourceService } from './api/keycloakGroupResource.service';
import { LinkResourceService } from './api/linkResource.service';
import { LiteralsResourceService } from './api/literalsResource.service';
import { MenuResourceService } from './api/menuResource.service';
import { MessageResourceService } from './api/messageResource.service';
import { NotificationTypeResourceService } from './api/notificationTypeResource.service';
import { OpenAIResourceService } from './api/openAIResource.service';
import { ProcedureResourceService } from './api/procedureResource.service';
import { SelfServiceResourceService } from './api/selfServiceResource.service';
import { StatusesResourceService } from './api/statusesResource.service';
import { SubmenuResourceService } from './api/submenuResource.service';
import { TicketResourceService } from './api/ticketResource.service';
import { TimeChannelResourceService } from './api/timeChannelResource.service';
import { TroubleshootingResourceService } from './api/troubleshootingResource.service';

import { Configuration } from './configuration';

@NgModule({
  imports: [],
  declarations: [],
  exports: [],
  providers: []
})
export class ApiModule {
  public static forRoot(configurationFactory: () => Configuration): ModuleWithProviders<ApiModule> {
    return {
      ngModule: ApiModule,
      providers: [{ provide: Configuration, useFactory: configurationFactory }]
    };
  }

  constructor(@Optional() @SkipSelf() parentModule: ApiModule, @Optional() http: HttpClient) {
    if (parentModule) {
      throw new Error('ApiModule is already loaded. Import in your base AppModule only.');
    }
    if (!http) {
      throw new Error(
        'You need to import the HttpClientModule in your AppModule! \n' +
          'See also https://github.com/angular/angular/issues/20575'
      );
    }
  }
}
