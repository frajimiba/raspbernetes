import { AssignmentsResourceService } from './assignmentsResource.service';
import { BotEngineResourceService } from './botEngineResource.service';
import { CategoryLinkResourceService } from './categoryLinkResource.service';
import { ClassificationResourceService } from './classificationResource.service';
import { DashboardResourceService } from './dashboardResource.service';
import { ElasticSearchResourceService } from './elasticSearchResource.service';
import { ExecutionResourceService } from './executionResource.service';
import { ExecutionTemplateResourceService } from './executionTemplateResource.service';
import { FeedbackResourceService } from './feedbackResource.service';
import { FrontLinkResourceService } from './frontLinkResource.service';
import { FrontMenuResourceService } from './frontMenuResource.service';
import { GiteaResourceService } from './giteaResource.service';
import { IssueResourceService } from './issueResource.service';
import { KeycloakGroupResourceService } from './keycloakGroupResource.service';
import { LinkResourceService } from './linkResource.service';
import { LiteralsResourceService } from './literalsResource.service';
import { MenuResourceService } from './menuResource.service';
import { MessageResourceService } from './messageResource.service';
import { NotificationTypeResourceService } from './notificationTypeResource.service';
import { OpenAIResourceService } from './openAIResource.service';
import { ProcedureResourceService } from './procedureResource.service';
import { SelfServiceResourceService } from './selfServiceResource.service';
import { StatusesResourceService } from './statusesResource.service';
import { SubmenuResourceService } from './submenuResource.service';
import { TicketResourceService } from './ticketResource.service';
import { TimeChannelResourceService } from './timeChannelResource.service';
import { TroubleshootingResourceService } from './troubleshootingResource.service';

export * from './assignmentsResource.service';

export * from './botEngineResource.service';

export * from './categoryLinkResource.service';

export * from './classificationResource.service';

export * from './dashboardResource.service';

export * from './elasticSearchResource.service';

export * from './executionResource.service';

export * from './executionTemplateResource.service';

export * from './feedbackResource.service';

export * from './frontLinkResource.service';

export * from './frontMenuResource.service';

export * from './giteaResource.service';

export * from './issueResource.service';

export * from './keycloakGroupResource.service';

export * from './linkResource.service';

export * from './literalsResource.service';

export * from './menuResource.service';

export * from './messageResource.service';

export * from './notificationTypeResource.service';

export * from './openAIResource.service';

export * from './procedureResource.service';

export * from './selfServiceResource.service';

export * from './statusesResource.service';

export * from './submenuResource.service';

export * from './ticketResource.service';

export * from './timeChannelResource.service';

export * from './troubleshootingResource.service';

export const APIS = [
  AssignmentsResourceService,
  BotEngineResourceService,
  CategoryLinkResourceService,
  ClassificationResourceService,
  DashboardResourceService,
  ElasticSearchResourceService,
  ExecutionResourceService,
  ExecutionTemplateResourceService,
  FeedbackResourceService,
  FrontLinkResourceService,
  FrontMenuResourceService,
  GiteaResourceService,
  IssueResourceService,
  KeycloakGroupResourceService,
  LinkResourceService,
  LiteralsResourceService,
  MenuResourceService,
  MessageResourceService,
  NotificationTypeResourceService,
  OpenAIResourceService,
  ProcedureResourceService,
  SelfServiceResourceService,
  StatusesResourceService,
  SubmenuResourceService,
  TicketResourceService,
  TimeChannelResourceService,
  TroubleshootingResourceService
];
