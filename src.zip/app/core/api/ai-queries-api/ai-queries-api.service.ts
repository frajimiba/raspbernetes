import { lastValueFrom } from 'rxjs';

import { Injectable } from '@angular/core';

import { LiteralsResourceService } from '../api-client-library/api/literalsResource.service';

import { LiteralDTO, LiteralEntry, PagedResultLiteralDTO } from '../api-client-library';

@Injectable({
  providedIn: 'root'
})
export class AiQueriesApiService {
  constructor(private readonly chatBotLiteralsResourceService: LiteralsResourceService) {
    this.chatBotLiteralsResourceService.configuration.basePath = '';
  }

  public async getAiQueries({
    page = 0,
    size = 1,
    sort = 'asc',
    ascending = false
  }: { page?: number; size?: number; sort?: string; ascending?: boolean } = {}): Promise<PagedResultLiteralDTO> {
    return lastValueFrom(
      this.chatBotLiteralsResourceService.appopsXplplataformaV0LiteralsPaginatedPost(ascending, page, size, sort)
    ).catch(error => {
      console.error('AiQueriesApiService getLiterals KO error', 'error data', error);
      throw new Error('Error al recuperar literals.');
    });
  }

  public async createAiQuery(item: LiteralDTO): Promise<LiteralDTO> {
    return lastValueFrom(this.chatBotLiteralsResourceService.appopsXplplataformaV0LiteralsPost(item)).catch(error => {
      console.error('AiQueriesApiService createAiQuery KO error', 'error data', error);
      throw new Error('Error al crear literal.');
    });
  }

  public async deleteAiQuery(id: string): Promise<any> {
    return lastValueFrom(this.chatBotLiteralsResourceService.appopsXplplataformaV0LiteralsIdDelete(id)).catch(error => {
      console.error('AiQueriesApiService deleteAiQuery KO error', 'error data', error);
      throw new Error('Error al crear literal.');
    });
  }

  public async updateAiQuery(id: string, item: LiteralEntry): Promise<LiteralDTO> {
    return lastValueFrom(this.chatBotLiteralsResourceService.appopsXplplataformaV0LiteralsIdPut(id, item)).catch(
      error => {
        console.error('AiQueriesApiService updateAiQuery KO error', 'error data', error);
        throw new Error(`Error al actualizar: ${id ?? ''}.`);
      }
    );
  }
}
