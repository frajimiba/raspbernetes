import { lastValueFrom } from 'rxjs';

import { Injectable } from '@angular/core';

import { LiteralsResourceService } from '../api-client-library/api/literalsResource.service';

import { LiteralDTO, LiteralEntry, PagedResultLiteralDTO } from '../api-client-library';

@Injectable({
  providedIn: 'root'
})
export class ChatbotLiteralsApiService {
  constructor(private readonly chatBotLiteralsResourceService: LiteralsResourceService) {
    this.chatBotLiteralsResourceService.configuration.basePath = '';
  }

  public async getChatbotLiterals({
    page = 0,
    size = 1,
    sort = 'asc',
    ascending = false
  }: { page?: number; size?: number; sort?: string; ascending?: boolean } = {}): Promise<PagedResultLiteralDTO> {
    return lastValueFrom(
      this.chatBotLiteralsResourceService.appopsXplplataformaV0LiteralsPaginatedPost(ascending, page, size, sort)
    ).catch(error => {
      console.error('ChatbotLiteralsApiService getLiterals KO error', 'error data', error);
      throw new Error('Error al recuperar literals.');
    });
  }

  public async createChatbotLiteral(item: LiteralDTO): Promise<LiteralDTO> {
    return lastValueFrom(this.chatBotLiteralsResourceService.appopsXplplataformaV0LiteralsPost(item)).catch(error => {
      console.error('ChatbotLiteralsApiService createChatbotLiteral KO error', 'error data', error);
      throw new Error('Error al crear literal.');
    });
  }

  public async deleteChatbotLiteral(id: string): Promise<any> {
    return lastValueFrom(this.chatBotLiteralsResourceService.appopsXplplataformaV0LiteralsIdDelete(id)).catch(error => {
      console.error('ChatbotLiteralsApiService deleteChatbotLiteral KO error', 'error data', error);
      throw new Error('Error al crear literal.');
    });
  }

  public async updateChatbotLiteral(id: string, item: LiteralEntry): Promise<LiteralDTO> {
    return lastValueFrom(this.chatBotLiteralsResourceService.appopsXplplataformaV0LiteralsIdPut(id, item)).catch(
      error => {
        console.error('ChatbotLiteralsApiService updateChatbotLiteral KO error', 'error data', error);
        throw new Error(`Error al actualizar: ${id ?? ''}.`);
      }
    );
  }
}
