import { AppopsXplplataformaV0GiteaCustomerGet200Response } from '../api-client-library';

export type CustomerConfig = Required<AppopsXplplataformaV0GiteaCustomerGet200Response>;
