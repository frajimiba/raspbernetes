import { lastValueFrom } from 'rxjs';

import { Injectable } from '@angular/core';

import { GiteaResourceService } from '../api-client-library';
import { CustomerConfig } from './gitea-api.model';

@Injectable({
  providedIn: 'root'
})
export class GiteaApiService {
  constructor(private readonly giteaResourceService: GiteaResourceService) {
    this.giteaResourceService.configuration.basePath = '';
  }

  public async getGitea(customer: string): Promise<CustomerConfig> {
    return lastValueFrom(this.giteaResourceService.appopsXplplataformaV0GiteaCustomerGet(customer))
      .then(result => {
        if (!result) {
          return {
            classifications: [],
            customer,
            groups: []
          };
        }
        return {
          classifications: result.classifications ?? [],
          customer: result.customer ?? customer,
          groups: result.groups ?? []
        };
      })
      .catch(error => {
        console.error('GiteaApiService getLiterals KO error', 'error data', error);
        throw new Error('Error al recuperar literals.');
      });
  }
}
