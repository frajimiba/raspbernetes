import { lastValueFrom } from 'rxjs';

import { Injectable } from '@angular/core';

import { MessageResourceService } from '../api-client-library/api/messageResource.service';
import { NotificationTypeResourceService } from '../api-client-library/api/notificationTypeResource.service';
import { TimeChannelResourceService } from '../api-client-library/api/timeChannelResource.service';

import { MessageDTO } from '../api-client-library/model/messageDTO';
import { MessageEntry } from '../api-client-library/model/messageEntry';
import { NotificationTypeDTO } from '../api-client-library/model/notificationTypeDTO';
import { NotificationTypeEntry } from '../api-client-library/model/notificationTypeEntry';
import { TimeChannelDTO } from '../api-client-library/model/timeChannelDTO';
import { TimeChannelEntry } from '../api-client-library/model/timeChannelEntry';

@Injectable({
  providedIn: 'root'
})
export class NotificationsApiService {
  constructor(
    private readonly notificationTypeResourceService: NotificationTypeResourceService,
    private readonly messageResourceService: MessageResourceService,
    private readonly timeChannelResourceService: TimeChannelResourceService
  ) {
    this.notificationTypeResourceService.configuration.basePath = '';
    this.messageResourceService.configuration.basePath = '';
    this.timeChannelResourceService.configuration.basePath = '';
  }

  public async getNotificationTypes(
    page = 0,
    size = 1,
    sort = 'asc',
    ascending = false
  ): Promise<NotificationTypeDTO[]> {
    return lastValueFrom(
      this.notificationTypeResourceService.appopsXplplataformaV0NotificationTypeGet(ascending, page, size, sort)
    ).catch(error => {
      console.error('NotificationsApiService getNotificationTypes KO error', 'error data', error);
      throw new Error('Error al recuperar notification types.');
    });
  }

  public async createNotificationType(item: NotificationTypeEntry): Promise<NotificationTypeEntry> {
    return lastValueFrom(this.notificationTypeResourceService.appopsXplplataformaV0NotificationTypePost(item)).catch(
      error => {
        console.error('NotificationsApiService createNotificationType KO error', 'error data', error);
        throw new Error('Error al crear mensaje.');
      }
    );
  }

  public async deleteNotificationType(item: NotificationTypeEntry): Promise<any> {
    return lastValueFrom(
      this.notificationTypeResourceService.appopsXplplataformaV0NotificationTypeIdDelete(item.id ?? '')
    ).catch(error => {
      console.error('NotificationsApiService deleteNotificationType KO error', 'error data', error);
      throw new Error('Error al crear mensaje.');
    });
  }

  public async updateNotificationType(item: NotificationTypeDTO): Promise<NotificationTypeEntry> {
    return lastValueFrom(
      this.notificationTypeResourceService.appopsXplplataformaV0NotificationTypePut({
        id: item.id,
        description: item.description
      })
    ).catch(error => {
      console.error('NotificationsApiService updateNotificationType KO error', 'error data', error);
      throw new Error(`Error al actualizar: ${item.id ?? ''}.`);
    });
  }

  public async getMessagesByNotificationTypeId(id: string): Promise<MessageDTO[]> {
    return lastValueFrom(
      this.messageResourceService.appopsXplplataformaV0NotificationMessagesNotificationIdGet(id)
    ).catch(error => {
      console.error('NotificationsApiService getNotificationTypes KO error', 'error data', error);
      throw new Error('Error al recuperar mensajes.');
    });
  }

  public async createMessage(notificationId: string, item: MessageEntry): Promise<MessageDTO> {
    return lastValueFrom(
      this.messageResourceService.appopsXplplataformaV0NotificationMessagesNotificationIdPost(notificationId, item)
    ).catch(error => {
      console.error('NotificationsApiService createMessage KO error', 'error data', error);
      throw new Error('Error al crear mensaje.');
    });
  }

  public async updateMessage(id: number, item: MessageEntry): Promise<MessageDTO> {
    return lastValueFrom(this.messageResourceService.appopsXplplataformaV0NotificationMessagesIdPut(id, item)).catch(
      error => {
        console.error('NotificationsApiService updateMessage KO error', 'error data', error);
        throw new Error('Error al actualizar mensaje.');
      }
    );
  }

  public async deleteMessage(id: number): Promise<void> {
    lastValueFrom(this.messageResourceService.appopsXplplataformaV0NotificationMessagesIdDelete(id)).catch(error => {
      console.error('NotificationsApiService getNotificationTypes KO error', 'error data', error);
      throw new Error('Error al eliminar mensaje');
    });
  }

  public async getTimeChannelsByNotificationTypeId(id: string): Promise<TimeChannelDTO[]> {
    return lastValueFrom(
      this.timeChannelResourceService.appopsXplplataformaV0NotificationTimechannelNotificationIdGet(id)
    ).catch(error => {
      console.error('NotificationsApiService createMessage KO error', 'error data', error);
      throw new Error('Error al crear mensaje.');
    });
  }

  public async createTimeChannel(notificationId: string, item: TimeChannelEntry): Promise<TimeChannelDTO> {
    return lastValueFrom(
      this.timeChannelResourceService.appopsXplplataformaV0NotificationTimechannelNotificationIdPost(
        notificationId,
        item
      )
    ).catch(error => {
      console.error('NotificationsApiService createMessage KO error', 'error data', error);
      throw new Error('Error al crear mensaje.');
    });
  }

  public async updateTimeChannel(id: number, item: TimeChannelEntry): Promise<TimeChannelDTO> {
    return lastValueFrom(
      this.timeChannelResourceService.appopsXplplataformaV0NotificationTimechannelIdPut(id, item)
    ).catch(error => {
      console.error('NotificationsApiService createMessage KO error', 'error data', error);
      throw new Error('Error al crear mensaje.');
    });
  }

  public async deleteTimeChannel(id: number): Promise<void> {
    void lastValueFrom(this.timeChannelResourceService.appopsXplplataformaV0NotificationTimechannelIdDelete(id)).catch(
      error => {
        console.error('NotificationsApiService createMessage KO error', 'error data', error);
        throw new Error('Error al crear mensaje.');
      }
    );
  }
}
