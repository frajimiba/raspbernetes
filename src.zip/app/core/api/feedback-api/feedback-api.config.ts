import { FeedbackEntry } from './../api-client-library/model/feedbackEntry';

export interface GetFeedbacksPageRequestConfig {
  index: number;
  size: number;
  sortId: string;
  sortAscending: boolean;
}

export interface GetFeedbacksByExecutionsRequestConfig extends GetFeedbacksPageRequestConfig {
  executionId: number;
}

export interface PutUpdateFeedbackRequestConfig {
  id: number;
  feedback: FeedbackEntry;
}
