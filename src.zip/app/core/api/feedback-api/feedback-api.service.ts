import { lastValueFrom } from 'rxjs';

import { Injectable } from '@angular/core';

import {
  ExecutionResourceService,
  FeedbackDTO,
  FeedbackEntry,
  FeedbackResourceService,
  GetFeedbacksByExecutionsRequestConfig,
  GetFeedbacksPageRequestConfig,
  PagedResultFeedbackDTO,
  PutUpdateFeedbackRequestConfig
} from '../../../../app/core';
import { validateApiResponse } from '../validate-api-response';

@Injectable({
  providedIn: 'root'
})
export class FeedbackApiService {
  constructor(
    private readonly feedbackResourceService: FeedbackResourceService,
    private readonly executionResourceService: ExecutionResourceService
  ) {
    this.feedbackResourceService.configuration.basePath = '';
    this.executionResourceService.configuration.basePath = '';
  }

  public async getFeedbacks(config: GetFeedbacksPageRequestConfig): Promise<PagedResultFeedbackDTO> {
    return lastValueFrom(
      this.feedbackResourceService.appopsXplplataformaV0FeedbacksGet(
        config.sortAscending,
        config.index,
        config.size,
        config.sortId
      )
    )
      .then((feedbackPage: PagedResultFeedbackDTO) => validateApiResponse(feedbackPage))
      .catch(error => {
        console.error('FeedbackApiService getFeedbacks KO error', 'error data', error);
        throw new Error('Error al recuperar los feedbacks');
      });
  }

  public async getFeedbacksByExecution(config: GetFeedbacksByExecutionsRequestConfig): Promise<PagedResultFeedbackDTO> {
    return lastValueFrom(
      this.executionResourceService.appopsXplplataformaV0ExecutionsIdFeedbacksGet(
        config.executionId,
        config.sortAscending,
        config.index,
        config.size,
        config.sortId
      )
    )
      .then((feedbackPage: PagedResultFeedbackDTO) => validateApiResponse(feedbackPage))
      .catch(error => {
        console.error('FeedbackApiService getFeedbacksByExecution KO error', 'error data', error);
        throw new Error('Error al recuperar los feedbacks por id de ejecución');
      });
  }

  public async getFeedbackById(id: number): Promise<FeedbackDTO> {
    return lastValueFrom(this.feedbackResourceService.appopsXplplataformaV0FeedbacksFeebackIdDetailGet(id))
      .then((feedback: FeedbackDTO) => validateApiResponse(feedback))
      .catch(error => {
        console.error('FeedbackApiService getFeedbackById KO error', 'error data', error);
        throw new Error('Error al obtener feedback por id');
      });
  }

  public async postFeedback(feedback: FeedbackEntry): Promise<FeedbackDTO> {
    return lastValueFrom(this.feedbackResourceService.appopsXplplataformaV0FeedbacksPost(feedback))
      .then((feedback: FeedbackDTO) => validateApiResponse(feedback))
      .catch(error => {
        console.error('FeedbackApiService postFeedback KO error', 'error data', error);
        throw new Error('Error al enviar nuevo feedback');
      });
  }

  public async updateFeedback(config: PutUpdateFeedbackRequestConfig): Promise<FeedbackDTO> {
    return lastValueFrom(
      this.feedbackResourceService.appopsXplplataformaV0FeedbacksFeebackIdPut(config.id, config.feedback)
    )
      .then((feedback: FeedbackDTO) => validateApiResponse(feedback))
      .catch(error => {
        console.error('FeedbackApiService getFeedbackById KO error', 'error data', error);
        throw new Error('Error al obtener feedback por id');
      });
  }
}
