export const NO_VALID_DATA_RECEIVED = 'Datos recibidos no válidos.';
