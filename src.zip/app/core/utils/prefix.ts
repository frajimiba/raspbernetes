export const ZERO = 0;
export const SUBMIT_FORM_WITH_OK = 1;
export const DISCAR_FORM = -1;
export const MAT_DIALOG_CLOSE_WITH_OK = 1;
export const MAT_DIALOG_CLOSE_WITHOUT_ACTIONS = -1;
export const MAT_DIALOG_CLOSE_WITH_KO = 0;

export const MIN_POSITION_VALUE = 0;
export const MAX_POSITION_VALUE = 999;
export const MIN_NAME_LENGTH = 3;
export const MAX_NAME_LENGTH = 30;
export const MIN_DESCRIPTION_LENGTH = 3;
export const MAX_DESCRIPTION_LENGTH = 255;
export const MIN_LINK_LENGTH = 3;
export const MAX_LINK_LENGTH = 255;
export const DEFAULT_STRINGS_VALUES = '';
export const DEFAULT_OBJECTS_VALUES = {};
