export type IssueStatus = 'Unassigned' | 'Assigned' | 'Resolved' | 'In Progress' | 'Pending' | 'Failed';

export const ALL_ISSUES_STATUS: IssueStatus[] = [
  'Unassigned',
  'Assigned',
  'Resolved',
  'In Progress',
  'Pending',
  'Failed'
];
export const DEFAULT_SELECTED_ISSUES: IssueStatus[] = ['Unassigned', 'Assigned', 'In Progress', 'Pending', 'Failed'];
