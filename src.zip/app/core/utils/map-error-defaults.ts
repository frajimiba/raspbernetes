export const DEFAULT_INDEX = -1;
export const DEFAULT_STRING = '';
export const DEFAULT_NUMBER = 0;
export const EMPTY_ARRAY_SIZE = 0;
export const ARRAY_FIRST_POSITION = 0;
