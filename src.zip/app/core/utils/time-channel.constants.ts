export const timeChannelTable: { [key: string]: string } = {
  T: 'TEAMS',
  W: 'TWILIO',
  S: 'SLACK',
  E: 'EMAIL'
};
