import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { DemoPageComponentRoutingModule } from './demo-page.routing.module';
import { DemoMaterialModule } from './material.module';

import { DemoPageComponent } from './demo-page.component';

@NgModule({
  declarations: [DemoPageComponent],
  imports: [CommonModule, DemoPageComponentRoutingModule, DemoMaterialModule],
  exports: [DemoPageComponent]
})
export class DemoPageModule {}
