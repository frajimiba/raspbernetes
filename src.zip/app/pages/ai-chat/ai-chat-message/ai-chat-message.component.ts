import { ChangeDetectionStrategy, Component, Input, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';

import { AuthService } from '../../../../app/core';
import { UIChatMessage } from '../ai-chat.model';
import { AiChatMessage } from './ai-chat-message.model';

const LOG_TAG = 'AiChatMessageComponent';
@Component({
  selector: 'app-ai-chat-message',
  templateUrl: './ai-chat-message.component.html',
  styleUrls: ['./ai-chat-message.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AiChatMessageComponent implements OnInit {
  @Input() message: UIChatMessage;

  public splittedMessage: AiChatMessage[] = [];
  public isOwnMsg: boolean;
  public sanitizedContent: SafeHtml;
  public showMoreContent: boolean;

  constructor(
    private readonly dialog: MatDialog,
    private readonly authService: AuthService,
    private readonly domSanitizer: DomSanitizer
  ) {
    console.log(`${LOG_TAG}`, 'new instance');
  }

  ngOnInit(): void {
    console.log(`${LOG_TAG}`, 'ngOnInit');
    this.initOwnMsg();
    this.initMsgContent();
  }

  public showMoreModal(): void {
    console.log(`${LOG_TAG}`, 'showMoreModal');
  }

  private initOwnMsg(): void {
    this.isOwnMsg = this.message.role === 'user';
  }

  private initMsgContent(): void {
    const content = this.message.content ?? '';
    content.split(/^```(?:.+)?$/gm).forEach((messagePart: string) => {
      this.splittedMessage.push({
        content: messagePart,
        type: 'text'
      });
    });
  }
}
