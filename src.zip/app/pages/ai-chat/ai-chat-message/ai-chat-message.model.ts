import { SafeHtml } from '@angular/platform-browser';

export interface AiChatMessage {
  content: SafeHtml | string;
  type: 'text' | 'code';
}
