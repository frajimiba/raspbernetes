import { HIGHLIGHT_OPTIONS } from 'ngx-highlightjs';
import { HighlightPlusModule } from 'ngx-highlightjs/plus';

import { ScrollingModule } from '@angular/cdk/scrolling';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressBarModule } from '@angular/material/progress-bar';

import { AiChatRoutingModule } from './ai-chat-routing.module';

import { InfoRowModule } from '../../../app/shared';
import { AiChatMessageComponent } from './ai-chat-message/ai-chat-message.component';
import { AiChatQueryItemComponent } from './ai-chat-query-item/ai-chat-query-item.component';
import { AiChatComponent } from './ai-chat.component';

@NgModule({
  declarations: [AiChatComponent, AiChatQueryItemComponent, AiChatMessageComponent],
  imports: [
    HighlightPlusModule,
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    ScrollingModule,
    MatButtonModule,
    MatIconModule,
    MatCheckboxModule,
    MatProgressBarModule,
    MatCardModule,
    InfoRowModule,
    AiChatRoutingModule
  ],
  providers: [
    {
      provide: HIGHLIGHT_OPTIONS,
      useValue: {
        fullLibraryLoader: () => import('highlight.js')
      }
    }
  ],
  exports: [AiChatComponent]
})
export class AiChatModule {}
