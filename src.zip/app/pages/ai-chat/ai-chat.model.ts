import { Message } from '../../../app/core';

export type UIChatMessage = Readonly<Required<Message> & { creationDate: Date }>;

export interface UIChatRequest {
  messages: UIChatMessage[];
}
