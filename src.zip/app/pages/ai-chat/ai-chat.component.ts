/* eslint-disable @typescript-eslint/consistent-type-assertions */
import { CdkVirtualScrollViewport } from '@angular/cdk/scrolling';
import { ChangeDetectionStrategy, Component, OnInit, ViewChild } from '@angular/core';

import { ChatRequest, CompletionsCreate200Response } from '../../../app/core';
import { OpenAIApiService } from '../../../app/core/api/openai-api';
import { AiQueryItem } from '../admin-dashboard/ai-queries-management/models/ai-queries.model';
import { UIChatRequest } from './ai-chat.model';

@Component({
  selector: 'app-ai-chat',
  templateUrl: './ai-chat.component.html',
  styleUrls: ['./ai-chat.component.scss'],
  changeDetection: ChangeDetectionStrategy.Default
})
export class AiChatComponent implements OnInit {
  @ViewChild(CdkVirtualScrollViewport) virtualScrollViewport?: CdkVirtualScrollViewport;

  aiQueryItems: AiQueryItem[] = [];
  currentMessage: string = '';
  request: UIChatRequest = {
    messages: []
  };

  loadingResponse: boolean = false;

  constructor(private readonly openAIApiService: OpenAIApiService) {}

  ngOnInit(): void {
    this.aiQueryItems = Array.from(Array(10).keys()).map(item => {
      return {
        id: `${item}`,
        title: `Ejemplo ${item} de consulta`,
        description: 'Consulta...'
      } as AiQueryItem;
    });
  }

  public restart(): void {
    this.loadingResponse = false;
    this.request.messages = [];
  }

  public execQuery(query: string, event: Event): void {
    console.log('AiChatComponent', 'execQuery', query);
    event?.stopImmediatePropagation();
    this.request.messages?.push({
      role: 'user',
      content: query,
      creationDate: new Date()
    });
    setTimeout(() => {
      this.currentMessage = '';
      this.scrollToBottom();
    }, 50);
    this.loadingResponse = true;
    this.openAIApiService
      .sendMessage(this.request)
      .then((response: CompletionsCreate200Response) => {
        console.log('AiChatComponent', 'execQuery', query);
        const choice = response.choices?.shift();
        if (this.request.messages?.length !== 0) {
          // Add only when chat didn't was restarted
          this.request.messages?.push({
            role: choice?.message?.role ?? 'assistant',
            content: choice?.message?.content ?? '',
            creationDate: new Date()
          });
        }
      })
      .then(() => {
        setTimeout(() => {
          this.scrollToBottom();
        }, 50);
      })
      .finally(() => {
        this.loadingResponse = false;
      });
  }

  public scrollToBottom(): void {
    console.log('AiChatComponent', 'scrollToBottom');
    this.virtualScrollViewport?.scrollTo({
      bottom: 0,
      behavior: 'auto'
    });
  }
}
