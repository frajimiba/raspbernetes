import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';

import { AiQueryItem } from '../../admin-dashboard/ai-queries-management/models/ai-queries.model';

@Component({
  selector: 'app-ai-chat-query-item',
  templateUrl: './ai-chat-query-item.component.html',
  styleUrls: ['./ai-chat-query-item.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AiChatQueryItemComponent {
  @Input() item: AiQueryItem;
  @Output() itemClicked: EventEmitter<AiQueryItem> = new EventEmitter();

  public emitItemClicked(): void {
    this.itemClicked.emit(this.item);
  }
}
