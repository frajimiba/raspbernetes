import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AiChatQueryItemComponent } from './ai-chat-query-item.component';

xdescribe('AiChatQueryItemComponent', () => {
  let component: AiChatQueryItemComponent;
  let fixture: ComponentFixture<AiChatQueryItemComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AiChatQueryItemComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(AiChatQueryItemComponent);
    component = fixture.componentInstance;
    component.item = {
      title: '',
      description: '',
      id: ''
    };
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
