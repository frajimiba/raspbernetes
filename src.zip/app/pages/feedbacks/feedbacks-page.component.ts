import { Component } from '@angular/core';

@Component({
  selector: 'app-feedbacks-page',
  templateUrl: './feedbacks-page.component.html',
  styleUrls: ['./feedbacks-page.component.scss']
})
export class FeedbacksPageComponent {}
