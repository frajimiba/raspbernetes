export interface FeedbackListPageConfig {
  index: number;
  size: number;
  sortId: string;
  sortAscending: boolean;
  procedureId?: number;
}
