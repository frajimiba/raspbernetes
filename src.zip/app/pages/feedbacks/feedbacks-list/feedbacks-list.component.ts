import { Subject, takeUntil } from 'rxjs';
import swal2 from 'sweetalert2';

import { AfterViewInit, Component, Input, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';

import { FeedbackListService } from './feedbacks-list.service';

import { FeedbackDTO, PagedResultFeedbackDTO } from '../../../../app/core';
import { FeedbackListPageConfig } from './feedbacks-list.model';

const LOG_TAG = 'FeedbacksComponent';

@Component({
  selector: 'app-feedbacks-list',
  templateUrl: './feedbacks-list.component.html',
  styleUrls: ['./feedbacks-list.component.scss']
})
export class FeedbacksListComponent implements OnInit, AfterViewInit, OnDestroy {
  @ViewChild(MatSort) sort: MatSort;
  @Input() procedureId: number;

  public isLoadingResults = false;
  public columnsToDisplay: string[] = ['id', 'comments', 'userId', 'creationDate', 'stars']; // , 'actions'
  public expandedElement: FeedbackDTO | null;
  public dataSource: MatTableDataSource<FeedbackDTO> = new MatTableDataSource<FeedbackDTO>([]);

  public numOfResults = 0;
  public pageIndex = 0;
  public pageSize = 10;

  private readonly stopSubscriptionsNotifier = new Subject<void>();

  constructor(
    private readonly router: Router,
    private readonly route: ActivatedRoute,
    private readonly feedbackListService: FeedbackListService
  ) {}

  public ngOnInit(): void {
    console.log(`${LOG_TAG}`, 'ngOnInit');
    this.initializeState();
  }

  public ngAfterViewInit(): void {
    console.log(`${LOG_TAG}`, 'ngAfterViewInit');
    this.iniitializeSortChangeSubscription();
  }

  public ngOnDestroy(): void {
    console.log(`${LOG_TAG}`, 'ngOnDestroy');
    this.stopSubscriptionsNotifier.next();
    this.stopSubscriptionsNotifier.complete();
  }

  public goToEdit(feedbackDTO: FeedbackDTO): void {
    console.log(`${LOG_TAG}`, 'goToEdit', 'feedback:', feedbackDTO);
    void this.router.navigateByUrl('/procedures/edit', {
      state: feedbackDTO
    });
  }

  public applyFilter(event: Event): void {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
    console.log(this.dataSource.filteredData);
  }

  public pageChanged(event: any): void {
    console.log(`${LOG_TAG}`, 'pageChanged', event);
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
    void this.initializeState();
  }

  public sortChanged(): void {
    console.log(`${LOG_TAG}`, 'sortChanged');
    this.dataSource = new MatTableDataSource();
    void this.initializeState();
  }

  private initializeState(): void {
    console.log(`${LOG_TAG}`, 'initializeState');

    this.route.queryParams.pipe(takeUntil(this.stopSubscriptionsNotifier)).subscribe(params => {
      console.log(`${LOG_TAG}`, 'params received:', params);

      if (params?.id) {
        try {
          this.procedureId = Number(params.id);
        } catch (error) {
          console.error(`${LOG_TAG}`, 'initializeState', 'error', error);
        }
      }

      void this.getFeedbacks();
    });
  }

  private async getFeedbacks(): Promise<void> {
    console.log(`${LOG_TAG}`, 'getFeedbacks');

    this.isLoadingResults = true;

    try {
      const feedbackPage = await this.feedbackListService.getFeedbacks(this.generateFeedbackListPageConfig());
      this.initializeFeedbackPage(feedbackPage);
    } catch (error) {
      console.error(`${LOG_TAG}`, 'getFeedbacks', 'error', error);
      void swal2.fire(`Error en feedbacks`, `Error al obtener listado de feedbacks`, 'error');
    }
    this.isLoadingResults = false;
  }

  private generateFeedbackListPageConfig(): FeedbackListPageConfig {
    const defaultPageIndex = 0;
    const defaultPageSize = 5;
    return {
      index: this.pageIndex ?? defaultPageIndex,
      size: this.pageSize ?? defaultPageSize,
      sortId: this.sort?.active ?? 'id',
      sortAscending: this.sort?.direction === 'asc',
      procedureId: this.procedureId
    };
  }

  private initializeFeedbackPage(feedbackPage: PagedResultFeedbackDTO): void {
    console.log(`${LOG_TAG}`, 'initializeFeedbackPage', feedbackPage);
    this.dataSource.data = feedbackPage.list as FeedbackDTO[];
    this.dataSource.sort = this.sort ?? undefined;
    this.numOfResults = feedbackPage.numOfResults ?? 0;
    this.initializeCustomFeedbackFilters();
  }

  private initializeCustomFeedbackFilters(): void {
    console.log(`${LOG_TAG}`, 'initializeCustomFeedbackFilters');
    this.dataSource.filterPredicate = function customFilter(data: FeedbackDTO, filter: string): boolean {
      return (
        (data.id?.toString().includes(filter) ?? false) ||
        (data.userId?.toLowerCase().includes(filter) ?? false) ||
        (data.comments?.toLowerCase().includes(filter) ?? false) ||
        (data.stars?.toString() === filter ?? false)
      );
    };
  }

  // If the user changes the sort order, reset back to the first page.
  private iniitializeSortChangeSubscription(): void {
    this.sort?.sortChange
      .pipe(takeUntil(this.stopSubscriptionsNotifier))
      .subscribe(() => this.initializePaginatorIndex());
  }

  private initializePaginatorIndex(): void {
    this.pageIndex = 0;
  }
}
