import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatOptionModule } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSelectModule } from '@angular/material/select';
import { MatSortModule } from '@angular/material/sort';
import { MatTableModule } from '@angular/material/table';
import { RouterModule, Routes } from '@angular/router';

import { StarRatingModule } from '../../../../app/shared';
import { FeedbacksListComponent } from './feedbacks-list.component';

const routes: Routes = [{ path: '', component: FeedbacksListComponent }];

const DEPENDENCIES = [
  CommonModule,
  RouterModule,
  RouterModule.forChild(routes),
  ReactiveFormsModule,
  FormsModule,
  MatFormFieldModule,
  MatButtonModule,
  MatSelectModule,
  MatOptionModule,
  MatTableModule,
  MatInputModule,
  MatSortModule,
  MatPaginatorModule,
  StarRatingModule
];

@NgModule({
  declarations: [FeedbacksListComponent],
  imports: DEPENDENCIES,
  exports: [FeedbacksListComponent, DEPENDENCIES]
})
export class FeedbacksListModule {}
