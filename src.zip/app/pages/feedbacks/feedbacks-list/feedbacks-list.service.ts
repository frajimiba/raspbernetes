import { Injectable } from '@angular/core';

import { FeedbacksService } from '../feedbacks.service';

import {
  GetProcedureFeedbacksByIdRequestConfig,
  PagedResultFeedbackDTO,
  ProceduresApiService
} from '../../../../app/core';
import { FeedbackListPageConfig } from './feedbacks-list.model';

const LOG_TAG = 'FeedbackListService';

@Injectable({
  providedIn: 'root'
})
export class FeedbackListService {
  constructor(
    private readonly feedbackService: FeedbacksService,
    private readonly proceduresService: ProceduresApiService
  ) {}

  public async getFeedbacks(config: FeedbackListPageConfig): Promise<PagedResultFeedbackDTO> {
    console.log(`${LOG_TAG}`, 'getFeedbacks');

    return config?.procedureId ? this.getProcedureFeedbacksById(config) : this.feedbackService.getFeedbacksPage(config);
  }

  private async getProcedureFeedbacksById(config: FeedbackListPageConfig): Promise<PagedResultFeedbackDTO> {
    return this.proceduresService.getProcedureFeedbacksById(this.generateProcedureFeedbacksByIdRequest(config));
  }

  private generateProcedureFeedbacksByIdRequest(
    config: FeedbackListPageConfig
  ): GetProcedureFeedbacksByIdRequestConfig {
    const defaultId = -1;
    return {
      procedureId: config.procedureId ?? defaultId,
      page: config.index,
      size: config.size,
      sort: config.sortId,
      ascending: config.sortAscending
    };
  }
}
