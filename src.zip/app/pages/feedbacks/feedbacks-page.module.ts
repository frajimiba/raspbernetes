import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { FeedbacksPageComponentRoutingModule } from './feedbacks-page.routing.module';

import { FeedbacksPageComponent } from './feedbacks-page.component';

@NgModule({
  declarations: [FeedbacksPageComponent],
  imports: [CommonModule, FeedbacksPageComponentRoutingModule],
  exports: [FeedbacksPageComponent]
})
export class FeedbacksPageModule {}
