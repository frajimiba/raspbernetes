import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { FeedbacksCreationEditionModule } from '../shared';
import { FeedbacksManagementComponent } from './feedbacks-management.component';

const routes: Routes = [{ path: '', component: FeedbacksManagementComponent }];

const DEPENDENCIES = [CommonModule, FeedbacksCreationEditionModule, RouterModule.forChild(routes)];

@NgModule({
  declarations: [FeedbacksManagementComponent],
  imports: [DEPENDENCIES],
  exports: [FeedbacksManagementComponent, DEPENDENCIES]
})
export class FeedbacksManagementModule {}
