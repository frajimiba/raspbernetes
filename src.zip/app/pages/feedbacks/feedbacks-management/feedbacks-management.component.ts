import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

const LOG_TAG = 'FeedbacksManagementComponent';

@Component({
  selector: 'app-feedbacks-management',
  templateUrl: './feedbacks-management.component.html',
  styleUrls: ['./feedbacks-management.component.scss']
})
export class FeedbacksManagementComponent {
  public issueProcedureExecutionRef: string;

  constructor(public route: ActivatedRoute) {
    console.log(`${LOG_TAG}`, 'new instance');
  }

  public finishedFeedbackManagement(): void {
    console.log(`${LOG_TAG}`, 'finishedFeedbackManagement');
  }
}
