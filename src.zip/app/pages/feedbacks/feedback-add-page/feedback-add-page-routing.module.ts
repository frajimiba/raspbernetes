import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FeedbackAddPageComponent } from './feedback-add-page.component';
import { AuthGuard } from '../../../guards/auth.guard';

const routes: Routes = [{ path: 'feedbacks/add', component: FeedbackAddPageComponent, canActivate: [AuthGuard] }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FeedbackAddPageRoutingModule {}
