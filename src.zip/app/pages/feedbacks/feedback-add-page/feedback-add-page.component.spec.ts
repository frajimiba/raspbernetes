import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FeedbackAddPageComponent } from './feedback-add-page.component';

xdescribe('FeedbackAddPageComponent', () => {
  let component: FeedbackAddPageComponent;
  let fixture: ComponentFixture<FeedbackAddPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [FeedbackAddPageComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FeedbackAddPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
