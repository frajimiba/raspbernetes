import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-feedback-add-page',
  templateUrl: './feedback-add-page.component.html',
  styleUrls: ['./feedback-add-page.component.css']
})
export class FeedbackAddPageComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
