import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FeedbackAddPageRoutingModule } from './feedback-add-page-routing.module';
import { FeedbackAddPageComponent } from './feedback-add-page.component';
import { AddFeedbackModule } from '../../../components/dialogs/add-feedback/add-feedback.module';

@NgModule({
  declarations: [FeedbackAddPageComponent],
  imports: [CommonModule, AddFeedbackModule, FeedbackAddPageRoutingModule]
})
export class FeedbackAddPageModule {}
