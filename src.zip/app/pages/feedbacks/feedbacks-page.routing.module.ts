import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AuthGuard, FeedbacksRoutesIds } from '../../../app/core';
import { environment } from '../../../environments/environment';

const routes: Routes = [
  {
    path: '',
    title: 'Listado de feedbacks',
    loadChildren: () => import('./feedbacks-list/feedbacks-list.module').then(m => m.FeedbacksListModule),
    canActivate: [AuthGuard],
    data: { roles: environment.roles }
  },
  {
    path: FeedbacksRoutesIds.creationEdition,
    title: 'Creación - edición de feedbacks',
    loadChildren: () =>
      import('./feedbacks-management/feedbacks-management.module').then(m => m.FeedbacksManagementModule),
    canActivate: [AuthGuard],
    data: { roles: environment.roles }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FeedbacksPageComponentRoutingModule {}
