import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { FeedbacksCreationEditionModule } from '../feedbacks-creation-edition/feedbacks-creation-edition.module';

import { FeedbacksCreationEditionDialogComponent } from './feedbacks-creation-edition-dialog.component';

const DEPENDENCIES = [CommonModule, FeedbacksCreationEditionModule];

@NgModule({
  declarations: [FeedbacksCreationEditionDialogComponent],
  imports: [DEPENDENCIES],
  exports: [FeedbacksCreationEditionDialogComponent, DEPENDENCIES]
})
export class FeedbacksCreationEditionDialogModule {
  public static getComponent(): typeof FeedbacksCreationEditionDialogComponent {
    return FeedbacksCreationEditionDialogComponent;
  }
}
