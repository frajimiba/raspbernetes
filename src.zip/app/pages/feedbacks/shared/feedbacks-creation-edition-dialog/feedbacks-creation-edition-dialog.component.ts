import { Component, Inject } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

const LOG_TAG = 'FeedbacksCreationEditionDialogComponent';

@Component({
  selector: 'app-feedbacks-creation-edition-dialog',
  templateUrl: './feedbacks-creation-edition-dialog.component.html',
  styleUrls: ['./feedbacks-creation-edition-dialog.component.scss']
})
export class FeedbacksCreationEditionDialogComponent {
  constructor(
    @Inject(MAT_DIALOG_DATA) public issueProcedureExecutionRef: string,
    public dialogRef: MatDialogRef<FeedbacksCreationEditionDialogComponent>
  ) {
    console.log(`${LOG_TAG}`, 'new instance');
  }

  public finishedFeedbackManagement(): void {
    console.log(`${LOG_TAG}`, 'finishedFeedbackManagement');
    this.dialogRef.close();
  }
}
