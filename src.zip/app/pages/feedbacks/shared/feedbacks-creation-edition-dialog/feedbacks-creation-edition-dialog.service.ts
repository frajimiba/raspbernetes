/* eslint-disable @typescript-eslint/explicit-member-accessibility */
import { Injectable } from '@angular/core';
import { MatDialogConfig, MatDialogRef } from '@angular/material/dialog';

import { AsyncDialog } from '../../../../../app/core';
import { FeedbacksCreationEditionDialogComponent } from './feedbacks-creation-edition-dialog.component';

export type NewMenuOrSubMenu = 'NewMenu' | 'NewSubmenu';

@Injectable({
  providedIn: 'root'
})
export class FeedbacksCreationEditionDialogService extends AsyncDialog<
  FeedbacksCreationEditionDialogComponent,
  MatDialogConfig<string>,
  void
> {
  async open(config: MatDialogConfig<string>): Promise<MatDialogRef<FeedbacksCreationEditionDialogComponent, void>> {
    // Lazy loading componente ng-module
    const { FeedbacksCreationEditionDialogModule } = await import('./feedbacks-creation-edition-dialog.module');

    return this.matDialog.open(FeedbacksCreationEditionDialogModule.getComponent(), config);
  }
}
