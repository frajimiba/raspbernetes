import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';

import { StarRatingModule } from '../../../../../app/shared';
import { FeedbacksCreationEditionComponent } from './feedbacks-creation-edition.component';

const DEPENDENCIES = [
  CommonModule,
  ReactiveFormsModule,
  FormsModule,
  StarRatingModule,
  MatFormFieldModule,
  MatInputModule,
  MatProgressSpinnerModule,
  MatButtonModule
];

@NgModule({
  declarations: [FeedbacksCreationEditionComponent],
  imports: [DEPENDENCIES],
  exports: [FeedbacksCreationEditionComponent, DEPENDENCIES]
})
export class FeedbacksCreationEditionModule {}
