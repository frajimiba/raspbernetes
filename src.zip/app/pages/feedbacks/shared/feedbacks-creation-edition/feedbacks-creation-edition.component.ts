import swal2 from 'sweetalert2';

import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';

import { FeedbacksService } from '../../feedbacks.service';

import { FeedbackDTO } from '../../../../../app/core';

const LOG_TAG = 'AddFeedbackComponent';

@Component({
  selector: 'app-feedbacks-creation-edition',
  templateUrl: './feedbacks-creation-edition.component.html',
  styleUrls: ['./feedbacks-creation-edition.component.scss']
})
export class FeedbacksCreationEditionComponent implements OnInit {
  @Input() executionRef: string;
  @Output() finishedFeedbackManagement: EventEmitter<void> = new EventEmitter();

  public form: FormGroup;

  constructor(private readonly formBuilder: FormBuilder, private readonly feedbacksService: FeedbacksService) {
    console.log(`${LOG_TAG}`, 'new instance', this.executionRef);
  }

  public ngOnInit(): void {
    console.log(`${LOG_TAG}`, 'ngOnInit', this.executionRef);
    this.initializeState();
  }

  public ratingUpdated(rating: number): void {
    this.form?.controls.stars.setValue(rating);
  }

  public async submitFeedback(): Promise<void> {
    console.log(`${LOG_TAG}`, 'submitForm', this.executionRef);

    this.feedbacksService.loadingService.setLoadingState(true);

    try {
      const newFeedback = await this.feedbacksService.sendFeedback({
        stars: this.form?.controls.stars.value,
        comments: this.form?.controls.comments.value,
        executionRef: this.form?.controls.executionRef.value
      });
      this.showNewFeedbackRegisteredUi(newFeedback);
    } catch (error) {
      console.error(`${LOG_TAG}`, 'submitFeedback error', error);
      void swal2.fire(`Error en envío de feedback`, `Error al registrar nuevo feedback`, 'error');
    }

    this.feedbacksService.loadingService.setLoadingState(false);
  }

  private initializeState(): void {
    console.log(`${LOG_TAG}`, 'initializeState');

    if (!this.executionRef) {
      console.error(`${LOG_TAG}`, 'parametro obligatorio no definido, valor actual (executionRef):', this.executionRef);
      return;
    }
    this.initializeForm();
  }

  private initializeForm(): void {
    const defaultStartValue = 4;
    this.form = this.formBuilder.group({
      stars: this.formBuilder.control(defaultStartValue),
      comments: this.formBuilder.control(''),
      executionRef: this.formBuilder.control(this.executionRef)
    });
  }

  private showNewFeedbackRegisteredUi(feedback: FeedbackDTO): void {
    console.log(`${LOG_TAG}`, 'submitForm OK', this.executionRef, 'feedback', feedback);

    void swal2
      .fire(`Gracias por el feedback`, `Se ha registrado el comentario y la valoración correctamente.`, 'success')
      .then(() => this.finishedFeedbackManagement.emit());
  }
}
