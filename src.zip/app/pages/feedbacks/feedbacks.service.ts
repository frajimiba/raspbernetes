import { Injectable } from '@angular/core';

import {
  FeedbackApiService,
  FeedbackDTO,
  GetFeedbacksPageRequestConfig,
  LoadingService,
  PagedResultFeedbackDTO
} from '../../../app/core';
import { NewFeedback } from './feedbacks.model';

@Injectable({
  providedIn: 'root'
})
export class FeedbacksService {
  constructor(
    private readonly feedbackApiService: FeedbackApiService,
    public readonly loadingService: LoadingService
  ) {}

  public async getFeedbacksPage(config: GetFeedbacksPageRequestConfig): Promise<PagedResultFeedbackDTO> {
    return this.feedbackApiService.getFeedbacks(config);
  }

  public async sendFeedback(newFeedback: NewFeedback): Promise<FeedbackDTO> {
    return this.feedbackApiService.postFeedback(newFeedback);
  }
}
