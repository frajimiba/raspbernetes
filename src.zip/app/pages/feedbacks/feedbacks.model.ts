export interface NewFeedback {
  stars: number;
  comments: string;
  executionRef: number;
}
