import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AdminDashboardRoutesIds, AuthGuard } from '../../../app/core';
import { AdminDashboardPageComponent } from './admin-dashboard-page.component';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { MenuManagementModeConfig } from './menus-management';

export interface MenuRouteConfig extends MenuManagementModeConfig {
  roles: string[]; // allowed roles to grant access
}

const menuManagementModeConfig: MenuRouteConfig = {
  mode: 'Menu',
  roles: ['admin']
};

const subMenuManagementModeConfig: MenuRouteConfig = {
  mode: 'Submenu',
  roles: ['admin']
};

const routes: Routes = [
  {
    path: '',
    component: AdminDashboardPageComponent,
    children: [
      {
        path: '',
        title: 'Admin Dashboard',
        component: AdminHomeComponent
      },
      {
        path: AdminDashboardRoutesIds.home,
        title: 'Admin Dashboard',
        component: AdminHomeComponent,
        canActivate: [AuthGuard],
        data: { roles: ['admin'] }
      },
      {
        path: AdminDashboardRoutesIds.bookmarksCategories,
        title: 'Gestión de categorías de favoritos',
        loadChildren: () =>
          import('./bookmarks-management/categories/categories.module').then(m => m.CategoriesPageModule),
        canActivate: [AuthGuard],
        data: { roles: ['admin'] }
      },
      {
        path: AdminDashboardRoutesIds.bookmarksLinks,
        title: 'Gestión de enlaces favoritos',
        loadChildren: () =>
          import('./bookmarks-management/bookmark-links/bookmark-links.module').then(m => m.BookmarkLinksModule),
        canActivate: [AuthGuard],
        data: { roles: ['admin'] }
      },
      {
        path: AdminDashboardRoutesIds.menusManagement,
        title: 'Gestión de menus',
        loadChildren: () => import('./menus-management/menu-management.module').then(m => m.MenuManagementModule),
        data: menuManagementModeConfig,
        canActivate: [AuthGuard]
      },
      {
        path: AdminDashboardRoutesIds.submenusManagement,
        title: 'Gestión de submenus',
        loadChildren: () => import('./menus-management/menu-management.module').then(m => m.MenuManagementModule),
        data: subMenuManagementModeConfig,
        canActivate: [AuthGuard]
      },
      {
        path: AdminDashboardRoutesIds.notificationsManagement,
        title: 'Gestión de notificaciones',
        loadChildren: () =>
          import('./notifications-management/notifications-management.module').then(
            m => m.NotificationsManagementModule
          ),
        data: { roles: ['admin'] },
        canActivate: [AuthGuard]
      },
      {
        path: AdminDashboardRoutesIds.chatbotLiteralsManagement,
        title: 'Gestión de literales',
        loadChildren: () =>
          import('./chatbot-literals-management/chatbot-literals-management.module').then(
            m => m.ChatbotLiteralsManagementModule
          ),
        data: { roles: ['admin'] },
        canActivate: [AuthGuard]
      },
      {
        path: AdminDashboardRoutesIds.dashboardManagement,
        title: 'Gestión de dashboard',
        loadChildren: () =>
          import('./dashboard-management/dashboard-management.module').then(m => m.DashboardManagementModule),
        data: { roles: ['admin'] },
        canActivate: [AuthGuard]
      },
      {
        path: AdminDashboardRoutesIds.usersManagement,
        title: 'Gestión de usuarios',
        loadChildren: () => import('./users-management/users-management.module').then(m => m.UsersManagementModule),
        data: { roles: ['admin'] },
        canActivate: [AuthGuard]
      },
      {
        path: AdminDashboardRoutesIds.proceduresManagement,
        title: 'Gestión de procedimientos',
        loadChildren: () =>
          import('./procedures-management/procedures-management.module').then(m => m.ProceduresManagementModule),
        data: { roles: ['admin'] },
        canActivate: [AuthGuard]
      }
      /* {
        path: AdminDashboardRoutesIds.aiqueriesManagement,
        title: 'Gestión de consultas',
        loadChildren: () =>
          import('./ai-queries-management/ai-queries-management.module').then(m => m.AiQueriesManagementModule),
        data: { roles: ['admin'] },
        canActivate: [AuthGuard]
      } */
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminDashboardPageRoutingModule {}
