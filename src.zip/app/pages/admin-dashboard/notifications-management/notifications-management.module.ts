import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatOptionModule } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectModule } from '@angular/material/select';
import { MatSortModule } from '@angular/material/sort';
import { MatTableModule } from '@angular/material/table';
import { MatTabsModule } from '@angular/material/tabs';
import { RouterModule, Routes } from '@angular/router';

import { PipesModule } from '../../../shared/pipes/pipes.module';

import { AddEditNotificationTypeComponent } from './components/add-edit-notification-type/add-edit-notification-type.component';
import { AddEditMessageComponent } from './components/notification-type-management/components/messages-management/components/add-edit-message/add-edit-message.component';
import { MessagesEmptyListComponent } from './components/notification-type-management/components/messages-management/components/messages-list/components/messages-empty-list/messages-empty-list.component';
import { MessagesListComponent } from './components/notification-type-management/components/messages-management/components/messages-list/messages-list.component';
import { MessagesManagementComponent } from './components/notification-type-management/components/messages-management/messages-management.component';
import { AddEditTimechannelComponent } from './components/notification-type-management/components/timechannels-management/components/add-edit-timechannel/add-edit-timechannel.component';
import { TimechannelsEmptyListComponent } from './components/notification-type-management/components/timechannels-management/components/timechannels-list/components/timechannels-empty-list/timechannels-empty-list.component';
import { TimechannelsListComponent } from './components/notification-type-management/components/timechannels-management/components/timechannels-list/timechannels-list.component';
import { TimechannelsManagementComponent } from './components/notification-type-management/components/timechannels-management/timechannels-management.component';
import { NotificationTypeManagementComponent } from './components/notification-type-management/notification-type-management.component';
import { NotificationTypesListComponent } from './components/notification-types-list/notification-types-list.component';
import { NotificationsManagementComponent } from './notifications-management.component';

const routes: Routes = [{ path: '', component: NotificationsManagementComponent }];

@NgModule({
  declarations: [
    NotificationsManagementComponent,
    AddEditNotificationTypeComponent,
    NotificationTypesListComponent,
    NotificationTypeManagementComponent,
    MessagesManagementComponent,
    TimechannelsManagementComponent,
    MessagesListComponent,
    MessagesEmptyListComponent,
    AddEditMessageComponent,
    TimechannelsListComponent,
    TimechannelsEmptyListComponent,
    AddEditTimechannelComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    ReactiveFormsModule,
    FormsModule,
    MatFormFieldModule,
    MatOptionModule,
    MatTableModule,
    MatInputModule,
    PipesModule,
    MatProgressSpinnerModule,
    MatPaginatorModule,
    MatFormFieldModule,
    MatCheckboxModule,
    MatSelectModule,
    MatIconModule,
    MatProgressSpinnerModule,
    MatButtonModule,
    MatTabsModule,
    MatSortModule
  ],
  exports: [
    ReactiveFormsModule,
    FormsModule,
    MatOptionModule,
    MatFormFieldModule,
    MatTableModule,
    MatInputModule,
    MatPaginatorModule,
    MatProgressSpinnerModule,
    MatFormFieldModule,
    MatCheckboxModule,
    MatSelectModule,
    MatIconModule,
    MatProgressSpinnerModule,
    MatButtonModule,
    MatTabsModule,
    MatSortModule
  ]
})
export class NotificationsManagementModule {}
