import { Subject, takeUntil } from 'rxjs';

import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute } from '@angular/router';

import { MAT_DIALOG_CLOSE_WITH_OK } from '../../../../app/core';
import { AddEditNotificationTypeComponent } from './components/add-edit-notification-type/add-edit-notification-type.component';
import { NotificationTypesListComponent } from './components/notification-types-list/notification-types-list.component';
import { NotificationTypeItem } from './models/notification.model';

@Component({
  selector: 'app-notifications-management',
  templateUrl: './notifications-management.component.html',
  styleUrls: ['./notifications-management.component.scss']
})
export class NotificationsManagementComponent implements OnInit, OnDestroy {
  @ViewChild('notificationTypesListComponentRef') notificationTypesListComponent: NotificationTypesListComponent;
  public isLoading = true;

  private readonly stopSubscriptionsNotifier = new Subject<void>();

  constructor(private readonly route: ActivatedRoute, private readonly dialog: MatDialog) {}

  public ngOnInit(): void {
    console.log('NotificationsManagementComponent', 'ngOnInit');
    this.isLoading = false;
  }

  public ngOnDestroy(): void {
    console.log('NotificationsManagementComponent', 'ngOnDestroy');
    this.stopSubscriptionsNotifier.next();
    this.stopSubscriptionsNotifier.complete();
  }

  public addNewNotificationType(): void {
    console.log('NotificationsManagementComponent', 'addNewNotificationType');
    this.showAddEditNotificationType();
  }

  private showAddEditNotificationType(notificationTypeDTO?: NotificationTypeItem): void {
    console.log('AddUpdateMenuService', 'showAddUpdateSubMenuUi');

    const modalUiConfig = {
      panelClass: 'default-modal',
      data: {
        item: notificationTypeDTO
      }
    };

    this.dialog
      .open(AddEditNotificationTypeComponent, {
        panelClass: 'default-modal',
        data: modalUiConfig
      })
      .afterClosed()
      .pipe(takeUntil(this.stopSubscriptionsNotifier))
      .subscribe({
        next: modalClosedResult => {
          if (modalClosedResult !== MAT_DIALOG_CLOSE_WITH_OK) {
            return;
          }
          console.log('BookmarkLinksComponent', 'addNewLink', 'create new link OK');
          void this.notificationTypesListComponent?.initializeState();
        }
      });
  }
}
