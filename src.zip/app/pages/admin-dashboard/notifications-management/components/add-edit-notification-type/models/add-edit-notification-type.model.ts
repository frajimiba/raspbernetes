import { NotificationTypeItem } from '../../../models/notification.model';

export interface AddEditInput {
  item: NotificationTypeItem;
}
