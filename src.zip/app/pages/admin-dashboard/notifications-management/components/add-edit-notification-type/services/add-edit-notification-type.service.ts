import { Injectable } from '@angular/core';

import { NotificationsApiService } from '../../../../../../../app/core';
import { toNotificationTypeEntryItem } from '../../../models/notification.mapper';
import { NotificationTypeEntryItem, NotificationTypeItem } from '../../../models/notification.model';

@Injectable({
  providedIn: 'root'
})
export class AddEditNotificationTypeService {
  constructor(private readonly notificationsApiService: NotificationsApiService) {}

  public async createNotificationType(notificationTypeItem: NotificationTypeItem): Promise<NotificationTypeEntryItem> {
    console.log('NotificationTypeService', 'createNotificationType');

    return this.notificationsApiService
      .createNotificationType({
        id: notificationTypeItem.id,
        description: notificationTypeItem.description
      })
      .then(item => toNotificationTypeEntryItem(item));
  }

  public async updateNotificationType(notificationTypeItem: NotificationTypeItem): Promise<NotificationTypeItem> {
    console.log('NotificationTypeService', 'updateNotificationType');

    return this.notificationsApiService
      .updateNotificationType(notificationTypeItem)
      .then(item => toNotificationTypeEntryItem(item));
  }
}
