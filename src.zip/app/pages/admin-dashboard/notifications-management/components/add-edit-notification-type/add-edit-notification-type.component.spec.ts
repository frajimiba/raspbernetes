import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditNotificationTypeComponent } from './add-edit-notification-type.component';

xdescribe('AddEditNotificationTypeComponent', () => {
  let component: AddEditNotificationTypeComponent;
  let fixture: ComponentFixture<AddEditNotificationTypeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AddEditNotificationTypeComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(AddEditNotificationTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
