import swal2 from 'sweetalert2';

import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

import { AddEditNotificationTypeService } from './services/add-edit-notification-type.service';

import { MAT_DIALOG_CLOSE_WITH_OK, MAT_DIALOG_CLOSE_WITHOUT_ACTIONS } from '../../../../../../app/core';
import { AddEditInput } from './models/add-edit-notification-type.model';

@Component({
  selector: 'app-add-edit-notification-type',
  templateUrl: './add-edit-notification-type.component.html',
  styleUrls: ['./add-edit-notification-type.component.scss']
})
export class AddEditNotificationTypeComponent implements OnInit {
  edit: boolean = false;
  isLoading: boolean = false;
  public form: FormGroup;

  constructor(
    private readonly formBuilder: FormBuilder,
    public readonly dialogRef: MatDialogRef<AddEditNotificationTypeComponent>,
    public readonly addEditNotificationTypeService: AddEditNotificationTypeService,
    @Inject(MAT_DIALOG_DATA) public readonly input: AddEditInput
  ) {}

  ngOnInit(): void {
    this.edit = this.input.item !== undefined;
    this.form = this.formBuilder.group({
      id: this.formBuilder.control(this.input.item?.id ?? ''),
      description: this.formBuilder.control(this.input.item?.description ?? '')
    });
  }

  public submitForm(): void {
    if (this.form.valid) {
      this.isLoading = true;
      this.edit ? this.submitUpdated() : this.submitNew();
    }
  }

  public submitNew(): void {
    this.addEditNotificationTypeService
      .createNotificationType({
        id: this.form.controls.id.value,
        description: this.form.controls.description.value
      })
      .then(async result => this.showCreateSuccessUi())
      .catch(async result => this.showCreateErrorUi());
  }

  public submitUpdated(): void {
    this.addEditNotificationTypeService
      .updateNotificationType({
        id: this.form.controls.id.value,
        description: this.form.controls.description.value
      })
      .then(async result => this.showUpdateSuccessUi())
      .catch(async result => this.showUpdateErrorUi());
  }

  public discardForm(): void {
    this.dialogRef.close(MAT_DIALOG_CLOSE_WITHOUT_ACTIONS);
  }

  public getTitle(): string {
    return this.edit ? 'Editar tipo de notificación' : 'Habilitar tipo de notificación';
  }

  private async showCreateSuccessUi(): Promise<void> {
    await swal2.fire(`Tipo de notificación habilitado`, `Se ha habilitado correctamente.`, 'success');
    this.dialogRef.close(MAT_DIALOG_CLOSE_WITH_OK);
  }

  private async showUpdateSuccessUi(): Promise<void> {
    await swal2.fire(`Tipo de notificación actualizado`, `Se ha actualizado correctamente.`, 'success');
    this.dialogRef.close(MAT_DIALOG_CLOSE_WITH_OK);
  }

  private showCreateErrorUi(): void {
    void swal2.fire(`Error inesperado`, `No se ha podido crear.`, 'error');
  }

  private showUpdateErrorUi(): void {
    void swal2.fire(`Error inesperado`, `No se ha podido actualizar.`, 'error');
  }
}
