import { TimeChannelDTO } from '../../../../../../../../core/api/api-client-library/model/timeChannelDTO';

export type TimeChannelItem = Readonly<Required<TimeChannelDTO>>;
