import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TimechannelsEmptyListComponent } from './timechannels-empty-list.component';

xdescribe('TimechannelsEmptyListComponent', () => {
  let component: TimechannelsEmptyListComponent;
  let fixture: ComponentFixture<TimechannelsEmptyListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [TimechannelsEmptyListComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(TimechannelsEmptyListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
