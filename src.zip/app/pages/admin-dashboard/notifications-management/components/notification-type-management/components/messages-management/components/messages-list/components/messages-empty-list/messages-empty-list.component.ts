import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-messages-empty-list',
  templateUrl: './messages-empty-list.component.html',
  styleUrls: ['./messages-empty-list.component.scss']
})
export class MessagesEmptyListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
