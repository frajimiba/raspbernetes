import swal2 from 'sweetalert2';

import { animate, state, style, transition, trigger } from '@angular/animations';
import { Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';

import { MessagesService } from './services/messages.service';

import { ZERO } from '../../../../../../../../../../app/core';
import { PaginatorModel } from '../../../../../../../../../../app/shared';
import { NotificationTypeItem } from '../../../../../../models/notification.model';
import { MessageItem } from '../../models/messages.model';

@Component({
  selector: 'app-messages-list',
  templateUrl: './messages-list.component.html',
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)'))
    ])
  ],
  styleUrls: ['./messages-list.component.scss']
})
export class MessagesListComponent implements OnInit {
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  @Input() notificationTypeItem: NotificationTypeItem;
  @Output() showEditItem: EventEmitter<MessageItem> = new EventEmitter();

  public isLoading = true;
  public paginatorModel: PaginatorModel;
  public numOfResults = ZERO;
  public expandedItem: MessageItem;

  public dataSource: MatTableDataSource<MessageItem> = new MatTableDataSource<MessageItem>();
  public columnsToDisplay: string[] = ['title', 'body', 'actions'];

  private readonly swalWithButtons = swal2.mixin({
    customClass: {
      confirmButton: 'btn btn-solid__success',
      cancelButton: 'btn btn-solid__danger'
    },
    buttonsStyling: false
  });

  constructor(private readonly messagesService: MessagesService) {
    console.log('MessagesListComponent', 'new instance');
  }

  ngOnInit(): void {
    console.log('MessagesListComponent', 'ngOnInit');
    this.initializeState();
  }

  public initializeState(): void {
    console.log('MessagesListComponent', 'initializeState');
    void this.messagesService
      .getMessagesByNotificationTypeId(this.notificationTypeItem.id)
      .then(items => this.onReceiveItems(items))
      .catch(error => this.onReceiveItemsError(error));
  }

  public applyFilter(event: Event): void {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  public sortChanged(): void {
    this.paginatorModel.sortCol = this.sort.active;
    this.paginatorModel.ascending = this.sort.direction === 'asc';
  }

  public pageChanged(event: any): void {
    this.paginatorModel.pageIndex = event.pageIndex;
    this.paginatorModel.size = event.pageSize;
  }

  public onReceiveItems(items: MessageItem[]): void {
    console.log('MessagesListComponent', 'onReceiveItems', items);
    this.isLoading = false;
    this.dataSource.data = items;
    this.dataSource.sort = this.sort;
    this.numOfResults = items.length;
    this.paginatorModel = {
      pageIndex: 0,
      ascending: true,
      size: items.length,
      sortCol: 'title'
    };
  }

  public onReceiveItemsError(error: any): void {
    console.error('MessagesListComponent', 'onReceiveItemsError', error);
    this.isLoading = false;
  }

  public showAskToDelete(item: MessageItem): void {
    this.swalWithButtons
      .fire({
        title: '¿Está seguro?',
        html: `¿Seguro que desea eliminar '${item.title}'?`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Si, eliminar!',
        cancelButtonText: 'No, cancelar!',
        reverseButtons: true
      })
      .then(result => {
        if (result.isConfirmed) {
          this.deleteMessage(item);
        }
      })
      .catch(error => {
        console.log(error);
      });
  }

  private deleteMessage(item: MessageItem): void {
    this.messagesService
      .deleteMessage(item.id)
      .then(async () => {
        await this.showDeleteSuccessUi();
        void this.initializeState();
      })
      .catch(async () => this.showDeleteErrorUi());
  }

  private async showDeleteSuccessUi(): Promise<void> {
    await swal2.fire(`Mensaje eliminado`, `Se ha eliminado correctamente.`, 'success');
  }

  private showDeleteErrorUi(): void {
    void swal2.fire(`Error inesperado`, `No se ha podido eliminar.`, 'error');
  }
}
