import { Injectable } from '@angular/core';

import { NotificationsApiService } from '../../../../../../../../../../../app/core';
import { toTimeChannelItem } from '../../../models/timechannels.mapper';
import { TimeChannelItem } from '../../../models/timechannels.model';

@Injectable({
  providedIn: 'root'
})
export class AddEditTimeChannelService {
  constructor(private readonly notificationsApiService: NotificationsApiService) {}

  public async createTimeChannel(notificationId: string, item: TimeChannelItem): Promise<TimeChannelItem> {
    console.log('AddEditTimeChannelService', 'createTimeChannel');
    return this.notificationsApiService.createTimeChannel(notificationId, item).then(item => toTimeChannelItem(item));
  }

  public async updateTimeChannel(messageId: number, item: TimeChannelItem): Promise<TimeChannelItem> {
    console.log('AddEditTimeChannelService', 'updateTimeChannel', item);
    return this.notificationsApiService.updateTimeChannel(messageId, item).then(item => toTimeChannelItem(item));
  }
}
