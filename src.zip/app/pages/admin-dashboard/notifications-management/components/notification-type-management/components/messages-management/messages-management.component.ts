import { Subject, takeUntil } from 'rxjs';
import swal2 from 'sweetalert2';

import { Component, Input, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';

import { MessagesService } from './components/messages-list/services/messages.service';

import { MAT_DIALOG_CLOSE_WITH_OK } from '../../../../../../../core/utils/prefix';
import { NotificationTypeItem } from '../../../../models/notification.model';
import { AddEditMessageComponent } from './components/add-edit-message/add-edit-message.component';
import { MessagesListComponent } from './components/messages-list/messages-list.component';
import { DEFAULT_ACCEPTED_MSG_VARS, MessageItem } from './models/messages.model';

@Component({
  selector: 'app-messages-management',
  templateUrl: './messages-management.component.html',
  styleUrls: ['./messages-management.component.scss']
})
export class MessagesManagementComponent implements OnInit, OnDestroy {
  @ViewChild('list') list: MessagesListComponent;
  @Input() notificationTypeItem: NotificationTypeItem;

  public messages: MessageItem[];
  public isLoading = false;

  public acceptedMessageVars = DEFAULT_ACCEPTED_MSG_VARS;

  private readonly stopSubscriptionsNotifier = new Subject<void>();

  constructor(private readonly dialog: MatDialog) {
    console.log('MessagesManagementComponent', 'new instance');
  }

  ngOnInit(): void {
    console.log('MessagesManagementComponent', 'ngOnInit');
  }

  public ngOnDestroy(): void {
    console.log('NotificationsManagementComponent', 'ngOnDestroy');
    this.stopSubscriptionsNotifier.next();
    this.stopSubscriptionsNotifier.complete();
  }

  public addNewMessage(): void {
    console.log('NotificationsManagementComponent', 'addNewMessage');
    this.showAddEditMessage(undefined);
  }

  public showAddEditMessage(messageItem?: MessageItem): void {
    console.log('NotificationsManagementComponent', 'showAddEditMessage');

    const modalUiConfig = {
      panelClass: 'default-modal',
      data: {
        item: messageItem,
        notificationId: this.notificationTypeItem.id
      }
    };

    this.dialog
      .open(AddEditMessageComponent, modalUiConfig)
      .afterClosed()
      .pipe(takeUntil(this.stopSubscriptionsNotifier))
      .subscribe({
        next: modalClosedResult => {
          if (modalClosedResult !== MAT_DIALOG_CLOSE_WITH_OK) {
            return;
          }
          console.log('MessagesComponent', 'addNewLink', 'create new link OK');
          void this.list.initializeState();
        }
      });
  }
}
