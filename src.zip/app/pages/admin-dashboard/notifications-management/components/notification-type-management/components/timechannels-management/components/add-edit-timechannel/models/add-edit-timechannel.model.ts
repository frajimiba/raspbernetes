import { TimeChannelItem } from '../../../models/timechannels.model';

export interface AddEditInput {
  item: TimeChannelItem;
  notificationId: string;
  disabledChannels: string[];
}
