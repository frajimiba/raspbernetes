import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-timechannels-empty-list',
  templateUrl: './timechannels-empty-list.component.html',
  styleUrls: ['./timechannels-empty-list.component.scss']
})
export class TimechannelsEmptyListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
