import { Subject, takeUntil } from 'rxjs';
import swal2 from 'sweetalert2';

import { Component, Input, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';

import { TimeChannelsService } from './components/timechannels-list/services/timechannels.service';

import { MAT_DIALOG_CLOSE_WITH_OK } from '../../../../../../../core/utils/prefix';
import { NotificationTypeItem } from '../../../../models/notification.model';
import { AddEditTimechannelComponent } from './components/add-edit-timechannel/add-edit-timechannel.component';
import { TimechannelsListComponent } from './components/timechannels-list/timechannels-list.component';
import { TimeChannelItem } from './models/timechannels.model';

export const MAX_CHANNELS = 4;

@Component({
  selector: 'app-timechannels-management',
  templateUrl: './timechannels-management.component.html',
  styleUrls: ['./timechannels-management.component.scss']
})
export class TimechannelsManagementComponent implements OnInit, OnDestroy {
  @ViewChild('list') list: TimechannelsListComponent;
  @Input() notificationTypeItem: NotificationTypeItem;

  showAddChannelBtn = true;

  private readonly swalWithButtons = swal2.mixin({
    customClass: {
      confirmButton: 'btn btn-solid__success',
      cancelButton: 'btn btn-solid__danger'
    },
    buttonsStyling: false
  });

  private readonly stopSubscriptionsNotifier = new Subject<void>();

  constructor(private readonly dialog: MatDialog, private readonly timeChannelsService: TimeChannelsService) {
    console.log('TimechannelsManagementComponent', 'new instance');
  }

  ngOnInit(): void {
    console.log('TimechannelsManagementComponent', 'ngOnInit');
    this.checkAddChannelBtn();
  }

  public ngOnDestroy(): void {
    console.log('NotificationsManagementComponent', 'ngOnDestroy');
    this.stopSubscriptionsNotifier.next();
    this.stopSubscriptionsNotifier.complete();
  }

  public checkAddChannelBtn(): void {
    console.log('NotificationsManagementComponent', 'checkAddChannelBtn');
    void this.timeChannelsService
      .getTimeChannelsByNotificationTypeId(this.notificationTypeItem.id)
      .then(items => items.length !== MAX_CHANNELS)
      .then(result => {
        console.log('NotificationsManagementComponent', 'showAddChannelBtn', result);
        this.showAddChannelBtn = result;
      });
  }

  public addNewChannel(): void {
    console.log('NotificationsManagementComponent', 'addNewChannel');
    this.showAddEditTimeChannel(undefined);
  }

  public showAddEditTimeChannel(timeChannelItem?: TimeChannelItem): void {
    console.log('NotificationsManagementComponent', 'showAddEditTimeChannel');

    const disabledChannels = this.generateDisabledChannels(timeChannelItem);

    const modalUiConfig = {
      panelClass: 'default-modal',
      data: {
        notificationId: this.notificationTypeItem.id,
        item: timeChannelItem,
        disabledChannels
      }
    };

    this.dialog
      .open(AddEditTimechannelComponent, modalUiConfig)
      .afterClosed()
      .pipe(takeUntil(this.stopSubscriptionsNotifier))
      .subscribe({
        next: modalClosedResult => {
          if (modalClosedResult !== MAT_DIALOG_CLOSE_WITH_OK) {
            return;
          }
          console.log('AddEditTimechannelComponent', 'addNewLink', 'create new link OK');
          void this.list.initializeState();
          this.checkAddChannelBtn();
        }
      });
  }

  public generateDisabledChannels(timeChannelItem?: TimeChannelItem): string[] {
    const result: string[] = [];
    this.list.dataSource.data.forEach(timeChannel => {
      if (timeChannelItem?.channel !== timeChannel.channel) {
        result.push(timeChannel.channel);
      }
    });
    return result;
  }
}
