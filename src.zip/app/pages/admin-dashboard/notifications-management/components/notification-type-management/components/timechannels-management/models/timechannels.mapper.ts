import { TimeChannelDTO } from '../../../../../../../../core/api/api-client-library/model/timeChannelDTO';
import { TimeChannelItem } from './timechannels.model';

export function toTimeChannelItem(item: TimeChannelDTO): TimeChannelItem {
  return {
    channel: item.channel ?? '',
    outTime: item.outTime ?? false,
    inTime: item.inTime ?? false,
    notificationId: item.notificationId ?? '',
    id: item.id ?? 0
  };
}
