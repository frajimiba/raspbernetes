import { MessageItem } from '../../../models/messages.model';

export interface AddEditInput {
  item: MessageItem;
  notificationId: string;
}
