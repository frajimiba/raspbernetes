import swal2 from 'sweetalert2';

import { animate, state, style, transition, trigger } from '@angular/animations';
import { Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';

import { TimeChannelsService } from './services/timechannels.service';

import { ZERO } from '../../../../../../../../../../app/core';
import { PaginatorModel } from '../../../../../../../../../../app/shared';
import { NotificationTypeItem } from '../../../../../../models/notification.model';
import { TimeChannelItem } from '../../models/timechannels.model';

@Component({
  selector: 'app-timechannels-list',
  templateUrl: './timechannels-list.component.html',
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)'))
    ])
  ],
  styleUrls: ['./timechannels-list.component.scss']
})
export class TimechannelsListComponent implements OnInit {
  @Input() notificationTypeItem: NotificationTypeItem;
  @Output() showEditItem: EventEmitter<TimeChannelItem> = new EventEmitter();
  @Output() itemDeleted: EventEmitter<TimeChannelItem> = new EventEmitter();

  @ViewChild(MatSort, { static: true }) sort: MatSort;
  public isLoading = true;
  public paginatorModel: PaginatorModel;
  public numOfResults = ZERO;
  public expandedItem: TimeChannelItem;

  public dataSource: MatTableDataSource<TimeChannelItem> = new MatTableDataSource<TimeChannelItem>();
  public columnsToDisplay: string[] = ['channel', 'inTime', 'outTime', 'actions'];

  private readonly swalWithButtons = swal2.mixin({
    customClass: {
      confirmButton: 'btn btn-solid__success',
      cancelButton: 'btn btn-solid__danger'
    },
    buttonsStyling: false
  });

  constructor(private readonly timeChannelsService: TimeChannelsService) {
    console.log('TimechannelsListComponent', 'new instance');
  }

  ngOnInit(): void {
    console.log('TimechannelsListComponent', 'ngOnInit');
    this.initializeState();
  }

  public initializeState(): void {
    void this.timeChannelsService
      .getTimeChannelsByNotificationTypeId(this.notificationTypeItem.id)
      .then(items => this.onReceiveItems(items));
  }

  public onReceiveItems(items: TimeChannelItem[]): void {
    this.isLoading = false;
    this.dataSource.data = items;
    this.dataSource.sort = this.sort;
    this.numOfResults = items.length;
    this.paginatorModel = {
      pageIndex: 0,
      ascending: true,
      size: items.length,
      sortCol: 'channel'
    };
  }

  public applyFilter(event: Event): void {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  public sortChanged(): void {
    this.paginatorModel.sortCol = this.sort.active;
    this.paginatorModel.ascending = this.sort.direction === 'asc';
  }

  public pageChanged(event: any): void {
    this.paginatorModel.pageIndex = event.pageIndex;
    this.paginatorModel.size = event.pageSize;
  }

  public editItem(item: TimeChannelItem): void {
    this.showEditItem.emit(item);
  }

  public showAskToDelete(item: TimeChannelItem): void {
    this.swalWithButtons
      .fire({
        title: '¿Está seguro?',
        html: `¿Seguro que desea deshabilitar '${item.channel}'?`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Si, deshabilitar!',
        cancelButtonText: 'No, cancelar!',
        reverseButtons: true
      })
      .then(result => {
        if (result.isConfirmed) {
          this.deleteMessage(item);
        }
      })
      .catch(error => {
        console.log(error);
      });
  }

  private deleteMessage(item: TimeChannelItem): void {
    this.timeChannelsService
      .deleteTimeChannel(item.id)
      .then(async result => {
        await this.showDeleteSuccessUi();
        void this.initializeState();
        this.itemDeleted.emit(item);
      })
      .catch(error => {
        console.error('TimechannelsListComponent', error);
        this.showDeleteErrorUi();
      });
  }

  private async showDeleteSuccessUi(): Promise<void> {
    await swal2.fire(`Canal deshabilitado`, `Se ha deshabilitado correctamente.`, 'success');
  }

  private showDeleteErrorUi(): void {
    void swal2.fire(`Error inesperado`, `No se ha podido deshabilitar.`, 'error');
  }
}
