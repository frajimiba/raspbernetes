import swal2 from 'sweetalert2';

import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

import { AddEditMessagesService } from './services/add-edit-message.service';

import {
  MAT_DIALOG_CLOSE_WITH_OK,
  MAT_DIALOG_CLOSE_WITHOUT_ACTIONS
} from '../../../../../../../../../core/utils/prefix';
import { DEFAULT_ACCEPTED_MSG_VARS } from '../../models/messages.model';
import { AddEditInput } from './models/add-edit-message.model';

@Component({
  selector: 'app-add-edit-message',
  templateUrl: './add-edit-message.component.html',
  styleUrls: ['./add-edit-message.component.scss']
})
export class AddEditMessageComponent implements OnInit {
  edit: boolean = false;
  isLoading: boolean = false;
  public form: FormGroup;

  public acceptedMessageVars = DEFAULT_ACCEPTED_MSG_VARS;
  public infoTeams = '(*) Para TEAMS el formato de URL es: [{varURL}]({varURL})';

  constructor(
    private readonly formBuilder: FormBuilder,
    public readonly dialogRef: MatDialogRef<AddEditMessageComponent>,
    public readonly addEditMessagesService: AddEditMessagesService,
    @Inject(MAT_DIALOG_DATA) public readonly input: AddEditInput
  ) {}

  ngOnInit(): void {
    this.edit = this.input.item !== undefined;
    this.form = this.formBuilder.group({
      title: this.formBuilder.control(this.input.item?.title ?? ''),
      body: this.formBuilder.control(this.input.item?.body ?? '')
    });
  }

  public submitForm(): void {
    if (this.form.valid) {
      this.isLoading = true;
      this.edit ? this.submitUpdated() : this.submitNew();
    }
  }

  public submitNew(): void {
    this.addEditMessagesService
      .createMessage(this.input.notificationId, {
        id: 0,
        title: this.form.controls.title.value,
        body: this.form.controls.body.value,
        notificationId: this.input.notificationId
      })
      .then(async result => this.showCreateSuccessUi())
      .catch(async result => this.showCreateErrorUi());
  }

  public submitUpdated(): void {
    this.addEditMessagesService
      .updateMessage(this.input.item.id, {
        id: this.input.item.id,
        title: this.form.controls.title.value,
        body: this.form.controls.body.value,
        notificationId: this.input.notificationId
      })
      .then(async result => this.showUpdateSuccessUi())
      .catch(async result => this.showUpdateErrorUi());
  }

  public discardForm(): void {
    this.dialogRef.close(MAT_DIALOG_CLOSE_WITHOUT_ACTIONS);
  }

  public getTitle(): string {
    return this.edit ? 'Editar plantilla' : 'Crear nueva plantilla';
  }

  private async showCreateSuccessUi(): Promise<void> {
    await swal2.fire(`Mensaje creado`, `Se ha creado correctamente.`, 'success');
    this.dialogRef.close(MAT_DIALOG_CLOSE_WITH_OK);
  }

  private async showUpdateSuccessUi(): Promise<void> {
    await swal2.fire(`Mensaje actualizado`, `Se ha actualizado correctamente.`, 'success');
    this.dialogRef.close(MAT_DIALOG_CLOSE_WITH_OK);
  }

  private showCreateErrorUi(): void {
    void swal2.fire(`Error inesperado`, `No se ha podido crear.`, 'error');
  }

  private showUpdateErrorUi(): void {
    void swal2.fire(`Error inesperado`, `No se ha podido actualizar.`, 'error');
  }
}
