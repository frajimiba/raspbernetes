import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TimechannelsManagementComponent } from './timechannels-management.component';

xdescribe('TimechannelsManagementComponent', () => {
  let component: TimechannelsManagementComponent;
  let fixture: ComponentFixture<TimechannelsManagementComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [TimechannelsManagementComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(TimechannelsManagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
