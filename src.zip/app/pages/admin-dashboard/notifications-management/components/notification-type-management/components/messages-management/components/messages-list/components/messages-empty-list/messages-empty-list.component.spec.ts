import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MessagesEmptyListComponent } from './messages-empty-list.component';

xdescribe('MessagesEmptyListComponent', () => {
  let component: MessagesEmptyListComponent;
  let fixture: ComponentFixture<MessagesEmptyListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [MessagesEmptyListComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(MessagesEmptyListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
