import { Injectable } from '@angular/core';

import { NotificationsApiService } from '../../../../../../../../../../../app/core/api/notifications-api/notifications-api.service';

import { toMessageItem } from '../../../models/messages.mapper';
import { MessageItem } from '../../../models/messages.model';

@Injectable({
  providedIn: 'root'
})
export class AddEditMessagesService {
  constructor(private readonly notificationsApiService: NotificationsApiService) {}

  public async createMessage(notificationId: string, item: MessageItem): Promise<MessageItem> {
    console.log('MessagesService', 'createMessage');
    return this.notificationsApiService.createMessage(notificationId, item).then(item => toMessageItem(item));
  }

  public async updateMessage(messageId: number, item: MessageItem): Promise<MessageItem> {
    console.log('MessagesService', 'updateMessage', item);
    return this.notificationsApiService.updateMessage(messageId, item).then(item => toMessageItem(item));
  }
}
