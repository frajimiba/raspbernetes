import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TimechannelsListComponent } from './timechannels-list.component';

xdescribe('TimechannelsListComponent', () => {
  let component: TimechannelsListComponent;
  let fixture: ComponentFixture<TimechannelsListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [TimechannelsListComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(TimechannelsListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
