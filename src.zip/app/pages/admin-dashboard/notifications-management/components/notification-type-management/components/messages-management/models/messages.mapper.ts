import { MessageDTO } from '../../../../../../../../core/api/api-client-library/model/messageDTO';
import { MessageItem } from './messages.model';

export function toMessageItem(item: MessageDTO): MessageItem {
  return {
    body: item.body ?? '',
    notificationId: item.notificationId ?? '',
    title: item.title ?? '',
    id: item.id ?? 0
  };
}
