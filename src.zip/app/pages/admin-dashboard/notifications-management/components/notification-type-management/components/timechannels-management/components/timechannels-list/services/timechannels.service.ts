import { Injectable } from '@angular/core';

import { NotificationsApiService } from '../../../../../../../../../../core/api/notifications-api/notifications-api.service';

import { toTimeChannelItem } from '../../../models/timechannels.mapper';
import { TimeChannelItem } from '../../../models/timechannels.model';

@Injectable({
  providedIn: 'root'
})
export class TimeChannelsService {
  constructor(private readonly notificationsApiService: NotificationsApiService) {}

  public async getTimeChannelsByNotificationTypeId(id: string): Promise<TimeChannelItem[]> {
    console.log('TimeChannelsService', 'getTimeChannelsByNotificationTypeId');
    return this.notificationsApiService
      .getTimeChannelsByNotificationTypeId(id)
      .then(items => items.map(item => toTimeChannelItem(item)))
      .catch(error => {
        console.error(error);
        return [];
      });
  }

  public async createTimeChannel(notificationId: string, item: TimeChannelItem): Promise<TimeChannelItem> {
    console.log('TimeChannelsService', 'createTimeChannel');
    return this.notificationsApiService.createTimeChannel(notificationId, item).then(item => toTimeChannelItem(item));
  }

  public async updateTimeChannel(messageId: number, item: TimeChannelItem): Promise<TimeChannelItem> {
    console.log('TimeChannelsService', 'updateTimeChannel', item);
    return this.notificationsApiService.updateTimeChannel(messageId, item).then(item => toTimeChannelItem(item));
  }

  public async deleteTimeChannel(messageId: number): Promise<void> {
    console.log('TimeChannelsService', 'deleteTimeChannel', messageId);
    return this.notificationsApiService.deleteTimeChannel(messageId);
  }
}
