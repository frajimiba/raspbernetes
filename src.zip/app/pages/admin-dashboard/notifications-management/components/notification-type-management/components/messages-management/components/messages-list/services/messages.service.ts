import { Injectable } from '@angular/core';

import { NotificationsApiService } from '../../../../../../../../../../core/api/notifications-api/notifications-api.service';

import { toMessageItem } from '../../../models/messages.mapper';
import { MessageItem } from '../../../models/messages.model';

@Injectable({
  providedIn: 'root'
})
export class MessagesService {
  constructor(private readonly notificationsApiService: NotificationsApiService) {}

  public async getMessagesByNotificationTypeId(id: string): Promise<MessageItem[]> {
    console.log('MessagesService', 'getMessagesByNotificationTypeId');
    return this.notificationsApiService
      .getMessagesByNotificationTypeId(id)
      .then(items => items.map(item => toMessageItem(item)))
      .catch(error => {
        console.error(error);
        return [];
      });
  }

  public async deleteMessage(messageId: number): Promise<void> {
    console.log('MessagesService', 'deleteMessage', messageId);
    return this.notificationsApiService.deleteMessage(messageId);
  }
}
