import { MessageDTO } from '../../../../../../../../core/api/api-client-library/model/messageDTO';

export type MessageItem = Readonly<Required<MessageDTO>>;

export const DEFAULT_ACCEPTED_MSG_VARS = [
  '{ticketId} - Identificador del ticket según la herramienta del cliente.',
  '{clientId} - Identificador o nombre del cliente.',
  '{assignedGroup} - Grupo resolutor asignado.',
  '{issueUrl} - URL de acceso a la incidencia.',
  '{title} - Título de la incidencia.',
  '{description} - Descripción de la incidencia.',
  '{severity} - Severidad de la incidencia.'
];
