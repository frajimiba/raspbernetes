import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditTimechannelComponent } from './add-edit-timechannel.component';

xdescribe('AddEditTimechannelComponent', () => {
  let component: AddEditTimechannelComponent;
  let fixture: ComponentFixture<AddEditTimechannelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AddEditTimechannelComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(AddEditTimechannelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
