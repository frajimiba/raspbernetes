import swal2 from 'sweetalert2';

import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

import { AddEditTimeChannelService } from './services/add-edit-timeschannel.service';

import { MAT_DIALOG_CLOSE_WITH_OK, MAT_DIALOG_CLOSE_WITHOUT_ACTIONS } from '../../../../../../../../../../app/core';
import { AddEditInput } from './models/add-edit-timechannel.model';

@Component({
  selector: 'app-add-edit-timechannel',
  templateUrl: './add-edit-timechannel.component.html',
  styleUrls: ['./add-edit-timechannel.component.scss']
})
export class AddEditTimechannelComponent implements OnInit {
  edit: boolean = false;
  isLoading: boolean = false;
  channelList: Array<{ value: string; name: string }>;

  public form: FormGroup;

  constructor(
    private readonly formBuilder: FormBuilder,
    public readonly dialogRef: MatDialogRef<AddEditTimechannelComponent>,
    public readonly addEditTimeChannelService: AddEditTimeChannelService,
    @Inject(MAT_DIALOG_DATA) public readonly input: AddEditInput
  ) {}

  ngOnInit(): void {
    console.log('AddEditTimechannelComponent', 'ngOnInit');
    this.edit = this.input.item !== undefined;
    this.form = this.formBuilder.group({
      channel: this.formBuilder.control(this.input.item?.channel ?? 'T'),
      inTime: this.formBuilder.control(this.input.item?.inTime ?? false),
      outTime: this.formBuilder.control(this.input.item?.outTime ?? false)
    });

    this.channelList = [
      { value: 'T', name: 'TEAMS' },
      { value: 'W', name: 'TWILIO' },
      { value: 'S', name: 'SLACK' },
      { value: 'E', name: 'EMAIL' }
    ];

    this.input.disabledChannels.forEach(disabledChannel => {
      const index = this.channelList.findIndex(channelListValue => channelListValue.value === disabledChannel);
      if (index !== -1) {
        this.channelList.splice(index, 1);
      }
    });
  }

  public submitForm(): void {
    if (this.form.valid) {
      this.isLoading = true;
      this.edit ? this.submitUpdated() : this.submitNew();
    }
  }

  public submitNew(): void {
    this.addEditTimeChannelService
      .createTimeChannel(this.input.notificationId, {
        id: 0,
        channel: this.form.controls.channel.value,
        outTime: this.form.controls.outTime.value,
        inTime: this.form.controls.inTime.value,
        notificationId: this.input.notificationId
      })
      .then(async result => this.showCreateSuccessUi())
      .catch(async result => this.showCreateErrorUi());
  }

  public submitUpdated(): void {
    this.addEditTimeChannelService
      .updateTimeChannel(this.input.item.id, {
        id: this.input.item.id,
        channel: this.form.controls.channel.value,
        outTime: this.form.controls.outTime.value,
        inTime: this.form.controls.inTime.value,
        notificationId: this.input.notificationId
      })
      .then(async result => this.showUpdateSuccessUi())
      .catch(async result => this.showUpdateErrorUi());
  }

  public discardForm(): void {
    this.dialogRef.close(MAT_DIALOG_CLOSE_WITHOUT_ACTIONS);
  }

  public getTitle(): string {
    return this.edit ? 'Editar canal' : 'Habilitar canal';
  }

  private async showCreateSuccessUi(): Promise<void> {
    await swal2.fire(`Canal habilitado`, `Se ha creado correctamente.`, 'success');
    this.dialogRef.close(MAT_DIALOG_CLOSE_WITH_OK);
  }

  private async showUpdateSuccessUi(): Promise<void> {
    await swal2.fire(`Canal actualizado`, `Se ha actualizado correctamente.`, 'success');
    this.dialogRef.close(MAT_DIALOG_CLOSE_WITH_OK);
  }

  private showCreateErrorUi(): void {
    void swal2.fire(`Error inesperado`, `No se ha podido crear.`, 'error');
  }

  private showUpdateErrorUi(): void {
    void swal2.fire(`Error inesperado`, `No se ha podido actualizar.`, 'error');
  }
}
