import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

import { NotificationTypeItem } from '../../models/notification.model';

@Component({
  selector: 'app-notification-type-management',
  templateUrl: './notification-type-management.component.html',
  styleUrls: ['./notification-type-management.component.scss']
})
export class NotificationTypeManagementComponent implements OnInit {
  @Input() notificationTypeItem: NotificationTypeItem;

  constructor() {
    console.log('NotificationTypeManagementComponent', 'new instance');
  }

  ngOnInit(): void {
    console.log('NotificationTypeManagementComponent', 'ngOnInit');
  }
}
