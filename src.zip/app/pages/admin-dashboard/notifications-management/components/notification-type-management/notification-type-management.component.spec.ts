import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NotificationTypeManagementComponent } from './notification-type-management.component';

xdescribe('NotificationTypeManagementComponent', () => {
  let component: NotificationTypeManagementComponent;
  let fixture: ComponentFixture<NotificationTypeManagementComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [NotificationTypeManagementComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(NotificationTypeManagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
