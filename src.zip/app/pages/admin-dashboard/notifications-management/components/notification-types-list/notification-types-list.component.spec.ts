import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MatDialogModule } from '@angular/material/dialog';

import { NotificationTypesListComponent } from './notification-types-list.component';

xdescribe('NotificationTypesListComponent', () => {
  let component: NotificationTypesListComponent;
  let fixture: ComponentFixture<NotificationTypesListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [NotificationTypesListComponent, MatDialogModule]
    }).compileComponents();

    fixture = TestBed.createComponent(NotificationTypesListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
