import { NotificationTypeDTO } from '../../../../core/api/api-client-library/model/notificationTypeDTO';
import { NotificationTypeEntry } from '../../../../core/api/api-client-library/model/notificationTypeEntry';

export type NotificationTypeItem = Readonly<Required<NotificationTypeDTO>>;

export type NotificationTypeEntryItem = Readonly<Required<NotificationTypeEntry>>;
