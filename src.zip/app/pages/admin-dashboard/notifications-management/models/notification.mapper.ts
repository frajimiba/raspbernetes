import { NotificationTypeDTO } from '../../../../core/api/api-client-library/model/notificationTypeDTO';
import { NotificationTypeEntry } from '../../../../core/api/api-client-library/model/notificationTypeEntry';
import { NotificationTypeItem } from './notification.model';

export function toNotificationTypeItem(item: NotificationTypeDTO): NotificationTypeItem {
  return {
    id: item.id ?? '',
    description: item.description ?? ''
  };
}

export function toNotificationTypeEntryItem(item: NotificationTypeEntry): NotificationTypeItem {
  return {
    id: item.id ?? '',
    description: item.description ?? ''
  };
}
