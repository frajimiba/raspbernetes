import { Injectable } from '@angular/core';

import { NotificationsApiService } from '../../../../core/api/notifications-api/notifications-api.service';

import { NotificationTypeEntry } from '../../../../core/api/api-client-library/model/notificationTypeEntry';
import { PaginatorModel } from '../../../../shared/models/paginator.model';
import { toNotificationTypeItem } from '../models/notification.mapper';
import { NotificationTypeItem } from '../models/notification.model';

@Injectable({
  providedIn: 'root'
})
export class NotificationTypesListService {
  constructor(private readonly notificationsApiService: NotificationsApiService) {}

  public async getNotificationTypes(paginatorModel: PaginatorModel): Promise<NotificationTypeItem[]> {
    console.log('NotificationTypesListService', 'getMenuConfigurations');
    return this.notificationsApiService
      .getNotificationTypes(
        paginatorModel.pageIndex,
        paginatorModel.size,
        paginatorModel.sortCol,
        paginatorModel.ascending
      )
      .then(items => items.map(item => toNotificationTypeItem(item)))
      .catch(error => {
        console.error(error);
        return [];
      });
  }

  public async updateNotificationType(item: NotificationTypeItem): Promise<NotificationTypeEntry> {
    console.log('NotificationTypesListService', 'updateNotificationType', item);
    return this.notificationsApiService.updateNotificationType(item);
  }

  public async deleteNotificationType(item: NotificationTypeItem): Promise<any> {
    console.log('NotificationTypesListService', 'deleteNotificationType', item);
    return this.notificationsApiService.deleteNotificationType(item);
  }
}
