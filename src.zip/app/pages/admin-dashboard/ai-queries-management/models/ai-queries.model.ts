import { LiteralDTO, LiteralEntry } from '../../../../../app/core';

export type AiQueryItem = Readonly<Required<LiteralDTO>>;

export type AiQueryEntryItem = Readonly<Required<LiteralEntry>>;
