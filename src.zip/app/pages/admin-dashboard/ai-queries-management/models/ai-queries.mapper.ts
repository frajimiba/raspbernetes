import { LiteralDTO, LiteralEntry } from '../../../../../app/core';
import { AiQueryItem } from './ai-queries.model';

export function toAiQueryItem(item: LiteralDTO): AiQueryItem {
  return {
    id: item.id ?? '',
    description: item.description ?? '',
    title: item.title ?? ''
  };
}

export function toAiQueryEntryItem(id: string, item: LiteralEntry): AiQueryItem {
  return {
    id,
    description: item.description ?? '',
    title: item.title ?? ''
  };
}
