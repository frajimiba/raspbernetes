import { PagedResultLiteralDTO } from '../../../../../app/core';
import { AiQueryItem } from './ai-queries.model';

export type PagedChabotLiterals = Readonly<
  Required<Omit<PagedResultLiteralDTO, 'content'> & { content: AiQueryItem[] }>
>;
