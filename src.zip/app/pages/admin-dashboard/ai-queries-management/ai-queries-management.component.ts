import { Subject, takeUntil } from 'rxjs';

import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute } from '@angular/router';

import { MAT_DIALOG_CLOSE_WITH_OK } from '../../../../app/core';
import { AddEditAiQueriesComponent } from './components/add-edit-ai-queries/add-edit-ai-queries.component';
import { AiQueriesListComponent } from './components/ai-queries-list/ai-queries-list.component';
import { AiQueryItem } from './models/ai-queries.model';

@Component({
  selector: 'app-ai-queries-management',
  templateUrl: './ai-queries-management.component.html',
  styleUrls: ['./ai-queries-management.component.scss']
})
export class AiQueriesManagementComponent implements OnInit, OnDestroy {
  @ViewChild('aiQueriesListComponentRef') aiQueriesListComponent: AiQueriesListComponent;
  public isLoading = true;

  private readonly stopSubscriptionsNotifier = new Subject<void>();

  constructor(private readonly route: ActivatedRoute, private readonly dialog: MatDialog) {}

  public ngOnInit(): void {
    console.log('NotificationsManagementComponent', 'ngOnInit');
    this.isLoading = false;
  }

  public ngOnDestroy(): void {
    console.log('NotificationsManagementComponent', 'ngOnDestroy');
    this.stopSubscriptionsNotifier.next();
    this.stopSubscriptionsNotifier.complete();
  }

  public addNewAiQuery(): void {
    console.log('NotificationsManagementComponent', 'addNewAiQuery');
    this.showAddEditLiteral();
  }

  private showAddEditLiteral(dto?: AiQueryItem): void {
    console.log('AddUpdateMenuService', 'showAddUpdateSubMenuUi');

    const modalUiConfig = {
      panelClass: 'default-modal',
      data: {
        item: dto
      }
    };

    this.dialog
      .open(AddEditAiQueriesComponent, {
        panelClass: 'default-modal',
        data: modalUiConfig
      })
      .afterClosed()
      .pipe(takeUntil(this.stopSubscriptionsNotifier))
      .subscribe({
        next: modalClosedResult => {
          if (modalClosedResult !== MAT_DIALOG_CLOSE_WITH_OK) {
            return;
          }
          console.log('BookmarkLinksComponent', 'addNewLink', 'create new link OK');
          void this.aiQueriesListComponent?.initializeState();
        }
      });
  }
}
