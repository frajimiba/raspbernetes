import { Subject, takeUntil } from 'rxjs';
import swal2 from 'sweetalert2';

import { animate, state, style, transition, trigger } from '@angular/animations';
import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSort, Sort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';

import { AiQueriesListService } from '../../services/ai-queries-list.service';

import { LoadingService, MAT_DIALOG_CLOSE_WITH_OK, ZERO } from '../../../../../../app/core';
import { PaginatorModel } from '../../../../../../app/shared';
import { PagedChabotLiterals } from '../../models/ai-queries-list.model';
import { AiQueryItem } from '../../models/ai-queries.model';
import { AddEditAiQueriesComponent } from '../add-edit-ai-queries/add-edit-ai-queries.component';

const LOG_TAG = 'AiQueriesListComponent';

@Component({
  selector: 'app-ai-queries-list',
  templateUrl: './ai-queries-list.component.html',
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)'))
    ])
  ],
  styleUrls: ['./ai-queries-list.component.scss']
})
export class AiQueriesListComponent implements OnInit, OnDestroy {
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  public isLoading = true;
  public paginatorModel: PaginatorModel;
  public numOfResults = ZERO;

  public items: AiQueryItem[];
  public dataSource: MatTableDataSource<AiQueryItem>;
  public columnsToDisplay: string[] = ['id', 'title', 'description', 'actions'];
  public expandedItem: AiQueryItem | undefined;

  private readonly swalWithButtons = swal2.mixin({
    customClass: {
      confirmButton: 'btn btn-solid__success',
      cancelButton: 'btn btn-solid__danger'
    },
    buttonsStyling: false
  });

  private readonly stopSubscriptionsNotifier = new Subject<void>();

  constructor(
    private readonly dialog: MatDialog,
    private readonly aiQueriesListService: AiQueriesListService,
    private readonly loadingService: LoadingService
  ) {}

  public ngOnInit(): void {
    console.log(`${LOG_TAG}`, 'ngOnInit');
    this.setInitialPaginatorConfig();
    void this.initializeState();
  }

  public ngOnDestroy(): void {
    console.log(`${LOG_TAG}`, 'ngOnDestroy');
    this.stopSubscriptionsNotifier.next();
    this.stopSubscriptionsNotifier.complete();
  }

  public async initializeState(): Promise<void> {
    console.log(`${LOG_TAG}`, 'initializeState');
    this.startLoading();
    this.getAllLinks();
  }

  public editItem(item: AiQueryItem): void {
    this.openUpdateItemModal(item);
  }

  public askToDeleteItem(item: AiQueryItem): void {
    this.swalWithButtons
      .fire({
        title: '¿Está seguro?',
        html: `¿Seguro que desea eliminar '${item.id}'?`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Si, eliminar!',
        cancelButtonText: 'No, cancelar!',
        reverseButtons: true
      })
      .then(result => {
        if (result.isConfirmed) {
          this.deleteItem(item);
        }
      })
      .catch(error => {
        console.log(error);
      });
  }

  public applyFilter(event: Event): void {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  public sortChanged(event: Sort): void {
    this.paginatorModel.sortCol = event.active;
    this.paginatorModel.ascending = event.direction === 'asc';
    this.getAllLinks();
  }

  public pageChanged(event: any): void {
    this.paginatorModel.pageIndex = event.pageIndex;
    this.paginatorModel.size = event.pageSize;
    this.getAllLinks();
  }

  private getAllLinks(): void {
    this.aiQueriesListService
      .getAiQueries(this.paginatorModel)
      .then((items: PagedChabotLiterals) => this.onGetListOK(items))
      .catch(error => this.onGetListKO(error))
      .finally(() => this.stopLoading());
  }

  private onGetListOK(result: PagedChabotLiterals): void {
    this.items = result.content;
    this.dataSource = new MatTableDataSource<AiQueryItem>(this.items);
    this.dataSource.sort = this.sort;
    this.numOfResults = result.content.length;
  }

  private onGetListKO(error: any): void {
    console.error(`${LOG_TAG} - No ha sido posible recuperar los enlaces`, error);
    void swal2.fire('Error recuperando los enlaces', `No ha sido posible recuperar los enlaces`, 'error');
  }

  private deleteItem(item: AiQueryItem): void {
    this.loadingService.setLoadingState(true);
    this.aiQueriesListService
      .deleteAiQuery(item)
      .then(() => {
        this.itemDeleted(item.id);
      })
      .catch(() => {
        void swal2.fire('Error inesperado!', 'No se ha podido eliminar el enlace', 'error');
      })
      .finally(() => this.loadingService.setLoadingState(false));
  }

  private itemDeleted(itemName: string): void {
    void swal2.fire('Eliminado!', `'${itemName}' eliminado con éxito.`, 'success').then(result => {
      if (result.isConfirmed) {
        this.getAllLinks();
      }
    });
  }

  private openUpdateItemModal(item: AiQueryItem): void {
    this.dialog
      .open(AddEditAiQueriesComponent, {
        panelClass: 'default-modal',
        data: {
          item
        }
      })
      .afterClosed()
      .pipe(takeUntil(this.stopSubscriptionsNotifier))
      .subscribe({
        next: modalClosedResult => {
          if (modalClosedResult !== MAT_DIALOG_CLOSE_WITH_OK) {
            return;
          }
          console.log(LOG_TAG, 'openUpdateItemModal OK');
          void this.initializeState();
        }
      });
  }

  private setInitialPaginatorConfig(): void {
    this.paginatorModel = {
      pageIndex: 0,
      size: 50,
      ascending: true,
      sortCol: 'id'
    };
  }

  private startLoading(): void {
    this.isLoading = true;
  }

  private stopLoading(): void {
    this.isLoading = false;
  }
}
