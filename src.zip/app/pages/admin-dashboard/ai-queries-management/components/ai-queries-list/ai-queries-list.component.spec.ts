import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AiQueriesListComponent } from './ai-queries-list.component';

xdescribe('AiQueriesListComponent', () => {
  let component: AiQueriesListComponent;
  let fixture: ComponentFixture<AiQueriesListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AiQueriesListComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(AiQueriesListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
