import { AiQueryItem } from '../../../models/ai-queries.model';

export interface AddEditInput {
  item: AiQueryItem;
}
