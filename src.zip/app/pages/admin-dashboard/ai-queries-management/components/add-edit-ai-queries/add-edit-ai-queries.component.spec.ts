import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditAiQueriesComponent } from './add-edit-ai-queries.component';

xdescribe('AddEditAiQueriesComponent', () => {
  let component: AddEditAiQueriesComponent;
  let fixture: ComponentFixture<AddEditAiQueriesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AddEditAiQueriesComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(AddEditAiQueriesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
