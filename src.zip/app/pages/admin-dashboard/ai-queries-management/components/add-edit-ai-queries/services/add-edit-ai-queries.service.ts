import { Injectable } from '@angular/core';

import { AiQueriesApiService } from '../../../../../../core/api/ai-queries-api/ai-queries-api.service';

import { toAiQueryItem } from '../../../models/ai-queries.mapper';
import { AiQueryItem } from '../../../models/ai-queries.model';

@Injectable({
  providedIn: 'root'
})
export class AddEditAiQueriesService {
  constructor(private readonly aiQueriesApiService: AiQueriesApiService) {}

  public async createAiQueries(item: AiQueryItem): Promise<AiQueryItem> {
    console.log('AiQueriesService', 'createAiQueries');

    return this.aiQueriesApiService
      .createAiQuery({
        id: item.id,
        title: item.title,
        description: item.description
      })
      .then(item => toAiQueryItem(item));
  }

  public async updateAiQueries(item: AiQueryItem): Promise<AiQueryItem> {
    console.log('AiQueriesService', 'updateAiQueries');
    return this.aiQueriesApiService.updateAiQuery(item.id, item).then(item => toAiQueryItem(item));
  }
}
