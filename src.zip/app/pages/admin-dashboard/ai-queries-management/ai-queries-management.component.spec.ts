import { CommonModule } from '@angular/common';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatOptionModule } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectModule } from '@angular/material/select';
import { MatSortModule } from '@angular/material/sort';
import { MatTableModule } from '@angular/material/table';
import { MatTabsModule } from '@angular/material/tabs';

import { PipesModule } from '../../../../app/shared';
import { AiQueriesManagementComponent } from './ai-queries-management.component';

xdescribe('AiQueriesManagementComponent', () => {
  let component: AiQueriesManagementComponent;
  let fixture: ComponentFixture<AiQueriesManagementComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AiQueriesManagementComponent],
      imports: [
        CommonModule,
        ReactiveFormsModule,
        FormsModule,
        MatFormFieldModule,
        MatOptionModule,
        MatTableModule,
        MatInputModule,
        PipesModule,
        MatProgressSpinnerModule,
        MatPaginatorModule,
        MatFormFieldModule,
        MatCheckboxModule,
        MatSelectModule,
        MatIconModule,
        MatProgressSpinnerModule,
        MatButtonModule,
        MatTabsModule,
        MatSortModule
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(AiQueriesManagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
