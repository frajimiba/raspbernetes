import { Injectable } from '@angular/core';

import { AiQueriesApiService } from '../../../../../app/core';
import { PaginatorModel } from '../../../../shared/models/paginator.model';
import { PagedChabotLiterals } from '../models/ai-queries-list.model';
import { toAiQueryItem } from '../models/ai-queries.mapper';
import { AiQueryItem } from '../models/ai-queries.model';

@Injectable({
  providedIn: 'root'
})
export class AiQueriesListService {
  constructor(private readonly aiQueriesApiService: AiQueriesApiService) {}

  public async getAiQueries(paginatorModel: PaginatorModel): Promise<PagedChabotLiterals> {
    console.log('AiQueryListService', 'getMenuConfigurations');
    return this.aiQueriesApiService
      .getAiQueries({
        page: paginatorModel.pageIndex,
        size: paginatorModel.size,
        sort: paginatorModel.sortCol,
        ascending: paginatorModel.ascending
      })
      .then(items => {
        return {
          content: items.content?.map(contentItem => toAiQueryItem(contentItem)) ?? [],
          index: items.index ?? 0,
          size: items.size ?? 0,
          totalCount: items.totalCount ?? 0
        };
      })
      .catch(error => {
        console.error(error);
        return {
          content: [],
          index: 0,
          size: 0,
          totalCount: 0
        };
      });
  }

  public async updateAiQuery(item: AiQueryItem): Promise<AiQueryItem> {
    console.log('AiQueryListService', 'updateAiQuery', item);
    return this.aiQueriesApiService.updateAiQuery(item.id, item).then(item => toAiQueryItem(item));
  }

  public async deleteAiQuery(item: AiQueryItem): Promise<any> {
    console.log('AiQueryListService', 'deleteAiQuery', item);
    return this.aiQueriesApiService.deleteAiQuery(item.id);
  }
}
