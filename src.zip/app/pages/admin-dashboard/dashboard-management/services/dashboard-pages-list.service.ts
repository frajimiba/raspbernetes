import { Injectable } from '@angular/core';

import { DashboardApiService } from '../../../../../app/core/api/dashboard-api/dashboard-api.service';

import { ClassificationsGroupsClientsEntry } from '../../../../../app/core';
import { PaginatorModel } from '../../../../shared/models/paginator.model';
import { toDashboardPageItem } from '../models/dashboard-page-item.mapper';
import { DashboardPageItem } from '../models/dashboard-page-item.model';
import { PagedDashboardPages } from '../models/dashboard-page-list.model';

@Injectable({
  providedIn: 'root'
})
export class DashboardPagesListService {
  constructor(private readonly chatbotLiteralsApiService: DashboardApiService) {}

  public async getDashboardPages(
    paginatorModel: PaginatorModel,
    classification: ClassificationsGroupsClientsEntry
  ): Promise<PagedDashboardPages> {
    console.log('DashboardPageListService', 'getMenuConfigurations');
    return this.chatbotLiteralsApiService
      .getAllPages(
        {
          pageIndex: paginatorModel.pageIndex,
          size: paginatorModel.size,
          sortCol: paginatorModel.sortCol,
          ascending: paginatorModel.ascending
        },
        classification
      )
      .then(items => {
        return {
          content: items.content?.map(contentItem => toDashboardPageItem(contentItem)) ?? [],
          index: items.index ?? 0,
          size: items.size ?? 0,
          totalCount: items.totalCount ?? 0
        };
      })
      .catch(error => {
        console.error(error);
        return {
          content: [],
          index: 0,
          size: 0,
          totalCount: 0
        };
      });
  }

  public async updateDashboardPage(item: DashboardPageItem): Promise<void> {
    console.log('DashboardPageListService', 'updateDashboardPage', item);
    return this.chatbotLiteralsApiService.updateDashboardPage(item.id, item);
  }

  public async deleteDashboardPage(item: DashboardPageItem): Promise<any> {
    console.log('DashboardPageListService', 'deleteDashboardPage', item);
    return this.chatbotLiteralsApiService.deleteDashboardPage(item.id);
  }
}
