import { Injectable } from '@angular/core';

import { DashboardApiService } from '../../../../../../../app/core';
import { DashboardPageItem } from '../../../models/dashboard-page-item.model';

@Injectable({
  providedIn: 'root'
})
export class AddEditDashboardPageService {
  constructor(private readonly dashboardApiService: DashboardApiService) {}

  public async createDashboardPages(item: DashboardPageItem): Promise<void> {
    console.log('DashboardPagesService', 'createDashboardPages');
    return this.dashboardApiService.createDashboardPage(item);
  }

  public async updateDashboardPages(item: DashboardPageItem): Promise<void> {
    console.log('DashboardPagesService', 'updateDashboardPages');
    return this.dashboardApiService.updateDashboardPage(item.id, item);
  }
}
