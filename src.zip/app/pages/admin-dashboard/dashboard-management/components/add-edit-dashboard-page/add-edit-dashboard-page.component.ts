import { Editor, Toolbar } from 'ngx-editor';
import swal2 from 'sweetalert2';

import { Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

import { AddEditDashboardPageService } from './services/add-edit-dashboard-page.service';

import {
  KeycloakGroupEntry,
  MAT_DIALOG_CLOSE_WITH_OK,
  MAT_DIALOG_CLOSE_WITHOUT_ACTIONS,
  NGX_TOOLBAR_CONFIG
} from '../../../../../../app/core';
import { AddEditInput } from './models/add-edit-dashboard-page.model';

@Component({
  selector: 'app-add-edit-dashboard-page',
  templateUrl: './add-edit-dashboard-page.component.html',
  styleUrls: ['./add-edit-dashboard-page.component.scss']
})
export class AddEditDashboardPageComponent implements OnInit, OnDestroy {
  edit: boolean = false;
  isLoading: boolean = false;
  public form: FormGroup;
  public classificationId: string;
  public toolbar: Toolbar = NGX_TOOLBAR_CONFIG;
  public editor: Editor;
  private classificationSelected: KeycloakGroupEntry;

  constructor(
    private readonly formBuilder: FormBuilder,
    public readonly dialogRef: MatDialogRef<AddEditDashboardPageComponent>,
    public readonly addEditDashboardPageService: AddEditDashboardPageService,
    @Inject(MAT_DIALOG_DATA) public readonly input: AddEditInput
  ) {}

  ngOnInit(): void {
    this.edit = this.input.item !== undefined;
    this.editor = new Editor();
    this.initForm();
    if (this.edit) {
      this.form.controls.id.disable();
    }
  }

  public ngOnDestroy(): void {
    this.editor.destroy();
  }

  public onClassificationGroupSelected(classificationGroup: KeycloakGroupEntry): void {
    this.classificationId = classificationGroup?.id ?? '';
    this.classificationSelected = classificationGroup;
  }

  public submitForm(): void {
    if (this.form.valid) {
      this.isLoading = true;
      this.edit ? this.submitUpdated() : this.submitNew();
    }
  }

  public submitNew(): void {
    this.addEditDashboardPageService
      .createDashboardPages({
        id: this.form.controls.id.value,
        position: this.form.controls.position.value,
        name: this.form.controls.name.value,
        content: this.form.controls.content.value,
        roles: this.form.controls.roles.value.join(', '),
        active: this.form.controls.active.value,
        client: this.form.controls.client.value,
        group: this.form.controls.group.value,
        classification: this.form.controls.classification.value,
        ingestedAt: this.form.controls.ingestedAt.value,
        modifiedAt: this.form.controls.modifiedAt.value
      })
      .then(async result => this.showCreateSuccessUi())
      .catch(async result => this.showCreateErrorUi());
  }

  public submitUpdated(): void {
    this.addEditDashboardPageService
      .updateDashboardPages({
        id: this.form.controls.id.value,
        position: this.form.controls.position.value,
        name: this.form.controls.name.value,
        content: this.form.controls.content.value,
        roles: this.form.controls.roles.value.join(', '),
        active: this.form.controls.active.value,
        client: this.form.controls.client.value,
        group: this.form.controls.group.value,
        classification: this.form.controls.classification.value,
        ingestedAt: this.form.controls.ingestedAt.value,
        modifiedAt: this.form.controls.modifiedAt.value
      })
      .then(async result => this.showUpdateSuccessUi())
      .catch(async result => this.showUpdateErrorUi());
  }

  public discardForm(): void {
    this.dialogRef.close(MAT_DIALOG_CLOSE_WITHOUT_ACTIONS);
  }

  public getTitle(): string {
    return this.edit ? 'Editar página' : 'Agregar página';
  }

  private initForm(): void {
    this.form = this.formBuilder.group({
      id: [this.input?.item?.id ?? 0],
      position: [this.input?.item?.position ?? 0],
      name: [this.input?.item?.name ?? '', Validators.required],
      content: [this.input?.item?.content ?? '', Validators.required],
      roles: [this.splitRoles(this.input?.item?.roles) ?? ''],
      active: [this.input?.item?.active ?? false],
      client: [this.input?.item?.client ?? ''],
      group: [this.input?.item?.group ?? ''],
      classification: [this.input?.item?.classification ?? ''],
      ingestedAt: [this.input?.item?.ingestedAt ?? ''],
      modifiedAt: [this.input?.item?.modifiedAt ?? '']
    });
  }

  private async showCreateSuccessUi(): Promise<void> {
    await swal2.fire(`Página de dashboard creada`, `Se ha creado correctamente.`, 'success');
    this.dialogRef.close(MAT_DIALOG_CLOSE_WITH_OK);
  }

  private async showUpdateSuccessUi(): Promise<void> {
    await swal2.fire(`Página de dashboard actualizada`, `Se ha actualizado correctamente.`, 'success');
    this.dialogRef.close(MAT_DIALOG_CLOSE_WITH_OK);
  }

  private showCreateErrorUi(): void {
    void swal2.fire(`Error inesperado`, `No se ha podido crear.`, 'error');
  }

  private showUpdateErrorUi(): void {
    void swal2.fire(`Error inesperado`, `No se ha podido actualizar.`, 'error');
  }

  private splitRoles(roles: string): string[] {
    return roles && roles !== '' ? roles.split(',') : [''];
  }
}
