import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditDashboardPageComponent } from './add-edit-dashboard-page.component';

xdescribe('AddEditDashboardPageComponent', () => {
  let component: AddEditDashboardPageComponent;
  let fixture: ComponentFixture<AddEditDashboardPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AddEditDashboardPageComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(AddEditDashboardPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
