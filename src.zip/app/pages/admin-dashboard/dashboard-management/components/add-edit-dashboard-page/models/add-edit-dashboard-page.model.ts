import { DashboardPageItem } from '../../../models/dashboard-page-item.model';

export interface AddEditInput {
  item: DashboardPageItem;
}
