import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DashboardPagesListComponent } from './dashboard-pages-list.component';

xdescribe('DashboardPagesListComponent', () => {
  let component: DashboardPagesListComponent;
  let fixture: ComponentFixture<DashboardPagesListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [DashboardPagesListComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(DashboardPagesListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
