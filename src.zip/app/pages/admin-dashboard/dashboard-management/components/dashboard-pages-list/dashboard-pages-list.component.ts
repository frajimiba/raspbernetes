import { Subject, takeUntil } from 'rxjs';
import swal2 from 'sweetalert2';

import { animate, state, style, transition, trigger } from '@angular/animations';
import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSort, Sort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';

import { DashboardPagesListService } from '../../services/dashboard-pages-list.service';

import {
  ClassificationsGroupsClientsEntry,
  LoadingService,
  MAT_DIALOG_CLOSE_WITH_OK,
  ZERO
} from '../../../../../../app/core';
import { PaginatorModel } from '../../../../../../app/shared';
import { DashboardPageItem } from '../../models/dashboard-page-item.model';
import { PagedDashboardPages } from '../../models/dashboard-page-list.model';
import { AddEditDashboardPageComponent } from '../add-edit-dashboard-page/add-edit-dashboard-page.component';

const LOG_TAG = 'DashboardPagesListComponent';

@Component({
  selector: 'app-dashboard-pages-list',
  templateUrl: './dashboard-pages-list.component.html',
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)'))
    ])
  ],
  styleUrls: ['./dashboard-pages-list.component.scss']
})
export class DashboardPagesListComponent implements OnInit, OnDestroy {
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  public isLoading = true;
  public paginatorModel: PaginatorModel;
  public numOfResults = ZERO;

  public items: DashboardPageItem[];
  public dataSource: MatTableDataSource<DashboardPageItem>;
  public columnsToDisplay: string[] = ['position', 'name', 'actions'];
  public expandedItem: DashboardPageItem | undefined;

  private readonly swalWithButtons = swal2.mixin({
    customClass: {
      confirmButton: 'btn btn-solid__success',
      cancelButton: 'btn btn-solid__danger'
    },
    buttonsStyling: false
  });

  private readonly stopSubscriptionsNotifier = new Subject<void>();

  private classificationsGroupsClientsEntry: ClassificationsGroupsClientsEntry;

  constructor(
    private readonly dialog: MatDialog,
    private readonly dashboardPagesService: DashboardPagesListService,
    private readonly loadingService: LoadingService
  ) {}

  public ngOnInit(): void {
    console.log(`${LOG_TAG}`, 'ngOnInit');
    this.setInitialPaginatorConfig();
    this.setDeultClassificationsGroupsClientsEntryConfig();
    void this.initializeState();
  }

  public ngOnDestroy(): void {
    console.log(`${LOG_TAG}`, 'ngOnDestroy');
    this.stopSubscriptionsNotifier.next();
    this.stopSubscriptionsNotifier.complete();
  }

  public async initializeState(): Promise<void> {
    console.log(`${LOG_TAG}`, 'initializeState');
    this.startLoading();
    this.getAllLinks();
  }

  public setSearchCombos(classificationsGroupsClientsEntry: ClassificationsGroupsClientsEntry): void {
    this.classificationsGroupsClientsEntry = classificationsGroupsClientsEntry;
  }

  public editItem(item: DashboardPageItem): void {
    this.openUpdateItemModal(item);
  }

  public askToDeleteItem(item: DashboardPageItem): void {
    this.swalWithButtons
      .fire({
        title: '¿Está seguro?',
        html: `¿Seguro que desea eliminar '${item.id}'?`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Si, eliminar!',
        cancelButtonText: 'No, cancelar!',
        reverseButtons: true
      })
      .then(result => {
        if (result.isConfirmed) {
          this.deleteItem(item);
        }
      })
      .catch(error => {
        console.log(error);
      });
  }

  public applyFilter(event: Event): void {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  public sortChanged(event: Sort): void {
    this.paginatorModel.sortCol = event.active;
    this.paginatorModel.ascending = event.direction === 'asc';
    this.getAllLinks();
  }

  public pageChanged(event: any): void {
    this.paginatorModel.pageIndex = event.pageIndex;
    this.paginatorModel.size = event.pageSize;
    this.getAllLinks();
  }

  private setDeultClassificationsGroupsClientsEntryConfig(): void {
    this.classificationsGroupsClientsEntry = {
      groups: [],
      clients: [],
      classifications: []
    };
  }

  private getAllLinks(): void {
    this.dashboardPagesService
      .getDashboardPages(this.paginatorModel, this.classificationsGroupsClientsEntry)
      .then((items: PagedDashboardPages) => this.onGetListOK(items))
      .catch(error => this.onGetListKO(error))
      .finally(() => this.stopLoading());
  }

  private onGetListOK(result: PagedDashboardPages): void {
    this.items = result.content;
    this.dataSource = new MatTableDataSource<DashboardPageItem>(this.items);
    this.dataSource.sort = this.sort;
    this.numOfResults = result.content.length;
  }

  private onGetListKO(error: any): void {
    console.error(`${LOG_TAG} - No ha sido posible recuperar los enlaces`, error);
    void swal2.fire('Error recuperando los enlaces', `No ha sido posible recuperar los enlaces`, 'error');
  }

  private deleteItem(item: DashboardPageItem): void {
    this.loadingService.setLoadingState(true);
    this.dashboardPagesService
      .deleteDashboardPage(item)
      .then(() => {
        this.itemDeleted(item.name);
      })
      .catch(() => {
        void swal2.fire('Error inesperado!', 'No se ha podido eliminar el enlace', 'error');
      })
      .finally(() => this.loadingService.setLoadingState(false));
  }

  private itemDeleted(itemName: string): void {
    void swal2.fire('Eliminado!', `'${itemName}' eliminado con éxito.`, 'success').then(result => {
      if (result.isConfirmed) {
        this.getAllLinks();
      }
    });
  }

  private openUpdateItemModal(item: DashboardPageItem): void {
    this.dialog
      .open(AddEditDashboardPageComponent, {
        panelClass: 'default-modal',
        data: {
          item
        }
      })
      .afterClosed()
      .pipe(takeUntil(this.stopSubscriptionsNotifier))
      .subscribe({
        next: modalClosedResult => {
          if (modalClosedResult !== MAT_DIALOG_CLOSE_WITH_OK) {
            return;
          }
          console.log(LOG_TAG, 'openUpdateItemModal OK');
          void this.initializeState();
        }
      });
  }

  private setInitialPaginatorConfig(): void {
    this.paginatorModel = {
      pageIndex: 0,
      size: 50,
      ascending: true,
      sortCol: 'position'
    };
  }

  private startLoading(): void {
    this.isLoading = true;
  }

  private stopLoading(): void {
    this.isLoading = false;
  }
}
