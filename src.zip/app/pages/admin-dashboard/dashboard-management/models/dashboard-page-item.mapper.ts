import { DashboardEntry } from '../../../../../app/core';
import { DashboardPageEntryItem, DashboardPageItem } from './dashboard-page-item.model';

export function toDashboardPageItem(item: DashboardEntry): DashboardPageItem {
  return {
    id: item.id ?? 0,
    name: item.name ?? '',
    content: item.content ?? '',
    active: item.active ?? false,
    roles: item.roles ?? '',
    client: item.client ?? '',
    group: item.group ?? '',
    classification: item.classification ?? '',
    position: item.position ?? 0,
    ingestedAt: item.ingestedAt ?? '',
    modifiedAt: item.modifiedAt ?? ''
  };
}

export function toDashboardPageEntryItem(id: string, item: DashboardEntry): DashboardPageEntryItem {
  return {
    name: item.name ?? '',
    content: item.content ?? '',
    active: item.active ?? false,
    roles: item.roles ?? '',
    client: item.client ?? '',
    group: item.group ?? '',
    classification: item.classification ?? '',
    position: item.position ?? 0,
    ingestedAt: item.ingestedAt ?? '',
    modifiedAt: item.modifiedAt ?? ''
  };
}
