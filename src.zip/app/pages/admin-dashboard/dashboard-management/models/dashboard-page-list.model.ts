import { PagedResultLiteralDTO } from '../../../../../app/core/api/api-client-library';
import { DashboardPageItem } from './dashboard-page-item.model';

export type PagedDashboardPages = Readonly<
  Required<Omit<PagedResultLiteralDTO, 'content'> & { content: DashboardPageItem[] }>
>;
