import { DashboardEntry } from '../../../../../app/core';

export type DashboardPageItem = Readonly<Required<DashboardEntry>>;

export type DashboardPageEntryItem = Readonly<Required<Omit<DashboardEntry, 'id'>>>;
