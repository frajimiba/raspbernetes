import { Subject, takeUntil } from 'rxjs';

import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute } from '@angular/router';

import { MAT_DIALOG_CLOSE_WITH_OK } from '../../../../app/core';
import { AddEditDashboardPageComponent } from './components/add-edit-dashboard-page/add-edit-dashboard-page.component';
import { DashboardPagesListComponent } from './components/dashboard-pages-list/dashboard-pages-list.component';
import { DashboardPageItem } from './models/dashboard-page-item.model';

@Component({
  selector: 'app-dashboard-management',
  templateUrl: './dashboard-management.component.html',
  styleUrls: ['./dashboard-management.component.scss']
})
export class DashboardManagementComponent implements OnInit, OnDestroy {
  @ViewChild('dashboardPagesListComponentRef') dashboardPagesListComponent: DashboardPagesListComponent;
  public isLoading = true;

  private readonly stopSubscriptionsNotifier = new Subject<void>();

  constructor(private readonly route: ActivatedRoute, private readonly dialog: MatDialog) {}

  public ngOnInit(): void {
    console.log('DashboardManagementComponent', 'ngOnInit');
    this.isLoading = false;
  }

  public ngOnDestroy(): void {
    console.log('DashboardManagementComponent', 'ngOnDestroy');
    this.stopSubscriptionsNotifier.next();
    this.stopSubscriptionsNotifier.complete();
  }

  public addNewChatbotLiteral(): void {
    console.log('DashboardManagementComponent', 'addNewChatbotLiteral');
    this.showAddEditLiteral();
  }

  private showAddEditLiteral(dto?: DashboardPageItem): void {
    console.log('AddUpdateMenuService', 'showAddUpdateSubMenuUi');

    const modalUiConfig = {
      panelClass: 'default-modal',
      data: {
        item: dto
      }
    };

    this.dialog
      .open(AddEditDashboardPageComponent, {
        panelClass: 'default-modal',
        data: modalUiConfig
      })
      .afterClosed()
      .pipe(takeUntil(this.stopSubscriptionsNotifier))
      .subscribe({
        next: modalClosedResult => {
          if (modalClosedResult !== MAT_DIALOG_CLOSE_WITH_OK) {
            return;
          }
          console.log('BookmarkLinksComponent', 'addNewLink', 'create new link OK');
          void this.dashboardPagesListComponent?.initializeState();
        }
      });
  }
}
