import { Component } from '@angular/core';

import { AdminDashboardRouteId } from '../../../app/core';

@Component({
  selector: 'app-admin-dashboard-page',
  templateUrl: './admin-dashboard-page.component.html',
  styleUrls: ['./admin-dashboard-page.component.scss']
})
export class AdminDashboardPageComponent {
  public categoriesRouterId: AdminDashboardRouteId = 'bookmarks-categories';
  public linksRouterId: AdminDashboardRouteId = 'bookmarks-links';
  public menusRouterId: AdminDashboardRouteId = 'menus-management';
  public submenusRouterId: AdminDashboardRouteId = 'submenus-management';
  public notificationsRouterId: AdminDashboardRouteId = 'notifications-management';
  public chatbotLiteralsRouterId: AdminDashboardRouteId = 'chatbotliterals-management';
  public dashboardRouterId: AdminDashboardRouteId = 'dashboard-management';
  public aiqueriesRouterId: AdminDashboardRouteId = 'aiqueries-management';
  public usersRouterId: AdminDashboardRouteId = 'users-management';
  public proceduresRouterId: AdminDashboardRouteId = 'procedures-management';
}
