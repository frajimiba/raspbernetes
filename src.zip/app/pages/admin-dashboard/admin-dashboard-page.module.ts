import { NgxEditorModule } from 'ngx-editor';

import { BlockScrollStrategy, Overlay } from '@angular/cdk/overlay';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { MAT_AUTOCOMPLETE_SCROLL_STRATEGY } from '@angular/material/autocomplete';
import { MatButtonModule } from '@angular/material/button';
import { MatChipsModule } from '@angular/material/chips';
import { MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatListModule } from '@angular/material/list';
import { MatSidenavModule } from '@angular/material/sidenav';

import { AdminDashboardPageRoutingModule } from './admin-dashboard.routing.module';

import { AdminDashboardPageComponent } from './admin-dashboard-page.component';

export function scrollFactory(overlay: Overlay): () => BlockScrollStrategy {
  return () => overlay.scrollStrategies.block();
}

@NgModule({
  declarations: [AdminDashboardPageComponent],
  imports: [
    CommonModule,
    AdminDashboardPageRoutingModule,
    NgxEditorModule,
    MatFormFieldModule,
    MatChipsModule,
    MatButtonModule,
    MatListModule,
    MatIconModule,
    MatSidenavModule,
    MatDialogModule
  ],
  providers: [
    {
      provide: MAT_AUTOCOMPLETE_SCROLL_STRATEGY,
      useFactory: scrollFactory,
      deps: [Overlay]
    }
  ],
  exports: [
    AdminDashboardPageComponent,
    MatFormFieldModule,
    MatChipsModule,
    MatButtonModule,
    MatListModule,
    MatIconModule,
    MatSidenavModule,
    MatDialogModule
  ]
})
export class AdminDashboardPageModule {}
