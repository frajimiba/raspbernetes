import { Injectable } from '@angular/core';

import { ChatbotLiteralsApiService } from '../../../../../app/core/api/chatbot-literals-api/chatbot-literals-api.service';

import { PaginatorModel } from '../../../../shared/models/paginator.model';
import { PagedChabotLiterals } from '../models/chatbot-literals-list.model';
import { toChatbotLiteralItem } from '../models/chatbot-literals.mapper';
import { ChatbotLiteralItem } from '../models/chatbot-literals.model';

@Injectable({
  providedIn: 'root'
})
export class ChatbotLiteralsListService {
  constructor(private readonly chatbotLiteralsApiService: ChatbotLiteralsApiService) {}

  public async getChatbotLiterals(paginatorModel: PaginatorModel): Promise<PagedChabotLiterals> {
    console.log('ChatbotLiteralListService', 'getMenuConfigurations');
    return this.chatbotLiteralsApiService
      .getChatbotLiterals({
        page: paginatorModel.pageIndex,
        size: paginatorModel.size,
        sort: paginatorModel.sortCol,
        ascending: paginatorModel.ascending
      })
      .then(items => {
        return {
          content: items.content?.map(contentItem => toChatbotLiteralItem(contentItem)) ?? [],
          index: items.index ?? 0,
          size: items.size ?? 0,
          totalCount: items.totalCount ?? 0
        };
      })
      .catch(error => {
        console.error(error);
        return {
          content: [],
          index: 0,
          size: 0,
          totalCount: 0
        };
      });
  }

  public async updateChatbotLiteral(item: ChatbotLiteralItem): Promise<ChatbotLiteralItem> {
    console.log('ChatbotLiteralListService', 'updateChatbotLiteral', item);
    return this.chatbotLiteralsApiService.updateChatbotLiteral(item.id, item).then(item => toChatbotLiteralItem(item));
  }

  public async deleteChatbotLiteral(item: ChatbotLiteralItem): Promise<any> {
    console.log('ChatbotLiteralListService', 'deleteChatbotLiteral', item);
    return this.chatbotLiteralsApiService.deleteChatbotLiteral(item.id);
  }
}
