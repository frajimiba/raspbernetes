import { Subject, takeUntil } from 'rxjs';

import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute } from '@angular/router';

import { MAT_DIALOG_CLOSE_WITH_OK } from '../../../../app/core';
import { AddEditChatbotLiteralsComponent } from './components/add-edit-chatbot-literals/add-edit-chatbot-literals.component';
import { ChatbotLiteralsListComponent } from './components/chatbot-literals-list/chatbot-literals-list.component';
import { ChatbotLiteralItem } from './models/chatbot-literals.model';

@Component({
  selector: 'app-chatbot-literals-management',
  templateUrl: './chatbot-literals-management.component.html',
  styleUrls: ['./chatbot-literals-management.component.scss']
})
export class ChatbotLiteralsManagementComponent implements OnInit, OnDestroy {
  @ViewChild('chatbotLiteralsListComponentRef') chatbotLiteralsListComponent: ChatbotLiteralsListComponent;
  public isLoading = true;

  private readonly stopSubscriptionsNotifier = new Subject<void>();

  constructor(private readonly route: ActivatedRoute, private readonly dialog: MatDialog) {}

  public ngOnInit(): void {
    console.log('NotificationsManagementComponent', 'ngOnInit');
    this.isLoading = false;
  }

  public ngOnDestroy(): void {
    console.log('NotificationsManagementComponent', 'ngOnDestroy');
    this.stopSubscriptionsNotifier.next();
    this.stopSubscriptionsNotifier.complete();
  }

  public addNewChatbotLiteral(): void {
    console.log('NotificationsManagementComponent', 'addNewChatbotLiteral');
    this.showAddEditLiteral();
  }

  private showAddEditLiteral(dto?: ChatbotLiteralItem): void {
    console.log('AddUpdateMenuService', 'showAddUpdateSubMenuUi');

    const modalUiConfig = {
      panelClass: 'default-modal',
      data: {
        item: dto
      }
    };

    this.dialog
      .open(AddEditChatbotLiteralsComponent, {
        panelClass: 'default-modal',
        data: modalUiConfig
      })
      .afterClosed()
      .pipe(takeUntil(this.stopSubscriptionsNotifier))
      .subscribe({
        next: modalClosedResult => {
          if (modalClosedResult !== MAT_DIALOG_CLOSE_WITH_OK) {
            return;
          }
          console.log('BookmarkLinksComponent', 'addNewLink', 'create new link OK');
          void this.chatbotLiteralsListComponent?.initializeState();
        }
      });
  }
}
