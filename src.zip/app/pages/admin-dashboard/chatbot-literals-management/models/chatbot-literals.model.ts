import { LiteralDTO, LiteralEntry } from '../../../../../app/core';

export type ChatbotLiteralItem = Readonly<Required<LiteralDTO>>;

export type ChatbotLiteralEntryItem = Readonly<Required<LiteralEntry>>;
