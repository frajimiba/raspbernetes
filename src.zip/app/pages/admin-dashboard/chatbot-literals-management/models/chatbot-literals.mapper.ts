import { LiteralDTO, LiteralEntry } from '../../../../../app/core';
import { ChatbotLiteralItem } from './chatbot-literals.model';

export function toChatbotLiteralItem(item: LiteralDTO): ChatbotLiteralItem {
  return {
    id: item.id ?? '',
    description: item.description ?? '',
    title: item.title ?? ''
  };
}

export function toChatbotLiteralEntryItem(id: string, item: LiteralEntry): ChatbotLiteralItem {
  return {
    id,
    description: item.description ?? '',
    title: item.title ?? ''
  };
}
