import { PagedResultLiteralDTO } from '../../../../core/api/api-client-library';
import { ChatbotLiteralItem } from './chatbot-literals.model';

export type PagedChabotLiterals = Readonly<
  Required<Omit<PagedResultLiteralDTO, 'content'> & { content: ChatbotLiteralItem[] }>
>;
