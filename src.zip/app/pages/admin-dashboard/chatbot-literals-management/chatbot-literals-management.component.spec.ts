import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChatbotLiteralsManagementComponent } from './chatbot-literals-management.component';

xdescribe('ChatbotLiteralsManagementComponent', () => {
  let component: ChatbotLiteralsManagementComponent;
  let fixture: ComponentFixture<ChatbotLiteralsManagementComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ChatbotLiteralsManagementComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(ChatbotLiteralsManagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
