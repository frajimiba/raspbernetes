import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditChatbotLiteralsComponent } from './add-edit-chatbot-literals.component';

xdescribe('AddEditChatbotLiteralsComponent', () => {
  let component: AddEditChatbotLiteralsComponent;
  let fixture: ComponentFixture<AddEditChatbotLiteralsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AddEditChatbotLiteralsComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(AddEditChatbotLiteralsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
