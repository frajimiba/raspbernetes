import { ChatbotLiteralItem } from '../../../models/chatbot-literals.model';

export interface AddEditInput {
  item: ChatbotLiteralItem;
}
