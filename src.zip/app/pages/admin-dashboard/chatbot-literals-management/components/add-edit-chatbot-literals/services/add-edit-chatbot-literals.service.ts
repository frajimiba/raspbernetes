import { Injectable } from '@angular/core';

import { ChatbotLiteralsApiService } from '../../../../../../core/api/chatbot-literals-api/chatbot-literals-api.service';

import { toChatbotLiteralItem } from '../../../models/chatbot-literals.mapper';
import { ChatbotLiteralItem } from '../../../models/chatbot-literals.model';

@Injectable({
  providedIn: 'root'
})
export class AddEditChatbotLiteralsService {
  constructor(private readonly chatbotLiteralsApiService: ChatbotLiteralsApiService) {}

  public async createChatbotLiterals(item: ChatbotLiteralItem): Promise<ChatbotLiteralItem> {
    console.log('ChatbotLiteralsService', 'createChatbotLiterals');

    return this.chatbotLiteralsApiService
      .createChatbotLiteral({
        id: item.id,
        title: item.title,
        description: item.description
      })
      .then(item => toChatbotLiteralItem(item));
  }

  public async updateChatbotLiterals(item: ChatbotLiteralItem): Promise<ChatbotLiteralItem> {
    console.log('ChatbotLiteralsService', 'updateChatbotLiterals');
    return this.chatbotLiteralsApiService.updateChatbotLiteral(item.id, item).then(item => toChatbotLiteralItem(item));
  }
}
