import swal2 from 'sweetalert2';

import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

import { AddEditChatbotLiteralsService } from './services/add-edit-chatbot-literals.service';

import { MAT_DIALOG_CLOSE_WITH_OK, MAT_DIALOG_CLOSE_WITHOUT_ACTIONS } from '../../../../../../app/core';
import { AddEditInput } from './models/add-edit-chatbot-literals.model';

export const LITERAL_COD_PREFIX = 'LITERAL_COD_';

@Component({
  selector: 'app-add-edit-chatbot-literals',
  templateUrl: './add-edit-chatbot-literals.component.html',
  styleUrls: ['./add-edit-chatbot-literals.component.scss']
})
export class AddEditChatbotLiteralsComponent implements OnInit {
  edit: boolean = false;
  isLoading: boolean = false;
  public form: FormGroup;

  constructor(
    private readonly formBuilder: FormBuilder,
    public readonly dialogRef: MatDialogRef<AddEditChatbotLiteralsComponent>,
    public readonly addEditChatbotLiteralsService: AddEditChatbotLiteralsService,
    @Inject(MAT_DIALOG_DATA) public readonly input: AddEditInput
  ) {}

  ngOnInit(): void {
    this.edit = this.input.item !== undefined;
    this.form = this.formBuilder.group({
      id: this.formBuilder.control(this.input.item?.id ?? ''),
      title: this.formBuilder.control(this.input.item?.title ?? ''),
      description: this.formBuilder.control(this.input.item?.description ?? '')
    });
    if (this.edit) {
      this.form.controls.id.disable();
    }
  }

  public submitForm(): void {
    if (this.form.valid) {
      this.isLoading = true;
      this.edit ? this.submitUpdated() : this.submitNew();
    }
  }

  public submitNew(): void {
    this.addEditChatbotLiteralsService
      .createChatbotLiterals({
        id: LITERAL_COD_PREFIX.concat(this.form.controls.id.value),
        title: this.form.controls.title.value,
        description: this.form.controls.description.value
      })
      .then(async result => this.showCreateSuccessUi())
      .catch(async result => this.showCreateErrorUi());
  }

  public submitUpdated(): void {
    this.addEditChatbotLiteralsService
      .updateChatbotLiterals({
        id: this.form.controls.id.value,
        title: this.form.controls.title.value,
        description: this.form.controls.description.value
      })
      .then(async result => this.showUpdateSuccessUi())
      .catch(async result => this.showUpdateErrorUi());
  }

  public discardForm(): void {
    this.dialogRef.close(MAT_DIALOG_CLOSE_WITHOUT_ACTIONS);
  }

  public getTitle(): string {
    return this.edit ? 'Editar literal' : 'Agregar literal';
  }

  private async showCreateSuccessUi(): Promise<void> {
    await swal2.fire(`Literal creado`, `Se ha creado correctamente.`, 'success');
    this.dialogRef.close(MAT_DIALOG_CLOSE_WITH_OK);
  }

  private async showUpdateSuccessUi(): Promise<void> {
    await swal2.fire(`Literal actualizado`, `Se ha actualizado correctamente.`, 'success');
    this.dialogRef.close(MAT_DIALOG_CLOSE_WITH_OK);
  }

  private showCreateErrorUi(): void {
    void swal2.fire(`Error inesperado`, `No se ha podido crear.`, 'error');
  }

  private showUpdateErrorUi(): void {
    void swal2.fire(`Error inesperado`, `No se ha podido actualizar.`, 'error');
  }
}
