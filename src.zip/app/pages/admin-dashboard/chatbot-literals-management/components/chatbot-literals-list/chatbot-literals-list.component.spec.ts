import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChatbotLiteralsListComponent } from './chatbot-literals-list.component';

xdescribe('ChatbotLiteralsListComponent', () => {
  let component: ChatbotLiteralsListComponent;
  let fixture: ComponentFixture<ChatbotLiteralsListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ChatbotLiteralsListComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(ChatbotLiteralsListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
