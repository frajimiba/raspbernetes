import { MenuEntry } from '../../../../app/core';

export type MenuConfiguration = Readonly<Required<Omit<MenuEntry, 'ingestedAt' | 'modifiedAt'>>>;
