import { Injectable } from '@angular/core';

import { ClassificationsGroupsClientsEntry, SubmenuService } from '../../../../../app/core';
import { NewSubMenuConfiguration, SubMenuConfiguration } from '../models/menu-configuration.model';
import { mapSubMenuEntries } from '../models/menu-submenus-maps';

@Injectable({
  providedIn: 'root'
})
export class SubmenusManagementService {
  constructor(private readonly subMenuService: SubmenuService) {}

  public async createSubMenuConfiguration(menuConfiguration: NewSubMenuConfiguration): Promise<void> {
    console.log('SubmenusManagementService', 'createMenuConfiguration');
    return this.subMenuService.createSubMenuConfiguration(menuConfiguration);
  }

  public async updateSubMenuConfiguration(menuConfiguration: SubMenuConfiguration): Promise<void> {
    console.log('SubmenusManagementService', 'updateMenuConfiguration');
    return this.subMenuService.updateSubMenuConfigurationById(menuConfiguration.id, menuConfiguration);
  }

  public async deleteSubMenuConfiguration(menuConfigurationId: number): Promise<void> {
    console.log('SubmenusManagementService', 'deleteMenuConfiguration');
    return this.subMenuService.deleteSubMenuConfigurationById(menuConfigurationId);
  }

  public async getSubMenusConfigurations(
    ascending: boolean,
    page: number,
    size: number,
    sort: string,
    classificationsGroupsClientsEntry: ClassificationsGroupsClientsEntry
  ): Promise<SubMenuConfiguration[]> {
    console.log('SubmenusManagementService', 'getSubMenusConfigurations');

    return this.subMenuService
      .getSubMenusConfigurations(ascending, page, size, sort, classificationsGroupsClientsEntry)
      .then(subMenuRemoteConfigurations => mapSubMenuEntries(subMenuRemoteConfigurations.content ?? []))
      .catch(error => {
        console.error(error);
        return [];
      });
  }
}
