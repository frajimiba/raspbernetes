import { Injectable } from '@angular/core';

import { ClassificationsGroupsClientsEntry, MenuService } from '../../../../../app/core';
import { MenuConfiguration, NewMenuConfiguration } from '../models/menu-configuration.model';
import { mapMenuEntries } from '../models/menu-submenus-maps';

@Injectable({
  providedIn: 'root'
})
export class MenusManagementService {
  constructor(private readonly menuService: MenuService) {}

  public async createMenuConfiguration(menuConfiguration: NewMenuConfiguration): Promise<void> {
    console.log('MenusManagementService', 'createMenuConfiguration');
    return this.menuService.createMenuConfiguration(menuConfiguration);
  }

  public async updateMenuConfiguration(menuConfiguration: MenuConfiguration): Promise<void> {
    console.log('MenusManagementService', 'updateMenuConfiguration');
    return this.menuService.updateMenuConfigurationById(menuConfiguration.id, menuConfiguration);
  }

  public async deleteMenuConfiguration(menuConfigurationId: number): Promise<void> {
    console.log('MenusManagementService', 'deleteMenuConfiguration');
    return this.menuService.deleteMenuConfigurationById(menuConfigurationId);
  }

  public async getMenuConfigurations(
    ascending: boolean,
    page: number,
    size: number,
    sort: string,
    classificationsGroupsClientsEntry: ClassificationsGroupsClientsEntry
  ): Promise<MenuConfiguration[]> {
    console.log('MenusManagementService', 'getMenuConfigurations');
    return this.menuService
      .getMenuConfigurations(ascending, page, size, sort, classificationsGroupsClientsEntry)
      .then(menuRemoteConfigurations => mapMenuEntries(menuRemoteConfigurations.content ?? []))
      .catch(error => {
        console.error(error);
        return [];
      });
  }
}
