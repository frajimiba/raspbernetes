import { Subject, takeUntil } from 'rxjs';

import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { ActivatedRoute } from '@angular/router';

import { ClassificationsGroupsClientsEntry, MAT_DIALOG_CLOSE_WITH_OK } from '../../../../app/core';
import { AssignmentSelectorConfig, AssignmentSelectorSelectedConfig } from '../../../../app/shared';
import { MenuListComponent } from './components/menu-list/menu-list.component';
import { MenuManagementMode, MenuManagementModeConfig } from './models/menu-configuration.model';
import { MenuCreationEditionDialogService, NewMenuOrSubMenu } from './shared';
import { MenuCreationEditionDialogComponent } from './shared/menu-creation-edition-dialog/menu-creation-edition-dialog.component';

@Component({
  selector: 'app-menu-management',
  templateUrl: './menu-management.component.html',
  styleUrls: ['./menu-management.component.scss']
})
export class MenuManagementComponent implements OnInit, OnDestroy {
  @ViewChild('menuListComponentRef') menuListComponent: MenuListComponent;
  public isLoading = true;

  public assignmentSelectorConfig: AssignmentSelectorConfig = {
    clientSelectorEnabled: true,
    projectSelectorEnabled: true,
    clasificationSelectorEnabled: true,
    searchButtonEnabled: true,
    sessionStorageKey: 'menu-management',
    onlyOwnCustomers: true,
    filterSubGroups: false,
    includeDefaultGroups: false
  };

  public menuManagementMode: MenuManagementMode = 'Menu';
  private readonly stopSubscriptionsNotifier = new Subject<void>();

  constructor(
    private readonly route: ActivatedRoute,
    private readonly dialogService: MenuCreationEditionDialogService
  ) {}

  public ngOnInit(): void {
    console.log('MenuManagementComponent', 'ngOnInit');

    this.route.data.pipe(takeUntil(this.stopSubscriptionsNotifier)).subscribe({
      next: (menuManagementModeConfig: MenuManagementModeConfig) => {
        this.menuManagementMode = menuManagementModeConfig.mode;
        this.isLoading = false;
      }
    });
  }

  public ngOnDestroy(): void {
    console.log('MenuManagementComponent', 'ngOnDestroy');
    this.stopSubscriptionsNotifier.next();
    this.stopSubscriptionsNotifier.complete();
  }

  public selectedAssignment(selectedConfig: AssignmentSelectorSelectedConfig): void {
    console.log('MenuManagementComponent', 'selectedAssignment', selectedConfig);
    const classificationsGroupsClientsEntry: ClassificationsGroupsClientsEntry = {
      clients: selectedConfig.selectedClient ? [selectedConfig.selectedClient] : [],
      groups: selectedConfig.selectedProject ? [selectedConfig.selectedProject] : [],
      classifications: selectedConfig.selectedClasification ? [selectedConfig.selectedClasification] : []
    };

    this.menuListComponent.setSearchCombos(classificationsGroupsClientsEntry);
    void this.menuListComponent?.initializeState();
  }

  public getMenuManagementTitle(): string {
    return this.menuManagementMode === 'Menu' ? 'Añadir nuevo menú' : 'Añadir nuevo submenú';
  }

  public async addNewMenu(): Promise<void> {
    console.log('MenuManagementComponent', 'addNewMenu clicked');

    const creationEditionDialogRef = await this.showCreateOrUpdateMenuUi();
    if (!creationEditionDialogRef) {
      return;
    }

    this.setDialogCloseActions(creationEditionDialogRef);
  }

  public isSubMenuManagementMode(): boolean {
    return this.menuManagementMode === 'Submenu';
  }

  private async showCreateOrUpdateMenuUi(): Promise<MatDialogRef<MenuCreationEditionDialogComponent>> {
    console.log('AddUpdateMenuService', 'showAddUpdateSubMenuUi');

    const newMenuDialogMode: NewMenuOrSubMenu = this.menuManagementMode === 'Menu' ? 'NewMenu' : 'NewSubmenu';
    const modalUiConfig = {
      panelClass: 'default-modal',
      data: newMenuDialogMode
    };
    return this.dialogService.open(modalUiConfig);
  }

  private setDialogCloseActions(
    creationEditionDialogRef: MatDialogRef<MenuCreationEditionDialogComponent, number>
  ): void {
    creationEditionDialogRef
      .afterClosed()
      .pipe(takeUntil(this.stopSubscriptionsNotifier))
      .subscribe({
        next: modalClosedResult => {
          if (modalClosedResult !== MAT_DIALOG_CLOSE_WITH_OK) {
            return;
          }
          console.log('MenuManagementComponent', 'addNewMenu', 'create new menu OK');
          void this.menuListComponent?.initializeState();
        }
      });
  }
}
