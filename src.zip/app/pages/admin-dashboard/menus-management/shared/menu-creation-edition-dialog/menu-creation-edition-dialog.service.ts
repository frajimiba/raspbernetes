/* eslint-disable @typescript-eslint/explicit-member-accessibility */
import { Injectable } from '@angular/core';
import { MatDialogConfig, MatDialogRef } from '@angular/material/dialog';

import { AsyncDialog } from '../../../../../../app/core';
import { MenuConfiguration, SubMenuConfiguration } from '../../../../../../app/pages';
import { MenuCreationEditionDialogComponent } from './menu-creation-edition-dialog.component';

export type NewMenuOrSubMenu = 'NewMenu' | 'NewSubmenu';

@Injectable({
  providedIn: 'root'
})
export class MenuCreationEditionDialogService extends AsyncDialog<
  MenuCreationEditionDialogComponent,
  MatDialogConfig<SubMenuConfiguration | MenuConfiguration | NewMenuOrSubMenu>,
  number
> {
  async open(
    config: MatDialogConfig<SubMenuConfiguration | MenuConfiguration | NewMenuOrSubMenu>
  ): Promise<MatDialogRef<MenuCreationEditionDialogComponent, number>> {
    // Lazy loading componente ng-module
    const { MenuCreationEditionDialogModule } = await import('./menu-creation-edition-dialog.module');

    return this.matDialog.open(MenuCreationEditionDialogModule.getComponent(), config);
  }
}
