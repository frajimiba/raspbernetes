import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

import { NewMenuOrSubMenu } from './menu-creation-edition-dialog.service';

import { MAT_DIALOG_CLOSE_WITH_OK } from '../../../../../../app/core';
import {
  isSubMenuConfiguration,
  MenuConfiguration,
  SubMenuConfiguration
} from '../../../../../../app/pages/admin-dashboard';
import { MenuCreationEditionComponent } from '../menu-creation-edition/menu-creation-edition.component';
import { MenusFormResult } from '../menu-creation-edition/menu-creation-edition.config';
import { SubmenuCreationEditionComponent } from '../menu-creation-edition/submenu-creation-edition.component';
import { MAT_DIALOG_CLOSE_WITH_KO } from './../../../../../core/utils/prefix';

const LOG_TAG = 'MenuCreationEditionDialogComponent';
@Component({
  selector: 'app-menu-creation-edition-dialog',
  templateUrl: './menu-creation-edition-dialog.component.html',
  styleUrls: ['./menu-creation-edition-dialog.component.scss']
})
export class MenuCreationEditionDialogComponent implements OnInit {
  constructor(
    @Inject(MAT_DIALOG_DATA) public readonly dialogData: SubMenuConfiguration | MenuConfiguration | NewMenuOrSubMenu,
    public readonly dialogRef: MatDialogRef<MenuCreationEditionComponent | SubmenuCreationEditionComponent>
  ) {}

  public ngOnInit(): void {
    console.log(`${LOG_TAG}`, 'ngOnInit');
  }

  public menuCreationEditionFormResult(menuFormResult: MenusFormResult): void {
    menuFormResult === 'Cancelled'
      ? this.dialogRef.close(MAT_DIALOG_CLOSE_WITH_KO)
      : this.dialogRef.close(MAT_DIALOG_CLOSE_WITH_OK);
  }

  public getConfigurationForMenuEdition(): SubMenuConfiguration | MenuConfiguration | undefined {
    return this.dialogData !== 'NewMenu' && this.dialogData !== 'NewSubmenu' ? this.dialogData : undefined;
  }

  public hasConfigForSubMenu(): boolean {
    return this.dialogData != null && this.isConfigForSubmenus(this.dialogData);
  }

  private isNewMenuOrSubmenuConfig(config: NewMenuOrSubMenu): boolean {
    return config === 'NewSubmenu';
  }

  private isConfigForSubmenus(config: SubMenuConfiguration | MenuConfiguration | NewMenuOrSubMenu): boolean {
    return (
      this.isNewMenuOrSubmenuConfig(config as NewMenuOrSubMenu) ||
      isSubMenuConfiguration(config as SubMenuConfiguration | MenuConfiguration)
    );
  }
}
