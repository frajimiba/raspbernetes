import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { MenuCreationEditionModule } from '../menu-creation-edition/menu-creation-edition.module';

import { MenuCreationEditionDialogComponent } from './menu-creation-edition-dialog.component';

const DEPENDENCIES = [CommonModule, MenuCreationEditionModule];

const DECLARATIONS = [MenuCreationEditionDialogComponent];

@NgModule({
  declarations: DECLARATIONS,
  imports: DEPENDENCIES,
  exports: [DECLARATIONS, DEPENDENCIES]
})
export class MenuCreationEditionDialogModule {
  public static getComponent(): typeof MenuCreationEditionDialogComponent {
    return MenuCreationEditionDialogComponent;
  }
}
