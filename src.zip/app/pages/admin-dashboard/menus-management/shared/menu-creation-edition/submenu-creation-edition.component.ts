import swal2 from 'sweetalert2';

import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatSelect } from '@angular/material/select';

import { AddUpdateMenuFormService, MenuFormControls } from './menu-creation-edition-form.service';

import { ClassificationsGroupsClientsEntry, DEFAULT_STRING } from '../../../../../../app/core';
import { MenuConfiguration } from '../../../../../../app/pages/admin-dashboard';
import { AssignmentSelectorFormConfig, AssignmentSelectorSelectedConfig } from '../../../../../../app/shared';
import { BaseMenuCreationEditonComponent } from './base-menu-creation-edition.component';

@Component({
  selector: 'app-submenu-creation-edition',
  templateUrl: './menu-creation-edition.component.html',
  styleUrls: ['./menu-creation-edition.component.scss']
})
export class SubmenuCreationEditionComponent extends BaseMenuCreationEditonComponent implements OnInit {
  @ViewChild('menuMatSelectRef') menuMatSelect: MatSelect;

  public titleLabel: string;
  public availableMenuConfigs: MenuConfiguration[];
  public selectedMenu: MenuConfiguration;
  public isSubmenuForm = true;
  public isLoading = true;
  public addOrUpdateMenuForm: FormGroup<MenuFormControls>;
  public classificationsGroupsClientsEntry: ClassificationsGroupsClientsEntry = {
    classifications: [],
    clients: [],
    groups: []
  };

  constructor(
    protected readonly addUpdateFormService: AddUpdateMenuFormService,
    protected readonly formBuilder: FormBuilder
  ) {
    super(addUpdateFormService);
  }

  public ngOnInit(): void {
    super.ngOnInit();
    console.log('AddUpdateSubMenuComponent', 'ngOnInit');
    this.titleLabel = this.isNewMenuForm() ? 'Crear nuevo submenú' : 'Actualizar submenú';
  }

  public setFormAssignament(assignmentSelectorFormConfig: AssignmentSelectorSelectedConfig): void {
    console.log('AddUpdateSubMenuComponent', 'setFormAssignament', assignmentSelectorFormConfig);
    this.addOrUpdateMenuForm.controls.classification?.setValue(
      assignmentSelectorFormConfig.selectedClasification ?? DEFAULT_STRING
    );
    this.addOrUpdateMenuForm.controls.group?.setValue(assignmentSelectorFormConfig.selectedProject ?? DEFAULT_STRING);
    this.addOrUpdateMenuForm.controls.client?.setValue(assignmentSelectorFormConfig.selectedClient ?? DEFAULT_STRING);
  }

  protected initializeForm(): void {
    console.log('AddUpdateSubMenuComponent', 'initializeForm');
    void this.initializeAvailableMenuConfigs();
  }

  protected async submitNewMenuForm(): Promise<void> {
    console.log('AddUpdateSubMenuComponent', 'submitNewMenuForm');

    await this.addUpdateFormService.submenuManagement
      .createSubMenuConfiguration(this.addUpdateFormService.formGroupToNewMenuConfig(this.addOrUpdateMenuForm))
      .then(() => this.formResult.emit('OK'))
      .catch(() => this.showCreateMenuConfigurationErrorUi());
  }

  protected async submitUpdatedMenuForm(): Promise<void> {
    console.log('AddUpdateSubMenuComponent', 'submitUpdatedMenuForm');

    await this.addUpdateFormService.submenuManagement
      .updateSubMenuConfiguration(
        this.addUpdateFormService.formGroupToUpdatedMenuConfig(this.addOrUpdateMenuForm, this.config)
      )
      .then(() => this.formResult.emit('OK'))
      .catch(() => this.showUpdateMenuConfigurationErrorUi());
  }

  protected showCreateMenuConfigurationErrorUi(): void {
    void swal2.fire('Error inesperado`, `No se ha podido crear el nuevo submenú.', 'error');
  }

  protected showUpdateMenuConfigurationErrorUi(): void {
    void swal2.fire('Error inesperado`, `No se ha podido actualizar submenú.', 'error');
  }

  private async initializeAvailableMenuConfigs(): Promise<void> {
    this.availableMenuConfigs = await this.addUpdateFormService.menuManagement.getMenuConfigurations(
      false,
      0,
      500,
      'id',
      this.classificationsGroupsClientsEntry
    );
    this.addOrUpdateMenuForm = this.addUpdateFormService.subMenuConfigToFormGroup(
      this.config,
      this.availableMenuConfigs
    );
    this.isLoading = false;
  }
}
