import { Injectable } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

import { LoadingService } from '../../../../../../app/core';
import {
  MenuConfiguration,
  MenusManagementService,
  NewMenuConfiguration,
  NewSubMenuConfiguration,
  SubMenuConfiguration,
  SubmenusManagementService
} from '../../../../../../app/pages/admin-dashboard';

const MIN_POSITION_VALUE = 0;
const MAX_POSITION_VALUE = 999;
const MIN_NAME_LENGTH = 3;
const MAX_NAME_LENGTH = 30;
const MIN_DESCRIPTION_LENGTH = 3;
const MAX_DESCRIPTION_LENGTH = 255;
const MIN_LINK_LENGTH = 3;
const MAX_LINK_LENGTH = 255;
const DEFAULT_STRINGS_VALUES = '';

export interface MenuFormControls {
  position: FormControl<number | null>;
  name: FormControl<string | null>;
  description: FormControl<string | null>;
  link: FormControl<string | null>;
  roles: FormControl<string[] | null>;
  internal: FormControl<boolean | null>;
  active: FormControl<boolean | null>;
  menu?: FormControl<MenuConfiguration | null>;
  classification?: FormControl<string | null>;
  group?: FormControl<string | null>;
  client?: FormControl<string | null>;
}

@Injectable({
  providedIn: 'root'
})
export class AddUpdateMenuFormService {
  constructor(
    public readonly menuManagement: MenusManagementService,
    public readonly submenuManagement: SubmenusManagementService,
    public readonly loadingService: LoadingService
  ) {}

  public menuConfigToFormGroup(menuConfiguration: MenuConfiguration): FormGroup<MenuFormControls> {
    console.log('AddUpdateMenuFormService', 'generateConfigForMenu');
    return this.generateCommonFormConfigFromMenu(menuConfiguration);
  }

  public subMenuConfigToFormGroup(
    subMenuConfiguration: SubMenuConfiguration,
    availableMenuConfigs: MenuConfiguration[]
  ): FormGroup<MenuFormControls> {
    console.log('AddUpdateMenuFormService', 'generateConfigForSubMenu');

    const formConfiguration: FormGroup<MenuFormControls> = this.generateCommonFormConfigFromMenu(subMenuConfiguration);
    const selectedMenuConfig = availableMenuConfigs.find(
      menuConfig => menuConfig?.id === subMenuConfiguration?.menu?.id
    );
    formConfiguration.controls.menu = new FormControl(selectedMenuConfig ?? null);

    return formConfiguration;
  }

  public formGroupToNewMenuConfig(newMenuForm: FormGroup): NewMenuConfiguration | NewSubMenuConfiguration {
    return this.formDataToNewMenuConfiguration(newMenuForm);
  }

  public formGroupToUpdatedMenuConfig(
    newMenuForm: FormGroup,
    menuConfiguration: MenuConfiguration | SubMenuConfiguration
  ): MenuConfiguration | SubMenuConfiguration {
    return this.formDataToUpdatedMenuConfiguration(newMenuForm, menuConfiguration);
  }

  private generateCommonFormConfigFromMenu(
    menuConfiguration: MenuConfiguration | SubMenuConfiguration
  ): FormGroup<MenuFormControls> {
    return new FormGroup<MenuFormControls>({
      position: new FormControl(menuConfiguration?.position ?? null, [
        Validators.required,
        Validators.min(MIN_POSITION_VALUE),
        Validators.max(MAX_POSITION_VALUE)
      ]),
      name: new FormControl(menuConfiguration?.name ?? DEFAULT_STRINGS_VALUES, [
        Validators.required,
        Validators.min(MIN_NAME_LENGTH),
        Validators.max(MAX_NAME_LENGTH)
      ]),
      description: new FormControl(menuConfiguration?.description ?? DEFAULT_STRINGS_VALUES, [
        Validators.required,
        Validators.min(MIN_DESCRIPTION_LENGTH),
        Validators.max(MAX_DESCRIPTION_LENGTH)
      ]),
      link: new FormControl(menuConfiguration?.link ?? DEFAULT_STRINGS_VALUES, [
        Validators.required,
        Validators.min(MIN_LINK_LENGTH),
        Validators.max(MAX_LINK_LENGTH)
      ]),
      roles: new FormControl(menuConfiguration?.roles ? this.splitRoles(menuConfiguration.roles) : [], [
        Validators.required
      ]),
      classification: new FormControl(menuConfiguration?.classification ?? DEFAULT_STRINGS_VALUES),
      group: new FormControl(menuConfiguration?.group ?? DEFAULT_STRINGS_VALUES),
      client: new FormControl(menuConfiguration?.client ?? DEFAULT_STRINGS_VALUES),
      internal: new FormControl(menuConfiguration?.internal ?? false),
      active: new FormControl(menuConfiguration?.active ?? false)
    });
  }

  private splitRoles(roles: string): string[] {
    return roles !== '' ? roles.split(',') : [''];
  }

  private formDataToNewMenuConfiguration(newMenuForm: FormGroup): NewMenuConfiguration | NewSubMenuConfiguration {
    const menuConfig: NewMenuConfiguration | NewSubMenuConfiguration = {
      active: newMenuForm.controls.active.value,
      description: newMenuForm.controls.description.value,
      internal: newMenuForm.controls.internal.value,
      link: newMenuForm.controls.link.value,
      name: newMenuForm.controls.name.value,
      position: newMenuForm.controls.position.value,
      roles: newMenuForm.controls.roles.value.toString(),
      menu: newMenuForm.controls?.menu?.value,
      classification: newMenuForm.controls?.classification?.value,
      group: newMenuForm.controls?.group?.value,
      client: newMenuForm.controls?.client?.value
    };

    return menuConfig;
  }

  private formDataToUpdatedMenuConfiguration(
    updatedMenuForm: FormGroup,
    menuConfiguration: MenuConfiguration | SubMenuConfiguration
  ): MenuConfiguration | SubMenuConfiguration {
    let updatedMenuConfig: MenuConfiguration | SubMenuConfiguration = {
      ...this.formDataToNewMenuConfiguration(updatedMenuForm),
      id: menuConfiguration.id
    };

    if (this.isSubMenuConfiguration(menuConfiguration)) {
      updatedMenuConfig = {
        ...updatedMenuConfig,
        id: menuConfiguration.id,
        menu: updatedMenuForm.controls.menu.value
      };
    } else {
      updatedMenuConfig = {
        ...updatedMenuConfig,
        submenus: menuConfiguration.submenus
      };
    }

    return updatedMenuConfig;
  }

  // Check input menuconfiguration type is for submenu configuration extended type
  private isSubMenuConfiguration(
    menuConfiguration: MenuConfiguration | SubMenuConfiguration
  ): menuConfiguration is SubMenuConfiguration {
    return (menuConfiguration as SubMenuConfiguration)?.menu != null;
  }
}
