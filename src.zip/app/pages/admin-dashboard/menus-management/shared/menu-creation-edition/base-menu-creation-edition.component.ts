import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormGroup } from '@angular/forms';

import { AddUpdateMenuFormService, MenuFormControls } from './menu-creation-edition-form.service';

import { ALL_AVAILABLE_ROLES, AuthRole, DEFAULT_STRING } from '../../../../../../app/core';
import { MenuConfiguration, SubMenuConfiguration } from '../../../../../../app/pages/admin-dashboard';
import {
  AssignmentSelectorConfig,
  AssignmentSelectorFormConfig,
  AssignmentSelectorSelectedConfig
} from '../../../../../../app/shared';
import { MenusFormResult } from './menu-creation-edition.config';

@Component({
  template: ''
})
export abstract class BaseMenuCreationEditonComponent implements OnInit {
  @Input() config: SubMenuConfiguration | MenuConfiguration;
  @Output() formResult: EventEmitter<MenusFormResult> = new EventEmitter();

  public assignmentSelectorConfig: AssignmentSelectorConfig;

  public isLoading: boolean = false;
  public rolesList: AuthRole[] = ALL_AVAILABLE_ROLES; // TODO: refactorizar de enum a list o sacar de otro sitio
  public abstract titleLabel: string;
  public abstract isSubmenuForm: boolean;
  public abstract addOrUpdateMenuForm: FormGroup<MenuFormControls>;

  constructor(protected readonly addUpdateFormService: AddUpdateMenuFormService) {}

  public ngOnInit(): void {
    console.log('BaseAddUpdateMenuComponent', 'ngOnInit');
    this.assignmentSelectorConfig = {
      clientSelectorEnabled: true,
      searchButtonEnabled: false,
      clasificationSelectorEnabled: true,
      projectSelectorEnabled: true,
      onlyOwnCustomers: true,
      filterSubGroups: false,
      disabledStorage: true,
      sessionStorageKey: 'menu-creation-edition',
      formConfig: {
        classification: this.config?.classification ?? DEFAULT_STRING,
        client: this.config?.client ?? DEFAULT_STRING,
        project: this.config?.group ?? DEFAULT_STRING
      },
      includeDefaultGroups: false
    };
    this.initializeForm();
  }

  public discardForm(): void {
    this.addOrUpdateMenuForm.reset();
    this.formResult.emit('Cancelled');
  }

  public async submitForm(): Promise<void> {
    if (this.addOrUpdateMenuForm.valid) {
      this.addUpdateFormService.loadingService.setLoadingState(true);
      this.isNewMenuForm() ? await this.submitNewMenuForm() : await this.submitUpdatedMenuForm();
      this.addUpdateFormService.loadingService.setLoadingState(false);
    }
  }

  public isNewMenuForm(): boolean {
    return !this.config;
  }

  public abstract setFormAssignament(assignmentSelectorFormConfig: AssignmentSelectorSelectedConfig): void;

  protected abstract initializeForm(): void;

  protected abstract showCreateMenuConfigurationErrorUi(): void;

  protected abstract showUpdateMenuConfigurationErrorUi(): void;

  protected abstract submitNewMenuForm(): Promise<void>;

  protected abstract submitUpdatedMenuForm(): Promise<void>;
}
