export type MenusFormResult = 'OK' | 'Cancelled';
