import swal2 from 'sweetalert2';

import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';

import { AddUpdateMenuFormService, MenuFormControls } from './menu-creation-edition-form.service';

import { DEFAULT_STRING } from '../../../../../../app/core';
import {
  AssignmentSelectorConfig,
  AssignmentSelectorFormConfig,
  AssignmentSelectorSelectedConfig
} from '../../../../../../app/shared';
import { MenuConfiguration } from '../../menu-configuration.model';
import { BaseMenuCreationEditonComponent } from './base-menu-creation-edition.component';

@Component({
  selector: 'app-menu-creation-edition',
  templateUrl: './menu-creation-edition.component.html',
  styleUrls: ['./menu-creation-edition.component.scss']
})
export class MenuCreationEditionComponent extends BaseMenuCreationEditonComponent implements OnInit {
  public titleLabel: string;
  public isSubmenuForm = false;
  public addOrUpdateMenuForm: FormGroup<MenuFormControls>;
  public availableMenuConfigs: MenuConfiguration[];

  constructor(
    protected readonly addUpdateFormService: AddUpdateMenuFormService,
    protected readonly formBuilder: FormBuilder
  ) {
    super(addUpdateFormService);
  }

  public ngOnInit(): void {
    super.ngOnInit();
    console.log('AddUpdateMenuComponent', 'ngOnInit');
    this.titleLabel = this.isNewMenuForm() ? 'Crear nuevo menú' : 'Actualizar menú';
  }

  public setFormAssignament(assignmentSelectorFormConfig: AssignmentSelectorSelectedConfig): void {
    console.log('AddUpdateMenuComponent', 'setFormAssignament', assignmentSelectorFormConfig);
    this.addOrUpdateMenuForm.controls.classification?.setValue(
      assignmentSelectorFormConfig.selectedClasification ?? DEFAULT_STRING
    );
    this.addOrUpdateMenuForm.controls.group?.setValue(assignmentSelectorFormConfig.selectedProject ?? DEFAULT_STRING);
    this.addOrUpdateMenuForm.controls.client?.setValue(assignmentSelectorFormConfig.selectedClient ?? DEFAULT_STRING);
  }

  protected initializeForm(): void {
    this.addOrUpdateMenuForm = this.addUpdateFormService.menuConfigToFormGroup(this.config);
  }

  protected async submitNewMenuForm(): Promise<void> {
    console.log('AddUpdateMenuComponent', 'submitNewMenuForm');

    await this.addUpdateFormService.menuManagement
      .createMenuConfiguration(this.addUpdateFormService.formGroupToNewMenuConfig(this.addOrUpdateMenuForm))
      .then(() => this.formResult.emit('OK'))
      .catch(() => this.showCreateMenuConfigurationErrorUi());
  }

  protected async submitUpdatedMenuForm(): Promise<void> {
    console.log('AddUpdateMenuComponent', 'submitUpdatedMenuForm');

    await this.addUpdateFormService.menuManagement
      .updateMenuConfiguration(
        this.addUpdateFormService.formGroupToUpdatedMenuConfig(this.addOrUpdateMenuForm, this.config)
      )
      .then(() => this.formResult.emit('OK'))
      .catch(() => this.showUpdateMenuConfigurationErrorUi());
  }

  protected showCreateMenuConfigurationErrorUi(): void {
    void swal2.fire('Error inesperado`, `No se ha podido crear el nuevo menú.', 'error');
  }

  protected showUpdateMenuConfigurationErrorUi(): void {
    void swal2.fire('Error inesperado`, `No se ha podido actualizar menú.', 'error');
  }
}
