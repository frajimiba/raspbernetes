import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatOptionModule } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectModule } from '@angular/material/select';

import { AssignmentSelectorModule } from '../../../../../../app/shared';
import { MenuCreationEditionComponent } from './menu-creation-edition.component';
import { SubmenuCreationEditionComponent } from './submenu-creation-edition.component';

const DEPENDENCIES = [
  CommonModule,
  ReactiveFormsModule,
  FormsModule,
  MatOptionModule,
  MatInputModule,
  MatFormFieldModule,
  MatCheckboxModule,
  MatSelectModule,
  MatIconModule,
  MatProgressSpinnerModule,
  MatButtonModule,
  AssignmentSelectorModule
];

const DECLARATIONS = [MenuCreationEditionComponent, SubmenuCreationEditionComponent];

@NgModule({
  declarations: DECLARATIONS,
  imports: DEPENDENCIES,
  exports: [DECLARATIONS, DEPENDENCIES]
})
export class MenuCreationEditionModule {}
