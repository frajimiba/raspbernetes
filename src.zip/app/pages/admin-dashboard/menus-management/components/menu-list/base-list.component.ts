import { Subject, takeUntil } from 'rxjs';
import swal2, { SweetAlertOptions } from 'sweetalert2';

import { ChangeDetectorRef, Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { MatSort, Sort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';

import {
  ClassificationsGroupsClientsEntry,
  LoadingService,
  MAT_DIALOG_CLOSE_WITH_OK
} from '../../../../../../app/core';
import { MenuConfiguration, SubMenuConfiguration } from '../../../../../../app/pages';
import { PaginatorModel } from '../../../../../../app/shared';
import { MenuCreationEditionDialogComponent, MenuCreationEditionDialogService } from '../../shared';

const LOG_TAG = 'BaseMenuListComponent';
@Component({
  template: ''
})
export abstract class BaseMenuListComponent implements OnInit, OnDestroy {
  @ViewChild('empTbSort') empTbSort = new MatSort();

  public paginatorModel: PaginatorModel = {
    ascending: true,
    pageIndex: 0,
    size: 50,
    sortCol: 'position'
  };

  public numOfResults = 0;

  protected classificationsGroupsClientsEntry: ClassificationsGroupsClientsEntry = {
    classifications: [],
    clients: [],
    groups: []
  };

  protected readonly stopSubscriptionsNotifier = new Subject<void>();

  public abstract menuTableDataSource: MatTableDataSource<MenuConfiguration | SubMenuConfiguration>;
  public abstract columnsToDisplay: string[];
  public abstract isLoading: boolean;

  constructor(
    protected readonly loadingService: LoadingService,
    protected readonly changeDetectorRef: ChangeDetectorRef,
    protected readonly menuCreationEditionDialogService: MenuCreationEditionDialogService
  ) {
    console.log(`${LOG_TAG}`, 'new instance');
  }

  public ngOnInit(): void {
    console.log(`${LOG_TAG}`, 'ngOnInit');
    void this.initializeState();
  }

  public ngOnDestroy(): void {
    console.log(`${LOG_TAG}`, 'ngOnDestroy');
    this.stopSubscriptionsNotifier.next();
    this.stopSubscriptionsNotifier.complete();
  }

  public applyFilter(event: Event): void {
    const filterValue = (event.target as HTMLInputElement).value;
    this.menuTableDataSource.filter = filterValue.trim().toLowerCase();
  }

  public setSearchCombos(classificationsGroupsClientsEntry: ClassificationsGroupsClientsEntry): void {
    this.classificationsGroupsClientsEntry = classificationsGroupsClientsEntry;
  }

  public updateMenuClicked(menuConfig: MenuConfiguration | SubMenuConfiguration): void {
    console.log(`${LOG_TAG}`, 'updateMenuClicked clicked');
    void this.showUpdateMenuUi(menuConfig);
  }

  public deleteMenuClicked(menuConfig: MenuConfiguration | SubMenuConfiguration): void {
    console.log(`${LOG_TAG}`, 'deleteMenuClicked', menuConfig);
    this.showDeleteMenuConfirmationUi(menuConfig);
  }

  protected initializeMatTableSorting(): void {
    this.changeDetectorRef.detectChanges();

    if (this.empTbSort) {
      this.empTbSort.disableClear = true;
      this.menuTableDataSource.sort = this.empTbSort;
    }
  }

  protected showDeleteMenuConfigurationErrorUi(): void {
    void this.generateSweetAlertDefaultConfiguration().fire('Error eliminando menú!'); // pasar a string especifico
  }

  protected generateSweetAlertDefaultConfiguration(): typeof swal2 {
    return swal2.mixin({
      customClass: {
        confirmButton: 'btn btn-solid__success',
        cancelButton: 'btn btn-solid__danger'
      },
      buttonsStyling: false
    });
  }

  protected showDeleteMenuConfirmationUi(menuConfig: MenuConfiguration | SubMenuConfiguration): void {
    void this.deleteConfirmationUi(menuConfig);
  }

  protected async showCreateUpdateMenuUi(
    config: SubMenuConfiguration | MenuConfiguration
  ): Promise<MatDialogRef<MenuCreationEditionDialogComponent>> {
    console.log(`${LOG_TAG}`, 'showCreateUpdateMenuUi');

    const modalUiConfig = {
      panelClass: 'default-modal',
      data: config
    };
    return this.menuCreationEditionDialogService.open(modalUiConfig);
  }

  protected menuCreationEditionUiClosed(dialogRef: MatDialogRef<MenuCreationEditionDialogComponent, number>): void {
    dialogRef
      .afterClosed()
      .pipe(takeUntil(this.stopSubscriptionsNotifier))
      .subscribe({
        next: modalClosedResult => {
          if (modalClosedResult !== MAT_DIALOG_CLOSE_WITH_OK) {
            return;
          }
          console.log(`${LOG_TAG}`, 'menuCreationEditionUiClosed', 'updated menu OK');
          void this.initializeState();
        }
      });
  }

  private deleteConfirmationUi(menuConfig: MenuConfiguration | SubMenuConfiguration): void {
    void this.generateSweetAlertDefaultConfiguration()
      .fire(this.getDeleteConfirmationAlertConfig(menuConfig.name))
      .then(result => {
        if (result.isConfirmed) {
          void this.deleteMenu(menuConfig);
        }
      })
      .catch(() => this.showDeleteMenuConfigurationErrorUi());
  }

  private async deleteMenu(menuConfig: MenuConfiguration | SubMenuConfiguration): Promise<void> {
    this.loadingService.setLoadingState(true);
    await this.deleteMenuById(menuConfig.id);
    this.loadingService.setLoadingState(false);
  }

  private getDeleteConfirmationAlertConfig(menuConfigName: string): SweetAlertOptions<any> {
    return {
      title: '¿Está seguro?',
      html: `¿Seguro que desea eliminar el menú '${menuConfigName}', <b>No se podrá eliminar si tiene submenús asociados</b> ?`, // textos especificos
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Si, eliminar!',
      cancelButtonText: 'No, cancelar!',
      reverseButtons: true
    };
  }

  /** Initialize table dataset state */
  public abstract initializeState(): Promise<void>;

  /* Sort config */
  public abstract sortMenuConfigs(event: Sort): void;

  /* Page config */
  public abstract pageChanged(event: any): void;

  /** Initialize table dataset state */
  protected abstract showUpdateMenuUi(menuConfig: MenuConfiguration | SubMenuConfiguration): Promise<void>;

  /** Initialize table dataset state */
  protected abstract deleteMenuById(menuConfigId: number): Promise<void>;
}
