import { ChangeDetectorRef, Component, OnDestroy, OnInit } from '@angular/core';
import { Sort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';

import { LoadingService, ZERO } from '../../../../../../app/core';
import { SubmenusManagementService } from '../../../../../../app/pages';
import { SubMenuConfiguration } from '../../models/menu-configuration.model';
import { MenuCreationEditionDialogService } from '../../shared';
import { BaseMenuListComponent } from './base-list.component';

@Component({
  selector: 'app-submenu-list',
  templateUrl: './menu-list.component.html',
  styleUrls: ['./menu-list.component.scss']
})
export class SubMenuListComponent extends BaseMenuListComponent implements OnDestroy, OnInit {
  public menuTableDataSource: MatTableDataSource<SubMenuConfiguration>;
  public columnsToDisplay: string[];
  public isLoading = true;

  constructor(
    private readonly submenusManagementService: SubmenusManagementService,
    protected readonly loadingService: LoadingService,
    protected readonly changeDetectorRef: ChangeDetectorRef,
    protected readonly menuCreationEditionDialogService: MenuCreationEditionDialogService
  ) {
    super(loadingService, changeDetectorRef, menuCreationEditionDialogService);
    console.log('SubMenuListComponent', 'new instance');
    this.menuTableDataSource = new MatTableDataSource<SubMenuConfiguration>([]);
    this.columnsToDisplay = [
      'position',
      'menu',
      'name',
      'description',
      'roles',
      'active',
      'edit-action',
      'delete-action'
    ];
  }

  public ngOnInit(): void {
    super.ngOnInit();
    console.log('SubMenuListComponent', 'ngOnInit');
  }

  public ngOnDestroy(): void {
    super.ngOnDestroy();
    console.log('SubMenuListComponent', 'ngOnDestroy');
  }

  public async initializeState(): Promise<void> {
    console.log('SubMenuListComponent', 'initializeState');
    this.menuTableDataSource.data = await this.submenusManagementService.getSubMenusConfigurations(
      this.paginatorModel.ascending,
      this.paginatorModel.pageIndex,
      this.paginatorModel.size,
      this.paginatorModel.sortCol,
      this.classificationsGroupsClientsEntry
    );
    this.isLoading = false;
    this.initializeMatTableSorting();
  }

  public pageChanged(event: any): void {
    this.paginatorModel.pageIndex = event.pageIndex;
    this.paginatorModel.size = event.pageSize;
    this.isLoading = true;
    void this.initializeState();
  }

  public sortMenuConfigs(event: Sort): void {
    this.paginatorModel.pageIndex = ZERO;
    this.paginatorModel.sortCol = this.empTbSort.active;
    this.paginatorModel.ascending = this.empTbSort.direction === 'asc';
    this.isLoading = true;
    void this.initializeState();
  }

  protected async showUpdateMenuUi(submenuConfiguration: SubMenuConfiguration): Promise<void> {
    console.log('SubMenuListComponent', 'showUpdateMenuUi');

    const dialogRef = await this.showCreateUpdateMenuUi(submenuConfiguration);
    if (!dialogRef) {
      return;
    }
    super.menuCreationEditionUiClosed(dialogRef);
  }

  protected async deleteMenuById(menuConfigId: number): Promise<void> {
    await this.submenusManagementService
      .deleteSubMenuConfiguration(menuConfigId)
      .then(async () => this.initializeState())
      .catch(() => this.showDeleteMenuConfigurationErrorUi());
  }
}
