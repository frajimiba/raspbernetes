/* eslint-disable @typescript-eslint/no-unnecessary-type-assertion */
import { MenuEntry, SubmenuEntry } from '../../../../../app/core';

/* Tipo personalizado con  las propiedades de "MenuEntry" para consultas
  - se convierten todas en inmutables, 
  - se convierten todas en obligatorias
  - se omiten las no usadas en el front-end 
  */
export type MenuConfiguration = Readonly<Required<Omit<MenuEntry, 'ingestedAt' | 'modifiedAt' | 'submenus'>>> & {
  readonly submenus?: SubMenuConfiguration[];
};

/* Tipo personalizado con  las propiedades de "MenuEntry" para creación de objetos
  - se omite adicionalmente la propiedad id
  */
export type NewMenuConfiguration = Omit<MenuConfiguration, 'id' | 'submenus'>;

/* Tipo personalizado con  las propiedades de "SubmenuEntry" para consultas
  - se convierten todas en inmutables, 
  - se convierten todas en obligatorias (excepto menu que es opcional)
  - se omiten las no usadas en el front-end 
  */
export type SubMenuConfiguration = Readonly<Required<Omit<SubmenuEntry, 'ingestedAt' | 'modifiedAt' | 'menu'>>> & {
  readonly menu?: MenuConfiguration; // convertirla a required en el tipo NewSubMenuConfiguration
};

/* Tipo personalizado con  las propiedades de "SubmenuEntry" para creación de objetos
  - se omite adicionalmente la propiedad id
  */
export type NewSubMenuConfiguration = Omit<SubMenuConfiguration, 'id'>;

export type MenuManagementMode = 'Menu' | 'Submenu';

export interface MenuManagementModeConfig {
  mode: MenuManagementMode;
}

export function isSubMenuConfiguration(config: SubMenuConfiguration): config is SubMenuConfiguration {
  return (config as SubMenuConfiguration).menu != null && (config as MenuConfiguration).submenus == null;
}
