/* eslint-disable complexity */
import { DEFAULT_INDEX, DEFAULT_STRING, MenuEntry, SubmenuEntry } from '../../../../../app/core';
import { MenuConfiguration, SubMenuConfiguration } from '../../../../../app/pages';

/** Set default values to menu if undefined */
export function subMenuEntryToSubMenuConfig(submenuEntry: SubmenuEntry): SubMenuConfiguration {
  const categoryLink: SubMenuConfiguration = {
    id: submenuEntry?.id ?? DEFAULT_INDEX,
    active: submenuEntry?.active ?? false,
    description: submenuEntry?.description ?? DEFAULT_STRING,
    internal: submenuEntry?.internal ?? false,
    link: submenuEntry?.link ?? DEFAULT_STRING,
    name: submenuEntry?.name ?? DEFAULT_STRING,
    position: submenuEntry?.position ?? DEFAULT_INDEX,
    roles: submenuEntry?.roles ?? DEFAULT_STRING,
    menu: submenuEntry?.menu ? menuEntryToMenuConfig(submenuEntry.menu) : undefined,
    client: submenuEntry?.client ?? DEFAULT_STRING,
    group: submenuEntry?.group ?? DEFAULT_STRING,
    classification: submenuEntry?.classification ?? DEFAULT_STRING
  };

  return categoryLink;
}

/** Set default values to menu if undefined */
export function menuEntryToMenuConfig(menuEntry: MenuEntry): MenuConfiguration {
  const categoryLink: MenuConfiguration = {
    id: menuEntry?.id ?? DEFAULT_INDEX,
    active: menuEntry?.active ?? false,
    description: menuEntry?.description ?? DEFAULT_STRING,
    internal: menuEntry?.internal ?? false,
    link: menuEntry?.link ?? DEFAULT_STRING,
    name: menuEntry?.name ?? DEFAULT_STRING,
    position: menuEntry?.position ?? DEFAULT_INDEX,
    roles: menuEntry?.roles ?? DEFAULT_STRING,
    submenus: menuEntry?.submenus ? mapSubMenuEntries(menuEntry.submenus) : [],
    client: menuEntry?.client ?? DEFAULT_STRING,
    group: menuEntry?.group ?? DEFAULT_STRING,
    classification: menuEntry?.classification ?? DEFAULT_STRING
  };

  return categoryLink;
}

export function mapSubMenuEntries(subMenuRemoteConfigurations: SubmenuEntry[]): SubMenuConfiguration[] {
  const subMenuConfigurations: SubMenuConfiguration[] = [];

  subMenuRemoteConfigurations.forEach(subMenuEntry => {
    if (!isValidSubMenuEntry(subMenuEntry)) {
      console.error('La configuracion de submenú no tiene un identificador válido', subMenuEntry);
    }
    subMenuConfigurations.push(subMenuEntryToSubMenuConfig(subMenuEntry));
  });

  return subMenuConfigurations;
}

export function mapMenuEntries(menuRemoteConfigurations: MenuEntry[]): MenuConfiguration[] {
  const menuConfigurations: MenuConfiguration[] = [];

  menuRemoteConfigurations.forEach(menuEntry => {
    if (!isValidMenuEntry(menuEntry)) {
      console.error('La configuracion de menu no tiene un identificador válido', menuEntry);
    }
    menuConfigurations.push(menuEntryToMenuConfig(menuEntry));
  });

  return menuConfigurations;
}

/** Valida una configuración de submenú si es un objeto válidao y al menos tiene un identificador válido */
function isValidSubMenuEntry(subMenuConfig: SubmenuEntry): boolean {
  return subMenuConfig && typeof subMenuConfig.id === 'number';
}

/** Valida una configuración de menú si es un objeto válidao y al menos tiene un identificador válido */
function isValidMenuEntry(menuConfig: MenuEntry): boolean {
  return menuConfig && typeof menuConfig.id === 'number';
}
