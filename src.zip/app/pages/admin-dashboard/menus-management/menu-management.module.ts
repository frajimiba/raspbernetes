import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatOptionModule } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectModule } from '@angular/material/select';
import { MatSortModule } from '@angular/material/sort';
import { MatTableModule } from '@angular/material/table';
import { RouterModule, Routes } from '@angular/router';

import { MenuCreationEditionModule } from './shared/menu-creation-edition/menu-creation-edition.module';

import { AssignmentSelectorModule } from '../../../../app/shared';
import { MenuListComponent } from './components/menu-list/menu-list.component';
import { SubMenuListComponent } from './components/menu-list/submenu-list.component';
import { MenuManagementComponent } from './menu-management.component';

const routes: Routes = [{ path: '', component: MenuManagementComponent }];

@NgModule({
  declarations: [MenuManagementComponent, MenuListComponent, SubMenuListComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    ReactiveFormsModule,
    FormsModule,
    MatOptionModule,
    MatTableModule,
    MatInputModule,
    MatPaginatorModule,
    MatFormFieldModule,
    MatCheckboxModule,
    MatSelectModule,
    MatIconModule,
    MatProgressSpinnerModule,
    MatButtonModule,
    MatSortModule,
    MenuCreationEditionModule, // TODO: quitar
    AssignmentSelectorModule
  ],
  exports: [
    MenuManagementComponent,
    ReactiveFormsModule,
    FormsModule,
    MatOptionModule,
    MatTableModule,
    MatInputModule,
    MatPaginatorModule,
    MatFormFieldModule,
    MatCheckboxModule,
    MatSelectModule,
    MatIconModule,
    MatProgressSpinnerModule,
    MatButtonModule,
    MatSortModule
  ]
})
export class MenuManagementModule {}
