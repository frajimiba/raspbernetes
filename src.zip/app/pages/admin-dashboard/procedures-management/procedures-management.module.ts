import { NgxJsonEditorModule } from '@dimakorotkov/ngx-json-editor';
import { NgxEditorModule } from 'ngx-editor';

import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatOptionModule } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectModule } from '@angular/material/select';
import { MatSortModule } from '@angular/material/sort';
import { MatTableModule } from '@angular/material/table';
import { MatTabsModule } from '@angular/material/tabs';
import { RouterModule, Routes } from '@angular/router';

import { AssignmentSelectorModule, PipesModule } from '../../../../app/shared';
import { AddEditProceduresPageComponent } from './components/add-edit-procedures-page/add-edit-procedures-page.component';
import { CustomNgxJsonEditorComponent } from './components/add-edit-procedures-page/components/custom-ngx-json-editor.component';
import { ProceduresPagesListComponent } from './components/procedures-pages-list/procedures-pages-list.component';
import { ProceduresManagementComponent } from './procedures-management.component';

const routes: Routes = [{ path: '', component: ProceduresManagementComponent }];
@NgModule({
  declarations: [
    CustomNgxJsonEditorComponent,
    ProceduresManagementComponent,
    ProceduresPagesListComponent,
    AddEditProceduresPageComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    ReactiveFormsModule,
    FormsModule,
    MatFormFieldModule,
    MatOptionModule,
    MatTableModule,
    MatInputModule,
    PipesModule,
    MatProgressSpinnerModule,
    MatPaginatorModule,
    MatFormFieldModule,
    MatCheckboxModule,
    MatSelectModule,
    MatIconModule,
    MatProgressSpinnerModule,
    MatButtonModule,
    MatTabsModule,
    MatSortModule,
    AssignmentSelectorModule,
    NgxJsonEditorModule
  ],
  exports: [
    ReactiveFormsModule,
    FormsModule,
    MatOptionModule,
    MatFormFieldModule,
    MatTableModule,
    MatInputModule,
    MatPaginatorModule,
    MatProgressSpinnerModule,
    MatFormFieldModule,
    MatCheckboxModule,
    MatSelectModule,
    MatIconModule,
    MatProgressSpinnerModule,
    MatButtonModule,
    MatTabsModule,
    MatSortModule
  ]
})
export class ProceduresManagementModule {}
