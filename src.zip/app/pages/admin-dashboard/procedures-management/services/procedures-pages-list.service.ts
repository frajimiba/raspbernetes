import { Injectable } from '@angular/core';

import { ExecutionTemplateApiService, ExecutionTemplateDTO } from '../../../../../app/core';
import { PaginatorModel } from '../../../../shared/models/paginator.model';
import { toProceduresPageItem } from '../models/procedures-page-item.mapper';
import { ProceduresPageItem } from '../models/procedures-page-item.model';
import { PagedProceduresPages } from '../models/procedures-page-list.model';

@Injectable({
  providedIn: 'root'
})
export class ProceduresPagesListService {
  constructor(private readonly executionTemplateApiService: ExecutionTemplateApiService) {}

  public async getProceduresPages(paginatorModel: PaginatorModel): Promise<PagedProceduresPages> {
    console.log('ProceduresPageListService', 'getMenuConfigurations');
    return this.executionTemplateApiService
      .getExecutionTemplates({
        page: paginatorModel.pageIndex,
        size: paginatorModel.size,
        sort: paginatorModel.sortCol,
        ascending: paginatorModel.ascending
      })
      .then(items => {
        return {
          content: items.list?.map(contentItem => toProceduresPageItem(contentItem)) ?? [],
          index: items.page ?? 0,
          size: items.size ?? 0,
          totalCount: items.numOfResults ?? 0
        };
      })
      .catch(error => {
        console.error(error);
        return {
          content: [],
          index: 0,
          size: 0,
          totalCount: 0
        };
      });
  }

  public async updateProceduresPage(item: ProceduresPageItem): Promise<ExecutionTemplateDTO> {
    console.log('ProceduresPageListService', 'updateProceduresPage', item);
    return this.executionTemplateApiService.updateExecutionTemplate(item.id, item);
  }

  public async deleteProceduresPage(item: ProceduresPageItem): Promise<any> {
    console.log('ProceduresPageListService', 'deleteProceduresPage', item);
    return this.executionTemplateApiService.deleteExecutionTemplate(item.id);
  }
}
