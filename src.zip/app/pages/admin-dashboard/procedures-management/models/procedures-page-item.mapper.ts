import { ExecutionTemplateDTO, ExecutionTemplateEntry } from '../../../../../app/core';
import { ProceduresPageEntryItem, ProceduresPageItem } from './procedures-page-item.model';

export function toProceduresPageItem(item: ExecutionTemplateDTO): ProceduresPageItem {
  return {
    id: item.id ?? 0,
    templateName: item.templateName ?? '',
    templateType: item.templateType ?? '',
    templateId: item.templateId ?? '',
    templateConfig: item.templateConfig ?? '',
    createdBy: item.createdBy ?? '',
    creationDate: item.creationDate ?? ''
  };
}

export function toProceduresPageEntryItem(item: ExecutionTemplateEntry): ProceduresPageEntryItem {
  return {
    templateName: item.templateName ?? '',
    templateType: item.templateType ?? '',
    templateId: item.templateId ?? '',
    templateConfig: item.templateConfig ?? ''
  };
}
