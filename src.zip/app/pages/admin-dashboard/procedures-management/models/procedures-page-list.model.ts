import { PagedResultLiteralDTO } from '../../../../../app/core/api/api-client-library';
import { ProceduresPageItem } from './procedures-page-item.model';

export type PagedProceduresPages = Readonly<
  Required<Omit<PagedResultLiteralDTO, 'content'> & { content: ProceduresPageItem[] }>
>;
