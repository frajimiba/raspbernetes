import { ExecutionTemplateDTO, ExecutionTemplateEntry } from '../../../../../app/core';

export type ProceduresPageItem = Readonly<Required<ExecutionTemplateDTO>>;

export type ProceduresPageEntryItem = Readonly<Required<Omit<ExecutionTemplateEntry, 'id'>>>;
