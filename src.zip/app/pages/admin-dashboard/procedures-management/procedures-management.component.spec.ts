import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProceduresManagementComponent } from './procedures-management.component';

xdescribe('ProceduresManagementComponent', () => {
  let component: ProceduresManagementComponent;
  let fixture: ComponentFixture<ProceduresManagementComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ProceduresManagementComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(ProceduresManagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
