import { Subject, takeUntil } from 'rxjs';
import swal2 from 'sweetalert2';

import { animate, state, style, transition, trigger } from '@angular/animations';
import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSort, Sort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';

import { ProceduresPagesListService } from '../../services/procedures-pages-list.service';

import { LoadingService, MAT_DIALOG_CLOSE_WITH_OK, ZERO } from '../../../../../../app/core';
import { PaginatorModel } from '../../../../../../app/shared';
import { ProceduresPageItem } from '../../models/procedures-page-item.model';
import { PagedProceduresPages } from '../../models/procedures-page-list.model';
import { AddEditProceduresPageComponent } from '../add-edit-procedures-page/add-edit-procedures-page.component';

const LOG_TAG = 'ProceduresPagesListComponent';

@Component({
  selector: 'app-procedures-pages-list',
  templateUrl: './procedures-pages-list.component.html',
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)'))
    ])
  ],
  styleUrls: ['./procedures-pages-list.component.scss']
})
export class ProceduresPagesListComponent implements OnInit, OnDestroy {
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  public isLoading = true;
  public paginatorModel: PaginatorModel;
  public numOfResults = ZERO;

  public items: ProceduresPageItem[];
  public dataSource: MatTableDataSource<ProceduresPageItem>;
  public columnsToDisplay: string[] = ['templateId', 'templateName', 'templateType', 'actions'];
  public expandedItem: ProceduresPageItem | undefined;

  private readonly swalWithButtons = swal2.mixin({
    customClass: {
      confirmButton: 'btn btn-solid__success',
      cancelButton: 'btn btn-solid__danger'
    },
    buttonsStyling: false
  });

  private readonly stopSubscriptionsNotifier = new Subject<void>();

  constructor(
    private readonly dialog: MatDialog,
    private readonly proceduresPagesService: ProceduresPagesListService,
    private readonly loadingService: LoadingService
  ) {}

  public ngOnInit(): void {
    console.log(`${LOG_TAG}`, 'ngOnInit');
    this.setInitialPaginatorConfig();
    void this.initializeState();
  }

  public ngOnDestroy(): void {
    console.log(`${LOG_TAG}`, 'ngOnDestroy');
    this.stopSubscriptionsNotifier.next();
    this.stopSubscriptionsNotifier.complete();
  }

  public async initializeState(): Promise<void> {
    console.log(`${LOG_TAG}`, 'initializeState');
    this.startLoading();
    this.getAllLinks();
  }

  public editItem(item: ProceduresPageItem): void {
    this.openUpdateItemModal(item);
  }

  public askToDeleteItem(item: ProceduresPageItem): void {
    this.swalWithButtons
      .fire({
        title: '¿Está seguro?',
        html: `¿Seguro que desea eliminar '${item.id}'?`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Si, eliminar!',
        cancelButtonText: 'No, cancelar!',
        reverseButtons: true
      })
      .then(result => {
        if (result.isConfirmed) {
          this.deleteItem(item);
        }
      })
      .catch(error => {
        console.log(error);
      });
  }

  public applyFilter(event: Event): void {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  public sortChanged(event: Sort): void {
    this.paginatorModel.sortCol = event.active;
    this.paginatorModel.ascending = event.direction === 'asc';
    this.getAllLinks();
  }

  public pageChanged(event: any): void {
    this.paginatorModel.pageIndex = event.pageIndex;
    this.paginatorModel.size = event.pageSize;
    this.getAllLinks();
  }

  public customFilterPredicate(data: ProceduresPageItem, filter: string): boolean {
    const filterLowerCased = filter.toLocaleLowerCase();
    return (
      data.templateId.toLocaleLowerCase().includes(filterLowerCased) ||
      data.templateName.toLocaleLowerCase().includes(filterLowerCased)
    );
  }

  private getAllLinks(): void {
    this.proceduresPagesService
      .getProceduresPages(this.paginatorModel)
      .then((items: PagedProceduresPages) => this.onGetListOK(items))
      .catch(error => this.onGetListKO(error))
      .finally(() => this.stopLoading());
  }

  private onGetListOK(result: PagedProceduresPages): void {
    this.items = result.content;
    this.dataSource = new MatTableDataSource<ProceduresPageItem>(this.items);
    this.dataSource.sort = this.sort;
    this.dataSource.filterPredicate = this.customFilterPredicate;
    this.numOfResults = result.content.length;
  }

  private onGetListKO(error: any): void {
    console.error(`${LOG_TAG} - No ha sido posible recuperar los enlaces`, error);
    void swal2.fire('Error recuperando los enlaces', `No ha sido posible recuperar los enlaces`, 'error');
  }

  private deleteItem(item: ProceduresPageItem): void {
    this.loadingService.setLoadingState(true);
    this.proceduresPagesService
      .deleteProceduresPage(item)
      .then(() => {
        this.itemDeleted(item.id);
      })
      .catch(() => {
        void swal2.fire('Error inesperado!', 'No se ha podido eliminar el enlace', 'error');
      })
      .finally(() => this.loadingService.setLoadingState(false));
  }

  private itemDeleted(itemName: number): void {
    void swal2.fire('Eliminado!', `'${itemName}' eliminado con éxito.`, 'success').then(result => {
      if (result.isConfirmed) {
        this.getAllLinks();
      }
    });
  }

  private openUpdateItemModal(item: ProceduresPageItem): void {
    this.dialog
      .open(AddEditProceduresPageComponent, {
        panelClass: 'default-modal',
        data: {
          item
        }
      })
      .afterClosed()
      .pipe(takeUntil(this.stopSubscriptionsNotifier))
      .subscribe({
        next: modalClosedResult => {
          if (modalClosedResult !== MAT_DIALOG_CLOSE_WITH_OK) {
            return;
          }
          console.log(LOG_TAG, 'openUpdateItemModal OK');
          void this.initializeState();
        }
      });
  }

  private setInitialPaginatorConfig(): void {
    this.paginatorModel = {
      pageIndex: 0,
      size: 50,
      ascending: true,
      sortCol: 'id'
    };
  }

  private startLoading(): void {
    this.isLoading = true;
  }

  private stopLoading(): void {
    this.isLoading = false;
  }
}
