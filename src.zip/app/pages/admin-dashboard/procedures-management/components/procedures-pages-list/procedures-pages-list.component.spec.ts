import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProceduresPagesListComponent } from './procedures-pages-list.component';

xdescribe('ProceduresPagesListComponent', () => {
  let component: ProceduresPagesListComponent;
  let fixture: ComponentFixture<ProceduresPagesListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ProceduresPagesListComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(ProceduresPagesListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
