import { Injectable } from '@angular/core';

import { ExecutionTemplateApiService, ExecutionTemplateDTO } from '../../../../../../../app/core';
import { ProceduresPageEntryItem, ProceduresPageItem } from '../../../models/procedures-page-item.model';

@Injectable({
  providedIn: 'root'
})
export class AddEditProceduresPageService {
  constructor(private readonly executionTemplateApiService: ExecutionTemplateApiService) {}

  public async createProceduresPages(item: ProceduresPageEntryItem): Promise<ExecutionTemplateDTO> {
    console.log('ProceduresPagesService', 'createProceduresPages');
    return this.executionTemplateApiService.createExecutionTemplate(item);
  }

  public async updateProceduresPages(item: ProceduresPageItem): Promise<ExecutionTemplateDTO> {
    console.log('ProceduresPagesService', 'updateProceduresPages');
    return this.executionTemplateApiService.updateExecutionTemplate(item.id, item);
  }
}
