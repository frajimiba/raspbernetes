import { Editor, Toolbar } from 'ngx-editor';
import swal2 from 'sweetalert2';

import { Component, Inject, Input, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

import { AddEditProceduresPageService } from './services/add-edit-procedures-page.service';

import { MAT_DIALOG_CLOSE_WITH_OK, MAT_DIALOG_CLOSE_WITHOUT_ACTIONS } from '../../../../../../app/core';
import { CustomNgxJsonEditorComponent } from './components/custom-ngx-json-editor.component';
import { AddEditInput } from './models/add-edit-procedures-page.model';

@Component({
  selector: 'app-add-edit-procedures-page',
  templateUrl: './add-edit-procedures-page.component.html',
  styleUrls: ['./add-edit-procedures-page.component.scss']
})
export class AddEditProceduresPageComponent implements OnInit {
  @ViewChild('editor') editor: CustomNgxJsonEditorComponent;

  edit: boolean = false;
  isLoading: boolean = false;
  public form: FormGroup;
  public classificationId: string;
  public templateTypes = ['RUNDECK', 'AWX'];

  public jsonEditorOptions: JSONEditorOptions<any> = {
    theme: 'bootstrap4',
    ajax: false,
    show_errors: 'always',
    schema: {
      type: 'object',
      properties: {
        argString: {
          type: 'string'
        },
        loglevel: {
          type: 'string'
        },
        asUser: {
          type: 'string'
        },
        filter: {
          type: 'string'
        },
        runAtTime: {
          type: 'string'
        },
        options: {
          type: 'object',
          additionalProperties: {
            type: 'string'
          }
        }
      },
      required: ['argString', 'loglevel', 'asUser', 'filter', 'runAtTime', 'options']
    }
  };

  public defaultTemplateConfig = {
    argString: '',
    loglevel: 'INFO',
    asUser: '',
    filter: '',
    runAtTime: '',
    options: {}
  };

  constructor(
    private readonly formBuilder: FormBuilder,
    public readonly dialogRef: MatDialogRef<AddEditProceduresPageComponent>,
    public readonly addEditProceduresPageService: AddEditProceduresPageService,
    @Inject(MAT_DIALOG_DATA) public readonly input: AddEditInput
  ) {}

  ngOnInit(): void {
    this.edit = this.input.item !== undefined;
    this.initForm();
    if (this.edit) {
      this.form.controls.id.disable();
    }
  }

  public updateInitialJsonEditorValues(): void {
    let jsonValue = JSON.parse(this.form.controls.templateConfig.value);
    const errors = this.editor.editor?.validate(jsonValue);
    if (errors?.length ?? 0 > 0) {
      this.editor.editor?.setValue(this.defaultTemplateConfig);
    } else {
      this.editor.editor?.setValue(jsonValue);
    }
  }

  public submitForm(): void {
    if (this.form.valid) {
      this.isLoading = true;
      this.edit ? this.submitUpdated() : this.submitNew();
    }
  }

  public submitNew(): void {
    const templateConfigEditorValue = JSON.stringify(this.editor.editor?.getValue());
    this.addEditProceduresPageService
      .createProceduresPages({
        templateId: this.form.controls.templateId.value,
        templateName: this.form.controls.templateName.value,
        templateType: this.form.controls.templateType.value,
        templateConfig: templateConfigEditorValue ?? this.form.controls.templateConfig.value
      })
      .then(async result => this.showCreateSuccessUi())
      .catch(async result => this.showCreateErrorUi());
  }

  public submitUpdated(): void {
    const templateConfigEditorValue = JSON.stringify(this.editor.editor?.getValue());
    this.addEditProceduresPageService
      .updateProceduresPages({
        id: this.form.controls.id.value,
        templateId: this.form.controls.templateId.value,
        templateName: this.form.controls.templateName.value,
        templateType: this.form.controls.templateType.value,
        templateConfig: templateConfigEditorValue ?? this.form.controls.templateConfig.value,
        createdBy: this.form.controls.createdBy.value,
        creationDate: this.form.controls.creationDate.value
      })
      .then(async result => this.showUpdateSuccessUi())
      .catch(async result => this.showUpdateErrorUi());
  }

  public discardForm(): void {
    this.dialogRef.close(MAT_DIALOG_CLOSE_WITHOUT_ACTIONS);
  }

  public getTitle(): string {
    return this.edit ? 'Editar plantilla de procedimiento' : 'Agregar plantilla de procedimiento';
  }

  private initForm(): void {
    this.form = this.formBuilder.group({
      id: new FormControl(this.input?.item?.id ?? 0),
      templateId: new FormControl(this.input?.item?.templateId ?? '', Validators.required),
      templateName: new FormControl(this.input?.item?.templateName ?? ''),
      templateType: new FormControl(this.input?.item?.templateType ?? this.templateTypes[0]),
      templateConfig: new FormControl(this.input?.item?.templateConfig ?? this.defaultTemplateConfig),
      createdBy: new FormControl(this.input?.item?.createdBy ?? ''),
      creationDate: new FormControl(this.input?.item?.creationDate ?? '')
    });
  }

  private async showCreateSuccessUi(): Promise<void> {
    await swal2.fire(`Plantilla del procedimiento de procedures creada`, `Se ha creado correctamente.`, 'success');
    this.dialogRef.close(MAT_DIALOG_CLOSE_WITH_OK);
  }

  private async showUpdateSuccessUi(): Promise<void> {
    await swal2.fire(
      `Plantilla del procedimiento de procedures actualizada`,
      `Se ha actualizado correctamente.`,
      'success'
    );
    this.dialogRef.close(MAT_DIALOG_CLOSE_WITH_OK);
  }

  private showCreateErrorUi(): void {
    void swal2.fire(`Error inesperado`, `No se ha podido crear.`, 'error');
  }

  private showUpdateErrorUi(): void {
    void swal2.fire(`Error inesperado`, `No se ha podido actualizar.`, 'error');
  }
}
