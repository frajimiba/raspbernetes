import { ProceduresPageItem } from '../../../models/procedures-page-item.model';

export interface AddEditInput {
  item: ProceduresPageItem;
}
