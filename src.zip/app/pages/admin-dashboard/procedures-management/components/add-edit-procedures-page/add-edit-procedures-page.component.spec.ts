import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditProceduresPageComponent } from './add-edit-procedures-page.component';

xdescribe('AddEditProceduresPageComponent', () => {
  let component: AddEditProceduresPageComponent;
  let fixture: ComponentFixture<AddEditProceduresPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AddEditProceduresPageComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(AddEditProceduresPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
