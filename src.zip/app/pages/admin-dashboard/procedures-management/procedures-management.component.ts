import { Subject, takeUntil } from 'rxjs';

import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute } from '@angular/router';

import { MAT_DIALOG_CLOSE_WITH_OK } from '../../../../app/core';
import { AddEditProceduresPageComponent } from './components/add-edit-procedures-page/add-edit-procedures-page.component';
import { ProceduresPagesListComponent } from './components/procedures-pages-list/procedures-pages-list.component';
import { ProceduresPageItem } from './models/procedures-page-item.model';

@Component({
  selector: 'app-procedures-management',
  templateUrl: './procedures-management.component.html',
  styleUrls: ['./procedures-management.component.scss']
})
export class ProceduresManagementComponent implements OnInit, OnDestroy {
  @ViewChild('proceduresPagesListComponentRef') proceduresPagesListComponent: ProceduresPagesListComponent;
  public isLoading = true;

  private readonly stopSubscriptionsNotifier = new Subject<void>();

  constructor(private readonly route: ActivatedRoute, private readonly dialog: MatDialog) {}

  public ngOnInit(): void {
    console.log('ProceduresManagementComponent', 'ngOnInit');
    this.isLoading = false;
  }

  public ngOnDestroy(): void {
    console.log('ProceduresManagementComponent', 'ngOnDestroy');
    this.stopSubscriptionsNotifier.next();
    this.stopSubscriptionsNotifier.complete();
  }

  public addNewChatbotLiteral(): void {
    console.log('ProceduresManagementComponent', 'addNewChatbotLiteral');
    this.showAddEditLiteral();
  }

  private showAddEditLiteral(dto?: ProceduresPageItem): void {
    console.log('AddUpdateMenuService', 'showAddUpdateSubMenuUi');

    const modalUiConfig = {
      panelClass: 'default-modal',
      data: {
        item: dto
      }
    };

    this.dialog
      .open(AddEditProceduresPageComponent, {
        panelClass: 'default-modal',
        data: modalUiConfig
      })
      .afterClosed()
      .pipe(takeUntil(this.stopSubscriptionsNotifier))
      .subscribe({
        next: modalClosedResult => {
          if (modalClosedResult !== MAT_DIALOG_CLOSE_WITH_OK) {
            return;
          }
          console.log('BookmarkLinksComponent', 'addNewLink', 'create new link OK');
          void this.proceduresPagesListComponent?.initializeState();
        }
      });
  }
}
