import { Injectable } from '@angular/core';

import {
  CustomerConfig,
  GiteaApiService,
  KeycloakApiService,
  KeycloakGroupEntry,
  MassiveCustomerUsers
} from '../../../../../app/core';

@Injectable({
  providedIn: 'root'
})
export class UsersManagementService {
  constructor(
    private readonly keycloakApiService: KeycloakApiService,
    private readonly giteaApiService: GiteaApiService
  ) {}

  public async getCustomers(): Promise<KeycloakGroupEntry[]> {
    console.log('UsersManagementService', 'getCustomers');
    return this.keycloakApiService.getAuthUserGroups('type', 'customer', false);
  }

  public async getCustomerCatalog(customer: string): Promise<CustomerConfig> {
    console.log('UsersManagementService', 'getCustomerCatalog', customer);
    return this.giteaApiService.getGitea(customer);
  }

  public async sendMassiveUsers(massiveCustomerUsers: MassiveCustomerUsers): Promise<void> {
    console.log('UsersManagementService', 'sendMassiveUsers', massiveCustomerUsers);
    return this.keycloakApiService.postMassiveCustomerUsers(massiveCustomerUsers);
  }

  /* public getSubgroupsByAttribute(node: KeycloakGroupEntry, filterType: string): KeycloakGroupEntry[] {
    try {
      return this.filterSubgroupsByAttribute(node?.subGroups ?? [], filterType);
    } catch (error) {
      console.error(error);
      return [];
    }
  }

  private filterSubgroupsByAttribute(subgroups: KeycloakGroupEntry[], filterType: string): KeycloakGroupEntry[] {
    const list: KeycloakGroupEntry[] = [];

    subgroups.forEach(subgroup => {
      const subgroupType: string[] = subgroup.attributes?.type ?? [];
      if (subgroupType.some(type => type === filterType)) {
        list.push(subgroup);
      }
      if (subgroup.subGroups) {
        const subList = this.filterSubgroupsByAttribute(subgroup.subGroups, filterType);
        subList.forEach(subListItem => list.push(subListItem));
      }
    });

    return list;
  } */
}
