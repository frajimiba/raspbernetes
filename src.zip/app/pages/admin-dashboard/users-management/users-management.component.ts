import swal2 from 'sweetalert2';

import { COMMA, ENTER, SPACE } from '@angular/cdk/keycodes';
import { Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';

import { UsersManagementService } from './services/users-management.service';

import { CustomerConfig, KeycloakGroupEntry } from '../../../../app/core';

@Component({
  selector: 'app-users-management',
  templateUrl: './users-management.component.html',
  styleUrls: ['./users-management.component.scss']
})
export class UsersManagementComponent implements OnInit, OnDestroy {
  @ViewChild('chipInput') chipInput: ElementRef<HTMLInputElement>;

  public isLoading = true;

  public customers: KeycloakGroupEntry[] = [];
  public groups: string[] = [];
  public classifications: string[] = [];

  public form: FormGroup;
  public readonly separatorKeysCodes = [ENTER, SPACE, COMMA] as const;

  public infoNote =
    '\nAntes de rellenar el nombre del Customer que quieres dar de alta, debes ir al repositorio de Gitea: appops/cgc-application-config, y crear un fichero con el nombre (literal exacto) del Customer que vas a poner en este campo. Puedes copiar el fichero base "xxxx.json" y renombrar con el nombre literal del Customer. Una vez realizado, edita y cambia los valores internos (customer, groups, y revisa si quieres añadir classification al catálogo). Una vez finalizado, indica el nombre en el campo del formulario y dale al botón: OBTENER CLASIFICACIONES Y BUZONES EXTERNOS.\nUna vez realizado se cargarán los buzones y clasificaciones del fichero "New Customer.json", debes seleccionar aquellos que apliquen. \nLas clasificaciones que vienen por defecto es la Knowlwdge Matrix más general del equipo. Añade las nuevas en el fichero que te apliquen para ese Customer-Contrato. \nUna vez seleccionado, debes añadir los usuarios que quieres asignar a esos buzones (ojo se asignan todos los buzones) y Customer. Sino deberás una vez finalizado el proceso ir a Keycloak y asignar tú usuarios-new customer - new buzonexterno.';

  constructor(
    private readonly formBuilder: FormBuilder,
    private readonly usersManagementService: UsersManagementService
  ) {}

  public ngOnInit(): void {
    console.log('UsersManagementComponent', 'ngOnInit');
    this.initForm();
    this.initCustomers();
  }

  public ngOnDestroy(): void {
    console.log('UsersManagementComponent', 'ngOnDestroy');
  }

  public submitForm(): void {
    console.log('UsersManagementComponent', this.form.value);

    this.isLoading = true;
    void this.usersManagementService
      .sendMassiveUsers({
        classifications: this.form.controls.classifications.value,
        customer: this.form.controls.customer.value,
        groups: this.form.controls.groups.value,
        users: this.form.controls.users.value
      })
      .then(() => {
        this.isLoading = false;
        this.form.reset();
        void swal2.fire(`Configuración enviada`, `Se han configurado los usuarios correctamente.`, 'success');
      })
      .catch(() => {
        this.isLoading = false;
        void swal2.fire(`Error inesperado`, `No se ha podido realizar la operación.`, 'error');
      });
  }

  public updateUsersSelection(event: string[]): void {
    this.form.controls.users.setValue(event);
  }

  public customerChanged(): void {
    console.log('UsersManagementComponent', this.form.controls.customer);
    const selectedCustomer = this.form.controls.customer.value;
    // const customerNode: KeycloakGroupEntry = this.customers.filter(item => item.name === selectedCustomer.value)[0];
    // this.groups = this.usersManagementService.getSubgroupsByAttribute(customerNode, 'buzonexterno');
    // this.classifications = this.usersManagementService.getSubgroupsByAttribute(customerNode, 'classification');
    if (selectedCustomer === '') {
      this.classifications = [];
      this.groups = [];
      return;
    }
    void this.usersManagementService.getCustomerCatalog(selectedCustomer).then((value: CustomerConfig) => {
      this.classifications = value.classifications;
      this.groups = value.groups;
    });
  }

  public selectAllClassifications(): void {
    this.form.controls.classifications.setValue(this.classifications);
  }

  public selectAllGroups(): void {
    this.form.controls.groups.setValue(this.groups);
  }

  public unselectAllClassifications(): void {
    this.form.controls.classifications.setValue([]);
  }

  public unselectAllGroups(): void {
    this.form.controls.groups.setValue([]);
  }

  private initCustomers(): void {
    void this.usersManagementService
      .getCustomers()
      .then(customers => {
        this.customers = customers;
      })
      .then(() => {
        this.isLoading = false;
      });
  }

  private initForm(): void {
    this.form = this.formBuilder.group({
      users: this.formBuilder.control<string[]>([]),
      customer: this.formBuilder.control<string>(''),
      groups: this.formBuilder.control<string[]>([]),
      classifications: this.formBuilder.control<string[]>([])
    });
  }
}
