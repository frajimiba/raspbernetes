import {
  AppopsXplplataformaV0AdminLinksCategoriesPaginatedPost200Response,
  CategoryLinkEntry
} from '../../../../../../../app/core';

export type BookmarkCategory = Readonly<Required<Omit<CategoryLinkEntry, 'ingestedAt' | 'modifiedAt'>>>;

export type UpdateBookmarkCategory = Required<
  Omit<BookmarkCategory, 'client' | 'group' | 'classification'> & {
    client: string | null | undefined;
    group: string | null | undefined;
    classification: string | null | undefined;
  }
>;

export type NewBookmarkCategory = Required<Omit<UpdateBookmarkCategory, 'id'>>;

export type PagedBookmarkCategory = Readonly<
  Required<
    Omit<AppopsXplplataformaV0AdminLinksCategoriesPaginatedPost200Response, 'content'> & {
      content: BookmarkCategory[];
    }
  >
>;
