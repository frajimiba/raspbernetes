import { Injectable } from '@angular/core';
import { FormGroup } from '@angular/forms';

import { CategoryLinkEntry, CategoryLinkService } from '../../../../../../../app/core';
import { NewBookmarkCategory, UpdateBookmarkCategory } from '../models/favourite-category.model';

@Injectable({
  providedIn: 'root'
})
export class CategoryManagementService {
  constructor(private readonly categoryLinkService: CategoryLinkService) {}

  public async createNewCategory(newBookmarkCategory: NewBookmarkCategory): Promise<void> {
    return this.categoryLinkService.createCategory(newBookmarkCategory);
  }

  public async updateCategory(updateBookmarkCategory: UpdateBookmarkCategory): Promise<void> {
    return this.categoryLinkService.updateCategory(updateBookmarkCategory.id, updateBookmarkCategory);
  }
}
