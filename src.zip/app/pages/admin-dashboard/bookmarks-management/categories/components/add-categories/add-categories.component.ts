import swal2 from 'sweetalert2';

import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

import { CategoryManagementService } from './category-management.service';

import {
  ALL_AVAILABLE_ROLES,
  AuthRole,
  KeycloakGroupEntry,
  LoadingService,
  MAT_DIALOG_CLOSE_WITH_OK,
  MAT_DIALOG_CLOSE_WITHOUT_ACTIONS
} from '../../../../../../../app/core';
import { AssignmentSelectorComponent, AssignmentSelectorConfig } from '../../../../../../../app/shared';
import { BookmarkCategory, NewBookmarkCategory, UpdateBookmarkCategory } from '../models/favourite-category.model';

@Component({
  selector: 'app-add-categories',
  templateUrl: './add-categories.component.html',
  styleUrls: ['./add-categories.component.scss']
})
export class AddCategoriesComponent implements OnInit {
  @ViewChild('client') assignmentSelectorComponent: AssignmentSelectorComponent;

  public isLoading: boolean = false;
  public addBookmarkCategoryForm: FormGroup;
  public rolesList: AuthRole[] = ALL_AVAILABLE_ROLES;

  public assignmentSelectorConfig: AssignmentSelectorConfig;

  public classificationId: string;
  private classificationSelected: KeycloakGroupEntry;

  constructor(
    @Inject(MAT_DIALOG_DATA) public readonly bookmarkCategory: BookmarkCategory,
    private readonly formBuilder: FormBuilder,
    private readonly categoryManagementService: CategoryManagementService,
    public readonly dialogRef: MatDialogRef<AddCategoriesComponent>,
    private readonly loadingService: LoadingService
  ) {}

  ngOnInit(): void {
    console.log('ngOnInit AddCategoriesComponent');
    this.setClientProjectConfig();
    this.initForm();
  }

  public onClassificationGroupSelected(classificationGroup: KeycloakGroupEntry): void {
    this.classificationId = classificationGroup?.id ?? '';
    this.classificationSelected = classificationGroup;
  }

  public submitForm(): void {
    if (this.addBookmarkCategoryForm.valid) {
      this.loadingService.setLoadingState(true);
      this.isCategoryLinkDefined() ? this.updateCategory() : this.createNewCategory();
    }
  }

  public discardForm(): void {
    this.dialogRef.close(MAT_DIALOG_CLOSE_WITHOUT_ACTIONS);
  }

  private createNewCategory(): void {
    this.categoryManagementService
      .createNewCategory(this.mapFormDataToBookmarkCategory())
      .then(() => this.categoryCreatedOk())
      .catch(() => this.categoryCreatedKo())
      .finally(() => this.loadingService.setLoadingState(false));
  }

  private categoryCreatedKo(): void {
    void swal2.fire(`Error inesperado`, `No se ha podido crear la nueva categoría.`, 'error');
  }

  private categoryCreatedOk(): void {
    void swal2.fire(`Categoría creada`, `Se ha creado la categoría correctamente.`, 'success').then(result => {
      this.dialogRef.close(MAT_DIALOG_CLOSE_WITH_OK);
    });
  }

  private updateCategory(): void {
    this.categoryManagementService
      .updateCategory(this.mapFormDataToUpdateBookmarkCategory())
      .then(() => {
        void this.categoryUpdatedOk();
      })
      .catch(() => this.categoryUpdatedKo())
      .finally(() => this.loadingService.setLoadingState(false));
  }

  private categoryUpdatedKo(): void {
    void swal2.fire(`Error inesperado`, `No se ha podido actualizar la nueva categoría.`, 'error');
  }

  private async categoryUpdatedOk(): Promise<void> {
    await swal2.fire(`Categoría actualizada`, `Se ha actualizado la categoría correctamente.`, 'success');
    this.dialogRef.close(MAT_DIALOG_CLOSE_WITH_OK);
  }

  private isCategoryLinkDefined(): boolean {
    return this.bookmarkCategory != null;
  }

  private mapFormDataToBookmarkCategory(): NewBookmarkCategory {
    return {
      position: this.addBookmarkCategoryForm.controls.position.value,
      name: this.addBookmarkCategoryForm.controls.name.value,
      description: this.addBookmarkCategoryForm.controls.description.value,
      client: this.assignmentSelectorComponent.assignmentSelectorFormGroup?.value.clientFormControl ?? null,
      group: this.assignmentSelectorComponent.assignmentSelectorFormGroup?.value.projectFormControl ?? null,
      classification:
        this.assignmentSelectorComponent.assignmentSelectorFormGroup?.value.classificationFormControl ?? null,
      active: this.addBookmarkCategoryForm.controls.active.value,
      roles: this.addBookmarkCategoryForm.controls.roles.value.toString()
    };
  }

  private mapFormDataToUpdateBookmarkCategory(): UpdateBookmarkCategory {
    return {
      ...this.mapFormDataToBookmarkCategory(),
      id: this.bookmarkCategory.id
    };
  }

  private initForm(): void {
    if (this.isCategoryLinkDefined()) {
      this.initEditForm();
    } else {
      this.initNewForm();
    }
  }

  private initNewForm(): void {
    this.addBookmarkCategoryForm = this.formBuilder.group({
      position: [null, Validators.required],
      name: ['', Validators.required],
      description: ['', Validators.required],
      roles: ['', Validators.required],
      active: [false]
    });
  }

  private initEditForm(): void {
    this.addBookmarkCategoryForm = this.formBuilder.group({
      position: [this.bookmarkCategory.position, Validators.required],
      name: [this.bookmarkCategory.name, Validators.required],
      description: [this.bookmarkCategory.description, Validators.required],
      roles: [this.splitRoles(this.bookmarkCategory.roles), Validators.required],
      active: [this.bookmarkCategory.active]
    });
  }

  private setClientProjectConfig(): void {
    this.assignmentSelectorConfig = {
      clientSelectorEnabled: true,
      projectSelectorEnabled: true,
      clasificationSelectorEnabled: true,
      searchButtonEnabled: false,
      sessionStorageKey: 'add_update_bookmark_category',
      onlyOwnCustomers: true,
      filterSubGroups: false,
      includeDefaultGroups: false
    };

    if (this.isCategoryLinkDefined()) {
      this.assignmentSelectorConfig.formConfig = {
        client: this.bookmarkCategory.client,
        project: this.bookmarkCategory.group,
        classification: this.bookmarkCategory.classification
      };
    }
  }

  private splitRoles(roles: string): string[] {
    return roles !== '' ? roles.split(',') : [''];
  }
}
