import { Subject, takeUntil } from 'rxjs';
import swal2, { SweetAlertIcon, SweetAlertResult } from 'sweetalert2';

import { animate, state, style, transition, trigger } from '@angular/animations';
import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSort, Sort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';

import { CategoriesListService } from './categories-list.service';

import {
  ClassificationsGroupsClientsEntry,
  LoadingService,
  MAT_DIALOG_CLOSE_WITH_OK,
  ZERO
} from '../../../../../../../app/core';
import { PaginatorModel } from '../../../../../../../app/shared';
import { AddCategoriesComponent } from '../add-categories/add-categories.component';
import { BookmarkCategory, PagedBookmarkCategory } from '../models/favourite-category.model';

const LOG_TAG = 'CategoriesListComponent';

@Component({
  selector: 'app-categories-list',
  templateUrl: './categories-list.component.html',
  styleUrls: ['./categories-list.component.scss'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)'))
    ])
  ]
})
export class CategoriesListComponent implements OnInit, OnDestroy {
  @ViewChild(MatSort) sort: MatSort;
  public isLoading = true;

  public paginatorModel: PaginatorModel;
  public numOfResults = ZERO;

  public bookmarkCategoryList: BookmarkCategory[];
  public categoryTableDataSource: MatTableDataSource<BookmarkCategory>;
  public columnsToDisplay: string[] = ['position', 'name', 'description', 'roles', 'active', 'actions'];

  private classificationsGroupsClientsEntry: ClassificationsGroupsClientsEntry;

  private readonly swalWithButtons = swal2.mixin({
    customClass: {
      confirmButton: 'btn btn-solid__success',
      cancelButton: 'btn btn-solid__danger'
    },
    buttonsStyling: false
  });

  private readonly stopSubscriptionsNotifier = new Subject<void>();

  constructor(
    private readonly dialog: MatDialog,
    private readonly categoriesListService: CategoriesListService,
    private readonly loadingService: LoadingService
  ) {}

  ngOnInit(): void {
    this.setDeultPaginatorConfig();
    this.setDeultClassificationsGroupsClientsEntryConfig();
    this.getAllCategories();
  }

  public ngOnDestroy(): void {
    console.log('MenuManagementComponent', 'ngOnDestroy');
    this.stopSubscriptionsNotifier.next();
    this.stopSubscriptionsNotifier.complete();
  }

  public async initializeState(): Promise<void> {
    this.getAllCategories();
  }

  public setSearchCombos(classificationsGroupsClientsEntry: ClassificationsGroupsClientsEntry): void {
    this.classificationsGroupsClientsEntry = classificationsGroupsClientsEntry;
  }

  public editCategory(bookmarkCategory: BookmarkCategory): void {
    this.openEditCategoryModal(bookmarkCategory);
  }

  public askToDeleteCategory(categoryLink: BookmarkCategory): void {
    this.swalWithButtons
      .fire({
        title: '¿Está seguro?',
        html: `¿Seguro que desea eliminar la categoría '${categoryLink.name}', 
          <b>No se podrá eliminar si tiene enlaces asociados</b> ?`,
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Si, eliminar!',
        cancelButtonText: 'No, cancelar!',
        reverseButtons: true
      })
      .then(result => {
        if (result.isConfirmed) {
          this.deleteCategory(categoryLink);
        }
      })
      .catch(error => {
        console.log(error);
      });
  }

  public applyFilter(event: Event): void {
    const filterValue = (event.target as HTMLInputElement).value;
    this.categoryTableDataSource.filter = filterValue.trim().toLowerCase();
  }

  public sortChanged(event: Sort): void {
    this.paginatorModel.pageIndex = ZERO;
    this.paginatorModel.sortCol = event.active;
    this.paginatorModel.ascending = event.direction === 'asc';
    this.getAllCategories();
  }

  public pageChanged(event: any): void {
    this.paginatorModel.pageIndex = event.pageIndex;
    this.paginatorModel.size = event.pageSize;
    this.getAllCategories();
  }

  private getAllCategories(): void {
    this.isLoading = true;

    this.categoriesListService
      .getAllCategories(this.paginatorModel, this.classificationsGroupsClientsEntry)
      .then((pagedBookmarkCategoryList: PagedBookmarkCategory) => this.onGetAllCategoriesOK(pagedBookmarkCategoryList))
      .catch(error => this.onGetAllCategoriesKO(error))
      .finally(() => this.stopLoading());
  }

  private onGetAllCategoriesOK(pagedBookmarkCategoryList: PagedBookmarkCategory): void {
    this.bookmarkCategoryList = pagedBookmarkCategoryList.content;
    this.categoryTableDataSource = new MatTableDataSource<BookmarkCategory>(this.bookmarkCategoryList);
    this.categoryTableDataSource.sort = this.sort;
    this.numOfResults = pagedBookmarkCategoryList.totalCount;
  }

  private onGetAllCategoriesKO(error: any): void {
    console.error(`${LOG_TAG} - No ha sido posible recuperar las categrías`, error);
    void swal2.fire('Error recuperando categorías', `No ha sido posible recuperar las categrías`, 'error');
  }

  private deleteCategory(bookmarkCategory: BookmarkCategory): void {
    this.loadingService.setLoadingState(true);
    this.categoriesListService
      .deleteCategory(bookmarkCategory.id)
      .then(() => {
        this.deleteCategoryOK(bookmarkCategory);
      })
      .catch(() => {
        void this.showAlert('Error inesperado', 'Ha ocurrido un error al intentar borrar la categoría', 'error');
      })
      .finally(() => this.loadingService.setLoadingState(false));
  }

  private deleteCategoryOK(bookmarkCategory: BookmarkCategory): void {
    this.showAlert('Categoría Eliminada!', `Categoría '${bookmarkCategory.name}' eliminada con éxito.`, 'success')
      .then(result => {
        if (result.isConfirmed) {
          this.getAllCategories();
        }
      })
      .catch(error => {
        throw error;
      });
  }

  private openEditCategoryModal(categoryLink: BookmarkCategory): void {
    this.dialog
      .open(AddCategoriesComponent, {
        panelClass: 'default-modal',
        data: categoryLink
      })
      .afterClosed()
      .pipe(takeUntil(this.stopSubscriptionsNotifier))
      .subscribe({
        next: modalClosedResult => {
          if (modalClosedResult !== MAT_DIALOG_CLOSE_WITH_OK) {
            return;
          }
          console.log(LOG_TAG, 'updateBookmarkLink OK');
          void this.initializeState();
        }
      });
  }

  private setDeultPaginatorConfig(): void {
    this.paginatorModel = {
      pageIndex: 0,
      size: 50,
      ascending: true,
      sortCol: 'position'
    };
  }

  private setDeultClassificationsGroupsClientsEntryConfig(): void {
    this.classificationsGroupsClientsEntry = {
      groups: [],
      clients: [],
      classifications: []
    };
  }

  private stopLoading(): void {
    this.isLoading = false;
  }

  private async showAlert(title: string, html: string, icon: SweetAlertIcon): Promise<SweetAlertResult<any>> {
    return await this.swalWithButtons.fire(title, html, icon);
  }
}
