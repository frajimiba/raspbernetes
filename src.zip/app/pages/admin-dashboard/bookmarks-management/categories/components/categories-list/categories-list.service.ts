import { Injectable } from '@angular/core';

import {
  AppopsXplplataformaV0AdminLinksCategoriesPaginatedPost200Response,
  CategoryLinkEntry,
  CategoryLinkService,
  ClassificationsGroupsClientsEntry,
  ZERO
} from '../../../../../../../app/core';
import { PaginatorModel } from '../../../../../../../app/shared';
import { BookmarkCategory, PagedBookmarkCategory } from '../models/favourite-category.model';

const DEFAULT_INDEX = -1;
const DEFAULT_STRING = '';

@Injectable({
  providedIn: 'root'
})
export class CategoriesListService {
  constructor(private readonly categoryLinkService: CategoryLinkService) {}

  public async deleteCategory(categoryId: number): Promise<void> {
    if (!categoryId) {
      console.error('La categroía no tiene un id válido para ser eliminado.');
      throw new Error('Identificador del id no es válido');
    }
    return this.categoryLinkService.deleteCategory(categoryId);
  }

  public async getAllCategories(
    paginatorModel: PaginatorModel,
    classificationsGroupsClientsEntry: ClassificationsGroupsClientsEntry
  ): Promise<PagedBookmarkCategory> {
    return this.categoryLinkService
      .getAllCategories(paginatorModel, classificationsGroupsClientsEntry)
      .then((categoryLinkList: AppopsXplplataformaV0AdminLinksCategoriesPaginatedPost200Response) =>
        this.mapPagedBookmarkCategories(categoryLinkList)
      )
      .catch(error => {
        console.error('CategoriesListService getAllCategories error', error);
        return { index: 0, size: 0, totalCount: 0, content: [] };
      });
  }

  private mapPagedBookmarkCategories(
    pagedCategoryLinks: AppopsXplplataformaV0AdminLinksCategoriesPaginatedPost200Response
  ): PagedBookmarkCategory {
    const pagedBookmarkLinks: PagedBookmarkCategory = {
      index: pagedCategoryLinks.index ?? DEFAULT_INDEX,
      size: pagedCategoryLinks.size ?? ZERO,
      totalCount: pagedCategoryLinks.totalCount ?? ZERO,
      content: this.mapCategories(pagedCategoryLinks.content ?? [])
    };

    return pagedBookmarkLinks;
  }

  private mapCategories(categories: CategoryLinkEntry[]): BookmarkCategory[] {
    const categoryLinkList: BookmarkCategory[] = [];
    categories.forEach(category => {
      if (this.isValidCategory(category.id)) {
        categoryLinkList.push(this.mapCategory(category));
      } else {
        console.error('La categroía no tiene un id válido.', category);
      }
    });

    return categoryLinkList;
  }

  /** Set default values to category if undefined */
  private mapCategory(category: CategoryLinkEntry): BookmarkCategory {
    const categoryLink: BookmarkCategory = {
      id: category.id ?? DEFAULT_INDEX,
      name: category.name ?? DEFAULT_STRING,
      description: category.description ?? DEFAULT_STRING,
      active: category.active ?? false,
      roles: category.roles ?? DEFAULT_STRING,
      position: category.position ?? DEFAULT_INDEX,
      client: category.client ?? DEFAULT_STRING,
      group: category.group ?? DEFAULT_STRING,
      classification: category.classification ?? DEFAULT_STRING
    };

    return categoryLink;
  }

  /** Valida al menos si la categoría tiene un id válido */
  private isValidCategory(categoryId: number | undefined): boolean {
    return typeof categoryId === 'number';
  }
}
