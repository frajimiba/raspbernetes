import { Subject, takeUntil } from 'rxjs';

import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';

import { ClassificationsGroupsClientsEntry, MAT_DIALOG_CLOSE_WITH_OK } from '../../../../../app/core';
import { AssignmentSelectorConfig, AssignmentSelectorSelectedConfig } from '../../../../../app/shared';
import { AddCategoriesComponent } from './components/add-categories/add-categories.component';
import { CategoriesListComponent } from './components/categories-list/categories-list.component';

@Component({
  selector: 'app-categories',
  templateUrl: './categories.component.html',
  styleUrls: ['./categories.component.scss']
})
export class CategoriesComponent implements OnInit, OnDestroy {
  @ViewChild('categoriesListComponentRef') categoriesListComponent: CategoriesListComponent;

  public clientProjectConfig: AssignmentSelectorConfig = {
    clientSelectorEnabled: true,
    projectSelectorEnabled: true,
    clasificationSelectorEnabled: true,
    searchButtonEnabled: true,
    sessionStorageKey: 'bookmarks_categories',
    onlyOwnCustomers: true,
    filterSubGroups: false,
    includeDefaultGroups: false
  };

  private readonly stopSubscriptionsNotifier = new Subject<void>();

  constructor(private readonly dialog: MatDialog) {}

  public ngOnInit(): void {
    console.log('ngOnInit');
  }

  public ngOnDestroy(): void {
    console.log('MenuManagementComponent', 'ngOnDestroy');
    this.stopSubscriptionsNotifier.next();
    this.stopSubscriptionsNotifier.complete();
  }

  public selectedAssignment(selectedConfig: AssignmentSelectorSelectedConfig): void {
    const classificationsGroupsClientsEntry: ClassificationsGroupsClientsEntry = {
      clients: selectedConfig.selectedClient ? [selectedConfig.selectedClient] : [],
      groups: selectedConfig.selectedProject ? [selectedConfig.selectedProject] : [],
      classifications: selectedConfig.selectedClasification ? [selectedConfig.selectedClasification] : []
    };

    this.categoriesListComponent.setSearchCombos(classificationsGroupsClientsEntry);
    void this.categoriesListComponent?.initializeState();
  }

  public addNewCategory(): void {
    this.openAddCategoryModal();
  }

  private openAddCategoryModal(): void {
    this.dialog
      .open(AddCategoriesComponent, {
        panelClass: 'default-modal'
      })
      .afterClosed()
      .pipe(takeUntil(this.stopSubscriptionsNotifier))
      .subscribe({
        next: modalClosedResult => {
          if (modalClosedResult !== MAT_DIALOG_CLOSE_WITH_OK) {
            return;
          }
          console.log('CategoriesComponent', 'addNewCategory', 'create new category OK');
          void this.categoriesListComponent?.initializeState();
        }
      });
  }
}
