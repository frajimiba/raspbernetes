import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatOptionModule } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectModule } from '@angular/material/select';
import { MatSortModule } from '@angular/material/sort';
import { MatTableModule } from '@angular/material/table';
import { RouterModule, Routes } from '@angular/router';

import { AssignmentSelectorModule, PipesModule } from '../../../../../app/shared';
import { CategoriesComponent } from './categories.component';
import { AddCategoriesComponent } from './components/add-categories/add-categories.component';
import { CategoriesListComponent } from './components/categories-list/categories-list.component';

const routes: Routes = [{ path: '', component: CategoriesComponent }];

@NgModule({
  declarations: [CategoriesComponent, CategoriesListComponent, AddCategoriesComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    MatPaginatorModule,
    MatFormFieldModule,
    MatIconModule,
    MatTableModule,
    MatInputModule,
    PipesModule,
    ReactiveFormsModule,
    FormsModule,
    MatProgressSpinnerModule,
    MatButtonModule,
    MatOptionModule,
    MatCheckboxModule,
    MatSelectModule,
    AssignmentSelectorModule,
    MatSortModule
  ],
  exports: [
    CategoriesComponent,
    MatPaginatorModule,
    MatFormFieldModule,
    MatIconModule,
    MatTableModule,
    MatInputModule,
    PipesModule,
    ReactiveFormsModule,
    FormsModule,
    MatProgressSpinnerModule,
    MatButtonModule,
    MatOptionModule,
    MatCheckboxModule,
    MatSelectModule,
    AssignmentSelectorModule,
    MatSortModule
  ]
})
export class CategoriesPageModule {}
