import { AppopsXplplataformaV0AdminLinksPaginatedPost200Response, LinkEntry } from '../../../../../../../app/core';
import { BookmarkCategory } from '../../../categories/components/models/favourite-category.model';

export type BookmarkLink = Readonly<
  Required<Omit<LinkEntry, 'ingestedAt' | 'modifiedAt' | 'category'> & { category: BookmarkCategory }>
>;
// export type PostBookmarkLink = <LinkEntry, 'ingestedAt' | 'modifiedAt' | 'category'> & { category: BoomarkCategory }

export type UpdateBookmarkLink = Required<
  Omit<BookmarkLink, 'client' | 'group' | 'classification'> & {
    client: string | null | undefined;
    group: string | null | undefined;
    classification: string | null | undefined;
  }
>;

export type NewBookmarkLink = Required<Omit<UpdateBookmarkLink, 'id'>>;

export type PagedBookmarkLinks = Readonly<
  Required<Omit<AppopsXplplataformaV0AdminLinksPaginatedPost200Response, 'content'> & { content: BookmarkLink[] }>
>;
