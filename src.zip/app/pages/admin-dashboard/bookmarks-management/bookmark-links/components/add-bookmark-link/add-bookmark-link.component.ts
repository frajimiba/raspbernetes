import swal2 from 'sweetalert2';

import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

import { AddBookmarkLinkService } from './add-bookmark-link.service';

import {
  ALL_AVAILABLE_ROLES,
  AuthRole,
  KeycloakGroupEntry,
  LoadingService,
  MAT_DIALOG_CLOSE_WITH_OK,
  MAT_DIALOG_CLOSE_WITHOUT_ACTIONS
} from '../../../../../../../app/core';
import { AssignmentSelectorComponent, AssignmentSelectorConfig } from '../../../../../../../app/shared';
import { BookmarkCategory } from '../../../categories/components/models/favourite-category.model';
import { BookmarkLink, NewBookmarkLink, UpdateBookmarkLink } from '../models/bookmark-link.model';

@Component({
  selector: 'app-add-bookmark-link',
  templateUrl: './add-bookmark-link.component.html',
  styleUrls: ['./add-bookmark-link.component.scss']
})
export class AddBookmarkLinkComponent implements OnInit {
  @ViewChild('assignmentSelector') assignmentSelectorComponent: AssignmentSelectorComponent;

  public isLoading: boolean = true;
  public addBookmarkLinkForm: FormGroup;
  public rolesList: AuthRole[] = ALL_AVAILABLE_ROLES;
  public categoryList: BookmarkCategory[];

  public assignmentSelectorConfig: AssignmentSelectorConfig;

  public classificationId: string;
  private classificationSelected: KeycloakGroupEntry;

  constructor(
    @Inject(MAT_DIALOG_DATA) public readonly bookmarkLink: BookmarkLink,
    private readonly formBuilder: FormBuilder,
    private readonly addBookmarkLinkService: AddBookmarkLinkService,
    public readonly dialogRef: MatDialogRef<AddBookmarkLinkComponent>,
    private readonly loadingService: LoadingService
  ) {}

  public ngOnInit(): void {
    console.log('ngOnInit AddBookmarkLinkComponent');
    this.setClientProjectConfig();
    void this.initialize();
  }

  public onClassificationGroupSelected(classificationGroup: KeycloakGroupEntry): void {
    this.classificationId = classificationGroup?.id ?? '';
    this.classificationSelected = classificationGroup;
  }

  public discardForm(): void {
    this.dialogRef.close(MAT_DIALOG_CLOSE_WITHOUT_ACTIONS);
  }

  public submitForm(): void {
    if (this.addBookmarkLinkForm.valid) {
      this.loadingService.setLoadingState(true);
      this.isNewBookmarkLink() ? this.submitNewMenuForm() : this.submitUpdatedMenuForm();
    }
  }

  private async initialize(): Promise<void> {
    await this.getCategories();
    this.initializeForm();
    this.isLoading = false;
  }

  private async getCategories(): Promise<void> {
    this.categoryList = await this.addBookmarkLinkService.getCategories();
  }

  private submitNewMenuForm(): void {
    console.log('AddBookmarkLinkComponent', 'submitNewMenuForm');
    this.addBookmarkLinkService
      .createBookmarkLink(this.mapFormDataToBookmarkLink())
      .then(() => {
        void this.showCreateBookmarkLinkSuccessUi();
      })
      .catch(() => this.showCreateBookmarkLinkErrorUi())
      .finally(() => this.loadingService.setLoadingState(false));
  }

  private submitUpdatedMenuForm(): void {
    console.log('AddBookmarkLinkComponent', 'submitUpdatedMenuForm');
    this.addBookmarkLinkService
      .updateBookmarkLink(this.mapFormDataToUpdateBookmarkLink())
      .then(() => {
        void this.showUpdateBookmarkLinkSuccessUi();
      })
      .catch(() => this.showCreateBookmarkLinkErrorUi())
      .finally(() => this.loadingService.setLoadingState(false));
  }

  private mapFormDataToBookmarkLink(): NewBookmarkLink {
    return {
      position: this.addBookmarkLinkForm.controls.position.value,
      name: this.addBookmarkLinkForm.controls.name.value,
      description: this.addBookmarkLinkForm.controls.description.value,
      url: this.addBookmarkLinkForm.controls.url.value,
      urlImage: this.addBookmarkLinkForm.controls.urlImage.value,
      client: this.assignmentSelectorComponent.assignmentSelectorFormGroup?.value.clientFormControl ?? null,
      group: this.assignmentSelectorComponent.assignmentSelectorFormGroup?.value.projectFormControl ?? null,
      classification:
        this.assignmentSelectorComponent.assignmentSelectorFormGroup?.value.classificationFormControl ?? null,
      active: this.addBookmarkLinkForm.controls.active.value,
      category: this.addBookmarkLinkForm.controls.category.value,
      roles: this.addBookmarkLinkForm.controls.roles.value.toString()
    };
  }

  private mapFormDataToUpdateBookmarkLink(): UpdateBookmarkLink {
    return {
      ...this.mapFormDataToBookmarkLink(),
      id: this.bookmarkLink.id,
      category: this.addBookmarkLinkForm.controls.category.value
    };
  }

  private isNewBookmarkLink(): boolean {
    return !this.bookmarkLink;
  }

  private initializeForm(): void {
    this.addBookmarkLinkForm = this.formBuilder.group(
      this.addBookmarkLinkService.generateAddUpdateBookmarkLinkFormConfiguration(this.bookmarkLink, this.categoryList)
    );
  }

  private setClientProjectConfig(): void {
    this.assignmentSelectorConfig = {
      clientSelectorEnabled: true,
      projectSelectorEnabled: true,
      clasificationSelectorEnabled: true,
      searchButtonEnabled: false,
      sessionStorageKey: 'add_update_bookmark_links',
      onlyOwnCustomers: true,
      filterSubGroups: false,
      includeDefaultGroups: false
    };

    if (!this.isNewBookmarkLink()) {
      this.assignmentSelectorConfig.formConfig = {
        client: this.bookmarkLink.client,
        project: this.bookmarkLink.group,
        classification: this.bookmarkLink.classification
      };
    }
  }

  private async showCreateBookmarkLinkSuccessUi(): Promise<void> {
    await swal2.fire(`Enlace creado`, `Se ha creado el enlace correctamente.`, 'success');
    this.dialogRef.close(MAT_DIALOG_CLOSE_WITH_OK);
  }

  private async showUpdateBookmarkLinkSuccessUi(): Promise<void> {
    await swal2.fire(`Enlace actulizado`, `Se ha actualizado el enlace correctamente.`, 'success');
    this.dialogRef.close(MAT_DIALOG_CLOSE_WITH_OK);
  }

  private showCreateBookmarkLinkErrorUi(): void {
    void swal2.fire(`Error inesperado`, `No se ha podido crear el nuevo enlace de categoría.`, 'error');
  }
}
