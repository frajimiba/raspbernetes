import { Injectable } from '@angular/core';
import { Validators } from '@angular/forms';

import { CategoriesListService } from '../../../categories/components/categories-list/categories-list.service';

import {
  BookmarkLinkService,
  ClassificationsGroupsClientsEntry,
  DEFAULT_OBJECTS_VALUES,
  DEFAULT_STRINGS_VALUES,
  MAX_DESCRIPTION_LENGTH,
  MAX_LINK_LENGTH,
  MAX_NAME_LENGTH,
  MAX_POSITION_VALUE,
  MIN_DESCRIPTION_LENGTH,
  MIN_LINK_LENGTH,
  MIN_NAME_LENGTH,
  MIN_POSITION_VALUE
} from '../../../../../../../app/core';
import { PaginatorModel } from '../../../../../../../app/shared';
import {
  BookmarkCategory,
  PagedBookmarkCategory
} from '../../../categories/components/models/favourite-category.model';
import { BookmarkLink, NewBookmarkLink, UpdateBookmarkLink } from '../models/bookmark-link.model';

@Injectable({
  providedIn: 'root'
})
export class AddBookmarkLinkService {
  constructor(
    private readonly bookmarkLinkService: BookmarkLinkService,
    private readonly categoriesListService: CategoriesListService
  ) {}

  public generateAddUpdateBookmarkLinkFormConfiguration(
    bookmarkLink: BookmarkLink,
    categoryList: BookmarkCategory[]
  ): Record<string, unknown> {
    console.log('generateAddUpdateBookmarkLinkFormConfiguration');
    return {
      position: [
        bookmarkLink?.position ?? null,
        [Validators.required, Validators.min(MIN_POSITION_VALUE), Validators.max(MAX_POSITION_VALUE)]
      ],
      name: [
        bookmarkLink?.name ?? DEFAULT_STRINGS_VALUES,
        [Validators.required, Validators.min(MIN_NAME_LENGTH), Validators.max(MAX_NAME_LENGTH)]
      ],
      description: [
        bookmarkLink?.description ?? DEFAULT_STRINGS_VALUES,
        [Validators.required, Validators.min(MIN_DESCRIPTION_LENGTH), Validators.max(MAX_DESCRIPTION_LENGTH)]
      ],
      url: [
        bookmarkLink?.url ?? DEFAULT_STRINGS_VALUES,
        [Validators.required, Validators.min(MIN_LINK_LENGTH), Validators.max(MAX_LINK_LENGTH)]
      ],
      roles: [bookmarkLink?.roles ? this.splitRoles(bookmarkLink.roles) : '', [Validators.required]],
      active: [bookmarkLink?.active ?? false],
      urlImage: [
        bookmarkLink?.urlImage ?? DEFAULT_STRINGS_VALUES,
        [Validators.min(MIN_LINK_LENGTH), Validators.max(MAX_LINK_LENGTH)]
      ],
      category: [
        this.setBookmarkCategory(bookmarkLink?.category?.id, categoryList) ?? DEFAULT_OBJECTS_VALUES,
        [Validators.required]
      ]
    };
  }

  public async getCategories(): Promise<BookmarkCategory[]> {
    const defaultFilter: ClassificationsGroupsClientsEntry = {
      groups: [],
      clients: [],
      classifications: []
    };
    return this.categoriesListService
      .getAllCategories(this.getDefaultPaginatorModel(), defaultFilter)
      .then((pagedBookmarkCategory: PagedBookmarkCategory) => {
        return pagedBookmarkCategory.content;
      })
      .catch(error => {
        console.error('AddBookmarkLinkService getCategories catch error', error);
        return [];
      });
  }

  public async createBookmarkLink(newBookmarkLink: NewBookmarkLink): Promise<void> {
    return this.bookmarkLinkService.createBookmarkLink(newBookmarkLink);
  }

  public async updateBookmarkLink(updateBookmarkLink: UpdateBookmarkLink): Promise<void> {
    return this.bookmarkLinkService.updateBookmarkLink(updateBookmarkLink.id, updateBookmarkLink);
  }

  private getDefaultPaginatorModel(): PaginatorModel {
    return {
      pageIndex: 0,
      size: 400,
      ascending: true,
      sortCol: 'position'
    };
  }

  private splitRoles(roles: string): string[] {
    return roles !== '' ? roles.split(',') : [''];
  }

  private setBookmarkCategory(
    categoryId: number | undefined,
    categoryList: BookmarkCategory[]
  ): BookmarkCategory | undefined {
    return categoryList.find(category => category.id === categoryId);
  }
}
