import { Subject, takeUntil } from 'rxjs';
import swal2 from 'sweetalert2';

import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSort, Sort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';

import { BookmarkLinksListService } from './bookmark-links-list.service';

import {
  ClassificationsGroupsClientsEntry,
  LoadingService,
  MAT_DIALOG_CLOSE_WITH_OK,
  ZERO
} from '../../../../../../../app/core';
import { PaginatorModel } from '../../../../../../../app/shared';
import { AddBookmarkLinkComponent } from '../add-bookmark-link/add-bookmark-link.component';
import { BookmarkLink, PagedBookmarkLinks } from '../models/bookmark-link.model';

const LOG_TAG = 'BookmarkLinksListComponent';

@Component({
  selector: 'app-bookmark-links-list',
  templateUrl: './bookmark-links-list.component.html',
  styleUrls: ['./bookmark-links-list.component.scss']
})
export class BookmarkLinksListComponent implements OnInit, OnDestroy {
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  public isLoading = true;
  public paginatorModel: PaginatorModel;
  public numOfResults = ZERO;

  public bookmarkLinkList: BookmarkLink[];
  public dataSource: MatTableDataSource<BookmarkLink>;
  public columnsToDisplay: string[] = [
    'position',
    'name',
    'description',
    'url',
    'urlImage',
    'category',
    'roles',
    'active',
    'actions'
  ];

  private classificationsGroupsClientsEntry: ClassificationsGroupsClientsEntry;

  private readonly swalWithButtons = swal2.mixin({
    customClass: {
      confirmButton: 'btn btn-solid__success',
      cancelButton: 'btn btn-solid__danger'
    },
    buttonsStyling: false
  });

  private readonly stopSubscriptionsNotifier = new Subject<void>();

  constructor(
    private readonly dialog: MatDialog,
    private readonly bookmarkLinksListService: BookmarkLinksListService,
    private readonly loadingService: LoadingService
  ) {}

  public ngOnInit(): void {
    console.log(`${LOG_TAG}`, 'ngOnInit');
    this.setDeultClassificationsGroupsClientsEntryConfig();
    this.setInitialPaginatorConfig();
    void this.initializeState();
  }

  public ngOnDestroy(): void {
    console.log(`${LOG_TAG}`, 'ngOnDestroy');
    this.stopSubscriptionsNotifier.next();
    this.stopSubscriptionsNotifier.complete();
  }

  public async initializeState(): Promise<void> {
    console.log(`${LOG_TAG}`, 'initializeState');
    this.startLoaing();
    this.getAllLinks();
  }

  public setSearchCombos(classificationsGroupsClientsEntry: ClassificationsGroupsClientsEntry): void {
    this.classificationsGroupsClientsEntry = classificationsGroupsClientsEntry;
  }

  public editBookmarkLink(bookmarkLink: BookmarkLink): void {
    this.openUpdateBookmarkLinkModal(bookmarkLink);
  }

  public askToDeleteBookmarkLink(bookmarkLink: BookmarkLink): void {
    this.swalWithButtons
      .fire({
        title: '¿Está seguro?',
        html: `¿Seguro que desea eliminar el enlace '${bookmarkLink.name}'?`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Si, eliminar!',
        cancelButtonText: 'No, cancelar!',
        reverseButtons: true
      })
      .then(result => {
        if (result.isConfirmed) {
          this.deleteBookmarkLink(bookmarkLink);
        }
      })
      .catch(error => {
        console.log(error);
      });
  }

  public applyFilter(event: Event): void {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  public sortChanged(event: Sort): void {
    this.paginatorModel.sortCol = event.active;
    this.paginatorModel.ascending = event.direction === 'asc';
    this.getAllLinks();
  }

  public pageChanged(event: any): void {
    this.paginatorModel.pageIndex = event.pageIndex;
    this.paginatorModel.size = event.pageSize;
    this.getAllLinks();
  }

  private getAllLinks(): void {
    this.bookmarkLinksListService
      .getAllLinks(this.paginatorModel, this.classificationsGroupsClientsEntry)
      .then((pagedBookmarkLinks: PagedBookmarkLinks) => this.onGetAllCategoriesOK(pagedBookmarkLinks))
      .catch(error => this.onGetAllCategoriesKO(error))
      .finally(() => this.stopLoading());
  }

  private onGetAllCategoriesOK(pagedBookmarkLinks: PagedBookmarkLinks): void {
    this.bookmarkLinkList = pagedBookmarkLinks.content;
    this.dataSource = new MatTableDataSource<BookmarkLink>(this.bookmarkLinkList);
    this.dataSource.sort = this.sort;
    this.numOfResults = pagedBookmarkLinks.totalCount;
  }

  private onGetAllCategoriesKO(error: any): void {
    console.error(`${LOG_TAG} - No ha sido posible recuperar los enlaces`, error);
    void swal2.fire('Error recuperando los enlaces', `No ha sido posible recuperar los enlaces`, 'error');
  }

  private deleteBookmarkLink(bookmarkLink: BookmarkLink): void {
    this.loadingService.setLoadingState(true);
    this.bookmarkLinksListService
      .deleteLink(bookmarkLink.id)
      .then(() => {
        this.bookmarkLinkDeleted(bookmarkLink.name);
      })
      .catch(() => {
        void swal2.fire('Error inesperado!', 'No se ha podido eliminar el enlace', 'error');
      })
      .finally(() => this.loadingService.setLoadingState(false));
  }

  private bookmarkLinkDeleted(bookmarkLinkName: string): void {
    void swal2
      .fire('Enlace Eliminado!', `Enlace '${bookmarkLinkName}' eliminado con éxito.`, 'success')
      .then(result => {
        if (result.isConfirmed) {
          this.getAllLinks();
        }
      });
  }

  private openUpdateBookmarkLinkModal(bookmarkLink: BookmarkLink): void {
    this.dialog
      .open(AddBookmarkLinkComponent, {
        panelClass: 'default-modal',
        data: bookmarkLink
      })
      .afterClosed()
      .pipe(takeUntil(this.stopSubscriptionsNotifier))
      .subscribe({
        next: modalClosedResult => {
          if (modalClosedResult !== MAT_DIALOG_CLOSE_WITH_OK) {
            return;
          }
          console.log(LOG_TAG, 'updateBookmarkLink OK');
          void this.initializeState();
        }
      });
  }

  private setInitialPaginatorConfig(): void {
    this.paginatorModel = {
      pageIndex: 0,
      size: 50,
      ascending: true,
      sortCol: 'position'
    };
  }

  private setDeultClassificationsGroupsClientsEntryConfig(): void {
    this.classificationsGroupsClientsEntry = {
      groups: [],
      clients: [],
      classifications: []
    };
  }

  private startLoaing(): void {
    this.isLoading = true;
  }

  private stopLoading(): void {
    this.isLoading = false;
  }
}
