import { Injectable } from '@angular/core';

import {
  AppopsXplplataformaV0AdminLinksPaginatedPost200Response,
  BookmarkLinkService,
  CategoryLinkEntry,
  ClassificationsGroupsClientsEntry,
  DEFAULT_STRINGS_VALUES,
  LinkEntry,
  ZERO
} from '../../../../../../../app/core';
import { PaginatorModel } from '../../../../../../../app/shared';
import { BookmarkCategory } from '../../../categories/components/models/favourite-category.model';
import { BookmarkLink, PagedBookmarkLinks } from '../models/bookmark-link.model';

const DEFAULT_INDEX = -1;

@Injectable({
  providedIn: 'root'
})
export class BookmarkLinksListService {
  constructor(private readonly bookmarkLinkService: BookmarkLinkService) {}

  public async deleteLink(linkId: number): Promise<void> {
    if (!linkId) {
      console.error('El enlace no tiene un id válido para ser eliminado.');
      throw new Error('Identificador del id no es válido');
    }
    return this.bookmarkLinkService.deleteBookmarkLink(linkId);
  }

  public async getAllLinks(
    paginatorModel: PaginatorModel,
    classificationsGroupsClientsEntry?: ClassificationsGroupsClientsEntry
  ): Promise<PagedBookmarkLinks> {
    return this.bookmarkLinkService
      .getAllLinks(paginatorModel, classificationsGroupsClientsEntry)
      .then((pagedCategoryLinks: AppopsXplplataformaV0AdminLinksPaginatedPost200Response) =>
        this.mapPagedCategoryLinks(pagedCategoryLinks)
      )
      .catch(error => {
        console.error('BookmarkLinksListService getAllLinks error', error);
        return { index: 0, size: 0, totalCount: 0, content: [] };
      });
  }

  private mapPagedCategoryLinks(
    pagedCategoryLinks: AppopsXplplataformaV0AdminLinksPaginatedPost200Response
  ): PagedBookmarkLinks {
    const pagedBookmarkLinks: PagedBookmarkLinks = {
      index: pagedCategoryLinks.index ?? DEFAULT_INDEX,
      size: pagedCategoryLinks.size ?? ZERO,
      totalCount: pagedCategoryLinks.totalCount ?? ZERO,
      content: this.mapLinks(pagedCategoryLinks.content ?? [])
    };

    return pagedBookmarkLinks;
  }

  private mapLinks(links: LinkEntry[]): BookmarkLink[] {
    const categoryLinkList: BookmarkLink[] = [];
    links.forEach(link => {
      if (this.isValidId(link.id)) {
        categoryLinkList.push(this.mapLink(link));
      } else {
        console.error('El enalce no tiene un id válido.', link);
      }
    });

    return categoryLinkList;
  }

  /** Set default values to category if undefined */
  private mapLink(link: LinkEntry): BookmarkLink {
    const categoryLink: BookmarkLink = {
      id: link.id ?? DEFAULT_INDEX,
      name: link.name ?? DEFAULT_STRINGS_VALUES,
      description: link.description ?? DEFAULT_STRINGS_VALUES,
      active: link.active ?? false,
      roles: link.roles ?? DEFAULT_STRINGS_VALUES,
      position: link.position ?? DEFAULT_INDEX,
      client: link.client ?? DEFAULT_STRINGS_VALUES,
      group: link.group ?? DEFAULT_STRINGS_VALUES,
      classification: link.classification ?? DEFAULT_STRINGS_VALUES,
      url: link.url ?? DEFAULT_STRINGS_VALUES,
      urlImage: link.urlImage ?? DEFAULT_STRINGS_VALUES,
      category: this.mapBookmarkCategory(link.category)
    };

    return categoryLink;
  }

  private mapBookmarkCategory(category: CategoryLinkEntry | undefined): BookmarkCategory {
    return {
      id: category?.id ?? DEFAULT_INDEX,
      name: category?.name ?? DEFAULT_STRINGS_VALUES,
      description: category?.description ?? DEFAULT_STRINGS_VALUES,
      active: category?.active ?? false,
      roles: category?.roles ?? DEFAULT_STRINGS_VALUES,
      client: category?.client ?? DEFAULT_STRINGS_VALUES,
      group: category?.group ?? DEFAULT_STRINGS_VALUES,
      classification: category?.classification ?? DEFAULT_STRINGS_VALUES,
      position: category?.position ?? DEFAULT_INDEX
    };
  }

  /** Valida al menos si el ID es válido */
  private isValidId(categoryId: number | undefined): boolean {
    return typeof categoryId === 'number';
  }
}
