import { Subject, takeUntil } from 'rxjs';

import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';

import { ClassificationsGroupsClientsEntry, MAT_DIALOG_CLOSE_WITH_OK } from '../../../../../app/core';
import { AssignmentSelectorConfig, AssignmentSelectorSelectedConfig } from '../../../../../app/shared';
import { AddBookmarkLinkComponent } from './components/add-bookmark-link/add-bookmark-link.component';
import { BookmarkLinksListComponent } from './components/bookmark-links-list/bookmark-links-list.component';

@Component({
  selector: 'app-bookmark-links',
  templateUrl: './bookmark-links.component.html',
  styleUrls: ['./bookmark-links.component.scss']
})
export class BookmarkLinksComponent implements OnInit, OnDestroy {
  @ViewChild('bookmarkLinksListComponentRef') bookmarkLinksListComponent: BookmarkLinksListComponent;

  public assignmentSelectorConfig: AssignmentSelectorConfig = {
    clientSelectorEnabled: true,
    projectSelectorEnabled: true,
    clasificationSelectorEnabled: true,
    searchButtonEnabled: true,
    sessionStorageKey: 'bookmarks',
    onlyOwnCustomers: true,
    filterSubGroups: false,
    includeDefaultGroups: false
  };

  private readonly stopSubscriptionsNotifier = new Subject<void>();

  constructor(private readonly dialog: MatDialog) {}

  public ngOnInit(): void {
    console.log('ngOnInit BookmarkLinksComponent');
  }

  public ngOnDestroy(): void {
    console.log('MenuManagementComponent', 'ngOnDestroy');
    this.stopSubscriptionsNotifier.next();
    this.stopSubscriptionsNotifier.complete();
  }

  public assignmentSelected(selectedConfig: AssignmentSelectorSelectedConfig): void {
    const classificationsGroupsClientsEntry: ClassificationsGroupsClientsEntry = {
      clients: selectedConfig.selectedClient ? [selectedConfig.selectedClient] : [],
      groups: selectedConfig.selectedProject ? [selectedConfig.selectedProject] : [],
      classifications: selectedConfig.selectedClasification ? [selectedConfig.selectedClasification] : []
    };

    this.bookmarkLinksListComponent.setSearchCombos(classificationsGroupsClientsEntry);
    void this.bookmarkLinksListComponent?.initializeState();
  }

  public addNewLink(): void {
    this.openAddBookmarkLinkModal();
  }

  private openAddBookmarkLinkModal(): void {
    this.dialog
      .open(AddBookmarkLinkComponent, {
        panelClass: 'default-modal'
      })
      .afterClosed()
      .pipe(takeUntil(this.stopSubscriptionsNotifier))
      .subscribe({
        next: modalClosedResult => {
          if (modalClosedResult !== MAT_DIALOG_CLOSE_WITH_OK) {
            return;
          }
          console.log('BookmarkLinksComponent', 'addNewLink', 'create new link OK');
          void this.bookmarkLinksListComponent?.initializeState();
        }
      });
  }
}
