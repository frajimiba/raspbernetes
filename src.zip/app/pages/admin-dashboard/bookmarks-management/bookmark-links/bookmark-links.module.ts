import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectModule } from '@angular/material/select';
import { MatSortModule } from '@angular/material/sort';
import { MatTableModule } from '@angular/material/table';
import { RouterModule, Routes } from '@angular/router';

import { AssignmentSelectorModule, ClassificationModule, PipesModule } from '../../../../../app/shared';
import { BookmarkLinksComponent } from './bookmark-links.component';
import { AddBookmarkLinkComponent } from './components/add-bookmark-link/add-bookmark-link.component';
import { BookmarkLinksListComponent } from './components/bookmark-links-list/bookmark-links-list.component';

const routes: Routes = [{ path: '', component: BookmarkLinksComponent }];

@NgModule({
  declarations: [BookmarkLinksComponent, AddBookmarkLinkComponent, BookmarkLinksListComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    MatPaginatorModule,
    ReactiveFormsModule,
    FormsModule,
    MatFormFieldModule,
    MatIconModule,
    MatTableModule,
    MatInputModule,
    AssignmentSelectorModule,
    PipesModule,
    MatCheckboxModule,
    MatSelectModule,
    MatProgressSpinnerModule,
    ClassificationModule,
    MatButtonModule,
    MatSortModule
  ],
  exports: [
    BookmarkLinksComponent,
    MatPaginatorModule,
    ReactiveFormsModule,
    FormsModule,
    MatFormFieldModule,
    MatIconModule,
    MatTableModule,
    MatInputModule,
    AssignmentSelectorModule,
    PipesModule,
    MatCheckboxModule,
    MatSelectModule,
    MatProgressSpinnerModule,
    ClassificationModule,
    MatButtonModule,
    MatSortModule
  ]
})
export class BookmarkLinksModule {}
