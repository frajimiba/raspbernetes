import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { MatCardModule } from '@angular/material/card';
import { MatDividerModule } from '@angular/material/divider';

import { HomePageRoutingModule } from './home-page-routing.module';

import { HomePageComponent } from './home-page.component';

@NgModule({
  declarations: [HomePageComponent],
  imports: [HomePageRoutingModule, CommonModule, MatCardModule, MatDividerModule],
  exports: [CommonModule, MatCardModule, MatDividerModule]
})
export class HomePageModule {}
