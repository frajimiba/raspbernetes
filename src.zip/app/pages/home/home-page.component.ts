import { Component } from '@angular/core';

import { ReleaseData } from './home-page.model';

@Component({
  selector: 'app-home',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.scss']
})
export class HomePageComponent {
  titulo: string = 'Torre de control';

  public genericText: any = {
    title: 'Torre de control',
    subtitle: 'Plataforma de visualización y gestión de incidencias'
  };

  public releases: ReleaseData[] = [
    {
      date: '21/04/2023',
      version: '1.0.16',
      features: [
        'Nuevo botón para reabrir incidencia.',
        'Nuevos estados: "Pendiente" y "Fallo de ejecución".',
        'Nuevo botón para reiniciar conversación de chatbot.',
        'Nuevo dashboard y gestión del mismo desde el panel de administración.'
      ],
      fixes: ['Comentarios de troubleshooting.']
    },
    {
      date: '11/04/2023',
      version: '1.0.15',
      features: ['Automatismo desatendido con ejecución automática.'],
      fixes: [
        'Filtro y ordenación en listado de procedimientos.',
        'Filtro y ordenación en listado de feedbacks.',
        'Error al mostrar tipos de procedimientos y poder ejecutarlos.',
        'Copiar y abrir enlaces desde descripción de incidencia.'
      ]
    },
    {
      date: '27/03/2023',
      version: '1.0.14',
      features: ['Filtro en selector de buzón externo.', 'Filtro en selector de usuario.'],
      fixes: ['Se deshabilita la caché del selector de clasificaciones.']
    },
    {
      date: '23/03/2023',
      version: '1.0.13',
      features: [
        'Alta de incidencia: Ahora se pueden seleccionar cualquiera de los buzones externos (incluidos los buzones a los que no pertenece el usuario).',
        'Edición de incidencia: Ahora se puede cambiar el buzón externo.',
        'Notificaciones: Nuevas variables para informar sobre la severidad, el título y la descripción de la incidencia.'
      ],
      fixes: ['Selector de clasificaciones']
    },
    {
      date: '21/03/2023',
      version: '1.0.12',
      features: [
        'Combo de clasificación manual al crear la incidencia.',
        'ID del usuario que ha creado la incidencia.'
      ],
      fixes: ['Documentación asociada a procedimiento en popup de información.']
    },
    {
      date: '15/03/2023',
      version: '1.0.11',
      features: [
        'Tickets relacionados.',
        'Árbol de procedimientos asociados a clasificaciones comunes.',
        'Botón de cerrar en la vista de información del procedimiento.'
      ],
      fixes: ['Título en la información de la incidencia.']
    },
    {
      date: '08/03/2023',
      version: '1.0.10',
      important:
        'IMPORTANTE: Desde esta versión se requiere incluir a todos los usuarios en el grupo de Keycloak: VIEWNEXT_TORRE_DE_CONTROL',
      features: ['Asignar hasta tres niveles de clasificación.', 'Asistente AppOps.'],
      fixes: [
        'Filtro de menús y submenús en panel de administración.',
        'Filtro de categorías y enlaces en panel de administración.'
      ]
    }
  ];
}
