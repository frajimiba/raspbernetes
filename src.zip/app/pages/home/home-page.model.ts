export interface ReleaseData {
  date: string;
  version: string;
  important?: string;
  features: string[];
  fixes: string[];
}
