import { Injectable } from '@angular/core';

import { BookmarkLinksFrontService, LinkEntry } from '../../../app/core';

const DEFAULT_MAX_DESCRIPTION_LENGTH = 10;
const NOT_FOUND_STRING_ID = -1;

@Injectable({
  providedIn: 'root'
})
export class BookmarksPageService {
  constructor(private readonly bookmarkLinksFrontService: BookmarkLinksFrontService) {}

  public async getAllBookmarks(): Promise<LinkEntry[]> {
    return this.bookmarkLinksFrontService.getAll();
  }

  /**
   * Acorta un texto o descripción utilizando el label '...' cuando la longitud
   * del mismo sea superior al indicado por parámatero
   *
   * TODO: se recomienda revisar posible refactorización utilizando CSS o un pipe de angular
   */
  public shortDescription(description: string, maxAllowedTextLength: number = DEFAULT_MAX_DESCRIPTION_LENGTH): string {
    const minDescriptionLength = 0;

    if (description == null || description.length <= minDescriptionLength) {
      return '';
    }

    const firstDescriptionIndex = 0;
    const limit = maxAllowedTextLength > minDescriptionLength ? maxAllowedTextLength : DEFAULT_MAX_DESCRIPTION_LENGTH;

    let whiteSpaces = description.indexOf(' ', maxAllowedTextLength);
    if (whiteSpaces === NOT_FOUND_STRING_ID) {
      whiteSpaces = description.length;
    }

    const dotsLabel = whiteSpaces >= description.length ? '' : '...';
    return description.length > limit
      ? description.substring(firstDescriptionIndex, whiteSpaces) + dotsLabel
      : description;
  }
}
