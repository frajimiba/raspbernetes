import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { MatCardModule } from '@angular/material/card';
import { MatDividerModule } from '@angular/material/divider';
import { MatExpansionModule } from '@angular/material/expansion';

import { BookmarksPageRoutingModule } from './bookmarks-page-routing.module';

import { BookmarksPageComponent } from './bookmarks-page.component';

@NgModule({
  declarations: [BookmarksPageComponent],
  imports: [BookmarksPageRoutingModule, MatExpansionModule, CommonModule, MatCardModule, MatDividerModule],
  exports: [CommonModule, MatCardModule, MatDividerModule]
})
export class BookmarksPageModule {}
