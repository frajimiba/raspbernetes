import { Subject } from 'rxjs';

import { Component, HostListener, OnDestroy, OnInit } from '@angular/core';

import { BookmarksPageService } from './bookmarks-page.service';

import { AuthService, LinkEntry } from '../../../app/core';
import { environment } from '../../../environments/environment';

const MAX_DESCRIPTION_ALLOWED_LENGTH = 10;
@Component({
  selector: 'app-bookmarks',
  templateUrl: './bookmarks-page.component.html',
  styleUrls: ['./bookmarks-page.component.scss']
})
export class BookmarksPageComponent implements OnInit, OnDestroy {
  public isShow: boolean = false;
  public linksFront: LinkEntry[] = [];
  public roles = environment.roles;
  public textAlert: any = {
    infoTitle: 'Información',
    info: 'No hay registros para mostrar.'
  };

  private readonly stopSubscriptionsNotifier = new Subject<void>();

  constructor(private readonly bookmarksPageService: BookmarksPageService, public auhtService: AuthService) {}

  @HostListener('window:scroll')
  public checkScroll(): void {
    const topPosToStartShowing = 100;

    const scrollPosition = this.getScrollPosition();
    if (scrollPosition >= topPosToStartShowing) {
      this.isShow = true;
    } else {
      this.isShow = false;
    }
  }

  public ngOnInit(): void {
    void this.getLinks();
  }

  public ngOnDestroy(): void {
    this.stopSubscriptionsNotifier.next();
    this.stopSubscriptionsNotifier.complete();
  }

  public gotoTop(): void {
    window.scroll({
      top: 0,
      left: 0,
      behavior: 'smooth'
    });
  }

  public shortDescription(description: string, maxAllowedTextLength: number = MAX_DESCRIPTION_ALLOWED_LENGTH): string {
    return this.bookmarksPageService.shortDescription(description, maxAllowedTextLength);
  }

  private getScrollPosition(): number {
    const initialPosition = 0;
    return window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || initialPosition;
  }

  private async getLinks(): Promise<void> {
    try {
      this.linksFront = await this.bookmarksPageService.getAllBookmarks();
    } catch (error) {
      console.error(error);
    }
  }
}
