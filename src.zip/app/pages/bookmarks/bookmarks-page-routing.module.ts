import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AuthGuard } from '../../../app/core';
import { environment } from '../../../environments/environment';
import { BookmarksPageComponent } from './bookmarks-page.component';

const routes: Routes = [
  {
    path: '',
    title: 'Enlaces favoritos a herramientas de trabajo',
    component: BookmarksPageComponent,
    canActivate: [AuthGuard],
    data: { roles: environment.roles }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BookmarksPageRoutingModule {}
