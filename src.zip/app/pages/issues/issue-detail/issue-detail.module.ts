import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { IssueModule } from '../shared';
import { IssueDetailComponent } from './issue-detail.component';

const routes: Routes = [{ path: '', component: IssueDetailComponent }];

@NgModule({
  declarations: [IssueDetailComponent],
  imports: [IssueModule, RouterModule.forChild(routes)],
  exports: [IssueDetailComponent, IssueModule]
})
export class IssueDetailModule {}
