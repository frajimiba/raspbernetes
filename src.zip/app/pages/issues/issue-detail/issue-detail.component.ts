import { Component, EventEmitter, Input, Output } from '@angular/core';

import { FullIssueViewDTO } from '../../../../app/core';

const LOG_TAG = 'IssueDetailComponent';

@Component({
  selector: 'app-issue-detail',
  templateUrl: './issue-detail.component.html',
  styleUrls: ['./issue-detail.component.scss']
})
export class IssueDetailComponent {
  @Input() issue: FullIssueViewDTO;
  @Output() public issueUpdated = new EventEmitter<FullIssueViewDTO>();
  @Output() public issueCollapsed = new EventEmitter<FullIssueViewDTO>();

  constructor() {
    console.log(`${LOG_TAG}`, 'new instance');
  }
}
