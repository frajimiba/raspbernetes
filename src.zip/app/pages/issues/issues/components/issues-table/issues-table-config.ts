export const COLUMNS_TO_DISPLAY: string[] = [
  'ticketId',
  'clientId',
  'issueType',
  'severity',
  'groupName',
  'classification',
  'specialFlag',
  'slaBreachTime',
  'status',
  'actions'
];

export const DEFAULT_NUMBER_OF_RESULTS = 0;
export const DEFAULT_PAGE_INDEX = 0;
export const DEFAULT_PAGE_SIZE = 50;
