export interface FilterConfig {
  clients: string[];
  groups: string[];
  classifications?: string[];
  hideExpired: boolean;
}
