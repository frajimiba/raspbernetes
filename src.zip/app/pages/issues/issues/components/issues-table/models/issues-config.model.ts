import { FullIssueViewDTO } from '../../../../../../../app/core';
import { PaginatorModel } from '../../../../../../../app/shared';

export interface IssuesRequestConfig {
  readonly pageConfig: PaginatorModel;
  readonly statuses?: string[];
  readonly groups?: string[];
  readonly classifications?: string[];
  readonly clients?: string[];
  readonly hideExpired: boolean;
}

export interface IssuesResponseConfig {
  readonly numOfResults: number;
  readonly issues: FullIssueViewDTO[];
}

export const EMPTY_ISSUE_RESPONSE: IssuesResponseConfig = { numOfResults: 0, issues: [] };
