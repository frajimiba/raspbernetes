import { animate, state, style, transition, trigger } from '@angular/animations';
import { ChangeDetectorRef, Component, Input, OnInit, ViewChild } from '@angular/core';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';

import { IssuesTableService } from './issues-table.service';

import { IssueStatus } from '../../../../../../app/core';
import { CustomIssueConfig, IssuesModeConfig, IssuesPageMode } from '../../../../../../app/pages';
import {
  COLUMNS_TO_DISPLAY,
  DEFAULT_NUMBER_OF_RESULTS,
  DEFAULT_PAGE_INDEX,
  DEFAULT_PAGE_SIZE
} from './issues-table-config';
import { FilterConfig, IssuesRequestConfig, IssuesResponseConfig } from './models';

const LOG_TAG = 'IssuesTableComponent';

export type IssuesModeConfigs = {
  [PageMode in IssuesPageMode]: () => Promise<IssuesResponseConfig>;
};

@Component({
  selector: 'app-issues-table',
  templateUrl: './issues-table.component.html',
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)'))
    ])
  ],
  styleUrls: ['./issues-table.component.scss']
})
export class IssuesTableComponent implements OnInit {
  @ViewChild(MatSort, { static: true }) sort: MatSort;

  @Input() public selectedStatuses: IssueStatus[];
  @Input() public config: IssuesModeConfig;

  public filterConfig: FilterConfig | undefined;
  public dataSource: MatTableDataSource<CustomIssueConfig>;
  public expandedIssue: CustomIssueConfig | undefined;
  public showFeedback = false;
  public columnsToDisplay: string[] = COLUMNS_TO_DISPLAY;

  // Pagination configs
  public numOfResults = DEFAULT_NUMBER_OF_RESULTS;
  public pageIndex = DEFAULT_PAGE_INDEX;
  public pageSize = DEFAULT_PAGE_SIZE;
  public initializedTable = false;
  public isLoading = false;
  private issuesModesConfig: IssuesModeConfigs;

  constructor(
    private readonly issuesTableService: IssuesTableService,
    private readonly changeDetectorRef: ChangeDetectorRef
  ) {
    console.log(`${LOG_TAG}`, 'new instance');
  }

  /**
   * En caso de no tener informado inicialmente estados y filtros no se inicializa la tabla
   * Para usuarios FTR se espera la busqueda manual usando la funcion searchIssues desde la UI
   * para usuarios no FTR se espera una configuración de filtro con al menos cliente/grupo especificado o una busqueda manual con filtro de grupo/cliente
   */
  public ngOnInit(): void {
    console.log(`${LOG_TAG}`, 'ngOnInit');
    this.initializeAvailablesIssuesModesConfig();
    void this.initializeState();
  }

  public hasNotResults(): boolean {
    const noIssueResult = 0;
    return this.initializedTable && this.numOfResults <= noIssueResult;
  }

  /**
   * Inicializa la tabla de incidencias con la configuración de filtros actual o la recibida por parámetros
   * @param filterConfig nueva configuración de filtro (cliente-proyecto / grupo / clasificación)
   */
  public searchIssues(filterConfig?: FilterConfig): void {
    console.log(`${LOG_TAG}`, 'searchIssues', filterConfig);
    this.filterConfig = filterConfig;
    void this.initializeState();
  }

  public hasNotValidMandatoryInputs(): boolean {
    return !this.selectedStatuses;
  }

  public pageChanged(event: any): void {
    console.log(`${LOG_TAG}`, 'pageChanged', event);
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
    void this.initializeState();
  }

  public sortChanged(): void {
    console.log(`${LOG_TAG}`, 'sortChanged');
    this.dataSource = new MatTableDataSource();
    void this.initializeState();
  }

  public clientProjectConfigSelected(): void {
    void this.initializeState();
  }

  public filterVisibleResult(event: Event): void {
    try {
      const filter = (event?.target as HTMLInputElement)?.value?.trim()?.toLowerCase();
      this.dataSource.filter = filter;
    } catch {
      console.error(`${LOG_TAG}`, 'filterVisibleResult', 'error parsing filter event value', event);
    }
  }

  public issueUpdated(updatedIssue: CustomIssueConfig): void {
    console.log(`${LOG_TAG}`, 'issueUpdated', updatedIssue);

    const NOT_FOUND_ISSUE_INDEX = -1;
    const index = this.dataSource.data.findIndex(issue => issue?.id === updatedIssue.id);
    if (index !== NOT_FOUND_ISSUE_INDEX) {
      this.dataSource.data[index] = Object.assign(this.dataSource.data[index], updatedIssue);
      this.changeDetectorRef.detectChanges();
    }
  }

  public issueCollapsed(collapsedIssue: CustomIssueConfig): void {
    console.log(`${LOG_TAG}`, 'issueCollapsed', collapsedIssue);
    this.expandedIssue = undefined;
  }

  private initializeAvailablesIssuesModesConfig(): void {
    this.issuesModesConfig = {
      myAssignedIssues: async (): Promise<IssuesResponseConfig> => this.initializeMyAssignedIssues(),
      pendingIssues: async (): Promise<IssuesResponseConfig> => this.initializePendingIssues(),
      myGroupsIssues: async (): Promise<IssuesResponseConfig> => this.initializeMyGroupsIssues(),
      allIssues: async (): Promise<IssuesResponseConfig> => this.initializeAllIssues()
    };
  }

  private async initializeIssues(): Promise<IssuesResponseConfig> {
    const issuesInitializationByPageConfig = this.issuesModesConfig[this.config?.mode];

    if (!issuesInitializationByPageConfig) {
      return Promise.resolve({ numOfResults: 0, issues: [] });
    }

    return issuesInitializationByPageConfig();
  }

  private async initializeState(): Promise<void> {
    console.log(`${LOG_TAG}`, 'initializeState');
    this.isLoading = true;

    const allIssuesResponse = await this.initializeIssues();
    const customIssueList: CustomIssueConfig[] = this.issuesTableService.mapCustomIssues(allIssuesResponse.issues);

    this.dataSource = new MatTableDataSource<CustomIssueConfig>(customIssueList);
    this.numOfResults = allIssuesResponse.numOfResults;
    this.initializedTable = true;
    this.isLoading = false;
  }

  private async initializeMyAssignedIssues(): Promise<IssuesResponseConfig> {
    const issuesRequestConfig: IssuesRequestConfig = this.getIssuesRequestConfig();
    return await this.issuesTableService.getMyAssignedIssues(issuesRequestConfig);
  }

  private async initializePendingIssues(): Promise<IssuesResponseConfig> {
    const issuesRequestConfig: IssuesRequestConfig = this.getIssuesRequestConfig();
    return await this.issuesTableService.getPendingIssuesByGroupsClassifications(issuesRequestConfig);
  }

  private async initializeMyGroupsIssues(): Promise<IssuesResponseConfig> {
    const issuesRequestConfig: IssuesRequestConfig = this.getIssuesRequestConfig();
    return await this.issuesTableService.getMyGroupsIssues(issuesRequestConfig);
  }

  private async initializeAllIssues(): Promise<IssuesResponseConfig> {
    const issuesRequestConfig: IssuesRequestConfig = this.getIssuesRequestConfig();
    return await this.issuesTableService.getIssuesByGroupsClassifications(issuesRequestConfig);
  }

  private getIssuesRequestConfig(): IssuesRequestConfig {
    return {
      pageConfig: {
        pageIndex: this.pageIndex,
        size: this.pageSize,
        sortCol: this.sort.active,
        ascending: this.sort.direction === 'asc'
      },
      statuses: this.selectedStatuses,
      groups: this.filterConfig?.groups,
      classifications: this.filterConfig?.classifications,
      clients: this.filterConfig?.clients,
      hideExpired: this.filterConfig?.hideExpired ?? true
    };
  }
}
