import { Injectable } from '@angular/core';

import {
  DEFAULT_NUMBER,
  FullIssueViewDTO,
  IssuesApiModel,
  IssuesApiService,
  PagedResultFullIssueViewDTO
} from '../../../../../../app/core';
import {
  CustomIssueConfig,
  IssueBreachTimeService,
  IssueDateService,
  IssuesPageMode
} from '../../../../../../app/pages';
import { EMPTY_ISSUE_RESPONSE, IssuesRequestConfig, IssuesResponseConfig } from './models/issues-config.model';

const LOG_TAG = 'IssuesListService';

@Injectable({
  providedIn: 'root'
})
export class IssuesTableService {
  constructor(
    private readonly issuesService: IssuesApiService,
    public readonly issueDateService: IssueDateService,
    private readonly issueBreachTimeService: IssueBreachTimeService
  ) {}

  public isPageModeMyAssignedIssues(issuesPageMode: IssuesPageMode): boolean {
    return issuesPageMode === 'myAssignedIssues';
  }

  public mapCustomIssues(issues: FullIssueViewDTO[]): CustomIssueConfig[] {
    return this.issueBreachTimeService.mapIssuesToCustomIssues(issues);
  }

  public async getMyAssignedIssues(issuesRequestConfig: IssuesRequestConfig): Promise<IssuesResponseConfig> {
    console.log(`${LOG_TAG}`, 'getMyAssignedIssues', issuesRequestConfig);
    const issuesApiModel: IssuesApiModel = this.mapIssuesRequestConfigToIssuesApiModel(issuesRequestConfig);

    return this.issuesService
      .getMyAssignedIssues(issuesApiModel)
      .then(issues => this.mapIssuesResponse(issues))
      .catch(error => {
        console.error(`${LOG_TAG}`, 'getMyAssignedIssues error', error);
        return EMPTY_ISSUE_RESPONSE;
      });
  }

  public async getPendingIssuesByGroupsClassifications(
    issuesRequestConfig: IssuesRequestConfig
  ): Promise<IssuesResponseConfig> {
    const issuesApiModel: IssuesApiModel = this.mapIssuesRequestConfigToIssuesApiModel(issuesRequestConfig);

    return this.issuesService
      .getPendingIssuesByGroupsClassifications(issuesApiModel)
      .then(issues => this.mapIssuesResponse(issues))
      .catch(error => {
        console.error(`${LOG_TAG}`, 'getPendingIssuesByGroupsClassifications error', error);
        return EMPTY_ISSUE_RESPONSE;
      });
  }

  public async getMyGroupsIssues(issuesRequestConfig: IssuesRequestConfig): Promise<IssuesResponseConfig> {
    const issuesApiModel: IssuesApiModel = this.mapIssuesRequestConfigToIssuesApiModel(issuesRequestConfig);

    return this.issuesService
      .getMyGroupsIssues(issuesApiModel)
      .then(issues => this.mapIssuesResponse(issues))
      .catch(error => {
        console.error(`${LOG_TAG}`, 'getMyGroupsIssues error', error);
        return EMPTY_ISSUE_RESPONSE;
      });
  }

  public async getIssuesByGroupsClassifications(
    issuesRequestConfig: IssuesRequestConfig
  ): Promise<IssuesResponseConfig> {
    const issuesApiModel: IssuesApiModel = this.mapIssuesRequestConfigToIssuesApiModel(issuesRequestConfig);

    return this.issuesService
      .getIssuesByGroupsClassifications(issuesApiModel)
      .then(issues => this.mapIssuesResponse(issues))
      .catch(error => {
        console.error(`${LOG_TAG}`, 'getIssuesByGroupsClassifications error', error);
        return EMPTY_ISSUE_RESPONSE;
      });
  }

  private mapIssuesRequestConfigToIssuesApiModel(issuesRequestConfig: IssuesRequestConfig): IssuesApiModel {
    return {
      page: issuesRequestConfig.pageConfig.pageIndex,
      size: issuesRequestConfig.pageConfig.size,
      sortCol: issuesRequestConfig.pageConfig.sortCol,
      ascending: issuesRequestConfig.pageConfig.ascending,
      fullIssueEntry: {
        groups: issuesRequestConfig?.groups ?? [],
        classifications: issuesRequestConfig?.classifications ?? [],
        statuses: issuesRequestConfig.statuses ?? [],
        clients: issuesRequestConfig?.clients ?? [],
        hideExpired: issuesRequestConfig?.hideExpired ?? true
      }
    };
  }

  private mapIssuesResponse(issues: PagedResultFullIssueViewDTO): IssuesResponseConfig {
    return { numOfResults: issues.numOfResults ?? DEFAULT_NUMBER, issues: issues?.list ?? [] };
  }
}
