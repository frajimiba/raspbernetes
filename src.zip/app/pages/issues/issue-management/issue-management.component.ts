import { Component, OnInit } from '@angular/core';

const LOG_TAG = 'IssueManagementComponent';

@Component({
  selector: 'app-issue-management',
  templateUrl: './issue-management.component.html',
  styleUrls: ['./issue-management.component.scss']
})
export class IssueManagementComponent implements OnInit {
  constructor() {
    console.log(`${LOG_TAG}`, 'new instance');
  }

  public ngOnInit(): void {
    console.log(`${LOG_TAG}`, 'ngOnInit');
  }
}
