import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { IssueCreationEditionModule } from '../shared/issue-creation-edition/issue-creation-edition.module';

import { IssueManagementComponent } from './issue-management.component';

const routes: Routes = [{ path: '', component: IssueManagementComponent }];

const DEPENDENCIES = [CommonModule, IssueCreationEditionModule, RouterModule.forChild(routes)];

@NgModule({
  declarations: [IssueManagementComponent],
  imports: DEPENDENCIES,
  exports: [IssueManagementComponent, DEPENDENCIES]
})
export class IssueManagementModule {}
