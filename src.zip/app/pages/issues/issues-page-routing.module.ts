import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AuthGuard, IssuesRoutesIds } from '../../../app/core';
import { environment } from '../../../environments/environment';
import { IssueStatus } from '../../core/utils/issue-status.constants';
import { IssuesModeConfig } from './models/issues-mode-config.model';

interface IssuesRouteConfig extends IssuesModeConfig {
  roles: string[];
  filters: IssueStatus[];
  preselectedFilters: IssueStatus[];
}

const myIssuesModeConfig: IssuesRouteConfig = {
  title: 'Mis incidencias asignadas',
  mode: 'myAssignedIssues',
  roles: environment.roles,
  filters: ['Assigned', 'Resolved', 'In Progress', 'Pending', 'Failed'],
  preselectedFilters: ['Assigned', 'In Progress', 'Pending', 'Failed']
};

const pendingIssuesModeConfig: IssuesRouteConfig = {
  title: 'Incidencias pendientes',
  mode: 'pendingIssues',
  roles: environment.roles,
  filters: ['Unassigned', 'Pending', 'Failed'],
  preselectedFilters: ['Unassigned', 'Pending', 'Failed']
};

const myGroupsIssuesModeConfig: IssuesRouteConfig = {
  title: 'Incidencias de mis grupos',
  mode: 'myGroupsIssues',
  roles: environment.roles,
  filters: ['Unassigned', 'Assigned', 'Resolved', 'In Progress', 'Pending', 'Failed'],
  preselectedFilters: ['Unassigned', 'Assigned', 'In Progress', 'Pending', 'Failed']
};

const routes: Routes = [
  {
    path: '',
    children: [
      {
        path: '',
        redirectTo: IssuesRoutesIds.myIssues,
        pathMatch: 'full'
      },
      {
        path: IssuesRoutesIds.myIssues,
        title: myIssuesModeConfig.title,
        loadChildren: () => import('./issues/issues.module').then(m => m.IssuesModule),
        canActivate: [AuthGuard],
        data: myIssuesModeConfig
      },
      {
        path: IssuesRoutesIds.pendingIssues,
        title: pendingIssuesModeConfig.title,
        loadChildren: () => import('./issues/issues.module').then(m => m.IssuesModule),
        canActivate: [AuthGuard],
        data: pendingIssuesModeConfig
      },
      {
        path: IssuesRoutesIds.myGroupIssues,
        title: myGroupsIssuesModeConfig.title,
        loadChildren: () => import('./issues/issues.module').then(m => m.IssuesModule),
        canActivate: [AuthGuard],
        data: myGroupsIssuesModeConfig
      }
    ]
  },
  {
    path: IssuesRoutesIds.issue,
    title: 'Gestión incidencias',
    loadChildren: () => import('./issue-detail/issue-detail.module').then(m => m.IssueDetailModule),
    canActivate: [AuthGuard],
    data: { roles: environment.roles }
  },
  {
    path: IssuesRoutesIds.creationEdition,
    title: 'Creación - edición de incidencias',
    loadChildren: () => import('./issue-management/issue-management.module').then(m => m.IssueManagementModule),
    canActivate: [AuthGuard],
    data: { roles: environment.roles }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class IssuesPageRoutingModule {}
