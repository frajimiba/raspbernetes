import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { IssuesPageRoutingModule } from './issues-page-routing.module';

import { IssuesPageComponent } from './issues-page.component';

@NgModule({
  declarations: [IssuesPageComponent],
  imports: [CommonModule, IssuesPageRoutingModule]
})
export class IssuesPageModule {}
