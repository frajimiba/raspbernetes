import { Component, OnInit } from '@angular/core';

import { DashboardApiService } from '../../../app/core/api/dashboard-api/dashboard-api.service';

import { PaginatorModel } from '../../../app/shared';
import { DashboardPage } from './dashboard.model';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  public currentPage: DashboardPage;
  public paginatorModel: PaginatorModel = {
    pageIndex: 0,
    size: 1,
    ascending: true,
    sortCol: 'position'
  };

  constructor(private readonly dashboardApiService: DashboardApiService) {}

  ngOnInit(): void {
    this.getPages();
  }

  public pageChanged(event: any): void {
    this.paginatorModel.pageIndex = event.pageIndex;
    this.paginatorModel.size = event.pageSize;
    this.getPages();
  }

  public getPages(): void {
    void this.dashboardApiService
      .getAllPages(
        {
          ascending: this.paginatorModel.ascending,
          pageIndex: this.paginatorModel.pageIndex,
          size: this.paginatorModel.size,
          sortCol: this.paginatorModel.sortCol
        },
        {
          classifications: [],
          clients: [],
          groups: []
        }
      )
      .then(page => {
        this.currentPage = page;
      });
  }
}
