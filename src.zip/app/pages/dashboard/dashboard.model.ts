import { PagedResultDashboardEntry } from '../../../app/core';

export type DashboardPage = Readonly<PagedResultDashboardEntry>;
