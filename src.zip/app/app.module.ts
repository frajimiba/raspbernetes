import { KeycloakAngularModule, KeycloakOptions, KeycloakService } from 'keycloak-angular';

import { registerLocaleData } from '@angular/common';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import localeES from '@angular/common/locales/es';
import { APP_INITIALIZER, ErrorHandler, LOCALE_ID, NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MAT_FORM_FIELD_DEFAULT_OPTIONS } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { AppRoutingModule } from './app-routing.module';
import { AppLayoutModule } from './core/layout/app-layout.module';
import { HomePageModule } from './pages/home/home-page.module';
import { ChatbotModule } from './shared/components/chatbot/chatbot.module';

import { environment } from '../environments/environment';
import { AppComponent } from './app.component';
import { AuthService, DEFAULT_HTTP_TIMEOUT, RequestHttpInterceptor } from './core';
import { CustomAngularErrorHandler } from './core/error/custom-angular-error-handler';
import { CustomMaxDirective, CustomMinDirective, PipesModule } from './shared';

registerLocaleData(localeES, 'es');

export function initializer(keycloak: KeycloakService): () => Promise<any> {
  const options: KeycloakOptions = {
    config: environment.keycloackConfig,
    initOptions: {
      onLoad: 'check-sso',
      checkLoginIframe: false
    },
    bearerExcludedUrls: []
  };
  return async (): Promise<any> => await keycloak.init(options);
}
@NgModule({
  declarations: [AppComponent, CustomMaxDirective, CustomMinDirective],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    AppLayoutModule,
    HttpClientModule,
    KeycloakAngularModule,
    PipesModule,
    HomePageModule,
    ReactiveFormsModule,
    FormsModule,
    MatSelectModule,
    ChatbotModule
  ],
  providers: [
    KeycloakService,
    { provide: ErrorHandler, useClass: CustomAngularErrorHandler },
    { provide: LOCALE_ID, useValue: 'es' },
    { provide: HTTP_INTERCEPTORS, useClass: RequestHttpInterceptor, multi: true },
    { provide: APP_INITIALIZER, useFactory: initializer, multi: true, deps: [KeycloakService] },
    { provide: DEFAULT_HTTP_TIMEOUT, useValue: 30000 },
    AuthService,
    { provide: MAT_FORM_FIELD_DEFAULT_OPTIONS, useValue: { appearance: 'outline' } }
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
