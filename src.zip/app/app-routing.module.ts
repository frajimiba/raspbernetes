import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { environment } from '../environments/environment';
import { AppRouteIds, AuthGuard } from './core';

export const routes: Routes = [
  { path: '', redirectTo: AppRouteIds.home, pathMatch: 'full' },
  {
    path: AppRouteIds.home,
    loadChildren: () => import('./pages/dashboard/dashboard.module').then(m => m.DashboardModule),
    canActivate: [AuthGuard],
    data: { roles: environment.roles }
  },
  {
    path: AppRouteIds.bookmarks,
    loadChildren: () => import('./pages/bookmarks/bookmarks-page.module').then(m => m.BookmarksPageModule),
    canActivate: [AuthGuard],
    data: { roles: environment.roles }
  },
  {
    path: AppRouteIds.admin,
    loadChildren: () =>
      import('./pages/admin-dashboard/admin-dashboard-page.module').then(m => m.AdminDashboardPageModule),
    canActivate: [AuthGuard],
    data: { roles: ['admin'] }
  },
  {
    path: AppRouteIds.procedures,
    loadChildren: () => import('./pages/procedures/procedures-page.module').then(m => m.ProceduresPageModule),
    canActivate: [AuthGuard],
    data: { roles: environment.roles }
  },
  {
    path: AppRouteIds.feedbacks,
    loadChildren: () => import('./pages/feedbacks/feedbacks-page.module').then(m => m.FeedbacksPageModule),
    canActivate: [AuthGuard],
    data: { roles: environment.roles }
  },
  {
    path: AppRouteIds.issues,
    loadChildren: () => import('./pages/issues/issues-page.module').then(m => m.IssuesPageModule),
    canActivate: [AuthGuard],
    data: { roles: environment.roles }
  },
  {
    path: AppRouteIds.selfservice,
    canActivate: [AuthGuard],
    data: { roles: environment.roles },
    loadChildren: () => import('./pages/self-service/self-service.module').then(m => m.SelfServiceModule)
  },
  {
    path: AppRouteIds.aichat,
    canActivate: [AuthGuard],
    data: { roles: environment.roles },
    loadChildren: () => import('./pages/ai-chat/ai-chat.module').then(m => m.AiChatModule)
  },
  {
    path: AppRouteIds.demo,
    loadChildren: () => import('./pages/demo/demo-page.module').then(m => m.DemoPageModule)
  },
  {
    path: AppRouteIds.error404,
    loadChildren: () => import('./pages/not-found/not-found-page.module').then(m => m.NotFoundPageModule)
  },
  { path: '**', redirectTo: `/${AppRouteIds.error404}` }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  providers: []
})
export class AppRoutingModule {}
