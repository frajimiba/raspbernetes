package isom.appops.domain.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

public class BaseJsonToObjectsCreator {
    protected String getStringFromFile(String resource) throws IOException {
        File file = FileUtils.toFile(BaseJsonToObjectsCreator.class.getResource(resource));
        return FileUtils.readFileToString(file, StandardCharsets.UTF_8);
    }

    protected <T> T getObjectFromFile(String resource, Class<T> clazz) throws IOException {
        File file = FileUtils.toFile(BaseJsonToObjectsCreator.class.getResource(resource));
        return new ObjectMapper().registerModule(new JavaTimeModule()).readValue(file, clazz);
    }

    /*protected <T> List<T> getObjectListFromFile(String resource, Class<T> clazz) throws IOException {
        File file = FileUtils.toFile(BaseJsonToObjectsCreator.class.getResource(resource));
        ObjectMapper mapper = new ObjectMapper();
        JavaType type = mapper.getTypeFactory().constructCollectionType(List.class, clazz);
        return mapper.registerModule(new JavaTimeModule()).registerModule(new JodaModule()).readValue(file, type);
    }*/
}
