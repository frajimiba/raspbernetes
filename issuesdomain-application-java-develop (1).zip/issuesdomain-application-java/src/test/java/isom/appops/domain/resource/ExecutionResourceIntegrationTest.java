package isom.appops.domain.resource;

import static io.restassured.RestAssured.given;

import isom.appops.domain.utils.TestConstants;
import io.quarkus.test.junit.QuarkusTest;
import org.junit.jupiter.api.Test;

import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.Map;
import java.util.UUID;

import isom.appops.domain.utils.TestsUtility;

@QuarkusTest
class ExecutionResourceIntegrationTest {

    private static final String PATH_EXECUTIONS_FEEDBACKS = "/executions/{id}/feedbacks";
    private static final String PATH_EXECUTIONS_BY_ISSUE = "/executions/by-issue/{issueId}";
    private static final String PATH_PARAM_ID = "id";
    private static final String PATH_PARAM_ISSUE_ID = "issueId";
    private static final Map<String, Long> pathParams = Map.of(PATH_PARAM_ID, 1L);
    private static final Map<String, UUID> pathParamsIssue = Map.of(PATH_PARAM_ISSUE_ID, TestsUtility.getUuid(TestConstants.UUID_ASSIGNMENT_ISSUE_4));

    @Test
    void GivenExecutionIdAndPageRequest_WhenGetExecutionsFeedback_ThenReturnStatusOk() {
        given()
                .auth().preemptive().oauth2(TestsUtility.getToken())
                .pathParams(pathParams)
                .queryParams(TestsUtility.getPageRequestMap())
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                .header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON)
                .when().get(PATH_EXECUTIONS_FEEDBACKS)
                .then().statusCode(Response.Status.OK.getStatusCode());
    }

    @Test
    void GivenPageRequestAndIssueId_WhenGetIssuesAssignedToAuthUser_ThenReturnStatusOk() {
        given()
                .auth().preemptive().oauth2(TestsUtility.getToken())
                .pathParams(pathParamsIssue)
                .queryParams(TestsUtility.getPageRequestMap())
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                .header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON)
                .when().get(PATH_EXECUTIONS_BY_ISSUE)
                .then().statusCode(Response.Status.OK.getStatusCode());
    }
}