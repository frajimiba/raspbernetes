package isom.appops.domain.utils;

import java.io.IOException;

public interface TestsUtilMethods {
    void loadData() throws IOException;
}
