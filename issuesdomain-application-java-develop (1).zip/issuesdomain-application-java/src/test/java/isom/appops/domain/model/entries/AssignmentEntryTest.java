package isom.appops.domain.model.entries;

import static org.junit.jupiter.api.Assertions.*;

import io.quarkus.test.junit.QuarkusTest;
import isom.appops.domain.utils.TestConstants;
import isom.appops.domain.utils.TestsUtility;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.time.OffsetDateTime;
import java.util.UUID;

import isom.appops.domain.utils.JsonToObjectsCreator;

@QuarkusTest
class AssignmentEntryTest extends JsonToObjectsCreator {

    private static final UUID uuidIssue = TestsUtility.getUuid(TestConstants.UUID_ASSIGNMENT_ISSUE_4);
    private static final OffsetDateTime now = TestsUtility.getOffsetDateTimeNow();
    @Test
    void testEquals() {
        AssignmentEntry assignmentEntry = new AssignmentEntry(
                TestConstants.GROUP_NAME,
                TestConstants.USERNAME,
                TestConstants.TEXT,
                uuidIssue);
        SlaBreachTimeEntry slaBreachTimeEntry = new SlaBreachTimeEntry(uuidIssue, now);
        assertFalse(notEquals(assignmentEntry, slaBreachTimeEntry));
        assertEquals(assignmentEntry, assignmentEntry);
        assertEquals(TestConstants.GROUP_NAME, assignmentEntry.getGroupName());
        assertEquals(TestConstants.USERNAME, assignmentEntry.getUserName());
        assertEquals(TestConstants.TEXT, assignmentEntry.getText());
    }

    @Test
    void testHashCode() throws IOException {
        AssignmentEntry assignmentEntry = assignmentEntry();
        AssignmentEntry assignmentEntry2 = new AssignmentEntry();
        assignmentEntry2.groupId(TestConstants.GROUP_NAME);
        assignmentEntry2.userId(TestConstants.USERNAME);
        assignmentEntry2.text(TestConstants.TEXT);
        assertTrue(equals(assignmentEntry, assignmentEntry2));
        assertEquals(assignmentEntry.hashCode(), assignmentEntry2.hashCode());
    }

    @Test
    void testToString() throws IOException {
        AssignmentEntry assignmentEntry = assignmentEntry();
        AssignmentEntry assignmentEntry2 = new AssignmentEntry();
        assignmentEntry2.setGroupName(TestConstants.GROUP_NAME);
        assignmentEntry2.setUserName(TestConstants.USERNAME);
        assignmentEntry2.setText(TestConstants.TEXT);
        assertEquals(assignmentEntry.toString(), assignmentEntry2.toString());
    }

    private boolean notEquals(AssignmentEntry assignmentEntry, SlaBreachTimeEntry slaBreachTimeEntry) {
        return assignmentEntry.equals(slaBreachTimeEntry);
    }

    private boolean equals(AssignmentEntry assignmentEntry, AssignmentEntry assignmentEntry2) {
        return assignmentEntry.equals(assignmentEntry2) &&
                assignmentEntry.getGroupName().equals(assignmentEntry2.getGroupName()) &&
                assignmentEntry.getUserName().equals(assignmentEntry2.getUserName()) &&
                assignmentEntry.getText().equals(assignmentEntry2.getText());
    }
}