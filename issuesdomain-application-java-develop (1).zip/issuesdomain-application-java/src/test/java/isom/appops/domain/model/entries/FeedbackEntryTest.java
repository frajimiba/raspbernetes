package isom.appops.domain.model.entries;

import static io.smallrye.common.constraint.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.*;

import isom.appops.domain.utils.TestConstants;
import io.quarkus.test.junit.QuarkusTest;
import org.junit.jupiter.api.Test;

@QuarkusTest
class FeedbackEntryTest {

    @Test
    void GivenFeedbackEntry_WhenSetAttributesPageRequest_ThenReturnsAttributes() {
        FeedbackEntry feedbackEntry = new FeedbackEntry(4, TestConstants.FEEBACK_COMMENT, 1l);
        assertNotNull(feedbackEntry);
        assertEquals(4, feedbackEntry.getStars());
        assertEquals(TestConstants.FEEBACK_COMMENT, feedbackEntry.getComments());
        assertEquals(1L, feedbackEntry.getExecutionRef());

        FeedbackEntry feedbackEntry2 = new FeedbackEntry();
        feedbackEntry2.setStars(5);
        feedbackEntry2.setComments(TestConstants.FEEBACK_COMMENT);
        feedbackEntry2.setExecutionRef(1L);
        assertNotNull(feedbackEntry2);
    }
}