package isom.appops.domain.model.entries;

import static io.smallrye.common.constraint.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import io.quarkus.test.junit.QuarkusTest;

import isom.appops.domain.utils.TestConstants;
import org.junit.jupiter.api.Test;

@QuarkusTest
class JobEntryTest {

    @Test
    void GivenJobEntry_WhenSetAttributesPageRequest_ThenReturnsAttributes() {
        JobEntry jobEntry = new JobEntry(
                TestConstants.JOB_NAME,
                TestConstants.CONFIG_FILE_ENV_DEV,
                TestConstants.CLIENT_ID,
                TestConstants.CONFIG_FILE_PATH,
                TestConstants.CONFIG_FILE_VERSION);
        assertNotNull(jobEntry);
        assertEquals(TestConstants.JOB_NAME, jobEntry.getJobName());
        assertEquals(TestConstants.CONFIG_FILE_ENV_DEV, jobEntry.getEnv());
        assertEquals(TestConstants.CLIENT_ID, jobEntry.getOrganization());
        assertEquals(TestConstants.CONFIG_FILE_PATH, jobEntry.getRepository());
        assertEquals(TestConstants.CONFIG_FILE_VERSION, jobEntry.getVersion());

        JobEntry jobEntry2 = new JobEntry();
        jobEntry2.setJobName(TestConstants.JOB_NAME);
        jobEntry2.setEnv(TestConstants.CONFIG_FILE_ENV_DEV);
        jobEntry2.setOrganization(TestConstants.CLIENT_ID);
        jobEntry2.setRepository(TestConstants.CONFIG_FILE_PATH);
        jobEntry2.setVersion(TestConstants.CONFIG_FILE_VERSION);
        assertNotNull(jobEntry2);
    }
}