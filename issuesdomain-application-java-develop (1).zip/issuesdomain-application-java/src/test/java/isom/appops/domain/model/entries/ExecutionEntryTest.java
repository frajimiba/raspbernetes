package isom.appops.domain.model.entries;

import static org.junit.jupiter.api.Assertions.*;

import io.quarkus.test.junit.QuarkusTest;
import isom.appops.domain.utils.TestConstants;
import isom.appops.domain.utils.TestsUtility;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.util.List;
import java.util.UUID;

import isom.appops.domain.utils.JsonToObjectsCreator;

@QuarkusTest
class ExecutionEntryTest extends JsonToObjectsCreator {

    private static final UUID uuidIssue = TestsUtility.getUuid(TestConstants.UUID_ASSIGNMENT_ISSUE_4);
    private static final List<String> parametersList = TestConstants.PARAMETERS_LIST;

    @Test
    void testEquals() throws IOException {
        AssignmentEntry assignmentEntry = assignmentEntry();
        ExecutionEntry executionEntry = new ExecutionEntry(uuidIssue, parametersList);
        assertFalse(notEquals(executionEntry, assignmentEntry));
        assertEquals(executionEntry, executionEntry);
        assertEquals(parametersList, executionEntry.getParameters());
        assertEquals(uuidIssue, executionEntry.getIssueId());
    }

    @Test
    void testHashCode() {
        ExecutionEntry executionEntry = new ExecutionEntry(uuidIssue, parametersList);
        ExecutionEntry executionEntry2 = new ExecutionEntry();
        executionEntry2.parameters(parametersList);
        executionEntry2.setIssueId(uuidIssue);
        assertTrue(equals(executionEntry, executionEntry2));
        assertEquals(executionEntry.hashCode(), executionEntry2.hashCode());
    }

    @Test
    void testToString() {
        ExecutionEntry executionEntry = new ExecutionEntry(uuidIssue, parametersList);
        ExecutionEntry executionEntry2 = new ExecutionEntry();
        executionEntry2.setParameters(parametersList);
        executionEntry2.setIssueId(uuidIssue);
        assertEquals(executionEntry.toString(), executionEntry2.toString());
    }

    private boolean notEquals(ExecutionEntry executionEntry, AssignmentEntry assignmentEntry) {
        return executionEntry.equals(assignmentEntry);
    }

    private boolean equals(ExecutionEntry executionEntry, ExecutionEntry executionEntry2) {
        return executionEntry.equals(executionEntry2) &&
                executionEntry.getParameters().equals(executionEntry2.getParameters()) &&
                executionEntry.getIssueId().equals(executionEntry2.getIssueId());
    }
}