package isom.appops.domain.services;

import isom.appops.database.entities.FeedbackEntity;
import isom.appops.database.repository.FeedbackEntityRepository;
import isom.appops.domain.utils.TestsUtilMethods;
import io.quarkus.test.junit.QuarkusTest;
import org.junit.jupiter.api.*;

import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import java.io.IOException;

import static io.smallrye.common.constraint.Assert.assertNotNull;

import isom.appops.domain.model.dto.FeedbackDTO;
import isom.appops.domain.model.entries.FeedbackEntry;
import isom.appops.domain.utils.JsonToObjectsCreator;

@QuarkusTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class FeedbackServiceTest extends JsonToObjectsCreator implements TestsUtilMethods {

    @Inject
    FeedbackService feedbackService;

    @Inject
    FeedbackEntityRepository feedbackEntityRepository;

    @BeforeEach
    @Transactional
    public void setup() {
        feedbackEntityRepository.deleteAll();
    }

//    @Test
    @Order(1)
    void GivenFeedbackEntry_WhenAddEntry_ThenReturnsFeedbackDto() throws IOException {
        FeedbackEntry feedbackEntry = feedbackEntry();
        FeedbackDTO feedbackDto = feedbackService.add(feedbackEntry);
        assertNotNull(feedbackDto);
    }

    @Override
    public void loadData() throws IOException {
        FeedbackEntity feedbackEntity = feedbackEntity();
        feedbackEntityRepository.persist(feedbackEntity);
    }
}