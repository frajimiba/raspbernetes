package isom.appops.domain.model.entries;

import static io.smallrye.common.constraint.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import io.quarkus.test.junit.QuarkusTest;
import isom.appops.domain.utils.TestConstants;
import org.junit.jupiter.api.Test;

import java.util.List;

@QuarkusTest
class FullIssueUsersEntryTest {

    @Test
    void GivenFullIssueUsersEntry_WhenSetAttributesPageRequest_ThenReturnsAttributes() {
        List<String> userIdList = TestConstants.USER_ID_LIST;
        List<String> statusList = TestConstants.STATUS_LIST;

        FullIssueUsersEntry fullIssueUsersEntry = new FullIssueUsersEntry(userIdList, statusList);
        assertNotNull(fullIssueUsersEntry);
        assertEquals(5, fullIssueUsersEntry.getUsers().size());
        assertEquals(5, fullIssueUsersEntry.getStatuses().size());
        assertEquals(TestConstants.USERNAME, fullIssueUsersEntry.getUsers().get(0));
        assertEquals(TestConstants.STATUS_UNASSIGNED, fullIssueUsersEntry.getStatuses().get(0));

        FullIssueUsersEntry fullIssueUsersEntry2 = new FullIssueUsersEntry();
        fullIssueUsersEntry2.setUsers(userIdList);
        fullIssueUsersEntry2.setStatuses(statusList);

        assertNotNull(fullIssueUsersEntry2);
        assertEquals(5, fullIssueUsersEntry2.getUsers().size());
        assertEquals(5, fullIssueUsersEntry2.getStatuses().size());
        assertEquals(TestConstants.USERNAME, fullIssueUsersEntry2.getUsers().get(0));
        assertEquals(TestConstants.STATUS_UNASSIGNED, fullIssueUsersEntry2.getStatuses().get(0));
    }

}