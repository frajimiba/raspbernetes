package isom.appops.domain.resource;

import static io.restassured.RestAssured.given;

import io.quarkus.test.junit.QuarkusTest;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.Map;
import java.util.UUID;

import isom.appops.domain.utils.TestConstants;
import isom.appops.domain.utils.TestsUtility;

@QuarkusTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class StatusTrackingResourceIntegrationTest {

    private static final String PATH_ROOT = "/issues/{id}/statuses/";
    private static final String PATH_ADD_STATUS = "/issues/{id}/statuses/status";
    private static final String PATH_PARAM_ID = "id";
    private static final Map<String, UUID> pathParams = Map.of(PATH_PARAM_ID, TestsUtility.getUuid(TestConstants.UUID_ASSIGNMENT_ISSUE_4));

    @Test
    @Order(1)
    void GivenIssueUuidAndStatusAssigned_WhenAddtatusIntoIssue_ThenReturnsResponseAccepted(){
        given()
                .auth().preemptive().oauth2(TestsUtility.getToken())
                .pathParams(pathParams)
                .body(TestConstants.STATUS_ASSIGNED)
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                .header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON)
                .when().post(PATH_ADD_STATUS)
                .then().statusCode(Response.Status.ACCEPTED.getStatusCode());
    }

    @Test
    @Order(2)
    void GivenIssueUuidAndStatusResolved_WhenAddtatusIntoIssue_ThenReturnsResponseAccepted(){
        given()
                .auth().preemptive().oauth2(TestsUtility.getToken())
                .pathParams(pathParams)
                .body(TestConstants.STATUS_RESOLVED)
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                .header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON)
                .when().post(PATH_ADD_STATUS)
                .then().statusCode(Response.Status.ACCEPTED.getStatusCode());
    }

    @Test
    @Order(3)
    void GivenIssueUuid_WhenGetStatus_ThenReturnsResponseOk(){
        given()
                .auth().preemptive().oauth2(TestsUtility.getToken())
                .pathParams(pathParams)
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                .header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON)
                .when().get(PATH_ROOT)
                .then().statusCode(Response.Status.OK.getStatusCode());
    }
}