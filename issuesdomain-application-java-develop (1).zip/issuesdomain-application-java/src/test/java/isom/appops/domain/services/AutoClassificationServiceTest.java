package isom.appops.domain.services;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

import io.quarkus.test.junit.QuarkusTest;
import isom.appops.database.entities.IssueEntity;
import isom.appops.domain.model.entries.AutomaticClassificationEntry;
import isom.appops.domain.utils.JsonToObjectsCreator;
import isom.appops.domain.utils.TestConstants;
import isom.appops.domain.utils.TestsUtility;
import org.junit.jupiter.api.Test;

import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import java.io.IOException;
import java.util.UUID;

import isom.appops.quarkus.errorhandler.exception.ApiBadRequestException;

@QuarkusTest
class AutoClassificationServiceTest extends JsonToObjectsCreator {

    @Inject
    AutoClassificationService autoClassificationService;

    @Test
    void GivenUuidIdRandomAndAutomaticClassificationEntryIsNull_WhenAutoClassify_ThenThrowsApiBadRequestException() {
        UUID randomUuid = TestsUtility.getRandomUuid();

        Exception exception = assertThrows(ApiBadRequestException.class, () ->
                autoClassificationService.autoClassify(randomUuid, null)
        );

        String expectedMessage = TestConstants.ISSUE_NOT_FOUND;
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
    }

    @Test
    @Transactional
    void GivenUuidAndAutomaticClassificationEntryNotNull_WhenAutoClassify_ThenReturnsIssueEntity() throws IOException {
        UUID uuidIssue = TestsUtility.getUuid(TestConstants.UUID_ASSIGNMENT_ISSUE);
        AutomaticClassificationEntry automaticClassificationEntry = automaticClassificationEntry();

        IssueEntity issueEntity = autoClassificationService.autoClassify(uuidIssue, automaticClassificationEntry);
        assertNotNull(issueEntity);
        assertEquals(uuidIssue.toString(), issueEntity.getId().toString());
        assertEquals(TestConstants.GROUP_NAME, issueEntity.getGroupName());
    }
}