package isom.appops.domain.resource;

import static io.restassured.RestAssured.given;

import io.quarkus.test.junit.QuarkusTest;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import java.io.IOException;
import java.util.Map;

import isom.appops.domain.model.entries.TroubleshootingEntry;
import isom.appops.domain.utils.JsonToObjectsCreator;
import isom.appops.domain.utils.TestConstants;
import isom.appops.domain.utils.TestsUtility;

@QuarkusTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class TroubleshootingResourceIntegrationTest extends JsonToObjectsCreator {

    private static final String PATH_ROOT = "/issues/{id}/troubleshootings/";
    private static final String PATH_ID = "/issues/{id}/troubleshootings/{tId}";
    private static final String PATH_PARAM_ID = "id";
    private static final String PATH_PARAM_TROUBLESHOOTING_ID = "tId";
    private static final Map<String, Object> pathParams = Map.of(
            PATH_PARAM_ID, TestsUtility.getUuid(TestConstants.UUID_ASSIGNMENT_ISSUE_4),
            PATH_PARAM_TROUBLESHOOTING_ID, 1L);

    private static final  Map<String, Object> pathParamsRandom = Map.of(
            PATH_PARAM_ID, TestsUtility.getRandomUuid(),
            PATH_PARAM_TROUBLESHOOTING_ID, 1L);

    @Test
    @Order(1)
    void GivenRandomIssueIdAndTroubleshootingEntry_WhenAddTroubleshootingEntry_ThenThrowsApiBadRequestException() throws IOException {
        TroubleshootingEntry troubleshootingEntry = troubleshootingEntry();
        addTroubleshootingEntry(troubleshootingEntry);
    }

    @Test
    @Order(2)
    void GivenIssueIdAndTroubleshootingEntry_WhenAddTroubleshootingEntry_ThenReturnsResponseAccepted() throws IOException {
        TroubleshootingEntry troubleshootingEntry = troubleshootingEntry();

        given()
                .auth().preemptive().oauth2(TestsUtility.getToken())
                .pathParams(PATH_PARAM_ID, TestsUtility.getUuid(TestConstants.UUID_ASSIGNMENT_ISSUE_4))
                .body(troubleshootingEntry)
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                .header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON)
                .when().post(PATH_ROOT)
                .then().statusCode(Response.Status.ACCEPTED.getStatusCode());
    }

    @Test
    @Order(3)
    void GivenRandomIssueId_WhenGetTroubleshooting_ThenThrowsApiBadRequestException() {
        given()
                .auth().preemptive().oauth2(TestsUtility.getToken())
                .pathParams(PATH_PARAM_ID, TestsUtility.getRandomUuid())
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                .header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON)
                .when().get(PATH_ROOT)
                .then().assertThat();
    }

    @Test
    @Order(4)
    void GivenIssueId_WhenGetTroubleshooting_ThenReturnsResponseOk() {
        given()
                .auth().preemptive().oauth2(TestsUtility.getToken())
                .pathParams(PATH_PARAM_ID, TestsUtility.getUuid(TestConstants.UUID_ASSIGNMENT_ISSUE_4))
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                .header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON)
                .when().get(PATH_ROOT)
                .then().statusCode(Response.Status.OK.getStatusCode());
    }

    @Test
    @Order(5)
    void GivenRandomIssueIdAndTroubleshootingIdAndTroubleshootingEntry_WhenUpdateTroubleshooting_ThenThrowsApiBadRequestException() throws IOException {
        TroubleshootingEntry troubleshootingEntryToUpdate = troubleshootingEntryToUpdate();

        given()
                .auth().preemptive().oauth2(TestsUtility.getToken())
                .pathParams(pathParamsRandom)
                .body(troubleshootingEntryToUpdate)
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                .header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON)
                .when().put(PATH_ID)
                .then().assertThat();
    }

    @Test
    @Order(6)
    void GivenRandomIssueIdAndTroubleshootingIdAndTroubleshootingEntry_WhenUpdateTroubleshooting_ThenReturnsResponseAccepted() throws IOException {
        TroubleshootingEntry troubleshootingEntryToUpdate = troubleshootingEntryToUpdate();

        given()
                .auth().preemptive().oauth2(TestsUtility.getToken())
                .pathParams(pathParams)
                .body(troubleshootingEntryToUpdate)
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                .header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON)
                .when().put(PATH_ID)
                .then().statusCode(Response.Status.ACCEPTED.getStatusCode());
    }

    @Test
    @Order(7)
    void GivenRandomIssueIdAndTroubleshootingId_WhenDeleteTroubleshooting_ThenThrowsApiBadRequestException() {
        given()
                .auth().preemptive().oauth2(TestsUtility.getToken())
                .pathParams(pathParamsRandom)
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                .header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON)
                .when().delete(PATH_ID)
                .then().assertThat();
    }

    @Test
    @Order(8)
    void GivenRandomIssueIdAndTroubleshootingId_WhenDeleteTroubleshooting_ThenReturnsResponseOk() throws IOException {
        TroubleshootingEntry troubleshootingEntry = troubleshootingEntryResource();
        addTroubleshootingEntry(troubleshootingEntry);

        given()
                .auth().preemptive().oauth2(TestsUtility.getToken())
                .pathParams(PATH_PARAM_ID, TestsUtility.getUuid(TestConstants.UUID_ASSIGNMENT_ISSUE_4),
                        PATH_PARAM_TROUBLESHOOTING_ID, 2L)
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                .header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON)
                .when().delete(PATH_ID)
                .then().statusCode(Response.Status.OK.getStatusCode());
    }

    private void addTroubleshootingEntry(TroubleshootingEntry troubleshootingEntry){
        given()
                .auth().preemptive().oauth2(TestsUtility.getToken())
                .pathParams(PATH_PARAM_ID, TestsUtility.getRandomUuid())
                .body(troubleshootingEntry)
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                .header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON)
                .when().post(PATH_ROOT)
                .then().assertThat();
    }

}