package isom.appops.domain.services;

import static io.smallrye.common.constraint.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.*;

import isom.appops.database.entities.IssueEntity;
import isom.appops.domain.model.PageRequest;
import isom.appops.ticketentry.model.TicketEntry;
import isom.appops.quarkus.data.PagedResult;
import io.quarkus.test.junit.QuarkusTest;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import jakarta.inject.Inject;

import java.io.IOException;
import java.net.URISyntaxException;
import java.time.OffsetDateTime;
import java.util.UUID;

import isom.appops.quarkus.errorhandler.exception.ApiBadRequestException;

import isom.appops.domain.model.dto.IssueDTO;
import isom.appops.domain.utils.TestConstants;
import isom.appops.domain.utils.TestsUtility;
import isom.appops.domain.utils.JsonToObjectsCreator;

@QuarkusTest
class IssuesServiceTest extends JsonToObjectsCreator {

    @Inject
    IssuesService issuesService;

    @Test
    void GivenUuid_WhenGetIssueEntity_ThenReturnsIssueDTO(){
        UUID uuidIssue = TestsUtility.getUuid(TestConstants.UUID_ASSIGNMENT_ISSUE);
        IssueDTO issueDTO = issuesService.get(uuidIssue);
        assertNotNull(issueDTO);
        assertEquals(uuidIssue.toString(), issueDTO.getId().toString());
        assertEquals(TestConstants.TICKET_ID, issueDTO.getTicketId());
        assertEquals(TestConstants.CLIENT_ID, issueDTO.getClientId());
        assertEquals(TestConstants.ISSUE_TYPE, issueDTO.getIssueType());
        assertEquals(TestConstants.SEVERITY, issueDTO.getSeverity());
        assertEquals(TestConstants.CLASSIFICATION_ASIGNADA, issueDTO.getClassification());
    }

    @Test
    void GivenIssueDtoNotExists_WhenUpdateIssueDto_ThenThrowsApiBadRequestException() throws IOException {
        IssueDTO issueDTO = issueDtoNotExists();

        Exception exception = assertThrows(ApiBadRequestException.class, () ->
                issuesService.update(issueDTO)
        );

        String expectedMessage = TestConstants.ISSUE_NOT_FOUND;
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
    }

    @Test
    void GivenTickeEntry_WhenAddOrUpdateTicket_ThenReturnsIssueDto() throws IOException, URISyntaxException {
        TicketEntry ticketEntry = ticketEntryOk();
        IssueDTO issueDTO = issuesService.addOrUpdate(ticketEntry);
        assertNotNull(issueDTO);
    }

    @Test
    void GivenIssueDtoExists_WhenUpdateIssueDto_ThenReturnsIssueDto() throws IOException, URISyntaxException {
        UUID uuidIssue = TestsUtility.getUuid(TestConstants.UUID_ASSIGNMENT_ISSUE);
        IssueDTO issueDTO = issueDtoToUpdate();
        IssueDTO issueDtoUpdated = issuesService.update(issueDTO);

        assertNotNull(issueDtoUpdated);
        assertEquals(uuidIssue.toString(), issueDtoUpdated.getId().toString());
        assertEquals(TestConstants.GROUP_NAME, issueDtoUpdated.getGroupName());
        assertEquals(TestConstants.TICKET_ID, issueDtoUpdated.getTicketId());
        assertEquals(TestConstants.CLIENT_ID, issueDtoUpdated.getClientId());
        assertEquals(TestConstants.ISSUE_TYPE, issueDtoUpdated.getIssueType());
        assertNotEquals(TestConstants.SEVERITY, issueDtoUpdated.getSeverity());
        assertEquals(TestConstants.CLASSIFICATION_ASIGNADA, issueDtoUpdated.getClassification());
    }

    @Test
    void GivenPageRequest_WhenGetIssues_ThenReturnPageResult(){
        PageRequest page = new PageRequest();
        page.setSize(3);
        page.setPage(1);
        PagedResult<IssueDTO> pagedResult = issuesService.getIssues(page);
        Assertions.assertNotNull(pagedResult);
        assertEquals(3,pagedResult.getSize());

        IssueDTO issueDTO = pagedResult.getList().get(1);
        assertEquals(TestsUtility.getUuid(TestConstants.UUID_ASSIGNMENT_ISSUE_2), issueDTO.getId());
        assertEquals(TestConstants.TICKET_ID_2, issueDTO.getTicketId());
        assertEquals(TestConstants.CLIENT_ID, issueDTO.getClientId());
        assertEquals(TestConstants.GROUP_NAME, issueDTO.getGroupName());
        assertEquals(TestConstants.ISSUE_TYPE, issueDTO.getIssueType());
        assertEquals(TestConstants.SEVERITY, issueDTO.getSeverity());
    }

    @Test
    void GivenUuidIdAndNewGroupName_WhenUpdateIssueGroupName_ThenReturnsIssueEntityWithGroupNameUpdated() {
        UUID uuidIssue = TestsUtility.getUuid(TestConstants.UUID_ASSIGNMENT_ISSUE);
        IssueEntity issueEntity = issuesService.updateIssueGroupName(uuidIssue, TestConstants.NEW_GROUP_NAME);

        assertNotNull(issueEntity);
        assertEquals(uuidIssue.toString(), issueEntity.getId().toString());
        assertEquals(TestConstants.NEW_GROUP_NAME, issueEntity.getGroupName());
        assertNotEquals(TestConstants.GROUP_NAME, issueEntity.getGroupName());
    }

    @Test
    void GivenUuidIdAndNewResolutionDate_WhenUpdateResolutionDate_ThenReturnsIssueEntityWithResolutionDateUpdated() {
        UUID uuidIssue = TestsUtility.getUuid(TestConstants.UUID_ASSIGNMENT_ISSUE);
        OffsetDateTime offsetDateTime = TestsUtility.getOffsetDateTimeNow();
        IssueEntity issueEntity = issuesService.updateResolutionDate(uuidIssue, offsetDateTime);

        assertNotNull(issueEntity);
        assertEquals(uuidIssue.toString(), issueEntity.getId().toString());
        assertEquals(offsetDateTime, issueEntity.getResolutionDate());
        assertNotEquals(TestsUtility.parseDateTimeString(TestConstants.RESOLUTION_DATE), issueEntity.getResolutionDate());
    }

}