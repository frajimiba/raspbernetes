package isom.appops.domain.utils;

import java.util.Arrays;
import java.util.List;

public class TestConstants {
    private TestConstants(){}
    public static final String EMPTY = "";
    public static final String CONST_STRING = "String";
    public static final String IS_NULL = "is null";
    public static final String ISSUE_NOT_FOUND = "Issue not found";
    public static final String INVALID_TRANSLATION = "Invalid translation";
    public static final String UUID_ASSIGNMENT_ISSUE = "54b2745c-52e8-38c4-a8d2-53883f9b3af1";
    public static final String UUID_ASSIGNMENT_ISSUE_2 = "fc7b9ae3-fad0-43d5-bcc2-305932cb98ef";
    public static final String UUID_ASSIGNMENT_ISSUE_3 = "43b283f5-0c85-4e35-b73d-78542a191a30";
    public static final String UUID_ASSIGNMENT_ISSUE_4 = "4004729e-81be-45dd-afcb-b4ca42b253da";
    public static final String USERNAME = "eaguirre";
    public static final String GROUP_NAME = "Tecnología";
    public static final String NEW_GROUP_NAME = "APL_MOV_CERES";
    public static final String TEXT = "Estos es una prueba";
    public static final String TEXT_2 = "Esto es otra prueba";
    public static final String TICKET_ID = "54b2745c-52e8-38c4-a8d2-53883f9b3af1";
    public static final String TICKET_ID_2 = "cf1d8b4e-e4dd-4b90-8df2-dee2da488242";
    public static final String TICKET_ID_3 = "6fd710af-74a7-4faa-8090-af7b4a2e2854";
    public static final String CLIENT_ID = "VIEWNEXT_TORRE_DE_CONTROL";
    public static final String ISSUE_TYPE = "Incident";
    public static final String SEVERITY = "Low";
    public static final String SPECIAL_FLAG = "OFF";
    public static final String CLASSIFICATION_ASIGNADA = "Asignada";
    public static final String CLASSIFICATION_DEMO = "DEMO_CLASSIFICATION";
    public static final String RESOLUTION_DATE = "2023-05-20T12:30:44.496Z";
    public static final String STATUS_UNASSIGNED = "Unassigned";
    public static final String STATUS_ASSIGNED = "Assigned";
    public static final String STATUS_ASIGNADA = "Asignada";
    public static final String STATUS_RESOLVED = "Resolved";
    public static final String PROCEDURE_TITLE = "Prueba2";
    public static final String PROCEDURE_DESCRIPTION = "<p>Estos es una prueba</p>";
    public static final String CONFIG_FILE_ENV_DEV = "DEV";
    public static final String CONFIG_FILE_PATH = "awxhelloworld-job-config";
    public static final String CONFIG_FILE_VERSION = "https://semver.org/lang/es/";
    public static final String PARAMETER_EXECUTION = "traceId";
    public static final String PROCEDURE_TITLE_UPDATED = "Prueba3";
    public static final String PROCEDURE_DESCRIP_UPDATED = "<p>Esto es una prueba</p>";
    public static final String CLASSIFICATION_OTHER_UPDATED = "OTHER_CLASSIFICATION";
    public static final String EXECUTION_URL_JOB = "http://localhost:4200/procedures/register";
    public static final List<String> PARAMETERS_LIST = Arrays.asList("demo=123", "traceId=122123434", "prueba");
    public static final List<String> STATUS_LIST = Arrays.asList("Unassigned", "Assigned", "Resolved", "Pending", "In Progress");
    public static final List<String> USER_ID_LIST = Arrays.asList("eaguirre", "admin001", "dnowends", "ftr001", "operador001");
    public static final List<String> USER_ID_LIST_2 = Arrays.asList("ticket-ingestor", "admin", "sre", "ftr", "operador");
    public static final String PAGE_REQUEST = "PageRequest";
    public static final String DATE_TIME_STRING = "2023-04-21T10:15:50-04:00";
    public static final String TIME_STRING = "10:15:50-04:00";
    public static final String JOB_NAME = "jobName";
    public static final String FEEBACK_COMMENT = "Está muy bien";
}

