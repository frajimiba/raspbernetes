package isom.appops.domain.model.entries;

import static org.junit.jupiter.api.Assertions.*;

import io.quarkus.test.junit.QuarkusTest;
import isom.appops.domain.utils.JsonToObjectsCreator;
import isom.appops.domain.utils.TestConstants;
import org.junit.jupiter.api.Test;

import java.io.IOException;

@QuarkusTest
class ManualClassificationEntryTest extends JsonToObjectsCreator {

    @Test
    void testEquals() throws IOException {
        AssignmentEntry assignmentEntry = assignmentEntry();
        ManualClassificationEntry manualClassificationEntry = new ManualClassificationEntry(
                TestConstants.CLASSIFICATION_DEMO, TestConstants.USERNAME);
        assertFalse(notEquals(manualClassificationEntry, assignmentEntry));
        assertEquals(manualClassificationEntry, manualClassificationEntry);
        assertEquals(TestConstants.CLASSIFICATION_DEMO, manualClassificationEntry.getClassification());
        assertEquals(TestConstants.USERNAME, manualClassificationEntry.getUserName());
    }

    @Test
    void testHashCode() {
        ManualClassificationEntry manualClassificationEntry = new ManualClassificationEntry(
                TestConstants.CLASSIFICATION_DEMO, TestConstants.USERNAME);
        ManualClassificationEntry manualClassificationEntry2 = new ManualClassificationEntry();
        manualClassificationEntry2.classification(TestConstants.CLASSIFICATION_DEMO);
        manualClassificationEntry2.userName(TestConstants.USERNAME);
        assertTrue(equals(manualClassificationEntry, manualClassificationEntry2));
        assertEquals(manualClassificationEntry.hashCode(), manualClassificationEntry2.hashCode());
    }

    @Test
    void testToString() {
        ManualClassificationEntry manualClassificationEntry = new ManualClassificationEntry(
                TestConstants.CLASSIFICATION_DEMO, TestConstants.USERNAME);
        ManualClassificationEntry manualClassificationEntry2 = new ManualClassificationEntry();
        manualClassificationEntry2.setClassification(TestConstants.CLASSIFICATION_DEMO);
        manualClassificationEntry2.setUserName(TestConstants.USERNAME);
        assertEquals(manualClassificationEntry.toString(), manualClassificationEntry2.toString());
    }

    private boolean notEquals(ManualClassificationEntry manualClassificationEntry, AssignmentEntry assignmentEntry) {
        return manualClassificationEntry.equals(assignmentEntry);
    }

    private boolean equals(ManualClassificationEntry manualClassificationEntry, ManualClassificationEntry manualClassificationEntry2) {
        return manualClassificationEntry.equals(manualClassificationEntry2) &&
                manualClassificationEntry.getClassification().equals(manualClassificationEntry2.getClassification()) &&
                manualClassificationEntry.getUserName().equals(manualClassificationEntry2.getUserName());
    }
}