package isom.appops.domain.services;

import static io.smallrye.common.constraint.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import io.quarkus.test.junit.QuarkusTest;
import isom.appops.domain.model.dto.TroubleshootingDTO;
import isom.appops.domain.model.entries.TroubleshootingEntry;
import isom.appops.domain.utils.JsonToObjectsCreator;
import isom.appops.domain.utils.TestConstants;
import isom.appops.domain.utils.TestsUtility;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;

import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

import org.junit.jupiter.api.TestMethodOrder;

@QuarkusTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class TroubleshootingServiceTest extends JsonToObjectsCreator {

    @Inject
    TroubleshootingService troubleshootingService;

    @Test
    @Order(1)
    void GivenUuidIssueAndTroubleshootingEntry_WhenAddTroubleshootingIntoIssue_ThenReturnsTroubleshootingDTO() throws IOException {
        UUID uuidIssue = TestsUtility.getUuid(TestConstants.UUID_ASSIGNMENT_ISSUE);
        TroubleshootingEntry troubleshootingEntry = troubleshootingEntry();
        TroubleshootingDTO troubleshootingDTO = troubleshootingService.add(uuidIssue, troubleshootingEntry);
        assertNotNull(troubleshootingDTO);
        assertEquals(TestConstants.TEXT_2, troubleshootingDTO.getContent());
    }
    @Test
    @Order(2)
    void GivenUuidIssue_WhenGetTroublesshootings_ThenReturnsListTroubleshootingDto(){
        UUID uuidIssue = TestsUtility.getUuid(TestConstants.UUID_ASSIGNMENT_ISSUE);
        List<TroubleshootingDTO> troubleshootingDtoList = troubleshootingService.getTroubleshootings(uuidIssue);
        assertNotNull(troubleshootingDtoList);
        TroubleshootingDTO troubleshootingDTO = troubleshootingDtoList.get(0);
        assertEquals(1, troubleshootingDtoList.size());
        assertEquals(2L, troubleshootingDTO.getId());
        assertEquals(TestConstants.TEXT_2, troubleshootingDTO.getContent());
        assertEquals(TestConstants.UUID_ASSIGNMENT_ISSUE, troubleshootingDTO.getIssueId().toString());
    }

    @Test
    @Order(3)
    void GivenTroubleshootingId_WhenUpdateTroubleshooting_ThenReturnsTroubleshootingDTO() throws IOException {
        TroubleshootingEntry troubleshootingEntryToUpdate = troubleshootingEntryToUpdate();
        TroubleshootingDTO troubleshootingDTO = troubleshootingService.update(1L, troubleshootingEntryToUpdate);
        assertNotNull(troubleshootingDTO);
        assertNotEquals(TestConstants.TEXT_2, troubleshootingDTO.getContent());
        assertEquals(TestConstants.TEXT, troubleshootingDTO.getContent());
    }

    @Test
    @Transactional
    @Order(4)
    void GivenTroubleshootingId_WhenDeleteTroubleshooting_ThenTroubleshootingDeleted() throws IOException {
        TroubleshootingEntry troubleshootingEntry = troubleshootingEntry();
        troubleshootingService.delete(1L);
        assertNotNull(troubleshootingEntry);
    }
}