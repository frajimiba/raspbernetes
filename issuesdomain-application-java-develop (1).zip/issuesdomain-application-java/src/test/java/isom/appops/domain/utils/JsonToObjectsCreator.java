package isom.appops.domain.utils;

import isom.appops.database.entities.*;
import isom.appops.database.entities.AssignamentEntity;
import isom.appops.database.entities.ExecutionEntity;
import isom.appops.database.entities.FeedbackEntity;
import isom.appops.database.entities.IssueEntity;
import isom.appops.domain.model.IssueTranslations;
import isom.appops.domain.model.Translations;
import isom.appops.domain.model.dto.IssueDTO;
import isom.appops.domain.model.dto.ManualClassificationDTO;
import isom.appops.domain.model.dto.ProcedureDTO;
import isom.appops.domain.model.entries.*;
import isom.appops.domain.model.entries.*;
import isom.appops.domain.model.events.NotificationEventData;
import isom.appops.ticketentry.model.TicketEntry;
import isom.appops.ticketentry.model.TicketHeader;
import isom.appops.openapi_ticketdetails.model.TicketDTO;

import java.io.IOException;

public class JsonToObjectsCreator extends BaseJsonToObjectsCreator {

    public AssignamentEntity assigmentEntity() throws IOException {
        return getObjectFromFile("/json/assigmentEntity/assigmentEntity.json", AssignamentEntity.class);
    }

    public AssignamentEntity assigmentEntity2() throws IOException {
        return getObjectFromFile("/json/assigmentEntity/assigmentEntity2.json", AssignamentEntity.class);
    }

    public AssignamentEntity assigmentEntity3() throws IOException {
        return getObjectFromFile("/json/assigmentEntity/assigmentEntity3.json", AssignamentEntity.class);
    }

    public AssignamentEntity assigmentEntity4() throws IOException {
        return getObjectFromFile("/json/assigmentEntity/assigmentEntity4.json", AssignamentEntity.class);
    }

    public AssignmentEntry assignmentEntry() throws IOException {
        return getObjectFromFile("/json/assignmentEntry/assignmentEntry.json", AssignmentEntry.class);
    }

    public AssignmentEntry assignmentEntryNotUsername() throws IOException {
        return getObjectFromFile("/json/assignmentEntry/assignmentEntryNotUsername.json", AssignmentEntry.class);
    }

    public AutomaticClassificationEntry automaticClassificationEntry() throws IOException {
        return getObjectFromFile("/json/automaticClassificationEntry/automaticClassificationEntry.json", AutomaticClassificationEntry.class);
    }

    public IssueDTO issueDtoNotExists() throws IOException {
        return getObjectFromFile("/json/issueDTO/issueDtoNotExists.json", IssueDTO.class);
    }

    public IssueDTO issueDtoToUpdate() throws IOException {
        return getObjectFromFile("/json/issueDTO/issueDtoToUpdate.json", IssueDTO.class);
    }

    public IssueDTO issueDtoToUpdateResource() throws IOException {
        return getObjectFromFile("/json/issueDTO/issueDtoToUpdateResource.json", IssueDTO.class);
    }

    public TicketEntry ticketEntryOk() throws IOException {
        return getObjectFromFile("/json/ticketEntry/ticketEntryOk.json", TicketEntry.class);
    }

    public TicketEntry ticketEntryStatusIsNull() throws IOException {
        return getObjectFromFile("/json/ticketEntry/ticketEntryStatusIsNull.json", TicketEntry.class);
    }

    public TicketEntry ticketEntryStatusKO() throws IOException {
        return getObjectFromFile("/json/ticketEntry/ticketEntryStatusKO.json", TicketEntry.class);
    }

    public TicketEntry ticketEntryWithoutHeader() throws IOException {
        return getObjectFromFile("/json/ticketEntry/ticketEntryWithoutHeader.json", TicketEntry.class);
    }

    public ManualClassificationEntry manualClassificationEntry() throws IOException {
        return getObjectFromFile("/json/manualClassificationEntry/manualClassificationEntry.json", ManualClassificationEntry.class);
    }

    public ManualClassificationDTO manualClassificationDTO() throws IOException {
        return getObjectFromFile("/json/manualClassificationDTO/manualClassificationDTO.json", ManualClassificationDTO.class);
    }

    public TicketDTO ticketDTO() throws IOException {
        return getObjectFromFile("/json/ticketDTO/ticketDTO.json", TicketDTO.class);
    }

    public TicketHeader ticketHeaderNoIssueType() throws IOException {
        return getObjectFromFile("/json/ticketHeader/ticketHeaderNoIssueType.json", TicketHeader.class);
    }

    public TicketHeader ticketHeaderNoSeverity() throws IOException {
        return getObjectFromFile("/json/ticketHeader/ticketHeaderNoSeverity.json", TicketHeader.class);
    }

    public TicketHeader ticketHeaderNoSpecialFlag() throws IOException {
        return getObjectFromFile("/json/ticketHeader/ticketHeaderNoSpecialFlag.json", TicketHeader.class);
    }

    public IssueEntity issueEntity() throws IOException {
        return getObjectFromFile("/json/issueEntity/issueEntity.json", IssueEntity.class);
    }

    public TroubleshootingEntry troubleshootingEntry() throws IOException {
        return getObjectFromFile("/json/troubleshootingEntry/troubleshootingEntry.json", TroubleshootingEntry.class);
    }

    public TroubleshootingEntry troubleshootingEntryResource() throws IOException {
        return getObjectFromFile("/json/troubleshootingEntry/troubleshootingEntryResource.json", TroubleshootingEntry.class);
    }

    public TroubleshootingEntry troubleshootingEntryToUpdate() throws IOException {
        return getObjectFromFile("/json/troubleshootingEntry/troubleshootingEntryToUpdate.json", TroubleshootingEntry.class);
    }

    public ProcedureEntry procedureEntry() throws IOException {
        return getObjectFromFile("/json/procedureEntry/procedureEntry.json", ProcedureEntry.class);
    }

    public ProcedureEntry procedureEntry2() throws IOException {
        return getObjectFromFile("/json/procedureEntry/procedureEntry2.json", ProcedureEntry.class);
    }

    public ProcedureEntry procedureEntryToUpdate() throws IOException {
        return getObjectFromFile("/json/procedureEntry/procedureEntryToUpdate.json", ProcedureEntry.class);
    }

    public ProcedureDTO procedureDtoNotAutomatic() throws IOException {
        return getObjectFromFile("/json/procedureDTO/procedureDtoNotAutomatic.json", ProcedureDTO.class);
    }

    public ProcedureDTO procedureDtoIsAutomatic() throws IOException {
        return getObjectFromFile("/json/procedureDTO/procedureDtoIsAutomatic.json", ProcedureDTO.class);
    }

    public ProcedureDTO procedureDtoIsAutomaticNoType() throws IOException {
        return getObjectFromFile("/json/procedureDTO/procedureDtoIsAutomaticNoType.json", ProcedureDTO.class);
    }

    public ExecutionEntity executionEntity() throws IOException {
        return getObjectFromFile("/json/executionEntity/executionEntity.json", ExecutionEntity.class);
    }

    public ExecutionEntry executionEntry() throws IOException {
        return getObjectFromFile("/json/executionEntry/executionEntry.json", ExecutionEntry.class);
    }

    public ExecutionEntry executionEntryProcedure() throws IOException {
        return getObjectFromFile("/json/executionEntry/executionEntryProcedure.json", ExecutionEntry.class);
    }

    public FeedbackEntry feedbackEntry() throws IOException {
        return getObjectFromFile("/json/feedbackEntry/feedbackEntry.json", FeedbackEntry.class);
    }

    public FeedbackEntry feedbackEntryToUpdate() throws IOException {
        return getObjectFromFile("/json/feedbackEntry/feedbackEntryToUpdate.json", FeedbackEntry.class);
    }

    public FeedbackEntity feedbackEntity() throws IOException {
        return getObjectFromFile("/json/feedbackEntity/feedbackEntity.json", FeedbackEntity.class);
    }

    public ProceduresByClassificationsEntry proceduresByClassificationsEntry() throws IOException {
        return getObjectFromFile("/json/proceduresByClassificationsEntry/proceduresByClassificationsEntry.json", ProceduresByClassificationsEntry.class);
    }

    public FullIssueEntry fullIssueEntry() throws IOException {
        return getObjectFromFile("/json/fullIssueEntry/fullIssueEntry.json", FullIssueEntry.class);
    }

    public String getStringTranslations() throws IOException {
        return getStringFromFile("/json/translations/translations.json");
    }

    public Translations getTranslations() throws IOException {
        return getObjectFromFile("/json/translations/translations.json", Translations.class);
    }

    public IssueTranslations issueTranslations() throws IOException {
        return getObjectFromFile("/json/issueTranslations/issueTranslations.json", IssueTranslations.class);
    }

    public NotificationEventData notificationEventData() throws IOException {
        return getObjectFromFile("/json/notificationEventData/notificationEventData.json", NotificationEventData.class);
    }
}
