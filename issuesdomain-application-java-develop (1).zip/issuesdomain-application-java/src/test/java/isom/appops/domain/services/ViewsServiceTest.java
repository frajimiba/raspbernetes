package isom.appops.domain.services;

import static io.smallrye.common.constraint.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import io.quarkus.test.junit.QuarkusTest;
import isom.appops.domain.model.PageRequest;
import isom.appops.domain.model.dto.ExecutionDTO;
import isom.appops.domain.model.dto.FullIssueViewDTO;
import isom.appops.domain.model.dto.ProcedureDTO;
import isom.appops.domain.model.dto.ProcedureRatingDTO;
import isom.appops.domain.utils.TestConstants;
import isom.appops.domain.utils.TestsUtility;
import org.junit.jupiter.api.Test;

import jakarta.inject.Inject;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import isom.appops.quarkus.data.PagedResult;

@QuarkusTest
class ViewsServiceTest {

    @Inject
    ViewsService viewsService;

//    @Test
    void GivenUserIdListAndStatusList_WhenGetAmountIssuesAssignedToUsers_ThenReturnsTheAmount(){
        System.out.println(TestConstants.USER_ID_LIST_2);
        List<String> userIdList = TestConstants.USER_ID_LIST;
        List<String> statusList = TestConstants.STATUS_LIST;
        Long amount = viewsService.getAmountIssuesAssignedToUsers(userIdList, statusList);
        assertNotNull(amount);
    }

    @Test
    void GivenClassificationsListAndPageRequest_WhenGetProceduresByClassifications_ThenReturnsPageResultOfProcedureDto(){
        List<String> listClassifications = Arrays.asList("DEMO_CLASSIFICATION");
        PageRequest pageRequest = new PageRequest();
        pageRequest.setSize(2);
        pageRequest.setPage(1);
        PagedResult<ProcedureDTO> pageResult = viewsService.getProceduresByClassifications(listClassifications, pageRequest);
        assertNotNull(pageResult);
        assertEquals(2, pageResult.getSize());
        assertEquals(1, pageResult.getPage());
    }

    @Test
    void GivenClassificationsListAndPageRequest_WhenGetProceduresByClassificationsWithRating_ThenReturnsPageResultOfProcedureDTO(){
        List<String> listClassifications = Arrays.asList("DEMO_CLASSIFICATION");
        PageRequest pageRequest = new PageRequest();
        pageRequest.setSize(2);
        pageRequest.setPage(1);
        PagedResult<ProcedureRatingDTO> pageResult = viewsService.getProceduresByClassificationsWithRating(listClassifications, pageRequest);
        assertNotNull(pageResult);
        assertEquals(2, pageResult.getSize());
        assertEquals(1, pageResult.getPage());
    }

    @Test
    void GivenUuidIssueAndPageRequest_WhenGetExecutionsByIssueId_ThenReturnsPageResultOfProcedureDTO(){
        UUID uuidIssue = TestsUtility.getUuid(TestConstants.UUID_ASSIGNMENT_ISSUE);
        PageRequest pageRequest = new PageRequest();
        pageRequest.setSize(2);
        pageRequest.setPage(1);
        PagedResult<ExecutionDTO> pageResult = viewsService.getExecutionsByIssueId(uuidIssue, pageRequest);
        assertNotNull(pageResult);
        assertEquals(2, pageResult.getSize());
        assertEquals(1, pageResult.getPage());
    }

//    @Test
    void GivenUuidIssue_WhenGetFullIsue_ThenReturnsFullIssueViewDto(){
        UUID uuidIssue = TestsUtility.getUuid(TestConstants.UUID_ASSIGNMENT_ISSUE);
        FullIssueViewDTO fullIssueViewDTO = viewsService.getFullIssue(uuidIssue);
        assertNotNull(fullIssueViewDTO);
    }

//    @Test
    void GivenClassification_WhenGetProcedureByClassification_ThenReturnsProcedureDTO(){
        ProcedureDTO procedureDTO = viewsService.getProcedureByClassification("DEMO_CLASSIFICATION");
        assertNotNull(procedureDTO);
    }
}