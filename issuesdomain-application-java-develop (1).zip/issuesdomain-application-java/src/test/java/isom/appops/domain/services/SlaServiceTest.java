package isom.appops.domain.services;

import static org.junit.jupiter.api.Assertions.*;

import io.quarkus.test.junit.QuarkusTest;
import isom.appops.domain.model.dto.IssueDTO;
import isom.appops.domain.utils.TestConstants;
import isom.appops.domain.utils.TestsUtility;
import org.junit.jupiter.api.Test;

import jakarta.inject.Inject;
import java.time.OffsetDateTime;
import java.util.UUID;

import isom.appops.quarkus.errorhandler.exception.ApiBadRequestException;

@QuarkusTest
class SlaServiceTest {

    @Inject
    SlaService slaService;

    @Test
    void GivenUuidIssueRandomAndOffsetDateTimeNow_WhenSetSlaBreachTime_ThenThrowsApiBadRequestException() {
        UUID randomUuid = TestsUtility.getRandomUuid();
        OffsetDateTime now = TestsUtility.getOffsetDateTimeNow();

        Exception exception = assertThrows(ApiBadRequestException.class, () ->
                slaService.setSlaBreachTime(randomUuid, now)
        );

        String expectedMessage = TestConstants.ISSUE_NOT_FOUND;
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
    }

    @Test
    void GivenUuidIssueAndOffsetDateTimeNow_WhenSetSlaBreachTime_ThenReturnsIssueDto(){
        UUID uuidIssue = TestsUtility.getUuid(TestConstants.UUID_ASSIGNMENT_ISSUE);
        OffsetDateTime now = TestsUtility.getOffsetDateTimeNow();
        IssueDTO issueDTO = slaService.setSlaBreachTime(uuidIssue, now);
        assertNotNull(issueDTO);
    }

}