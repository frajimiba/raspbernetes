package isom.appops.domain.model.entries;

import static io.smallrye.common.constraint.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import io.quarkus.test.junit.QuarkusTest;
import isom.appops.domain.utils.TestConstants;
import org.junit.jupiter.api.Test;

import java.util.List;

@QuarkusTest
class IssuesAssignedToUsersEntryTest {

    @Test
    void GivenIssuesAssignedToUsersEntry_WhenSetAttributesPageRequest_ThenReturnsAttributes() {
        List<String> userIdList = TestConstants.USER_ID_LIST;
        IssuesAssignedToUsersEntry issuesAssignedToUsersEntry = new IssuesAssignedToUsersEntry(userIdList);
        assertNotNull(issuesAssignedToUsersEntry);
        assertEquals(5, issuesAssignedToUsersEntry.getUserIds().size());
        assertEquals(TestConstants.USERNAME, issuesAssignedToUsersEntry.getUserIds().get(0));

        IssuesAssignedToUsersEntry issuesAssignedToUsersEntry2 = new IssuesAssignedToUsersEntry();
        issuesAssignedToUsersEntry2.setUserIds(userIdList);
        assertNotNull(issuesAssignedToUsersEntry2);
        assertEquals(5, issuesAssignedToUsersEntry2.getUserIds().size());
        assertEquals(TestConstants.USERNAME, issuesAssignedToUsersEntry2.getUserIds().get(0));
    }

}