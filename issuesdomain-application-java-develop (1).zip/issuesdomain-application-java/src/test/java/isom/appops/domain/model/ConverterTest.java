package isom.appops.domain.model;

import static io.smallrye.common.constraint.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import io.quarkus.test.junit.QuarkusTest;
import isom.appops.domain.utils.JsonToObjectsCreator;
import isom.appops.domain.utils.TestConstants;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.OffsetDateTime;
import java.time.OffsetTime;

@QuarkusTest
class ConverterTest extends JsonToObjectsCreator {

    private static final LocalDateTime localDateTime = LocalDateTime.of(2023, Month.APRIL, 21, 14,15);

    @Test
    void GivenStringDateTime_WhenParse_ThenReturnOffsetDateTime(){

        OffsetDateTime offsetDateTime = Converter.parseDateTimeString(TestConstants.DATE_TIME_STRING);
        assertNotNull(offsetDateTime);
        assertEquals(localDateTime.getYear(), offsetDateTime.getYear());
        assertEquals(localDateTime.getMonth(), offsetDateTime.getMonth());
        assertEquals(localDateTime.getDayOfMonth(), offsetDateTime.getDayOfMonth());
        assertEquals(localDateTime.getHour(), offsetDateTime.getHour());
        assertEquals(localDateTime.getMinute(), offsetDateTime.getMinute());
    }

    @Test
    void GivenStringDateTime_WhenParse_ThenReturnOffsetTime(){
        OffsetTime offsetTime = Converter.parseTimeString(TestConstants.TIME_STRING);
        assertNotNull(offsetTime);
        assertEquals(localDateTime.getHour(), offsetTime.getHour());
        assertEquals(localDateTime.getMinute(), offsetTime.getMinute());
    }

    @Test
    void GivenString_WhenParseFromStringToJson_ThenReturnTranslations() throws IOException {
        String stringJson = getStringTranslations();
        Translations translations = Converter.fromJsonString(stringJson);
        assertNotNull(translations);
    }

//    @Test
    void GivenTranslationsObject_WhenParseObjectToString_ThenReturnJsonString() throws IOException {
        Translations translations = getTranslations();
        String jsonString = Converter.toJsonString(translations);
        assertNotNull(jsonString);
    }

}