package isom.appops.domain.resource;

import static io.restassured.RestAssured.given;

import isom.appops.domain.model.dto.IssueDTO;
import io.quarkus.test.junit.QuarkusTest;
import org.junit.jupiter.api.Test;

import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import isom.appops.domain.utils.JsonToObjectsCreator;
import isom.appops.domain.utils.TestConstants;
import isom.appops.domain.utils.TestsUtility;

import isom.appops.ticketentry.model.TicketEntry;

@QuarkusTest
class IssuesResourceIntegrationTest extends JsonToObjectsCreator {

    private static final String PATH_ROOT = "/issues/";
    private static final String PATH_ISSUE_INFO = "/issues/{id}";
    private static final String PATH_INSERT_OR_UPDATE_TICKET = "/issues/issue";
    private static final String PATH_EXECUTION_BY_ISSUE = "/issues/{id}/executions";
    private static final String PATH_AMOUNT_USER_ISSUES = "/issues/amount/assigned-user";
    private static final String PATH_PARAM_ID = "id";
    private static final String PAGE_REQUEST = "PageRequest";
    private static final Map<String, UUID> pathParams = Map.of(PATH_PARAM_ID, TestsUtility.getUuid(TestConstants.UUID_ASSIGNMENT_ISSUE_4));

    @Test
    void GivenUuidIssue_WhenGetIssueInfo_ThenReturnStatusOk() {
        given()
                .auth().preemptive().oauth2(TestsUtility.getToken())
                .pathParams(pathParams)
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                .header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON)
                .when().get(PATH_ISSUE_INFO)
                .then().statusCode(Response.Status.OK.getStatusCode());
    }

    @Test
    void GivenTicketEntryWithoutHeader_WhenInsertTicketEntry_ThenThrowsApiBadRequestException() throws IOException {
        TicketEntry ticketEntryWithoutHeader = ticketEntryWithoutHeader();

        given()
                .auth().preemptive().oauth2(TestsUtility.getToken())
                .body(ticketEntryWithoutHeader)
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                .header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON)
                .when().post(PATH_INSERT_OR_UPDATE_TICKET)
                .then().assertThat();
    }

    @Test
    void GivenTicketEntryOk_WhenInsertTicketEntry_ThenReturnsCreated() throws IOException {
        TicketEntry ticketEntryOk = ticketEntryOk();

        given()
                .auth().preemptive().oauth2(TestsUtility.getToken())
                .body(ticketEntryOk)
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                .header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON)
                .when().post(PATH_INSERT_OR_UPDATE_TICKET)
                .then().statusCode(Response.Status.CREATED.getStatusCode());
    }

    @Test
    void GivenIssueDTO_WhenUpdateTicketEntry_ThenReturnsAccepted() throws IOException {
        IssueDTO issueDtoToUpdate = issueDtoToUpdateResource();

        given()
                .auth().preemptive().oauth2(TestsUtility.getToken())
                .body(issueDtoToUpdate)
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                .header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON)
                .when().put(PATH_INSERT_OR_UPDATE_TICKET)
                .then().statusCode(Response.Status.ACCEPTED.getStatusCode());
    }

    @Test
    void GivenPageRequest_WhenGetIssues_ThenReturnsOk() {
        given()
                .auth().preemptive().oauth2(TestsUtility.getToken())
                .queryParams(TestsUtility.getPageRequestMap())
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                .header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON)
                .when().get(PATH_ROOT)
                .then().statusCode(Response.Status.OK.getStatusCode());
    }

    @Test
    void GivenUuidIssue_WhenGetExecutionsByIssueId_ThenReturnsOk() {
        given()
                .auth().preemptive().oauth2(TestsUtility.getToken())
                .pathParams(pathParams)
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                .header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON)
                .when().get(PATH_EXECUTION_BY_ISSUE)
                .then().statusCode(Response.Status.OK.getStatusCode());
    }

    @Test
    void GivenStatusList_WhenGetAmountUserIssues_ThenReturnsOk() {
        List<String> statusList = TestConstants.STATUS_LIST;

        given()
                .auth().preemptive().oauth2(TestsUtility.getToken())
                .body(statusList)
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                .header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON)
                .when().post(PATH_AMOUNT_USER_ISSUES)
                .then().assertThat();
    }
}