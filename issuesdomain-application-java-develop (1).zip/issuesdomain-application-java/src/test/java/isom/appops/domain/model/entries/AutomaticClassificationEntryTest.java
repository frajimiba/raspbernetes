package isom.appops.domain.model.entries;

import static org.junit.jupiter.api.Assertions.*;

import io.quarkus.test.junit.QuarkusTest;
import isom.appops.domain.utils.JsonToObjectsCreator;
import isom.appops.domain.utils.TestConstants;
import org.junit.jupiter.api.Test;

import java.io.IOException;

@QuarkusTest
class AutomaticClassificationEntryTest extends JsonToObjectsCreator {

    @Test
    void testEquals() throws IOException {
        AssignmentEntry assignmentEntry = assignmentEntry();
        AutomaticClassificationEntry automaticClassificationEntry = automaticClassificationEntry();
        assertFalse(notEquals(automaticClassificationEntry, assignmentEntry));
        assertEquals(automaticClassificationEntry, automaticClassificationEntry);
        assertEquals(TestConstants.STATUS_ASIGNADA, automaticClassificationEntry.getClassification());
    }

    @Test
    void testHashCode() {
        AutomaticClassificationEntry automaticClassificationEntry = new AutomaticClassificationEntry(TestConstants.CLASSIFICATION_DEMO);
        AutomaticClassificationEntry automaticClassificationEntry2 = new AutomaticClassificationEntry();
        automaticClassificationEntry2.classification(TestConstants.CLASSIFICATION_DEMO);
        assertTrue(equals(automaticClassificationEntry, automaticClassificationEntry2));
        assertEquals(automaticClassificationEntry.hashCode(), automaticClassificationEntry2.hashCode());
    }

    @Test
    void testToString() {
        AutomaticClassificationEntry automaticClassificationEntry = new AutomaticClassificationEntry(TestConstants.CLASSIFICATION_DEMO);
        AutomaticClassificationEntry automaticClassificationEntry2 = new AutomaticClassificationEntry();
        automaticClassificationEntry2.setClassification(TestConstants.CLASSIFICATION_DEMO);
        assertEquals(automaticClassificationEntry.toString(), automaticClassificationEntry2.toString());
    }

    private boolean notEquals(AutomaticClassificationEntry automaticClassificationEntry, AssignmentEntry assignmentEntry) {
        return automaticClassificationEntry.equals(assignmentEntry);
    }

    private boolean equals(AutomaticClassificationEntry automaticClassificationEntry, AutomaticClassificationEntry automaticClassificationEntry2) {
        return automaticClassificationEntry.equals(automaticClassificationEntry2) &&
                automaticClassificationEntry.getClassification().equals(automaticClassificationEntry2.getClassification());
    }
}