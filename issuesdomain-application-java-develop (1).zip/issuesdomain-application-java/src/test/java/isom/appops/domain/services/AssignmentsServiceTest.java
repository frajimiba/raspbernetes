package isom.appops.domain.services;

import io.quarkus.test.junit.QuarkusTest;

import isom.appops.database.entities.AssignamentEntity;
import isom.appops.database.repository.AssignamentEntityRepository;
import isom.appops.domain.model.dto.AssignamentDTO;
import isom.appops.domain.model.entries.AssignmentEntry;
import isom.appops.domain.utils.JsonToObjectsCreator;
import isom.appops.domain.utils.TestConstants;
import isom.appops.domain.utils.TestsUtilMethods;
import isom.appops.domain.utils.TestsUtility;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

import isom.appops.quarkus.errorhandler.exception.ApiBadRequestException;

import static org.junit.jupiter.api.Assertions.*;

@QuarkusTest
class AssignmentsServiceTest extends JsonToObjectsCreator implements TestsUtilMethods {
    @Inject
    AssignmentsService assignmentsService;

    @Inject
    AssignamentEntityRepository assignamentEntityRepository;

    @BeforeEach
    @Transactional
    public void setup() {
        assignamentEntityRepository.deleteAll();
    }

    @Test
    void GivenUuidIdRandomAndAssignmentEntryIsNull_WhenAssigningIssueToUser_ThenThrowsApiBadRequestException() {
        UUID randomUuid = TestsUtility.getRandomUuid();

        Exception exception = assertThrows(ApiBadRequestException.class, () ->
                assignmentsService.assignIssueToUser(randomUuid, null)
        );

        String expectedMessage = TestConstants.ISSUE_NOT_FOUND;
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
    }

    @Test
    @Transactional
    void GivenUuidAndAssignmentEntryNotNullNull_WhenAssigningIssueToUser_ThenReturnsAssignamentDTO() throws IOException {
        loadData();
        UUID uuidIssue = TestsUtility.getUuid(TestConstants.UUID_ASSIGNMENT_ISSUE);
        AssignmentEntry assignmentEntry = assignmentEntry();

        AssignamentDTO assignamentDTO = assignmentsService.assignIssueToUser(uuidIssue, assignmentEntry);
        assertNotNull(assignamentDTO);
        assertEquals(TestConstants.USERNAME, assignamentDTO.getUserName());
        assertEquals(TestConstants.GROUP_NAME, assignamentDTO.getGroupName());
        assertEquals(TestConstants.TEXT, assignamentDTO.getText());
        assertEquals(uuidIssue.toString(), assignamentDTO.getIssueId().toString());
    }

    @Test
    void GivenRandomUuid_WhenAssigningEmptyUser_ThenThrowsApiBadRequestException() {
        UUID randomUuid = TestsUtility.getRandomUuid();

        Exception exception = assertThrows(ApiBadRequestException.class, () ->
                assignmentsService.assignEmptyUser(randomUuid)
        );

        String expectedMessage = TestConstants.ISSUE_NOT_FOUND;
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
    }

    @Test
    @Transactional
    void GivenUuid_WhenAssigningEmptyUser_ThenReturnsAssignamentDTO() {
        UUID uuidIssue = TestsUtility.getUuid(TestConstants.UUID_ASSIGNMENT_ISSUE);
        AssignamentDTO assignamentDTO = assignmentsService.assignEmptyUser(uuidIssue);
        assertNotNull(assignamentDTO);
        assertEquals(TestConstants.EMPTY, assignamentDTO.getUserName());
        assertEquals(TestConstants.GROUP_NAME, assignamentDTO.getGroupName());
        assertEquals(TestConstants.EMPTY, assignamentDTO.getText());
        assertEquals(uuidIssue.toString(), assignamentDTO.getIssueId().toString());
    }

    @Test
    @Transactional
    void GivenUuid_WhenGetAssignaments_ThenReturnsListAssignamentDTO() throws IOException {
        AssignamentEntity assignamentEntity2 = assigmentEntity2();
        assignamentEntityRepository.persist(assignamentEntity2);
        UUID uuidIssue = TestsUtility.getUuid(TestConstants.UUID_ASSIGNMENT_ISSUE_2);
        List<AssignamentDTO> listAssignamentDTO = assignmentsService.getAssignaments(uuidIssue);
        AssignamentDTO assignamentDTO = listAssignamentDTO.get(0);

        assertNotNull(listAssignamentDTO);
        assertEquals(1,listAssignamentDTO.size());
        assertEquals(TestConstants.USERNAME, assignamentDTO.getUserName());
        assertEquals(TestConstants.GROUP_NAME, assignamentDTO.getGroupName());
        assertEquals(TestConstants.TEXT_2, assignamentDTO.getText());
        assertEquals(uuidIssue.toString(), assignamentDTO.getIssueId().toString());
    }

    @Override
    public void loadData() throws IOException {
        AssignamentEntity assignamentEntity = assigmentEntity();
        assignamentEntityRepository.persist(assignamentEntity);
        AssignamentEntity assignamentEntity3 = assigmentEntity3();
        assignamentEntityRepository.persist(assignamentEntity3);
    }
}