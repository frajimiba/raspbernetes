package isom.appops.domain.services;

import isom.appops.domain.model.events.NotificationEventData;
import isom.appops.domain.utils.JsonToObjectsCreator;
import io.quarkus.test.junit.QuarkusTest;

import jakarta.inject.Inject;
import java.io.IOException;

import static io.smallrye.common.constraint.Assert.assertNotNull;

import isom.appops.domain.utils.TestConstants;
import isom.appops.domain.utils.TestsUtility;

@QuarkusTest
class NotificationServiceTest extends JsonToObjectsCreator {

    @Inject
    NotificationService notificationService;

//    @Test
    void GivenNotificationEventData_WhenSendNewIssueNotification_ThenNothingReturns() throws IOException {
        NotificationEventData notificationEventData = notificationEventData();
        notificationEventData.setIssueId(TestsUtility.getUuid(TestConstants.UUID_ASSIGNMENT_ISSUE));
        notificationEventData.setAuthToken(TestsUtility.getToken());
        notificationService.sendNewIssueNotification(notificationEventData);
        assertNotNull(notificationEventData);
    }

//    @Test
    void GivenNotificationEventData_WhenSendAssignamentNotification_ThenNothingReturns() throws IOException {
        NotificationEventData notificationEventData = notificationEventData();
        notificationEventData.setIssueId(TestsUtility.getUuid(TestConstants.UUID_ASSIGNMENT_ISSUE));
        notificationEventData.setAuthToken(TestsUtility.getToken());
        notificationService.sendAssignamentNotification(notificationEventData);
        assertNotNull(notificationEventData);
    }

//    @Test
    void GivenNotificationEventData_WhenSendCloseNotification_ThenNothingReturns() throws IOException {
        NotificationEventData notificationEventData = notificationEventData();
        notificationEventData.setIssueId(TestsUtility.getUuid(TestConstants.UUID_ASSIGNMENT_ISSUE));
        notificationEventData.setAuthToken(TestsUtility.getToken());
        notificationService.sendCloseIssueNotification(notificationEventData);
        assertNotNull(notificationEventData);
    }

//    @Test
    void GivenNotificationEventData_WhenSendAssignamentGroupNotification_ThenNothingReturns() throws IOException {
        NotificationEventData notificationEventData = notificationEventData();
        notificationEventData.setIssueId(TestsUtility.getUuid(TestConstants.UUID_ASSIGNMENT_ISSUE));
        notificationEventData.setAuthToken(TestsUtility.getToken());
        notificationService.sendAssignamentGroupNotification(notificationEventData);
        assertNotNull(notificationEventData);
    }
}