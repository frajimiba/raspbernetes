package isom.appops.domain.services;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import isom.appops.ticketentry.model.TicketEntry;
import isom.appops.ticketentry.model.TicketHeader;
import io.quarkus.test.junit.QuarkusTest;

import org.junit.jupiter.api.Test;

import jakarta.inject.Inject;

import isom.appops.quarkus.errorhandler.exception.ApiInternalServerErrorException;

import isom.appops.domain.utils.JsonToObjectsCreator;
import isom.appops.domain.utils.TestConstants;

import java.io.IOException;

@QuarkusTest
class TranslationsServiceTest extends JsonToObjectsCreator {

    @Inject
    TranslationsService translationsService;

    @Test
    void GivenTicketHeaderIssueTypeIsNull_WhenTranslateToIssue_ThenThrowsApiInternalServerErrorException() throws IOException {
        TicketHeader ticketHeaderNoIssueType = ticketHeaderNoIssueType();

        Exception exception = assertThrows(ApiInternalServerErrorException.class, () ->
                translationsService.translateToIssue(ticketHeaderNoIssueType)
        );

        String expectedMessage = TestConstants.INVALID_TRANSLATION;
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
    }

    @Test
    void GivenTicketHeaderSeverityIsNull_WhenTranslateToIssue_ThenThrowsApiInternalServerErrorException() throws IOException {
        TicketHeader ticketHeaderNoSeverity = ticketHeaderNoSeverity();

        Exception exception = assertThrows(ApiInternalServerErrorException.class, () ->
                translationsService.translateToIssue(ticketHeaderNoSeverity)
        );

        String expectedMessage = TestConstants.INVALID_TRANSLATION;
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
    }

    @Test
    void GivenTicketHeaderSpecialFlagIsNull_WhenTranslateToIssue_ThenThrowsNullPointerException() throws IOException {
        TicketHeader ticketHeaderNoSpecialFlag = ticketHeaderNoSpecialFlag();

        Exception exception = assertThrows(NullPointerException.class, () ->
                translationsService.translateToIssue(ticketHeaderNoSpecialFlag)
        );

        String expectedMessage = TestConstants.IS_NULL;
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
    }

    @Test
    void GivenTicketEntryStatusIsNull_WhenTranslateStatus_ThenThrowsApiInternalServerErrorException() throws IOException {
        TicketEntry ticketEntryIsNull = ticketEntryStatusIsNull();

        Exception exception = assertThrows(ApiInternalServerErrorException.class, () ->
                translationsService.translateStatus(ticketEntryIsNull)
        );

        String expectedMessage = TestConstants.INVALID_TRANSLATION;
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
    }

    @Test
    void GivenTicketEntryStatusKO_WhenTranslateStatus_ThenThrowsApiInternalServerErrorException() throws IOException {
        TicketEntry ticketEntryStatusKO = ticketEntryStatusKO();

        Exception exception = assertThrows(ApiInternalServerErrorException.class, () ->
                translationsService.translateStatus(ticketEntryStatusKO)
        );

        String expectedMessage = TestConstants.INVALID_TRANSLATION;
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
    }

}