package isom.appops.domain.model.dto;

import static io.smallrye.common.constraint.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.*;

import io.quarkus.test.junit.QuarkusTest;
import isom.appops.domain.utils.TestConstants;
import isom.appops.domain.utils.TestsUtility;
import org.junit.jupiter.api.Test;

import java.time.OffsetDateTime;

@QuarkusTest
class FeedbackDTOTest {

    private static final OffsetDateTime now = TestsUtility.getOffsetDateTimeNow();

    @Test
    void GivenFeedbackDTO_WhenSetAttributes_ThenReturnsAttributes(){
        FeedbackDTO feedbackDTO = new FeedbackDTO();
        feedbackDTO.setId(1L);
        feedbackDTO.setStars(4);
        feedbackDTO.setComments(TestConstants.FEEBACK_COMMENT);
        feedbackDTO.setUserId(TestConstants.USERNAME);
        feedbackDTO.setCreationDate(now);
        feedbackDTO.setExecutionRef(1L);
        assertNotNull(feedbackDTO);
        assertEquals(1l, feedbackDTO.getId());
        assertEquals(4, feedbackDTO.getStars());
        assertEquals(TestConstants.FEEBACK_COMMENT, feedbackDTO.getComments());
        assertEquals(TestConstants.USERNAME, feedbackDTO.getUserId());
        assertEquals(now, feedbackDTO.getCreationDate());
        assertEquals(1L, feedbackDTO.getExecutionRef());
    }
}