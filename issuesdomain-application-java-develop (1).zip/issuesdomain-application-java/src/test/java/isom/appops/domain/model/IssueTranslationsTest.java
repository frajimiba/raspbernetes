package isom.appops.domain.model;

import static org.junit.jupiter.api.Assertions.*;

import io.quarkus.test.junit.QuarkusTest;
import isom.appops.domain.utils.JsonToObjectsCreator;
import isom.appops.domain.utils.TestConstants;
import org.junit.jupiter.api.Test;

import java.io.IOException;

import isom.appops.domain.model.dto.IssueDTO;

@QuarkusTest
class IssueTranslationsTest extends JsonToObjectsCreator {

    @Test
    void testEquals() throws IOException {
        IssueDTO issueDto = issueDtoToUpdate();
        IssueTranslations issueTranslations = issueTranslations();
        assertFalse(notEquals(issueTranslations,issueDto));
        assertEquals(issueTranslations, issueTranslations);
    }

    @Test
    void testHashCode() throws IOException {
        IssueTranslations issueTranslations = new IssueTranslations();
        issueTranslations.issueType(TestConstants.ISSUE_TYPE);
        issueTranslations.severity(TestConstants.SEVERITY);
        issueTranslations.specialFlag(TestConstants.SPECIAL_FLAG);
        IssueTranslations issueTranslations2 = issueTranslations();
        assertTrue(equals(issueTranslations, issueTranslations2));
        assertEquals(issueTranslations.hashCode(), issueTranslations2.hashCode());
    }

    @Test
    void testToString() throws IOException {
        IssueTranslations issueTranslations = new IssueTranslations(TestConstants.ISSUE_TYPE, TestConstants.SEVERITY, TestConstants.SPECIAL_FLAG);
        IssueTranslations issueTranslations2 = issueTranslations();
        assertEquals(issueTranslations.toString(), issueTranslations2.toString());
    }

    private boolean notEquals(IssueTranslations issueTranslations, IssueDTO issueDTO) {
        return issueTranslations.equals(issueDTO);
    }
    private boolean equals(IssueTranslations issueTranslations, IssueTranslations issueTranslations2) {
        return issueTranslations.equals(issueTranslations2) &&
                issueTranslations.getIssueType().equals(issueTranslations2.getIssueType()) &&
                issueTranslations.getSeverity().equals(issueTranslations2.getSeverity()) &&
                issueTranslations.getSpecialFlag().equals(issueTranslations2.getSpecialFlag());
    }
}