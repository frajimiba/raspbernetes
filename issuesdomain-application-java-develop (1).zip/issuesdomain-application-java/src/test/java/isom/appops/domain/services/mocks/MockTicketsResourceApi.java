package isom.appops.domain.services.mocks;

import isom.appops.domain.utils.JsonToObjectsCreator;
import org.eclipse.microprofile.rest.client.inject.RestClient;

import jakarta.annotation.Priority;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.inject.Alternative;

import java.io.IOException;
import java.util.UUID;

import isom.appops.openapi_ticketdetails.api.TicketsResourceApi;
import isom.appops.openapi_ticketdetails.model.OutputTicketData;
import isom.appops.openapi_ticketdetails.model.PagedResult;
import isom.appops.openapi_ticketdetails.model.TicketDTO;
import isom.appops.openapi_ticketdetails.model.TicketEntry;

@Alternative()
@Priority(1)
@ApplicationScoped
@RestClient
public class MockTicketsResourceApi extends JsonToObjectsCreator implements TicketsResourceApi {
    @Override
    public PagedResult appopsTicketdetailsV0TicketsGet(Integer page, Integer size) {
        return null;
    }

    @Override
    public TicketDTO appopsTicketdetailsV0TicketsIdGet(UUID id) {
        TicketDTO ticketDTO = null;
        try {
            ticketDTO = ticketDTO();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return ticketDTO;
    }

    @Override
    public OutputTicketData appopsTicketdetailsV0TicketsIdNotesGet(UUID id) {
        return null;
    }

    @Override
    public TicketDTO appopsTicketdetailsV0TicketsTicketPut(TicketEntry ticketEntry) {
        return null;
    }
}
