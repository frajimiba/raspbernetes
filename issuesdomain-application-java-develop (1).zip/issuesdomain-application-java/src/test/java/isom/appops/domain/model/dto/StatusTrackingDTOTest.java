package isom.appops.domain.model.dto;

import static org.junit.jupiter.api.Assertions.*;

import io.quarkus.test.junit.QuarkusTest;
import isom.appops.domain.utils.JsonToObjectsCreator;
import isom.appops.domain.utils.TestConstants;
import isom.appops.domain.utils.TestsUtility;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.time.OffsetDateTime;
import java.util.UUID;

@QuarkusTest
class StatusTrackingDTOTest extends JsonToObjectsCreator {

    private static final UUID uuidIssue = TestsUtility.getUuid(TestConstants.UUID_ASSIGNMENT_ISSUE_4);
    private static final OffsetDateTime now = TestsUtility.getOffsetDateTimeNow();

    @Test
    void testEquals() throws IOException {
        ManualClassificationDTO manualClassificationDTO = manualClassificationDTO();
        StatusTrackingDTO statusTrackingDTO = new StatusTrackingDTO(
                1L, TestConstants.STATUS_UNASSIGNED, uuidIssue, now, now);
        assertFalse(notEquals(statusTrackingDTO, manualClassificationDTO));
        assertEquals(statusTrackingDTO, statusTrackingDTO);
    }

    @Test
    void testHashCode() {
        StatusTrackingDTO statusTrackingDTO = new StatusTrackingDTO(
                1L, TestConstants.STATUS_UNASSIGNED, uuidIssue, now, now);

        StatusTrackingDTO statusTrackingDTO2 = new StatusTrackingDTO();
        statusTrackingDTO2.id(1L);
        statusTrackingDTO2.status(TestConstants.STATUS_UNASSIGNED);
        statusTrackingDTO2.issueId(uuidIssue);
        statusTrackingDTO2.tsInitial(now);
        statusTrackingDTO2.tsFinal(now);

        assertTrue(equals(statusTrackingDTO, statusTrackingDTO2));
        assertEquals(statusTrackingDTO.hashCode(), statusTrackingDTO2.hashCode());
    }

    @Test
    void testToString() {
        StatusTrackingDTO statusTrackingDTO = new StatusTrackingDTO(
                1L, TestConstants.STATUS_UNASSIGNED, uuidIssue, now, now);

        StatusTrackingDTO statusTrackingDTO2 = new StatusTrackingDTO();
        statusTrackingDTO2.setId(1L);
        statusTrackingDTO2.setStatus(TestConstants.STATUS_UNASSIGNED);
        statusTrackingDTO2.setIssueId(uuidIssue);
        statusTrackingDTO2.setTsInitial(now);
        statusTrackingDTO2.setTsFinal(now);

        assertEquals(statusTrackingDTO.toString(), statusTrackingDTO2.toString());
    }

    private boolean notEquals(StatusTrackingDTO statusTrackingDTO, ManualClassificationDTO manualClassificationDTO) {
        return statusTrackingDTO.equals(manualClassificationDTO);
    }
    private boolean equals(StatusTrackingDTO statusTrackingDTO, StatusTrackingDTO statusTrackingDTO2) {
        return statusTrackingDTO.equals(statusTrackingDTO2) &&
                statusTrackingDTO.getId().equals(statusTrackingDTO2.getId()) &&
                statusTrackingDTO.getStatus().equals(statusTrackingDTO2.getStatus()) &&
                statusTrackingDTO.getTsInitial().equals(statusTrackingDTO2.getTsInitial()) &&
                statusTrackingDTO.getTsFinal().equals(statusTrackingDTO2.getTsFinal());
    }
}