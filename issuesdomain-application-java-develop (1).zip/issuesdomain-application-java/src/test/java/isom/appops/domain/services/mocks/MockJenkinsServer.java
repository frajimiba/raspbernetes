package isom.appops.domain.services.mocks;

import com.offbytwo.jenkins.JenkinsServer;
import com.offbytwo.jenkins.client.JenkinsHttpConnection;
import org.eclipse.microprofile.rest.client.inject.RestClient;

import jakarta.annotation.Priority;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.inject.Alternative;
import java.net.URI;

@Alternative()
@Priority(1)
@ApplicationScoped
@RestClient
public class MockJenkinsServer extends JenkinsServer {

    public MockJenkinsServer(URI serverUri) {
        super(serverUri);
    }

    public MockJenkinsServer(URI serverUri, String username, String passwordOrToken) {
        super(serverUri, username, passwordOrToken);
    }

    public MockJenkinsServer(JenkinsHttpConnection client) {
        super(client);
    }


}
