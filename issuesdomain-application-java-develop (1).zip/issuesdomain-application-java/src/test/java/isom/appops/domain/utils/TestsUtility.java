package isom.appops.domain.utils;

import isom.appops.domain.model.PageRequest;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.util.Map;
import java.util.UUID;

public final class TestsUtility {
    private static final DateTimeFormatter DATE_TIME_FORMATTER = new DateTimeFormatterBuilder()
            .appendOptional(DateTimeFormatter.ISO_DATE_TIME)
            .appendOptional(DateTimeFormatter.ISO_OFFSET_DATE_TIME)
            .appendOptional(DateTimeFormatter.ISO_INSTANT)
            .appendOptional(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SX"))
            .appendOptional(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ssX"))
            .appendOptional(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))
            .toFormatter()
            .withZone(ZoneOffset.UTC);

    private TestsUtility() {
    }

    public static UUID getRandomUuid() {
        return UUID.randomUUID();
    }

    public static UUID getUuid(String uuid) {
        return UUID.fromString(uuid);
    }

    public static OffsetDateTime getOffsetDateTimeNow() {
        return OffsetDateTime.now();
    }

    public static String getToken() {
        String result = null;
        try {
            result = JwtUtils.generateTokenString("/json/auth/jwt.json");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    public static Map<String, PageRequest> getPageRequestMap() {
        PageRequest page = new PageRequest();
        page.setSize(1);

        Map<String, PageRequest> beanParam = Map.of(TestConstants.PAGE_REQUEST, page);
        return beanParam;
    }

    public static OffsetDateTime parseDateTimeString(String str) {
        return ZonedDateTime.from(TestsUtility.DATE_TIME_FORMATTER.parse(str)).toOffsetDateTime();
    }
}
