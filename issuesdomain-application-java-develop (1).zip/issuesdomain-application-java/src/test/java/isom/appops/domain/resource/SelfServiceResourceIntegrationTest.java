package isom.appops.domain.resource;

import isom.appops.domain.utils.TestsUtility;
import io.quarkus.test.junit.QuarkusTest;
import org.junit.jupiter.api.Test;

import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import java.util.Map;

import static io.restassured.RestAssured.given;

@QuarkusTest
class SelfServiceResourceIntegrationTest {

    private static final String PATH_SUBMIT_FORM = "/self-service/submit/{templateId}";
    private static final String PATH_PARAM_TEMPLATE_ID = "templateId";
    private static final Map<String, Integer> pathParams = Map.of(PATH_PARAM_TEMPLATE_ID, 1);

    @Test
    void GivenTemplateIdAndForm_WhenSubmitForm_ThenReturnStatusAccepted() {
        given()
                .auth().preemptive().oauth2(TestsUtility.getToken())
                .pathParams(pathParams)
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                .header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON)
                .when().post(PATH_SUBMIT_FORM)
                .then().assertThat();
    }
}