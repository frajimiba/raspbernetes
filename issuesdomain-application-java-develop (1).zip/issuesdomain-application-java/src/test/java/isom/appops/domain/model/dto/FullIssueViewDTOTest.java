package isom.appops.domain.model.dto;

import static io.smallrye.common.constraint.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import io.quarkus.test.junit.QuarkusTest;
import isom.appops.domain.utils.TestConstants;
import isom.appops.domain.utils.TestsUtility;
import org.junit.jupiter.api.Test;

import java.time.OffsetDateTime;
import java.util.UUID;

@QuarkusTest
class FullIssueViewDTOTest {

    private static final UUID uuid = TestsUtility.getUuid(TestConstants.UUID_ASSIGNMENT_ISSUE_4);
    private static final OffsetDateTime now = TestsUtility.getOffsetDateTimeNow();

    @Test
    void GivenFullIssueViewDTO_WhenSetAttributes_ThenReturnsAttributes(){
        FullIssueViewDTO fullIssueViewDTO = new FullIssueViewDTO();
        fullIssueViewDTO.setId(uuid);
        fullIssueViewDTO.setTicketId(TestConstants.TICKET_ID);
        fullIssueViewDTO.setClientId(TestConstants.CLIENT_ID);
        fullIssueViewDTO.setIssueType(TestConstants.ISSUE_TYPE);
        fullIssueViewDTO.setGroupName(TestConstants.GROUP_NAME);
        fullIssueViewDTO.setSeverity(TestConstants.SEVERITY);
        fullIssueViewDTO.setSpecialFlag(TestConstants.SPECIAL_FLAG);
        fullIssueViewDTO.setSlaBreachTime(now);
        fullIssueViewDTO.setClassification(TestConstants.CLASSIFICATION_DEMO);
        fullIssueViewDTO.setClassificationDate(now);
        fullIssueViewDTO.setManualClassificationUser(TestConstants.CONST_STRING);
        fullIssueViewDTO.setManualClassificationTimestamp(now);
        fullIssueViewDTO.setAssignedUser(TestConstants.USERNAME);
        fullIssueViewDTO.setStatus(TestConstants.STATUS_UNASSIGNED);
        fullIssueViewDTO.setResolutionDate(now);
        assertNotNull(fullIssueViewDTO);

        FullIssueViewDTO fullIssueViewDTO2 = new FullIssueViewDTO(
                uuid, TestConstants.TICKET_ID, TestConstants.CLIENT_ID, TestConstants.ISSUE_TYPE,
                TestConstants.GROUP_NAME, TestConstants.SEVERITY, TestConstants.SPECIAL_FLAG, now, now,
                TestConstants.CLASSIFICATION_DEMO, now, TestConstants.CONST_STRING,
                TestConstants.CONST_STRING, now, TestConstants.USERNAME, TestConstants.STATUS_UNASSIGNED);
        assertNotNull(fullIssueViewDTO2);
        assertEquals(uuid, fullIssueViewDTO2.getId());
        assertEquals(TestConstants.TICKET_ID, fullIssueViewDTO2.getTicketId());
        assertEquals(TestConstants.CLIENT_ID, fullIssueViewDTO2.getClientId());
        assertEquals(TestConstants.ISSUE_TYPE, fullIssueViewDTO2.getIssueType());
        assertEquals(TestConstants.GROUP_NAME, fullIssueViewDTO2.getGroupName());
        assertEquals(TestConstants.SEVERITY, fullIssueViewDTO2.getSeverity());
        assertEquals(TestConstants.SPECIAL_FLAG, fullIssueViewDTO2.getSpecialFlag());
        assertNotNull(fullIssueViewDTO2.getSlaBreachTime());
        assertNotNull(fullIssueViewDTO2.getResolutionDate());
        assertEquals(TestConstants.CLASSIFICATION_DEMO, fullIssueViewDTO2.getClassification());
        assertNotNull(fullIssueViewDTO2.getClassificationDate());
        assertEquals(TestConstants.CONST_STRING, fullIssueViewDTO2.getManualClassificationUser());
        assertEquals(TestConstants.CONST_STRING, fullIssueViewDTO2.getManualClassification());
        assertNotNull(fullIssueViewDTO2.getManualClassificationTimestamp());
        assertEquals(TestConstants.USERNAME, fullIssueViewDTO2.getAssignedUser());
        assertEquals(TestConstants.STATUS_UNASSIGNED, fullIssueViewDTO2.getStatus());
    }
}