package isom.appops.domain.model.dto;

import static org.junit.jupiter.api.Assertions.*;

import io.quarkus.test.junit.QuarkusTest;
import isom.appops.domain.utils.JsonToObjectsCreator;
import isom.appops.domain.utils.TestConstants;
import isom.appops.domain.utils.TestsUtility;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.time.OffsetDateTime;
import java.util.UUID;

import isom.appops.domain.model.entries.ManualClassificationEntry;

@QuarkusTest
class ManualClassificationDTOTest extends JsonToObjectsCreator {

    private static final UUID uuidIssue = TestsUtility.getUuid(TestConstants.UUID_ASSIGNMENT_ISSUE_4);
    private static final OffsetDateTime now = TestsUtility.getOffsetDateTimeNow();

    @Test
    void testEquals() throws IOException {
        ManualClassificationDTO manualClassificationDTO = manualClassificationDTO();
        manualClassificationDTO.issueId(uuidIssue);
        ManualClassificationEntry manualClassificationEntry = manualClassificationEntry();
        assertFalse(notEquals(manualClassificationDTO, manualClassificationEntry));
        assertEquals(manualClassificationDTO, manualClassificationDTO);
    }

    @Test
    void testHashCode() throws IOException {
        ManualClassificationDTO manualClassificationDTO = new ManualClassificationDTO();
        manualClassificationDTO.setUserName(TestConstants.USERNAME);
        manualClassificationDTO.setClassification(TestConstants.CLASSIFICATION_DEMO);
        manualClassificationDTO.setCreationDate(now);
        manualClassificationDTO.setIssueId(uuidIssue);

        ManualClassificationDTO manualClassificationDTO2 = manualClassificationDTO();
        manualClassificationDTO2.setCreationDate(now);

        assertTrue(equals(manualClassificationDTO, manualClassificationDTO2));
        assertEquals(manualClassificationDTO.hashCode(), manualClassificationDTO2.hashCode());
    }

    @Test
    void testToString() throws IOException {
        ManualClassificationDTO manualClassificationDTO = new ManualClassificationDTO(
                TestConstants.USERNAME,
                TestConstants.CLASSIFICATION_DEMO,
                now,
                uuidIssue);

        ManualClassificationDTO manualClassificationDTO2 = manualClassificationDTO();
        manualClassificationDTO2.setCreationDate(now);

        assertEquals(manualClassificationDTO.toString(), manualClassificationDTO2.toString());
    }

    private boolean notEquals(ManualClassificationDTO manualClassificationDTO, ManualClassificationEntry manualClassificationEntry) {
        return manualClassificationDTO.equals(manualClassificationEntry);
    }
    private boolean equals(ManualClassificationDTO manualClassificationDTO, ManualClassificationDTO manualClassificationDTO2) {
        return manualClassificationDTO.equals(manualClassificationDTO2) &&
                manualClassificationDTO.getUserName().equals(manualClassificationDTO2.getUserName()) &&
                manualClassificationDTO.getClassification().equals(manualClassificationDTO2.getClassification()) &&
                manualClassificationDTO.getCreationDate().equals(manualClassificationDTO2.getCreationDate()) &&
                manualClassificationDTO.getIssueId().equals(manualClassificationDTO2.getIssueId());
    }
}