package isom.appops.domain.services;

import static io.smallrye.common.constraint.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

import io.quarkus.test.junit.QuarkusTest;
import org.junit.jupiter.api.*;

import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import java.io.IOException;

import isom.appops.domain.model.dto.ProcedureDTO;
import isom.appops.domain.model.PageRequest;
import isom.appops.domain.model.dto.ExecutionDTO;
import isom.appops.domain.model.entries.ExecutionEntry;
import isom.appops.domain.model.entries.ProcedureEntry;

import isom.appops.domain.utils.TestConstants;

import isom.appops.domain.utils.JsonToObjectsCreator;
import isom.appops.quarkus.data.PagedResult;

@QuarkusTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class ProcedureServiceTest extends JsonToObjectsCreator {

    @Inject
    ProcedureService procedureService;

    @Test
    @Order(1)
    void GivenProcedureEntry_WhenAddProcedure_ThenReturnsProcedureDto() throws IOException {
        ProcedureEntry procedureEntry = procedureEntry();
        ProcedureDTO procedureDTO = procedureService.add(procedureEntry);
        assertNotNull(procedureDTO);
        assertEquals(3L, procedureDTO.getId());
        assertEquals(TestConstants.PROCEDURE_TITLE, procedureDTO.getTitle());
        assertEquals(TestConstants.CLIENT_ID, procedureDTO.getClientId());
        assertEquals(TestConstants.PROCEDURE_DESCRIPTION, procedureDTO.getDescription());
        assertEquals(TestConstants.CLASSIFICATION_DEMO, procedureDTO.getClassification());
        assertEquals(TestConstants.CONFIG_FILE_ENV_DEV, procedureDTO.getConfigFileEnvironment());
    }

    @Test
    @Order(2)
    void GivenProcedureId_WhenGetProcedureId_ThenReturnsProcedureDto() {
        ProcedureDTO procedureDTO = procedureService.get(1L);
        assertNotNull(procedureDTO);
        assertEquals(1L, procedureDTO.getId());
        assertEquals(TestConstants.PROCEDURE_TITLE, procedureDTO.getTitle());
        assertEquals(TestConstants.CLIENT_ID, procedureDTO.getClientId());
        assertEquals(TestConstants.PROCEDURE_DESCRIPTION, procedureDTO.getDescription());
        assertEquals(TestConstants.CLASSIFICATION_DEMO, procedureDTO.getClassification());
        assertEquals(TestConstants.CONFIG_FILE_ENV_DEV, procedureDTO.getConfigFileEnvironment());
    }

    @Test
    @Order(3)
    void GivenPageRequest_WhenListResult_ThenReturnsPagedResultProcedureDto(){
        PageRequest page = new PageRequest();
        page.setSize(1);
        PagedResult<ProcedureDTO> procedureDTOPagedResult = procedureService.list(page);
        ProcedureDTO procedureDTO = procedureDTOPagedResult.getList().get(0);
        assertNotNull(procedureDTOPagedResult);
        assertEquals(TestConstants.PROCEDURE_TITLE, procedureDTO.getTitle());
        assertEquals(TestConstants.CLIENT_ID, procedureDTO.getClientId());
        assertEquals(TestConstants.PROCEDURE_DESCRIPTION, procedureDTO.getDescription());
        assertEquals(TestConstants.CLASSIFICATION_DEMO, procedureDTO.getClassification());
        assertEquals(TestConstants.CONFIG_FILE_ENV_DEV, procedureDTO.getConfigFileEnvironment());
    }

    @Test
    @Order(4)
    @Transactional
    void GivenProcedureIdAndExecutionEntry_WhenExecute_ThenReturnsExecutionDto() throws IOException {
        ExecutionEntry executionEntry = executionEntry();
        ExecutionDTO executionDTO = procedureService.execute(1L, executionEntry);
        assertNotNull(executionDTO);
        assertEquals(1L, executionDTO.getId());
        assertEquals(1L, executionDTO.getProcedureRef());
        assertEquals(TestConstants.UUID_ASSIGNMENT_ISSUE, executionDTO.getIssueRef().toString());
        assertEquals(1, executionDTO.getParameters().size());
        assertEquals(TestConstants.PARAMETER_EXECUTION, executionDTO.getParameters().get(0));
    }

    @Test
    @Order(5)
    void GivenProcedureIdAndPageRequest_WhenGetExecutions_ThenReturnsPagedResultExecutionDTO(){
        PageRequest page = new PageRequest();
        page.setSize(1);
        PagedResult<ExecutionDTO> executionDTOPagedResult = procedureService.getExecutions(1L, page);
        ExecutionDTO executionDTO = executionDTOPagedResult.getList().get(0);
        assertNotNull(executionDTOPagedResult);
        assertEquals(1L, executionDTO.getId());
        assertEquals(1L, executionDTO.getProcedureRef());
        assertEquals(TestConstants.UUID_ASSIGNMENT_ISSUE, executionDTO.getIssueRef().toString());
        assertEquals(1, executionDTO.getParameters().size());
        assertEquals(TestConstants.PARAMETER_EXECUTION, executionDTO.getParameters().get(0));
    }

    @Test
    @Order(6)
    void GivenProcedureId_WhenGetRating_ThenReturnsRating(){
        double rating = procedureService.getRating(1L);
        assertNotNull(rating);
    }

    @Test
    @Order(7)
    void GivenProcedureDto_WhenIsAutomaticUnnattendedProcedure_ThenReturnsFalse() throws IOException {
        ProcedureDTO procedureDtoNotAutomatic = procedureDtoNotAutomatic();
        boolean result = procedureService.isAutomaticUnnattendedProcedure(procedureDtoNotAutomatic);
        assertNotNull(result);
        assertFalse(result);
    }

    @Test
    @Order(8)
    void GivenProcedureDto_WhenIsAutomaticUnnattendedProcedure_ThenReturnsTrue() throws IOException {
        ProcedureDTO procedureDtoIsAutomatic = procedureDtoIsAutomatic();
        boolean result = procedureService.isAutomaticUnnattendedProcedure(procedureDtoIsAutomatic);
        assertNotNull(result);
        assertTrue(result);
    }

    @Test
    @Order(9)
    void GivenProcedureDtoNoType_WhenIsAutomaticUnnattendedProcedure_ThenReturnsTrue() throws IOException {
        ProcedureDTO procedureDtoIsAutomatic = procedureDtoIsAutomaticNoType();
        boolean result = procedureService.isAutomaticUnnattendedProcedure(procedureDtoIsAutomatic);
        assertNotNull(result);
        assertTrue(result);
    }

    @Test
    @Order(10)
    void GivenProcedureIdAndProcedureEntry_WhenUpdateProcedure_ThenReturnsProcedureDto() throws IOException {
        ProcedureEntry procedureEntry = procedureEntryToUpdate();
        ProcedureDTO procedureDTO = procedureService.update(1L, procedureEntry);
        assertNotNull(procedureDTO);
        assertEquals(TestConstants.PROCEDURE_TITLE_UPDATED, procedureDTO.getTitle());
        assertEquals(TestConstants.CLIENT_ID, procedureDTO.getClientId());
        assertEquals(TestConstants.PROCEDURE_DESCRIP_UPDATED, procedureDTO.getDescription());
        assertEquals(TestConstants.CLASSIFICATION_OTHER_UPDATED, procedureDTO.getClassification());
        assertEquals(TestConstants.CONFIG_FILE_ENV_DEV, procedureDTO.getConfigFileEnvironment());
    }

    @Test
    @Order(11)
    void GivenProcedureId_WhenMethodDelete_ThenNothingReturns() throws IOException {
        ProcedureEntry procedureEntry = procedureEntry();
        procedureService.delete(1L);
        assertNotNull(procedureEntry);
    }
}
