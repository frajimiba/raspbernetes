package isom.appops.domain.services;

import io.quarkus.test.junit.QuarkusTest;
import isom.appops.database.entities.ExecutionEntity;
import isom.appops.database.repository.ExecutionEntityRepository;
import isom.appops.domain.model.dto.ExecutionDTO;
import isom.appops.domain.utils.JsonToObjectsCreator;
import isom.appops.domain.utils.TestConstants;
import isom.appops.domain.utils.TestsUtilMethods;
import isom.appops.domain.utils.TestsUtility;
import org.junit.jupiter.api.*;

import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

import static io.smallrye.common.constraint.Assert.assertNotNull;

@QuarkusTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class ExecutionServiceTest extends JsonToObjectsCreator implements TestsUtilMethods {

    @Inject
    ExecutionService executionService;

    @Inject
    ExecutionEntityRepository executionEntityRepository;

    @BeforeEach
    @Transactional
    public void setup() {
        executionEntityRepository.deleteAll();
    }

//    @Test
    @Transactional
    @Order(1)
    void GivenExecutionEntityIdAndUrlJob_WhenUpdateUrlJob_ThenReturnsExecutionDto() throws IOException {
        loadData();
        ExecutionDTO executionDTO = executionService.updateUrlJob(1L, TestConstants.EXECUTION_URL_JOB);
        assertNotNull(executionDTO);
    }


    @Test
    @Transactional
    @Order(2)
    void GivenUuidIssue_WhenGetExecutionsByIssueId_ThenReturnsListExecutionDto() {
        UUID uuidIssue = TestsUtility.getUuid(TestConstants.UUID_ASSIGNMENT_ISSUE);
        List<ExecutionDTO> executionDtoList = executionService.getExecutionsByIssueId(uuidIssue);
        assertNotNull(executionDtoList);
    }

    @Override
    public void loadData() throws IOException {
        ExecutionEntity executionEntity = executionEntity();
        executionEntityRepository.persist(executionEntity);
    }
}