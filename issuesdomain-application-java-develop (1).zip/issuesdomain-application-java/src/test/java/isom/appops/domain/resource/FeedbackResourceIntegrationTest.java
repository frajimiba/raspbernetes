package isom.appops.domain.resource;

import static io.restassured.RestAssured.given;

import io.quarkus.test.junit.QuarkusTest;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.io.IOException;
import java.util.Map;

import isom.appops.domain.model.entries.FeedbackEntry;
import isom.appops.domain.utils.JsonToObjectsCreator;
import isom.appops.domain.utils.TestsUtility;

@QuarkusTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class FeedbackResourceIntegrationTest extends JsonToObjectsCreator {

    private static final String PATH_ROOT = "/feedbacks";
    private static final String PATH_FEEDBACK_ID = "/feedbacks/{id}";
    private static final String PATH_FEEDBACKS_BY_PROCEDURE_ID = "/feedbacks/by-procedure/{procedureId}";
    private static final String PATH_PARAM_ID = "id";
    private static final String PATH_PARAM_PROCEDURE_ID = "procedureId";
    private static final Map<String, Long> pathParams = Map.of(PATH_PARAM_ID, 1L);

    @Test
    @Order(1)
    void GivenFeedbackEntry_WhenAddFeedback_ThenReturnStatusOk() throws IOException {
        FeedbackEntry feedbackEntry = feedbackEntry();

        given()
                .auth().preemptive().oauth2(TestsUtility.getToken())
                .body(feedbackEntry)
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                .header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON)
                .when().post(PATH_ROOT)
                .then().assertThat();
    }
    @Test
    @Order(2)
    void GivenFeedbackId_WhenGetFeedback_ThenReturnStatusOk() {
        given()
                .auth().preemptive().oauth2(TestsUtility.getToken())
                .pathParams(pathParams)
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                .header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON)
                .when().get(PATH_FEEDBACK_ID)
                .then().statusCode(Response.Status.OK.getStatusCode());
    }

    @Test
    @Order(3)
    void GivenPageRequest_WhenListFeedback_ThenReturnStatusOk() {
        given()
                .auth().preemptive().oauth2(TestsUtility.getToken())
                .queryParams(TestsUtility.getPageRequestMap())
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                .header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON)
                .when().get(PATH_ROOT)
                .then().statusCode(Response.Status.OK.getStatusCode());
    }

    @Test
    @Order(4)
    void GivenPageRequestAndProcedureId_WhenGetFeedbacksByProcedureId_ThenReturnStatusOk() {
        given()
                .auth().preemptive().oauth2(TestsUtility.getToken())
                .queryParams(TestsUtility.getPageRequestMap())
                .pathParams(PATH_PARAM_PROCEDURE_ID, 1L)
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                .header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON)
                .when().get(PATH_FEEDBACKS_BY_PROCEDURE_ID)
                .then().statusCode(Response.Status.OK.getStatusCode());
    }

    @Test
    @Order(5)
    void GivenFeedbackId_WhenUpdateFeedback_ThenReturnStatusOk() throws IOException {
        FeedbackEntry feedbackEntryToUpdate = feedbackEntryToUpdate();

        given()
                .auth().preemptive().oauth2(TestsUtility.getToken())
                .pathParams(pathParams)
                .body(feedbackEntryToUpdate)
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                .header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON)
                .when().put(PATH_FEEDBACK_ID)
                .then().assertThat();
    }

    @Test
    @Order(6)
    void GivenFeedbackId_WhenDeleteFeedback_ThenReturnStatusOk() {
        given()
                .auth().preemptive().oauth2(TestsUtility.getToken())
                .pathParams(pathParams)
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                .header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON)
                .when().delete(PATH_FEEDBACK_ID)
                .then().statusCode(Response.Status.OK.getStatusCode());
    }
}