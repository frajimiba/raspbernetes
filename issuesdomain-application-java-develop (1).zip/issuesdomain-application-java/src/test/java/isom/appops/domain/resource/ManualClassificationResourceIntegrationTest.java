package isom.appops.domain.resource;

import isom.appops.domain.model.entries.ManualClassificationEntry;
import isom.appops.domain.utils.JsonToObjectsCreator;
import isom.appops.domain.utils.TestConstants;
import isom.appops.domain.utils.TestsUtility;
import io.quarkus.test.junit.QuarkusTest;
import org.junit.jupiter.api.Test;

import jakarta.transaction.Transactional;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.io.IOException;
import java.util.Map;
import java.util.UUID;

import static io.restassured.RestAssured.given;

@QuarkusTest
class ManualClassificationResourceIntegrationTest extends JsonToObjectsCreator {

    private static final String PATH_ROOT = "/issues/{id}/classification/manual";
    private static final String PATH_PARAM_ID = "id";
    private static final Map<String, UUID> pathParams = Map.of(PATH_PARAM_ID, TestsUtility.getUuid(TestConstants.UUID_ASSIGNMENT_ISSUE_4));

    @Test
    void GivenUuidIssueAndManualClassificationEntry_WhenManualClassifyIssue_ThenReturnStatusAccepted() throws IOException {
        ManualClassificationEntry manualClassificationEntry = manualClassificationEntry();

        given()
                .auth().preemptive().oauth2(TestsUtility.getToken())
                .pathParams(pathParams)
                .body(manualClassificationEntry)
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                .header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON)
                .when().post(PATH_ROOT)
                .then().statusCode(Response.Status.ACCEPTED.getStatusCode());
    }
}