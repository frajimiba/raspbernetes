package isom.appops.domain.model.entries;

import static io.smallrye.common.constraint.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import io.quarkus.test.junit.QuarkusTest;
import isom.appops.domain.utils.TestConstants;
import org.junit.jupiter.api.Test;

import java.util.List;

@QuarkusTest
class IssuesAssignedToUsersWithStatusEntryTest {

    @Test
    void GivenIssuesAssignedToUsersWithStatusEntry_WhenSetAttributesPageRequest_ThenReturnsAttributes() {
        List<String> userIdList = TestConstants.USER_ID_LIST;
        List<String> statusList = TestConstants.STATUS_LIST;

        IssuesAssignedToUsersWithStatusEntry issuesAssignedToUsersWithStatusEntry = new IssuesAssignedToUsersWithStatusEntry(userIdList, statusList);
        assertNotNull(issuesAssignedToUsersWithStatusEntry);
        assertEquals(5, issuesAssignedToUsersWithStatusEntry.getUserIds().size());
        assertEquals(5, issuesAssignedToUsersWithStatusEntry.getStatuses().size());
        assertEquals(TestConstants.USERNAME, issuesAssignedToUsersWithStatusEntry.getUserIds().get(0));
        assertEquals(TestConstants.STATUS_UNASSIGNED, issuesAssignedToUsersWithStatusEntry.getStatuses().get(0));

        IssuesAssignedToUsersWithStatusEntry issuesAssignedToUsersWithStatusEntry2 = new IssuesAssignedToUsersWithStatusEntry();
        issuesAssignedToUsersWithStatusEntry2.setUserIds(userIdList);
        issuesAssignedToUsersWithStatusEntry2.setStatuses(statusList);

        assertNotNull(issuesAssignedToUsersWithStatusEntry2);
        assertEquals(5, issuesAssignedToUsersWithStatusEntry2.getUserIds().size());
        assertEquals(5, issuesAssignedToUsersWithStatusEntry2.getStatuses().size());
        assertEquals(TestConstants.USERNAME, issuesAssignedToUsersWithStatusEntry2.getUserIds().get(0));
        assertEquals(TestConstants.STATUS_UNASSIGNED, issuesAssignedToUsersWithStatusEntry2.getStatuses().get(0));
    }
}