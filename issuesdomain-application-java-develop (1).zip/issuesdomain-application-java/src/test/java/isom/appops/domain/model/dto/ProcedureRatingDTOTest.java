package isom.appops.domain.model.dto;

import static io.smallrye.common.constraint.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import io.quarkus.test.junit.QuarkusTest;
import isom.appops.domain.utils.JsonToObjectsCreator;
import org.junit.jupiter.api.Test;

import java.io.IOException;

@QuarkusTest
class ProcedureRatingDTOTest extends JsonToObjectsCreator {

    @Test
    void GivenProcedureDTOAndRating_WhenSetAttributes_ThenReturnsRating() throws IOException {
        ProcedureDTO procedureDTO = procedureDtoIsAutomatic();
        ProcedureRatingDTO procedureRatingDTO = new ProcedureRatingDTO(procedureDTO, 3.5);
        procedureRatingDTO.setRating(4.5);
        assertNotNull(procedureDTO);
        assertEquals(4.5, procedureRatingDTO.getRating());

        ProcedureDTO procedureDTO2 = new ProcedureRatingDTO();
        assertNotNull(procedureDTO2);
    }
}