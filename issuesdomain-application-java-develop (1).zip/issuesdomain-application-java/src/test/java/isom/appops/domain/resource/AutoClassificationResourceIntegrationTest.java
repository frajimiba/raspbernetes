package isom.appops.domain.resource;

import static io.restassured.RestAssured.given;

import isom.appops.domain.model.entries.AutomaticClassificationEntry;
import isom.appops.domain.utils.JsonToObjectsCreator;
import io.quarkus.test.junit.QuarkusTest;
import org.junit.jupiter.api.Test;

import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.io.IOException;
import java.util.Map;
import java.util.UUID;

import isom.appops.domain.utils.TestConstants;
import isom.appops.domain.utils.TestsUtility;

@QuarkusTest
class AutoClassificationResourceIntegrationTest extends JsonToObjectsCreator {

    private static final String PATH_ROOT = "/issues/{id}/classification/auto";
    private static final String PATH_PARAM_ID = "id";
    private static final Map<String, UUID> pathParams = Map.of(PATH_PARAM_ID, TestsUtility.getUuid(TestConstants.UUID_ASSIGNMENT_ISSUE_4));

    @Test
    void GivenUuidAndAutomaticClassificationEntry_WhenAutoClassify_ThenReturnStatusAccepted() throws IOException {

        AutomaticClassificationEntry automaticClassificationEntry = automaticClassificationEntry();

        given()
                .auth().preemptive().oauth2(TestsUtility.getToken())
                .pathParams(pathParams)
                .body(automaticClassificationEntry)
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                .header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON)
                .when().put(PATH_ROOT)
                .then().statusCode(Response.Status.ACCEPTED.getStatusCode());
    }
}