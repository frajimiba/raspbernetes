package isom.appops.domain.model.dto;

import static org.junit.jupiter.api.Assertions.*;

import io.quarkus.test.junit.QuarkusTest;
import isom.appops.domain.utils.JsonToObjectsCreator;
import isom.appops.domain.utils.TestConstants;
import isom.appops.domain.utils.TestsUtility;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.time.OffsetDateTime;
import java.util.UUID;

@QuarkusTest
class AssignamentDTOTest extends JsonToObjectsCreator {

    private static final UUID uuidIssue = TestsUtility.getUuid(TestConstants.UUID_ASSIGNMENT_ISSUE_4);
    private static final OffsetDateTime now = TestsUtility.getOffsetDateTimeNow();

    @Test
    void testEquals() throws IOException {
        ManualClassificationDTO manualClassificationDTO = manualClassificationDTO();
        manualClassificationDTO.issueId(uuidIssue);
        AssignamentDTO assignamentDTO = new AssignamentDTO(
                TestConstants.USERNAME, TestConstants.GROUP_NAME,
                now, now, TestConstants.TEXT, uuidIssue);
        assertFalse(notEquals(assignamentDTO, manualClassificationDTO));
        assertEquals(assignamentDTO, assignamentDTO);
    }

    @Test
    void testHashCode() {
        AssignamentDTO assignamentDTO = new AssignamentDTO(
                TestConstants.USERNAME, TestConstants.GROUP_NAME,
                now, now, TestConstants.TEXT, uuidIssue);

        AssignamentDTO assignamentDTO2 = new AssignamentDTO();
        assignamentDTO2.userName(TestConstants.USERNAME);
        assignamentDTO2.groupName(TestConstants.GROUP_NAME);
        assignamentDTO2.tsInitial(now);
        assignamentDTO2.tsFinal(now);
        assignamentDTO2.text(TestConstants.TEXT);
        assignamentDTO2.issueId(uuidIssue);

        assertTrue(equals(assignamentDTO, assignamentDTO2));
        assertEquals(assignamentDTO.hashCode(), assignamentDTO2.hashCode());
    }

    @Test
    void testToString() {
        AssignamentDTO assignamentDTO = new AssignamentDTO(
                TestConstants.USERNAME,
                TestConstants.GROUP_NAME,
                now,
                now,
                TestConstants.TEXT,
                uuidIssue);

        AssignamentDTO assignamentDTO2 = new AssignamentDTO();
        assignamentDTO2.setUserName(TestConstants.USERNAME);
        assignamentDTO2.setGroupName(TestConstants.GROUP_NAME);
        assignamentDTO2.setTsInitial(now);
        assignamentDTO2.setTsFinal(now);
        assignamentDTO2.setText(TestConstants.TEXT);
        assignamentDTO2.setIssueId(uuidIssue);

        assertEquals(assignamentDTO.toString(), assignamentDTO2.toString());
    }

    private boolean notEquals(AssignamentDTO assignamentDTO, ManualClassificationDTO manualClassificationDTO) {
        return assignamentDTO.equals(manualClassificationDTO);
    }
    private boolean equals(AssignamentDTO assignamentDTO, AssignamentDTO assignamentDTO2) {
        return assignamentDTO.equals(assignamentDTO2) &&
                assignamentDTO.getUserName().equals(assignamentDTO2.getUserName()) &&
                assignamentDTO.getGroupName().equals(assignamentDTO2.getGroupName()) &&
                assignamentDTO.getTsInitial().equals(assignamentDTO2.getTsInitial()) &&
                assignamentDTO.getTsFinal().equals(assignamentDTO2.getTsFinal()) &&
                assignamentDTO.getText().equals(assignamentDTO2.getText()) &&
                assignamentDTO.getIssueId().equals(assignamentDTO2.getIssueId());
    }
}