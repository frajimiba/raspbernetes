package isom.appops.domain.services;

import static org.junit.jupiter.api.Assertions.*;

import io.quarkus.test.junit.QuarkusTest;
import org.junit.jupiter.api.Test;

import jakarta.inject.Inject;
import java.io.IOException;
import java.util.UUID;

import isom.appops.quarkus.errorhandler.exception.ApiBadRequestException;

import isom.appops.domain.model.entries.ManualClassificationEntry;
import isom.appops.domain.model.dto.ManualClassificationDTO;

import isom.appops.domain.utils.JsonToObjectsCreator;
import isom.appops.domain.utils.TestsUtility;
import isom.appops.domain.utils.TestConstants;


@QuarkusTest
class ManualClassificationServiceTest extends JsonToObjectsCreator {

    @Inject
    ManualClassificationService manualClassificationService;

    @Test
    void GivenUuidRandomAndEntryNotNull_WhenManualClassification_ThenApiBadRequestException() throws IOException {
        UUID randomUuid = TestsUtility.getRandomUuid();
        ManualClassificationEntry manualClassificationEntry =  manualClassificationEntry();

        Exception exception = assertThrows(ApiBadRequestException.class, () ->
                manualClassificationService.manualClassify(randomUuid, manualClassificationEntry)
        );

        String expectedMessage = TestConstants.ISSUE_NOT_FOUND;
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
    }

//    @Test
    void GivenUuidAndManualClassificationEntryNotNull_WhenManualClassification_ThenReturnsManualClassificationDTO() throws IOException {
        UUID uuidIssue = TestsUtility.getUuid(TestConstants.UUID_ASSIGNMENT_ISSUE_3);
        ManualClassificationEntry manualClassificationEntry =  manualClassificationEntry();

        ManualClassificationDTO manualClassificationDTO = manualClassificationService.manualClassify(uuidIssue, manualClassificationEntry);
        assertNotNull(manualClassificationDTO);
    }

    @Test
    void GivenUuidAndManualClassificationEntryNotNull_WhenCheckAndExecuteClassifitcationProcedure_ThenNothingReturn() throws IOException {
        UUID uuidIssue = TestsUtility.getUuid(TestConstants.UUID_ASSIGNMENT_ISSUE_3);
        ManualClassificationEntry manualClassificationEntry =  manualClassificationEntry();
        manualClassificationService.checkAndExecuteClassificationProcedure(uuidIssue, manualClassificationEntry);
        assertNotNull(manualClassificationEntry);
    }
}