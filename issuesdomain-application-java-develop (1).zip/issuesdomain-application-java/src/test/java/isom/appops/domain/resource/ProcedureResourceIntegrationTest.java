package isom.appops.domain.resource;

import static io.restassured.RestAssured.given;

import io.quarkus.test.junit.QuarkusTest;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.io.IOException;
import java.util.Map;

import isom.appops.domain.model.entries.ExecutionEntry;
import isom.appops.domain.model.entries.ProcedureEntry;
import isom.appops.domain.model.entries.ProceduresByClassificationsEntry;
import isom.appops.domain.utils.JsonToObjectsCreator;
import isom.appops.domain.utils.TestsUtility;

@QuarkusTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class ProcedureResourceIntegrationTest extends JsonToObjectsCreator {

    private static final String PATH_ROOT = "/procedures";
    private static final String PATH_GET_UPDATE_DELETE_PROCEDURE = "/procedures/{id}";
    private static final String PATH_EXECUTE_PROCEDURE = "/procedures/{id}/execute";
    private static final String PATH_FINISH_EXECUTE = "/procedures/{id}/finish-execution";
    private static final String PATH_RATING_PROCEDURE = "/procedures/{id}/rating";
    private static final String PATH_EXECUTIONS_PROCEDURE = "/procedures/{id}/executions";
    private static final String PATH_CLASSIFICATIONS_PROCEDURE = "/procedures/by-classification";
    private static final String PATH_CLASSIFICATIONS_RATING_PROCEDURE = "/procedures/by-classification-with-rating";
    private static final String PATH_PARAM_ID = "id";
    private static final Map<String, Long> pathParams = Map.of(PATH_PARAM_ID, 1L);

    @Test
    @Order(1)
    void GivenProcedureEntry_WhenAddProcedure_ThenReturnStatusOk() throws IOException {
        ProcedureEntry procedureEntry = procedureEntry();
        addProcedureEntry(procedureEntry);
    }

    @Test
    @Order(2)
    void GivenId_WhenGetProcedure_ThenReturnStatusOk() {
        given()
                .auth().preemptive().oauth2(TestsUtility.getToken())
                .pathParams(pathParams)
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                .header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON)
                .when().get(PATH_GET_UPDATE_DELETE_PROCEDURE)
                .then().statusCode(Response.Status.OK.getStatusCode());
    }

    @Test
    @Order(3)
    void GivenPageRequest_WhenListProcedures_ThenReturnStatusOk() {
        given()
                .auth().preemptive().oauth2(TestsUtility.getToken())
                .queryParams(TestsUtility.getPageRequestMap())
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                .header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON)
                .when().get(PATH_ROOT)
                .then().statusCode(Response.Status.OK.getStatusCode());
    }

    @Test
    @Order(4)
    void GivenProcedureId_WhenGetRating_ThenReturnsResponseOk(){
        given()
                .auth().preemptive().oauth2(TestsUtility.getToken())
                .pathParams(pathParams)
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                .header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON)
                .when().get(PATH_RATING_PROCEDURE)
                .then().statusCode(Response.Status.OK.getStatusCode());
    }

    @Test
    @Order(5)
    void GivenProceduresByClassificationsEntry_WhenGetProceduresByClassifications_ThenReturnsResponseOk() throws IOException {
        ProceduresByClassificationsEntry proceduresByClassificationsEntry = proceduresByClassificationsEntry();

        given()
                .auth().preemptive().oauth2(TestsUtility.getToken())
                .queryParams(TestsUtility.getPageRequestMap())
                .body(proceduresByClassificationsEntry)
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                .header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON)
                .when().post(PATH_CLASSIFICATIONS_PROCEDURE)
                .then().statusCode(Response.Status.OK.getStatusCode());
    }

    @Test
    @Order(6)
    void GivenProceduresByClassificationsEntry_WhenGetProceduresByClassificationsWithRating_ThenReturnsResponseOk() throws IOException {
        ProceduresByClassificationsEntry proceduresByClassificationsEntry = proceduresByClassificationsEntry();

        given()
                .auth().preemptive().oauth2(TestsUtility.getToken())
                .queryParams(TestsUtility.getPageRequestMap())
                .body(proceduresByClassificationsEntry)
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                .header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON)
                .when().post(PATH_CLASSIFICATIONS_RATING_PROCEDURE)
                .then().statusCode(Response.Status.OK.getStatusCode());
    }

    @Test
    @Order(7)
    void GivenProcedureIdAndProcedureEntry_WhenUpdateProcedure_ThenReturnsResponseOk() throws IOException {
        ProcedureEntry procedureEntry2 = procedureEntry2();
        addProcedureEntry(procedureEntry2);

        ProcedureEntry procedureEntryToUpdate = procedureEntryToUpdate();

        given()
                .auth().preemptive().oauth2(TestsUtility.getToken())
                .pathParams(PATH_PARAM_ID, 2L)
                .body(procedureEntryToUpdate)
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                .header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON)
                .when().put(PATH_GET_UPDATE_DELETE_PROCEDURE)
                .then().statusCode(Response.Status.OK.getStatusCode());
    }

//    @Test
//    @Order(8)
    void GivenProcedureIdAndExecutionEntry_WhenExecuteJenkinsProcedure_ThenReturnStatusOk() throws IOException {
        ExecutionEntry executionEntry = executionEntryProcedure();

        given()
                .auth().preemptive().oauth2(TestsUtility.getToken())
                .pathParams(PATH_PARAM_ID, 2L)
                .body(executionEntry)
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                .header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON)
                .when().post(PATH_EXECUTE_PROCEDURE)
                .then().statusCode(Response.Status.OK.getStatusCode());
    }

    @Test
    @Order(9)
    void GivenProcedureIdAndPageRequest_WhenGetExecutionsProcedure_ThenReturnStatusOk() {
        given()
                .auth().preemptive().oauth2(TestsUtility.getToken())
                .pathParams(pathParams)
                .queryParams(TestsUtility.getPageRequestMap())
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                .header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON)
                .when().get(PATH_EXECUTIONS_PROCEDURE)
                .then().statusCode(Response.Status.OK.getStatusCode());
    }

//    @Test
//    @Order(10)
    void GivenProcedureIdAndExecutionEntry_WhenFinishExecutionProcedure_ThenReturnStatusOk() throws IOException {
        ExecutionEntry executionEntry = executionEntryProcedure();

        given()
                .auth().preemptive().oauth2(TestsUtility.getToken())
                .pathParams(PATH_PARAM_ID, 2L)
                .body(executionEntry)
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                .header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON)
                .when().post(PATH_FINISH_EXECUTE)
                .then().statusCode(Response.Status.OK.getStatusCode());
    }

    @Test
    @Order(11)
    void GivenProcedureId_WhenDeleteProcedure_ThenReturnsResponseOk() {
        given()
                .auth().preemptive().oauth2(TestsUtility.getToken())
                .pathParams(PATH_PARAM_ID, 2L)
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                .header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON)
                .when().delete(PATH_GET_UPDATE_DELETE_PROCEDURE)
                .then().statusCode(Response.Status.OK.getStatusCode());
    }

    private void addProcedureEntry(ProcedureEntry procedureEntry){
        given()
                .auth().preemptive().oauth2(TestsUtility.getToken())
                .body(procedureEntry)
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                .header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON)
                .when().post(PATH_ROOT)
                .then().statusCode(Response.Status.OK.getStatusCode());
    }

}