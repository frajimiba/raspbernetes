package isom.appops.domain.resource;

import static io.restassured.RestAssured.given;

import io.quarkus.test.junit.QuarkusTest;
import org.junit.jupiter.api.Test;

import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;

import java.io.IOException;
import java.util.Map;
import java.util.UUID;

import isom.appops.domain.model.entries.FullIssueEntry;

import isom.appops.domain.utils.JsonToObjectsCreator;
import isom.appops.domain.utils.TestConstants;
import isom.appops.domain.utils.TestsUtility;

@QuarkusTest
class FullIssuesResourceIntegrationTest extends JsonToObjectsCreator {

    private static final String PATH_GET_FULL_ISSUE_ID = "/full-issues/{issueId}";
    private static final String PATH_GET_ADMIN_GROUPS = "/full-issues/admin/groups";
    private static final String PATH_GET_ISSUES_PENDING = "/full-issues/pending";
    private static final String PATH_GET_ISSUES_OWNED = "/full-issues/owned";
    private static final String PATH_GET_ISSUES_GROUPS = "/full-issues/groups";
    private static final String PATH_PARAM_ISSUE_ID = "issueId";
    private static final Map<String, UUID> pathParams = Map.of(PATH_PARAM_ISSUE_ID, TestsUtility.getUuid(TestConstants.UUID_ASSIGNMENT_ISSUE_4));

    @Test
    void GivenIssueId_WhenGetFullIssue_ThenReturnsResponseOk(){
        given()
                .auth().preemptive().oauth2(TestsUtility.getToken())
                .pathParams(pathParams)
                .body(TestConstants.STATUS_ASSIGNED)
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                .header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON)
                .when().get(PATH_GET_FULL_ISSUE_ID)
                .then().assertThat();
    }

    @Test
    void GivenFullIssueEntryAndPageRequest_WhenGetFullIssuesByAdminGroup_ThenReturnsResponseOk() throws IOException {
        FullIssueEntry fullIssueEntry = fullIssueEntry();

        given()
                .auth().preemptive().oauth2(TestsUtility.getToken())
                .queryParams(TestsUtility.getPageRequestMap())
                .body(fullIssueEntry)
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                .header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON)
                .when().post(PATH_GET_ADMIN_GROUPS)
                .then().assertThat();
    }

    @Test
    void GivenFullIssueEntryAndPageRequest_WhenGetFullIssuesPending_ThenReturnsResponseOk() throws IOException {
        FullIssueEntry fullIssueEntry = fullIssueEntry();

        given()
                .auth().preemptive().oauth2(TestsUtility.getToken())
                .queryParams(TestsUtility.getPageRequestMap())
                .body(fullIssueEntry)
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                .header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON)
                .when().post(PATH_GET_ISSUES_PENDING)
                .then().assertThat();
    }

    @Test
    void GivenFullIssueEntryAndPageRequest_WhenGetFullIssuesOwned_ThenReturnsResponseOk() throws IOException {
        FullIssueEntry fullIssueEntry = fullIssueEntry();

        given()
                .auth().preemptive().oauth2(TestsUtility.getToken())
                .queryParams(TestsUtility.getPageRequestMap())
                .body(fullIssueEntry)
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                .header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON)
                .when().post(PATH_GET_ISSUES_OWNED)
                .then().assertThat();
    }

    @Test
    void GivenFullIssueEntryAndPageRequest_WhenGetFullIssuesGroups_ThenReturnsResponseOk() throws IOException {
        FullIssueEntry fullIssueEntry = fullIssueEntry();

        given()
                .auth().preemptive().oauth2(TestsUtility.getToken())
                .queryParams(TestsUtility.getPageRequestMap())
                .body(fullIssueEntry)
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                .header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON)
                .when().post(PATH_GET_ISSUES_GROUPS)
                .then().assertThat();
    }
}