package isom.appops.domain.model.entries;

import static org.junit.jupiter.api.Assertions.*;

import io.quarkus.test.junit.QuarkusTest;
import isom.appops.domain.utils.JsonToObjectsCreator;
import isom.appops.domain.utils.TestConstants;
import isom.appops.domain.utils.TestsUtility;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.time.OffsetDateTime;
import java.util.UUID;

@QuarkusTest
class SlaBreachTimeEntryTest extends JsonToObjectsCreator {
    
    private static final UUID uuidIssue = TestsUtility.getUuid(TestConstants.UUID_ASSIGNMENT_ISSUE_4);
    private static final OffsetDateTime now = TestsUtility.getOffsetDateTimeNow();

    @Test
    void testEquals() throws IOException {
        AssignmentEntry assignmentEntry = assignmentEntry();
        SlaBreachTimeEntry slaBreachTimeEntry = new SlaBreachTimeEntry(uuidIssue, now);
        assertFalse(notEquals(slaBreachTimeEntry, assignmentEntry));
        assertEquals(slaBreachTimeEntry, slaBreachTimeEntry);
        assertEquals(uuidIssue, slaBreachTimeEntry.getIssueId());
        assertEquals(now, slaBreachTimeEntry.getSlaBreachTime());
    }

    @Test
    void testHashCode() {
        SlaBreachTimeEntry slaBreachTimeEntry = new SlaBreachTimeEntry(uuidIssue, now);
        SlaBreachTimeEntry slaBreachTimeEntry2 = new SlaBreachTimeEntry();
        slaBreachTimeEntry2.issueId(uuidIssue);
        slaBreachTimeEntry2.slaBreachTime(now);
        assertTrue(equals(slaBreachTimeEntry, slaBreachTimeEntry2));
        assertEquals(slaBreachTimeEntry.hashCode(), slaBreachTimeEntry2.hashCode());
    }

    @Test
    void testToString() {
        SlaBreachTimeEntry slaBreachTimeEntry = new SlaBreachTimeEntry(uuidIssue, now);
        SlaBreachTimeEntry slaBreachTimeEntry2 = new SlaBreachTimeEntry();
        slaBreachTimeEntry2.setIssueId(uuidIssue);
        slaBreachTimeEntry2.slaBreachTime(now);
        assertEquals(slaBreachTimeEntry.toString(), slaBreachTimeEntry2.toString());
    }

    private boolean notEquals(SlaBreachTimeEntry slaBreachTimeEntry, AssignmentEntry assignmentEntry) {
        return slaBreachTimeEntry.equals(assignmentEntry);
    }

    private boolean equals(SlaBreachTimeEntry slaBreachTimeEntry, SlaBreachTimeEntry slaBreachTimeEntry2) {
        return slaBreachTimeEntry.equals(slaBreachTimeEntry2) &&
                slaBreachTimeEntry.getIssueId().equals(slaBreachTimeEntry2.getIssueId()) &&
                slaBreachTimeEntry.getSlaBreachTime().equals(slaBreachTimeEntry2.getSlaBreachTime());
    }
}