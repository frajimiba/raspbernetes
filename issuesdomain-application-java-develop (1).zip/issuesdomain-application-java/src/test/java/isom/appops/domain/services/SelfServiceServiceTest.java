package isom.appops.domain.services;

import io.quarkus.test.junit.QuarkusTest;

import jakarta.inject.Inject;

import static io.smallrye.common.constraint.Assert.assertNotNull;

@QuarkusTest
class SelfServiceServiceTest {

    @Inject
    SelfServiceService selfServiceService;

//    @Test
    void GivenTemplateIdAndJsonForm_WhenSubmitForm_ThenReturnsJobId(){
        String jsonForm = "{\"extra_vars\":\"traceId\"}";
        int job = selfServiceService.submitForm(1, jsonForm);
        assertNotNull(job);
    }

}