package isom.appops.domain.resource;

import io.quarkus.test.junit.QuarkusTest;

@QuarkusTest
public class SlaResourceTest {


}
