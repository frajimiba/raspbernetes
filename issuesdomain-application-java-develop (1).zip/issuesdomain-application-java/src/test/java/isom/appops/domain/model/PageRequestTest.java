package isom.appops.domain.model;

import static io.smallrye.common.constraint.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

import isom.appops.domain.utils.TestConstants;
import io.quarkus.test.junit.QuarkusTest;
import org.junit.jupiter.api.Test;

@QuarkusTest
class PageRequestTest {

    @Test
    void GivenPageRequest_WhenSetAttributesPageRequest_ThenReturnsAttributes(){
        PageRequest page = new PageRequest();
        page.setSize(1);
        page.setSort(TestConstants.CONST_STRING);
        page.setAscending(true);

        assertEquals(1, page.getSize());
        assertEquals(TestConstants.CONST_STRING, page.getSort());
        assertTrue(page.isAscending());
    }

}