package isom.appops.domain.model.dto;

import static io.smallrye.common.constraint.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import io.quarkus.test.junit.QuarkusTest;
import isom.appops.domain.utils.TestConstants;
import org.junit.jupiter.api.Test;

@QuarkusTest
class UrlDTOTest {

    @Test
    void GivenUrlDTO_WhenSetAttributes_ThenReturnsAttributes(){
        UrlDTO urlDTO = new UrlDTO();
        urlDTO.setUrl(TestConstants.CONST_STRING);
        assertNotNull(urlDTO);
        assertEquals(TestConstants.CONST_STRING, urlDTO.getUrl());

        UrlDTO urlDTO2 = new UrlDTO(TestConstants.CONST_STRING);
        assertNotNull(urlDTO2);
        assertEquals(TestConstants.CONST_STRING, urlDTO2.getUrl());
    }
}