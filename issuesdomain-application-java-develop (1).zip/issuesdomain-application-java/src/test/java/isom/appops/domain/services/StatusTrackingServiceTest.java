package isom.appops.domain.services;

import static io.smallrye.common.constraint.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import io.quarkus.test.junit.QuarkusTest;
import org.junit.jupiter.api.Test;

import jakarta.inject.Inject;
import jakarta.transaction.Transactional;

import java.io.IOException;
import java.net.URISyntaxException;

import java.util.List;
import java.util.UUID;

import isom.appops.database.entities.IssueEntity;

import isom.appops.domain.model.dto.StatusTrackingDTO;
import isom.appops.domain.utils.JsonToObjectsCreator;
import isom.appops.domain.utils.TestConstants;
import isom.appops.domain.utils.TestsUtility;

import isom.appops.ticketentry.model.TicketEntry;

@QuarkusTest
class StatusTrackingServiceTest extends JsonToObjectsCreator {

    @Inject
    StatusTrackingService statusTrackingService;

    @Test
    void GivenUuidIssue_WhenGetStatus_ThenReturnsStatusTrackingDtoList(){
        UUID uuidIssue = TestsUtility.getUuid(TestConstants.UUID_ASSIGNMENT_ISSUE);
        List<StatusTrackingDTO> listStatusTrackingDto = statusTrackingService.getStatuses(uuidIssue);
        StatusTrackingDTO statusTrackingDTO = listStatusTrackingDto.get(0);
        assertNotNull(listStatusTrackingDto);
        assertEquals(2, listStatusTrackingDto.size());
        assertEquals(6, statusTrackingDTO.getId());
        assertEquals(TestConstants.STATUS_ASSIGNED, statusTrackingDTO.getStatus());
        assertEquals(TestConstants.UUID_ASSIGNMENT_ISSUE, statusTrackingDTO.getIssueId().toString());
    }

    @Test
    @Transactional
    void GivenUuidIssueAndNewStatus_WhenAddTicketEntryIntoIssue_ThenReturnsStatusTrackingDTO() throws IOException, URISyntaxException {
        IssueEntity issueEntity = issueEntity();
        TicketEntry ticketEntry = ticketEntryOk();
        StatusTrackingDTO statusTrackingDTO = statusTrackingService.add(issueEntity, ticketEntry);
        assertNotNull(statusTrackingDTO);
        assertEquals(7, statusTrackingDTO.getId());
        assertEquals(TestConstants.STATUS_UNASSIGNED, statusTrackingDTO.getStatus());
        assertEquals(TestConstants.UUID_ASSIGNMENT_ISSUE, statusTrackingDTO.getIssueId().toString());
    }

    @Test
    @Transactional
    void GivenUuidAndStatus_WhenAddStatusIntoIssue_ThenReturnsStatusTrackingDTO() {
        UUID uuid = TestsUtility.getUuid(TestConstants.UUID_ASSIGNMENT_ISSUE);
        StatusTrackingDTO statusTrackingDTO = statusTrackingService.add(uuid, TestConstants.STATUS_ASSIGNED);
        assertNotNull(statusTrackingDTO);
        assertNotEquals(TestConstants.STATUS_UNASSIGNED, statusTrackingDTO.getStatus());
        assertEquals(TestConstants.STATUS_ASSIGNED, statusTrackingDTO.getStatus());
    }
}