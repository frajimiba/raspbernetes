--------------------------------------------------------
--  DDL FOR INDEX SYS_C008774
--------------------------------------------------------

CREATE UNIQUE INDEX "PK_ASSIGNAMENT" ON "ASSIGNAMENT" ("ID");
--------------------------------------------------------
--  DDL FOR INDEX SYS_C008779
--------------------------------------------------------

CREATE UNIQUE INDEX "PK_EXECUTIONS" ON "EXECUTIONS" ("ID");
--------------------------------------------------------
--  DDL FOR INDEX SYS_C008782
--------------------------------------------------------

CREATE UNIQUE INDEX "PK_FEEDBACKS_ID" ON "FEEDBACKS" ("ID");
--------------------------------------------------------
--  DDL FOR INDEX SYS_C008783
--------------------------------------------------------

CREATE UNIQUE INDEX "PK_FEEDBACKS_EXECUTIONREF" ON "FEEDBACKS" ("EXECUTIONREF");
--------------------------------------------------------
--  DDL FOR INDEX SYS_C008787
--------------------------------------------------------

CREATE UNIQUE INDEX "PK_ISSUE" ON "ISSUE" ("ID");
--------------------------------------------------------
--  DDL FOR INDEX SYS_C008792
--------------------------------------------------------

CREATE UNIQUE INDEX "PK_MANUAL_CLASSIFICATION" ON "MANUAL_CLASSIFICATION" ("ID");
--------------------------------------------------------
--  DDL FOR INDEX SYS_C008795
--------------------------------------------------------

CREATE UNIQUE INDEX "PK_PROCEDURES" ON "PROCEDURES" ("ID");
--------------------------------------------------------
--  DDL FOR INDEX SYS_C008800
--------------------------------------------------------

CREATE UNIQUE INDEX "PK_STATUS_TRACKING" ON "STATUS_TRACKING" ("ID");
--------------------------------------------------------
--  DDL FOR INDEX SYS_C008803
--------------------------------------------------------

CREATE UNIQUE INDEX "PK_TROUBLESHOOTINGS" ON "TROUBLESHOOTINGS" ("ID");