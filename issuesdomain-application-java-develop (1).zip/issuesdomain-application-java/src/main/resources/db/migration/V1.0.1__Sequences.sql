--------------------------------------------------------
--  DDL FOR SEQUENCE SEQ_ASSIGNAMENT
--------------------------------------------------------

CREATE SEQUENCE  "ASSIGNAMENT_ID_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1;
--------------------------------------------------------
--  DDL FOR SEQUENCE SEQ_EXECUTION
--------------------------------------------------------

CREATE SEQUENCE  "EXECUTIONS_ID_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1;
--------------------------------------------------------
--  DDL FOR SEQUENCE SEQ_FEEDBACK
--------------------------------------------------------

CREATE SEQUENCE  "FEEDBACKS_ID_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1;
--------------------------------------------------------
--  DDL FOR SEQUENCE SEQ_MANUALCLASSIFICATION
--------------------------------------------------------

CREATE SEQUENCE  "MANUAL_CLASSIFICATION_ID_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1;
--------------------------------------------------------
--  DDL FOR SEQUENCE SEQ_PROCEDURE
--------------------------------------------------------

CREATE SEQUENCE  "PROCEDURES_ID_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1;
--------------------------------------------------------
--  DDL FOR SEQUENCE SEQ_STATUSTRACKING
--------------------------------------------------------

CREATE SEQUENCE  "STATUS_TRACKING_ID_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1;
--------------------------------------------------------
--  DDL FOR SEQUENCE SEQ_TROUBLESHOOTING
--------------------------------------------------------

CREATE SEQUENCE  "TROUBLESHOOTINGS_ID_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1;