
--------------------------------------------------------
--  CONSTRAINTS FOR TABLE ASSIGNAMENT
--------------------------------------------------------

ALTER TABLE "ASSIGNAMENT" ADD PRIMARY KEY ("ID");

--------------------------------------------------------
--  CONSTRAINTS FOR TABLE EXECUTIONS
--------------------------------------------------------

ALTER TABLE "EXECUTIONS" ADD PRIMARY KEY ("ID");
--------------------------------------------------------
--  CONSTRAINTS FOR TABLE FEEDBACKS
--------------------------------------------------------

ALTER TABLE "FEEDBACKS" ADD PRIMARY KEY ("ID");
ALTER TABLE "FEEDBACKS" ADD UNIQUE ("EXECUTIONREF");

--------------------------------------------------------
--  CONSTRAINTS FOR TABLE ISSUE
--------------------------------------------------------

ALTER TABLE "ISSUE" ADD PRIMARY KEY ("ID");
--------------------------------------------------------
--  CONSTRAINTS FOR TABLE MANUAL_CLASSIFICATION
--------------------------------------------------------

ALTER TABLE "MANUAL_CLASSIFICATION" ADD PRIMARY KEY ("ID");
--------------------------------------------------------
--  CONSTRAINTS FOR TABLE PROCEDURES
--------------------------------------------------------

ALTER TABLE "PROCEDURES" ADD CHECK ("AUTOMATIC" IN (0,1)) ENABLE;
ALTER TABLE "PROCEDURES" ADD PRIMARY KEY ("ID");
--------------------------------------------------------
--  CONSTRAINTS FOR TABLE STATUS_TRACKING
--------------------------------------------------------

ALTER TABLE "STATUS_TRACKING" ADD PRIMARY KEY ("ID");
--------------------------------------------------------
--  CONSTRAINTS FOR TABLE TROUBLESHOOTINGS
--------------------------------------------------------

ALTER TABLE "TROUBLESHOOTINGS" ADD PRIMARY KEY ("ID");
--------------------------------------------------------
--  REF CONSTRAINTS FOR TABLE ASSIGNAMENT
--------------------------------------------------------

ALTER TABLE "ASSIGNAMENT" ADD CONSTRAINT "FK_ISSUE_ASSIGNAMENT" FOREIGN KEY ("ISSUE") REFERENCES "ISSUE" ("ID") ENABLE;
--------------------------------------------------------
--  REF CONSTRAINTS FOR TABLE EXECUTIONPARAMETERS
--------------------------------------------------------

ALTER TABLE "EXECUTIONPARAMETERS" ADD CONSTRAINT "FK_EXECUTIONENTITY_EXECUTIONPARAMETERS" FOREIGN KEY ("EXECUTIONENTITY_ID") REFERENCES "EXECUTIONS" ("ID") ENABLE;
--------------------------------------------------------
--  REF CONSTRAINTS FOR TABLE EXECUTIONS
--------------------------------------------------------

ALTER TABLE "EXECUTIONS" ADD CONSTRAINT "FK_ISSUE_EXECUTIONS" FOREIGN KEY ("ISSUEREF") REFERENCES "ISSUE" ("ID") ENABLE;
ALTER TABLE "EXECUTIONS" ADD CONSTRAINT "FK_PROCEDURES_EXECUTIONS" FOREIGN KEY ("PROCEDUREREF") REFERENCES "PROCEDURES" ("ID") ENABLE;
--------------------------------------------------------
--  REF CONSTRAINTS FOR TABLE FEEDBACKS
--------------------------------------------------------

ALTER TABLE "FEEDBACKS" ADD CONSTRAINT "FK_EXECUTIONREF_FEEDBACKS" FOREIGN KEY ("EXECUTIONREF") REFERENCES "EXECUTIONS" ("ID") ENABLE;
--------------------------------------------------------
--  REF CONSTRAINTS FOR TABLE MANUAL_CLASSIFICATION
--------------------------------------------------------

ALTER TABLE "MANUAL_CLASSIFICATION" ADD CONSTRAINT "FK_ISSUE_MANUAL_CLASSIFICATION" FOREIGN KEY ("ISSUE") REFERENCES "ISSUE" ("ID") ENABLE;
--------------------------------------------------------
--  REF CONSTRAINTS FOR TABLE STATUS_TRACKING
--------------------------------------------------------

ALTER TABLE "STATUS_TRACKING" ADD CONSTRAINT "FK_ISSUE_STATUS_TRACKING" FOREIGN KEY ("ISSUE") REFERENCES "ISSUE" ("ID") ENABLE;
--------------------------------------------------------
--  REF CONSTRAINTS FOR TABLE TROUBLESHOOTINGS
--------------------------------------------------------

ALTER TABLE "TROUBLESHOOTINGS" ADD CONSTRAINT "FK_ISSUE_TROUBLESHOOTINGS" FOREIGN KEY ("ISSUE") REFERENCES "ISSUE" ("ID") ENABLE;


