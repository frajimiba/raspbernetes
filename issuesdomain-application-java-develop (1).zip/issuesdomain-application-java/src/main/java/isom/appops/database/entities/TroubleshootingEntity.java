package isom.appops.database.entities;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;

import jakarta.persistence.*;
import java.time.OffsetDateTime;

@Entity
@Table(name = "TROUBLESHOOTINGS")
@NamedQueries({
    @NamedQuery(name = "TroubleshootingEntity.findByIssueId", query = "Select pr FROM TroubleshootingEntity as pr WHERE pr.issue.id = :issueId"),
})
public class TroubleshootingEntity extends PanacheEntityBase {

    @Id
    @GeneratedValue(
            strategy = GenerationType.SEQUENCE,
            generator = "seq_troubleshooting"
    )
    @SequenceGenerator(
            name = "seq_troubleshooting",sequenceName = "TROUBLESHOOTINGS_ID_SEQ", allocationSize = 1, initialValue = 1)

    private Long id;

    @Column(name = "USERID")
    private String userId;

    @Lob
    @Column(name = "CONTENT")
    private String content;

    @ManyToOne(optional = false, cascade = CascadeType.PERSIST, fetch = FetchType.EAGER)
    @JoinColumn(name="issue", nullable=false)
    private IssueEntity issue;

    @Column(name = "CREATIONDATE")
    private OffsetDateTime creationDate;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public IssueEntity getIssue() {
        return issue;
    }

    public void setIssue(IssueEntity issue) {
        this.issue = issue;
    }

    public OffsetDateTime getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(OffsetDateTime creationDate) {
        this.creationDate = creationDate;
    }
}
