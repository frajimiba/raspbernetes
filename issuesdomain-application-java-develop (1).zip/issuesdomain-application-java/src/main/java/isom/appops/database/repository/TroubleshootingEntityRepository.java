package isom.appops.database.repository;

import isom.appops.database.entities.TroubleshootingEntity;
import io.quarkus.hibernate.orm.panache.PanacheRepository;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.persistence.TypedQuery;
import java.util.List;
import java.util.UUID;

@ApplicationScoped
public class TroubleshootingEntityRepository implements PanacheRepository<TroubleshootingEntity> {
	   
    public List<TroubleshootingEntity> findByIssueId(UUID issueId){
        try {
            TypedQuery<TroubleshootingEntity> query = getEntityManager().createNamedQuery("TroubleshootingEntity.findByIssueId", TroubleshootingEntity.class);
            query.setParameter("issueId", issueId);
            return query.getResultList();
        } catch (Exception exception){
            throw new RuntimeException(exception);
        }
    }

}