package isom.appops.database.entities;

import java.time.OffsetDateTime;

import jakarta.persistence.*;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;

@Entity
@Table(name = "ASSIGNAMENT")
@NamedQueries({
    @NamedQuery(name = "AssignamentEntity.findByAssignedUser", query = "from AssignamentEntity where userName = ?1"),
    @NamedQuery(name = "AssignamentEntity.findByAssignedUsers", query = "from AssignamentEntity where userName in (:userNames)"),
    @NamedQuery(name = "AssignamentEntity.findByAssignedUsersAndStatuses", query = "SELECT ae FROM AssignamentEntity AS ae WHERE (ae.userName IN (:userNames)) AND ((SELECT ste.status FROM StatusTrackingEntity AS ste WHERE ste.issue.id = ae.issue.id AND ste.tsInitial = (SELECT MAX(ae2.tsInitial) FROM AssignamentEntity as ae2 WHERE ae2.issue.id = ste.issue.id)) IN (:statuses))"),
	@NamedQuery(name = "AssignamentEntity.findAllAssignmentsByIssueId", query = "Select ae FROM AssignamentEntity as ae WHERE ae.issue.id = :issueId ORDER BY ae.tsInitial DESC"),
	@NamedQuery(name = "AssignamentEntity.findAssignmentsByIssueId", query = "Select ae FROM AssignamentEntity as ae WHERE ae.tsInitial = (SELECT MAX(ae2.tsInitial) FROM AssignamentEntity as ae2 WHERE ae.id = ae2.id) AND ae.issue.id = :issueId ORDER BY ae.tsInitial DESC"),
	@NamedQuery(name = "AssignamentEntity.countAssignmentsByIssueId", query = "Select COUNT(ae) FROM AssignamentEntity as ae WHERE ae.userName = :userId AND ae.tsInitial = (SELECT MAX(ae2.tsInitial) FROM AssignamentEntity as ae2 WHERE ae.issue.id = ae2.issue.id)")
})
public class AssignamentEntity extends PanacheEntityBase {

	@Id
	@GeneratedValue(
			strategy = GenerationType.SEQUENCE,
			generator = "seq_assignament"
	)
	@SequenceGenerator(
			name = "seq_assignament", sequenceName = "ASSIGNAMENT_ID_SEQ", allocationSize = 1, initialValue = 1)

	private Long id;

	@Column(name = "USERNAME", nullable=false)
	private String userName;

	@Column(name = "GROUPNAME", nullable=false)
	private String groupName;
	
	@Column(name = "TSINITIAL", nullable=false)
	private OffsetDateTime tsInitial;

	@Column(name = "TSFINAL")
	private OffsetDateTime tsFinal;
	
	@Column(name = "TEXT")
	private String text;
	
	@ManyToOne(optional = false, cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name="issue", nullable=false)	
	private IssueEntity issue;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUserName() {
		return this.userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getGroupName() {
		return this.groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public OffsetDateTime getTsInitial() {
		return this.tsInitial;
	}

	public void setTsInitial(OffsetDateTime tsInitial) {
		this.tsInitial = tsInitial;
	}

	public OffsetDateTime getTsFinal() {
		return this.tsFinal;
	}

	public void setTsFinal(OffsetDateTime tsFinal) {
		this.tsFinal = tsFinal;
	}

	public String getText() {
		return this.text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public IssueEntity getIssue() {
		return this.issue;
	}

	public void setIssue(IssueEntity issue) {
		this.issue = issue;
	}
	
	
}