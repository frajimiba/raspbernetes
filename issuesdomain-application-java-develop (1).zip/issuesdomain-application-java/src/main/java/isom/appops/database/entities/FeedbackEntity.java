package isom.appops.database.entities;

import java.time.OffsetDateTime;

import jakarta.persistence.*;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;

@Entity
@Table(name = "FEEDBACKS")
@NamedQueries({
        @NamedQuery(name = "FeedbackEntity.findAllByExecutionId", query = "Select fb FROM FeedbackEntity as fb WHERE fb.executionRef.id = :executionId ORDER BY fb.id ASC"),
        @NamedQuery(name = "FeedbackEntity.getAllByProcedureId", query = "Select fb FROM FeedbackEntity as fb WHERE fb.executionRef.procedureRef.id = :procedureId ORDER BY fb.id ASC"),
        @NamedQuery(name = "FeedbackEntity.deleteAllByProcedureId", query = "DELETE FROM FeedbackEntity as fb WHERE fb.executionRef.id IN (SELECT id FROM ExecutionEntity as ee WHERE ee.procedureRef.id = :procedureId)")
})
public class FeedbackEntity extends PanacheEntityBase {

    @Id
    @GeneratedValue(
            strategy = GenerationType.SEQUENCE,
            generator = "seq_feedback"
    )
    @SequenceGenerator(
            name = "seq_feedback",sequenceName = "FEEDBACKS_ID_SEQ", allocationSize = 1, initialValue = 1)
    private Long id;

    @Column(name = "STARS")
    private int stars;
    
    @Column(name = "COMMENTS")
    private String comments;
    
    @Column(name = "USERID")
    private String userId;
    
    @Column(name = "CREATIONDATE")
    private OffsetDateTime creationDate;
    
	@OneToOne(optional = false, cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name="executionref", nullable=false)
	private ExecutionEntity executionRef;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public int getStars() {
        return this.stars;
    }

    public void setStars(int stars) {
        this.stars = stars;
    }

    public String getComments() {
        return this.comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public String getUserId() {
        return this.userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public OffsetDateTime getCreationDate() {
        return this.creationDate;
    }

    public void setCreationDate(OffsetDateTime creationDate) {
        this.creationDate = creationDate;
    }

    public ExecutionEntity getExecutionRef() {
        return this.executionRef;
    }

    public void setExecutionRef(ExecutionEntity executionRef) {
        this.executionRef = executionRef;
    }

    
}
