package isom.appops.database.repository;

import java.util.UUID;

import jakarta.enterprise.context.ApplicationScoped;

import isom.appops.database.entities.IssueEntity;
import isom.appops.quarkus.data.PagedResult;

import io.quarkus.hibernate.orm.panache.PanacheQuery;
import io.quarkus.hibernate.orm.panache.PanacheRepositoryBase;
import io.quarkus.panache.common.Page;
import io.quarkus.panache.common.Sort;

@ApplicationScoped
public class IssueEntityRepository implements PanacheRepositoryBase<IssueEntity, UUID> {

    public PagedResult<IssueEntity> findBy(Page page, Sort sort) {
        PanacheQuery<IssueEntity> query = findAll(sort);
        query.page(page);
        return PagedResult.of(query);
    }


}