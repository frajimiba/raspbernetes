package isom.appops.database.entities;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import jakarta.persistence.*;

import java.time.OffsetDateTime;

@Entity
@Table(name = "EXECUTION_TEMPLATES")
@NamedQueries({
    @NamedQuery(name = "ExecutionTemplateEntity.findByExecutionByIdAndName", query = "Select ae FROM ExecutionTemplateEntity as ae WHERE ae.templateId = :templateId AND ae.templateName = :templateName"),
})
public class ExecutionTemplateEntity extends PanacheEntityBase {

    @Id
    @GeneratedValue(
            strategy = GenerationType.SEQUENCE,
            generator = "seq_execution_template"
    )
    @SequenceGenerator(
            name = "seq_execution_template",sequenceName = "EXECUTION_TEMPLATES_ID_SEQ", allocationSize = 1, initialValue = 1)
    private Long id;

    @Column(name = "TEMPLATE_NAME")
    private String templateName;

    @Column(name = "TEMPLATE_TYPE")
    private String templateType;

    @Column(name = "TEMPLATE_ID")
    private String templateId;

    @Lob
    @Column(name = "TEMPLATE_CONFIG")
    private String templateConfig;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "CREATION_DATE")
    private OffsetDateTime creationDate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTemplateName() {
        return templateName;
    }

    public void setTemplateName(String templateName) {
        this.templateName = templateName;
    }

    public String getTemplateType() {
        return templateType;
    }

    public void setTemplateType(String templateType) {
        this.templateType = templateType;
    }

    public String getTemplateId() {
        return templateId;
    }

    public void setTemplateId(String templateId) {
        this.templateId = templateId;
    }

    public String getTemplateConfig() {
        return templateConfig;
    }

    public void setTemplateConfig(String templateConfig) {
        this.templateConfig = templateConfig;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public OffsetDateTime getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(OffsetDateTime creationDate) {
        this.creationDate = creationDate;
    }
}
