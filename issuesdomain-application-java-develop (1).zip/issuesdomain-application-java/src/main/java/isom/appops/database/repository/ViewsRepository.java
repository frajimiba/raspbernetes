package isom.appops.database.repository;

import isom.appops.database.entities.ExecutionEntity;
import isom.appops.database.entities.ProcedureEntity;
import isom.appops.domain.mappers.ExecutionMapper;
import isom.appops.domain.mappers.ProcedureMapper;
import isom.appops.domain.model.PageRequest;
import isom.appops.domain.model.dto.ExecutionDTO;
import isom.appops.domain.model.dto.ProcedureDTO;
import isom.appops.domain.model.dto.ProcedureRatingDTO;
import isom.appops.quarkus.data.PagedResult;
import io.quarkus.hibernate.orm.panache.PanacheQuery;
import io.quarkus.panache.common.Page;
import io.quarkus.panache.common.Parameters;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import jakarta.persistence.TypedQuery;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@ApplicationScoped
public class ViewsRepository {

    @Inject
    ProcedureEntityRepository procedureEntityRepository;

    @Inject
    FeedbackEntityRepository feedbackEntityRepository;

    @Inject
    ExecutionEntityRepository executionEntityRepository;

    @Inject
    EntityManager entityManager;

    @Inject
    ProcedureMapper procedureMapper;

    @Inject
    ExecutionMapper executionMapper;

    public Long getAmountIssuesAssignedToUsers(List<String> users, List<String> statuses) {

        String querySQL =
                "SELECT ISS.ID AS ID " +
                        "FROM ISSUE ISS\n" +
                        "FULL OUTER JOIN\n" +
                        "   MANUAL_CLASSIFICATION MC ON\n" +
                        "   ISS.ID= MC.ISSUE AND MC.ID=(SELECT MAX(ID) FROM MANUAL_CLASSIFICATION WHERE ISSUE=ISS.ID)\n" +
                        "FULL OUTER JOIN\n" +
                        "   ASSIGNAMENT ASS ON\n" +
                        "   ISS.ID= ASS.ISSUE AND ASS.ID=(SELECT MAX(ID) FROM ASSIGNAMENT WHERE ISSUE=ISS.ID)\n" +
                        "FULL OUTER JOIN\n" +
                        "   STATUS_TRACKING STR ON\n" +
                        "   ISS.ID= STR.ISSUE AND STR.ID=(SELECT MAX(ID) FROM STATUS_TRACKING WHERE ISSUE=ISS.ID)\n" +
                        "WHERE ISS.ID IS NOT NULL" +
                        " AND (STR.STATUS IN (:statuses)) " +
                        " AND (ASS.USERNAME IN (:users))";

        try {
            Query queryCount = entityManager.createNativeQuery("SELECT COUNT(*) FROM (" + querySQL + ")");
            queryCount.setParameter("users", users);
            queryCount.setParameter("statuses", statuses);


            Long maxResults = Long.valueOf(queryCount.getSingleResult().toString());

            return maxResults;
        } catch (Exception exception){
            throw new RuntimeException(exception);
        }
    }

    public ProcedureDTO getFirstProcedureByClassification(String classification) {
        PagedResult<ProcedureDTO> procedures = this.getProceduresByClassifications(List.of(classification), new PageRequest(0, 1, "id", true));
        if (procedures.getNumOfResults() == 0L){
            return null;
        }
        return procedures.getList().get(0);
    }

    public PagedResult<ProcedureDTO> getProceduresByClassifications(List<String> classifications, PageRequest pageRequest) {

        PanacheQuery<ProcedureEntity> query = procedureEntityRepository.find("#ProcedureEntity.findByClassification", Parameters.with("classifications", classifications));
        query.page(Page.of(pageRequest.page, pageRequest.size));
        PagedResult<ProcedureEntity> procedures = PagedResult.of(query);

        List<ProcedureDTO> dtos = procedures.getList().stream().map((entity) -> procedureMapper.toDTO(entity)).collect(Collectors.toList());

        PagedResult<ProcedureDTO> paged = new PagedResult<ProcedureDTO>();
        paged.setNumOfResults(procedures.getNumOfResults());
        paged.setList(dtos);
        paged.setPage(pageRequest.page);
        paged.setSize(pageRequest.size);

        return paged;
    }

    public PagedResult<ProcedureRatingDTO> getProceduresByClassificationsWithRating(List<String> classifications, PageRequest pageRequest) {

        PanacheQuery<ProcedureEntity> query = procedureEntityRepository.find("#ProcedureEntity.findByClassification", Parameters.with("classifications", classifications));
        query.page(Page.of(pageRequest.page, pageRequest.size));
        PagedResult<ProcedureEntity> procedures = PagedResult.of(query);

        List<ProcedureRatingDTO> dtos = procedures.getList()
                .stream()
                .map((entity) -> {
                    ProcedureRatingDTO ratingDTO = procedureMapper.toRatingDTO(entity);
                    ratingDTO.setRating(feedbackEntityRepository.getProcedureRating(entity.getId()));
                    return ratingDTO;
                })
                .collect(Collectors.toList());

        PagedResult<ProcedureRatingDTO> paged = new PagedResult<ProcedureRatingDTO>();
        paged.setNumOfResults(procedures.getNumOfResults());
        paged.setList(dtos);
        paged.setPage(pageRequest.page);
        paged.setSize(pageRequest.size);

        return paged;
    }

    public PagedResult<ExecutionDTO> getExecutionsByIssueId(UUID issueId, PageRequest pageRequest) {
        PanacheQuery<ExecutionEntity> query = executionEntityRepository.find("#ExecutionEntity.findAllByIssueId", Parameters.with("issueId", issueId));
        query.page(Page.of(pageRequest.page, pageRequest.size));
        PagedResult<ExecutionEntity> executions = PagedResult.of(query);

        List<ExecutionDTO> dtos = executions.getList()
                .stream()
                .map((entity) -> {
                    ExecutionDTO executionDTO = executionMapper.toDTO(entity);
                    return executionDTO;
                })
                .collect(Collectors.toList());

        PagedResult<ExecutionDTO> paged = new PagedResult<ExecutionDTO>();
        paged.setNumOfResults(executions.getNumOfResults());
        paged.setList(dtos);
        paged.setPage(pageRequest.page);
        paged.setSize(pageRequest.size);

        return paged;
    }


}
