package isom.appops.database.entities;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.*;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import org.hibernate.annotations.Cascade;

@Entity
@Table(name = "EXECUTIONS")
@NamedQueries({
        @NamedQuery(name = "ExecutionEntity.findAllByIssueId", query = "Select ae FROM ExecutionEntity as ae WHERE ae.issueRef.id = :issueId"),
        @NamedQuery(name = "ExecutionEntity.findAllByProcedureId", query = "Select ae FROM ExecutionEntity as ae WHERE ae.procedureRef.id = :procedureId"),
        @NamedQuery(name = "ExecutionEntity.deleteAllByProcedureId", query = "DELETE FROM ExecutionEntity as ae WHERE ae.procedureRef.id = :procedureId")
})
@NamedNativeQueries({
        @NamedNativeQuery(name = "ExecutionEntity.deleteParamsByProcedureId", query = "DELETE FROM executionParameters as ep WHERE ep.ExecutionEntity_id IN (SELECT id FROM executions WHERE executions.procedureRef = :procedureId)")
})
public class ExecutionEntity extends PanacheEntityBase {

    @Id
    @GeneratedValue(
            strategy = GenerationType.SEQUENCE,
            generator = "seq_execution"
    )
    @SequenceGenerator(
            name = "seq_execution",sequenceName = "EXECUTIONS_ID_SEQ", allocationSize = 1, initialValue = 1)

    private Long id;

    @Column(name = "EXECUTIONDATE")
    private OffsetDateTime executionDate;

    @Column(name = "USERID")
    private String userId;

    @Column(name = "URLJOB")
    private String urlJob;

    @ManyToOne(optional = false, cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "issueref", nullable = false)
    private IssueEntity issueRef;

    @ManyToOne(optional = false, cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "procedureref", nullable = false)
    private ProcedureEntity procedureRef;

    @ElementCollection
    @CollectionTable(name = "executionparameters")
    @Column(name = "PARAMETERS")
    @Cascade(value = {org.hibernate.annotations.CascadeType.ALL})
    private List<String> parameters = new ArrayList<>();

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public OffsetDateTime getExecutionDate() {
        return this.executionDate;
    }

    public void setExecutionDate(OffsetDateTime executionDate) {
        this.executionDate = executionDate;
    }

    public String getUserId() {
        return this.userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public ProcedureEntity getProcedureRef() {
        return this.procedureRef;
    }

    public void setProcedureRef(ProcedureEntity procedureRef) {
        this.procedureRef = procedureRef;
    }

    public List<String> getParameters() {
        return this.parameters;
    }

    public void setParameters(List<String> parameters) {
        this.parameters = parameters;
    }

    public IssueEntity getIssueRef() {
        return issueRef;
    }

    public void setIssueRef(IssueEntity issueRef) {
        this.issueRef = issueRef;
    }

    public String getUrlJob() {
        return urlJob;
    }

    public void setUrlJob(String urlJob) {
        this.urlJob = urlJob;
    }
}
