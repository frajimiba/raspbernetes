package isom.appops.database.entities;

import java.time.OffsetDateTime;

import jakarta.persistence.*;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;

@Entity
@Table(name = "MANUAL_CLASSIFICATION")
@NamedQueries({
    @NamedQuery(name = "ManualClassificationEntity.findByIssueId", query = "Select mc FROM ManualClassificationEntity as mc WHERE mc.issue.id = :issueId ORDER BY mc.creationDate DESC"),
})
public class ManualClassificationEntity extends PanacheEntityBase {

	@Id
	@GeneratedValue(
			strategy = GenerationType.SEQUENCE,
			generator = "seq_manualclassification"
	)
	@SequenceGenerator(
			name = "seq_manualclassification",sequenceName = "MANUAL_CLASSIFICATION_ID_SEQ", allocationSize = 1, initialValue = 1)

	private Long id;

	@Column(name = "CLASSIFICATION", nullable=false)
	private String classification;

	@Column(name = "USERNAME", nullable=false)
	private String userName;
	
	@Column(name = "CREATIONDATE")
	private OffsetDateTime creationDate;
	
	@ManyToOne(optional = false, cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name="issue", nullable=false)	
	private IssueEntity issue;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getClassification() {
		return this.classification;
	}

	public void setClassification(String classification) {
		this.classification = classification;
	}

	public String getUserName() {
		return this.userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public OffsetDateTime getCreationDate() {
		return this.creationDate;
	}

	public void setCreationDate(OffsetDateTime creationDate) {
		this.creationDate = creationDate;
	}	

	public IssueEntity getIssue() {
		return this.issue;
	}

	public void setIssue(IssueEntity issue) {
		this.issue = issue;
	}
	
	
}
