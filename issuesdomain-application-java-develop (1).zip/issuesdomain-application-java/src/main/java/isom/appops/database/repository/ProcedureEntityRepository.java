package isom.appops.database.repository;

import jakarta.enterprise.context.ApplicationScoped;

import isom.appops.database.entities.ProcedureEntity;
import isom.appops.quarkus.data.PagedResult;

import io.quarkus.hibernate.orm.panache.PanacheQuery;
import io.quarkus.hibernate.orm.panache.PanacheRepository;
import io.quarkus.panache.common.Page;
import io.quarkus.panache.common.Sort;

@ApplicationScoped
public class ProcedureEntityRepository implements PanacheRepository<ProcedureEntity> {

    public PagedResult<ProcedureEntity> findBy(Page page, Sort sort) {
        PanacheQuery<ProcedureEntity> query = findAll(sort);
        query.page(page);
        return PagedResult.of(query);
    }

    public void deleteBy(Long id){
        ProcedureEntity procedureEntity = findById(id);
        getEntityManager().remove(procedureEntity);
    }

}