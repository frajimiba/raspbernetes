package isom.appops.database.repository;

import io.quarkus.hibernate.orm.panache.PanacheQuery;
import io.quarkus.hibernate.orm.panache.PanacheRepository;
import io.quarkus.panache.common.Page;
import io.quarkus.panache.common.Parameters;
import io.quarkus.panache.common.Sort;
import isom.appops.database.entities.ExecutionEntity;
import isom.appops.database.entities.ExecutionTemplateEntity;
import isom.appops.quarkus.data.PagedResult;
import jakarta.enterprise.context.ApplicationScoped;

import java.util.List;
import java.util.Optional;

@ApplicationScoped
public class ExecutionTemplateEntityRepository implements PanacheRepository<ExecutionTemplateEntity> {

    public PagedResult<ExecutionTemplateEntity> findBy(Page page, Sort sort) {
        PanacheQuery<ExecutionTemplateEntity> query = findAll(sort);
        query.page(page);
        return PagedResult.of(query);
    }

    public ExecutionTemplateEntity findByTemplateIdAndName(String templateId, String templateName) {
        try {
            PanacheQuery<ExecutionTemplateEntity> query = find("#ExecutionTemplateEntity.findByExecutionByIdAndName", Parameters.with("templateId", templateId).and("templateName", templateName));
            List<ExecutionTemplateEntity> executionTemplateEntities = query.list();
            Optional<ExecutionTemplateEntity> optional = executionTemplateEntities.stream().findFirst();
            if (optional.isPresent()){
                return optional.get();
            } else {
                return null;
            }
        } catch (Exception exception){
            throw new RuntimeException(exception);
        }
    }

}