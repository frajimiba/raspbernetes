package isom.appops.database.entities;

import java.time.OffsetDateTime;

import jakarta.persistence.*;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;

@Entity
@Table(name = "STATUS_TRACKING")
@NamedQueries({
    @NamedQuery(name = "StatusTrackingEntity.findStatusesByIssueId", query = "Select ste FROM StatusTrackingEntity as ste WHERE ste.issue.id = :issueId ORDER BY ste.tsInitial DESC"),
})
public class StatusTrackingEntity extends PanacheEntityBase {

	@Id
	@GeneratedValue(
			strategy = GenerationType.SEQUENCE,
			generator = "seq_statustracking"
	)
	@SequenceGenerator(
			name = "seq_statustracking",sequenceName = "STATUS_TRACKING_ID_SEQ", allocationSize = 1, initialValue = 1)

	private Long id;

	@Column(name = "STATUS", nullable=false)
	private String status;
		
	@Column(name = "TSINITIAL", nullable=false)
	private OffsetDateTime tsInitial;

	@Column(name = "TSFINAL")
	private OffsetDateTime tsFinal;
	
	@ManyToOne(optional = false, cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name="issue", nullable=false)	
	private IssueEntity issue;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public OffsetDateTime getTsInitial() {
		return this.tsInitial;
	}

	public void setTsInitial(OffsetDateTime tsInitial) {
		this.tsInitial = tsInitial;
	}

	public OffsetDateTime getTsFinal() {
		return this.tsFinal;
	}

	public void setTsFinal(OffsetDateTime tsFinal) {
		this.tsFinal = tsFinal;
	}

	public IssueEntity getIssue() {
		return this.issue;
	}

	public void setIssue(IssueEntity issue) {
		this.issue = issue;
	}
	

	
}
