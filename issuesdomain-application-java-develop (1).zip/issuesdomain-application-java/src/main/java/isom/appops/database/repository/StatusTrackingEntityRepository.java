package isom.appops.database.repository;

import java.util.List;
import java.util.UUID;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.persistence.TypedQuery;

import isom.appops.database.entities.StatusTrackingEntity;

import io.quarkus.hibernate.orm.panache.PanacheRepository;

@ApplicationScoped
public class StatusTrackingEntityRepository implements PanacheRepository<StatusTrackingEntity> {
	   
    public List<StatusTrackingEntity> findStatusesByIssueId(UUID issueId){
        try {
            TypedQuery<StatusTrackingEntity> query = getEntityManager().createNamedQuery("StatusTrackingEntity.findStatusesByIssueId", StatusTrackingEntity.class);
            query.setParameter("issueId", issueId);
            return query.getResultList();
        } catch (Exception exception){
            throw new RuntimeException(exception);
        }
    }

}