package isom.appops.database.repository;

import isom.appops.domain.model.PageRequest;
import isom.appops.domain.model.dto.FullIssueViewDTO;
import isom.appops.domain.model.entries.FullIssueEntry;
import isom.appops.quarkus.data.PagedResult;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

@ApplicationScoped
public class FullIssuesViewsRepository {

    @Inject
    EntityManager entityManager;


    public PagedResult<FullIssueViewDTO> getFullIssuesGroups(FullIssueEntry fullIssueEntry, PageRequest pageRequest) {

        PagedResult<FullIssueViewDTO> pagedResultCol = validateFullIssueSortCol(pageRequest);
        if (pagedResultCol != null) return pagedResultCol;

        String querySQL = getFullIssueGroupsSql();
        String queryPagination = getPagination(pageRequest.ascending);

        PagedResult<FullIssueViewDTO> pagedResult = new PagedResult<FullIssueViewDTO>();
        try {
            Query query = entityManager.createNativeQuery(querySQL + queryPagination, "FullIssueViewQueryResult");
            query.setParameter("clients", fullIssueEntry.getClients());
            query.setParameter("groups", fullIssueEntry.getGroups());
            query.setParameter("classifications", fullIssueEntry.getClassifications());
            query.setParameter("groupsEmpty", fullIssueEntry.getGroups() == null || fullIssueEntry.getGroups().isEmpty());
            query.setParameter("classificationsEmpty", fullIssueEntry.getClassifications() == null || fullIssueEntry.getClassifications().isEmpty());
            query.setParameter("statuses", fullIssueEntry.getStatuses());
            query.setParameter("limit", pageRequest.size);
            query.setParameter("hideExpired", fullIssueEntry.getHideExpired());
            query.setParameter("offset", pageRequest.page * pageRequest.size);
            query.setParameter("pageRequestSort", pageRequest.sort);

            List<FullIssueViewDTO> dtos = query.getResultList();

            Query queryCount = entityManager.createNativeQuery("SELECT COUNT(*) FROM (" + querySQL + ")");
            queryCount.setParameter("clients", fullIssueEntry.getClients());
            queryCount.setParameter("groups", fullIssueEntry.getGroups());
            queryCount.setParameter("classifications", fullIssueEntry.getClassifications());
            queryCount.setParameter("groupsEmpty", fullIssueEntry.getGroups() == null || fullIssueEntry.getGroups().isEmpty());
            queryCount.setParameter("classificationsEmpty", fullIssueEntry.getClassifications() == null || fullIssueEntry.getClassifications().isEmpty());
            queryCount.setParameter("statuses", fullIssueEntry.getStatuses());
            queryCount.setParameter("hideExpired", fullIssueEntry.getHideExpired());

            Long maxResults = Long.valueOf(queryCount.getSingleResult().toString());
            pagedResult.setList(dtos);
            pagedResult.setNumOfResults(maxResults);
            pagedResult.setPage(pageRequest.page);
            pagedResult.setSize(pageRequest.size);

        } catch (Exception exception){
            throw new RuntimeException(exception);
        }

        return pagedResult;
    }

    public PagedResult<FullIssueViewDTO> getFullIssuesPending(FullIssueEntry fullIssueEntry, PageRequest pageRequest) {

        PagedResult<FullIssueViewDTO> pagedResultCol = validateFullIssueSortCol(pageRequest);
        if (pagedResultCol != null) return pagedResultCol;

        String querySQL = getPendingFullIssueQuerySQL();
        String queryPagination = getPagination(pageRequest.ascending);

        PagedResult<FullIssueViewDTO> pagedResult = new PagedResult<FullIssueViewDTO>();
        try {

            Query query = entityManager.createNativeQuery(querySQL + queryPagination, "FullIssueViewQueryResult");
            query.setParameter("clients", fullIssueEntry.getClients());
            query.setParameter("groups", fullIssueEntry.getGroups());
            query.setParameter("classifications", fullIssueEntry.getClassifications());
            query.setParameter("groupsEmpty", fullIssueEntry.getGroups() == null || fullIssueEntry.getGroups().isEmpty());
            query.setParameter("classificationsEmpty", fullIssueEntry.getClassifications() == null || fullIssueEntry.getClassifications().isEmpty());
            query.setParameter("statuses", fullIssueEntry.getStatuses());
            query.setParameter("limit", pageRequest.size);
            query.setParameter("hideExpired", fullIssueEntry.getHideExpired());
            query.setParameter("offset", pageRequest.page * pageRequest.size);
            query.setParameter("pageRequestSort", pageRequest.sort);

            Query queryCount = entityManager.createNativeQuery("SELECT COUNT(*) FROM (" + querySQL + ")");
            queryCount.setParameter("clients", fullIssueEntry.getClients());
            queryCount.setParameter("groups", fullIssueEntry.getGroups());
            queryCount.setParameter("classifications", fullIssueEntry.getClassifications());
            queryCount.setParameter("groupsEmpty", fullIssueEntry.getGroups() == null || fullIssueEntry.getGroups().isEmpty());
            queryCount.setParameter("classificationsEmpty", fullIssueEntry.getClassifications() == null || fullIssueEntry.getClassifications().isEmpty());
            queryCount.setParameter("statuses", fullIssueEntry.getStatuses());
            queryCount.setParameter("hideExpired", fullIssueEntry.getHideExpired());

            List<FullIssueViewDTO> dtos = query.getResultList();

            Long maxResults = Long.valueOf(queryCount.getSingleResult().toString());

            pagedResult.setList(dtos);
            pagedResult.setNumOfResults(maxResults);
            pagedResult.setPage(pageRequest.page);
            pagedResult.setSize(pageRequest.size);

        } catch (Exception exception){
            throw new RuntimeException(exception);
        }

        return pagedResult;
    }

    public PagedResult<FullIssueViewDTO> getFullIssuesOwned(String userId, FullIssueEntry fullIssueEntry, PageRequest pageRequest) {

        PagedResult<FullIssueViewDTO> pagedResultCol = validateFullIssueSortCol(pageRequest);
        if (pagedResultCol != null) return pagedResultCol;

        String querySQL = getFullIssuesOwnedSql();
        String queryPagination = getPagination(pageRequest.ascending);

        PagedResult<FullIssueViewDTO> pagedResult = new PagedResult<FullIssueViewDTO>();

        try {
            Query query = entityManager.createNativeQuery(querySQL + queryPagination, "FullIssueViewQueryResult");
            query.setParameter("user", userId);
            query.setParameter("clients", fullIssueEntry.getClients());
            query.setParameter("groups", fullIssueEntry.getGroups());
            query.setParameter("classifications", fullIssueEntry.getClassifications());
            query.setParameter("groupsEmpty", fullIssueEntry.getGroups() == null || fullIssueEntry.getGroups().isEmpty());
            query.setParameter("classificationsEmpty", fullIssueEntry.getClassifications() == null || fullIssueEntry.getClassifications().isEmpty());
            query.setParameter("statuses", fullIssueEntry.getStatuses());
            query.setParameter("hideExpired", fullIssueEntry.getHideExpired());
            query.setParameter("limit", pageRequest.size);
            query.setParameter("offset", pageRequest.page * pageRequest.size);
            query.setParameter("pageRequestSort", pageRequest.sort);

            Query queryCount = entityManager.createNativeQuery("SELECT COUNT(*) FROM (" + querySQL + ")");
            queryCount.setParameter("user", userId);
            queryCount.setParameter("clients", fullIssueEntry.getClients());
            queryCount.setParameter("groups", fullIssueEntry.getGroups());
            queryCount.setParameter("classifications", fullIssueEntry.getClassifications());
            queryCount.setParameter("groupsEmpty", fullIssueEntry.getGroups() == null || fullIssueEntry.getGroups().isEmpty());
            queryCount.setParameter("classificationsEmpty", fullIssueEntry.getClassifications() == null || fullIssueEntry.getClassifications().isEmpty());
            queryCount.setParameter("hideExpired", fullIssueEntry.getHideExpired());
            queryCount.setParameter("statuses", fullIssueEntry.getStatuses());

            List<FullIssueViewDTO> dtos = query.getResultList();
            Long maxResults = Long.valueOf(queryCount.getSingleResult().toString());

            pagedResult.setList(dtos);
            pagedResult.setNumOfResults(maxResults);
            pagedResult.setPage(pageRequest.page);
            pagedResult.setSize(pageRequest.size);

        } catch (Exception exception){
            throw new RuntimeException(exception);
        }

        return pagedResult;

    }

    public FullIssueViewDTO getFullIssue(UUID issueId) {
        try {
            String querySQL = getFullIssueSql();

            Query query = entityManager.createNativeQuery(querySQL, "FullIssueViewQueryResult");
            query.setParameter("issueId", issueId);

            FullIssueViewDTO result = (FullIssueViewDTO) query.getSingleResult();
            return result;
        } catch (Exception exception){
            throw new RuntimeException(exception);
        }
    }

    private static String getFullIssueGroupsSql() {
        return "SELECT\n" +
                "    ISS.ID AS ID,\n" +
                "    ISS.TICKETID AS TICKETID,\n" +
                "    ISS.CLIENTID AS CLIENTID,\n" +
                "    ISS.ISSUETYPE AS ISSUETYPE,\n" +
                "    ISS.GROUPNAME AS GROUPNAME,\n" +
                "    ISS.SEVERITY AS SEVERITY,\n" +
                "    ISS.SPECIALFLAG AS SPECIALFLAG,\n" +
                "    ISS.SLABREACHTIME AS SLABREACHTIME,\n" +
                "    ISS.RESOLUTIONDATE AS RESOLUTIONDATE,\n" +
                "    ISS.CLASSIFICATION AS CLASSIFICATION,\n" +
                "    ISS.CLASSIFICATIONDATE AS CLASSIFICATIONDATE,\n" +
                "    MC.USERNAME AS MANUALCLASSIFICATIONUSER,\n" +
                "    MC.CLASSIFICATION AS MANUALCLASSIFICATION,\n" +
                "    MC.CREATIONDATE AS MANUALCLASSIFICATIONTIMESTAMP,\n" +
                "    ASS.USERNAME AS ASSIGNEDUSER,\n" +
                "    STR.STATUS AS STATUS  \n" +
                "FROM\n" +
                "    ISSUE ISS\n" +
                "LEFT JOIN\n" +
                "    (\n" +
                "        SELECT\n" +
                "            ISSUE,\n" +
                "            MAX(ID) AS MAX_MC_ID\n" +
                "        FROM\n" +
                "            MANUAL_CLASSIFICATION\n" +
                "        GROUP BY\n" +
                "            ISSUE\n" +
                "    ) LATEST_MC\n" +
                "ON\n" +
                "    ISS.ID = LATEST_MC.ISSUE\n" +
                "LEFT JOIN\n" +
                "    MANUAL_CLASSIFICATION MC\n" +
                "ON\n" +
                "    ISS.ID = MC.ISSUE AND LATEST_MC.MAX_MC_ID = MC.ID\n" +
                "LEFT JOIN\n" +
                "    (\n" +
                "        SELECT\n" +
                "            ISSUE,\n" +
                "            MAX(ID) AS MAX_ASS_ID\n" +
                "        FROM\n" +
                "            ASSIGNAMENT\n" +
                "        GROUP BY\n" +
                "            ISSUE\n" +
                "    ) LATEST_ASS\n" +
                "ON\n" +
                "    ISS.ID = LATEST_ASS.ISSUE\n" +
                "LEFT JOIN\n" +
                "    ASSIGNAMENT ASS\n" +
                "ON\n" +
                "    ISS.ID = ASS.ISSUE AND LATEST_ASS.MAX_ASS_ID = ASS.ID\n" +
                "LEFT JOIN\n" +
                "    (\n" +
                "        SELECT\n" +
                "            ISSUE,\n" +
                "            MAX(ID) AS MAX_STR_ID\n" +
                "        FROM\n" +
                "            STATUS_TRACKING\n" +
                "        GROUP BY\n" +
                "            ISSUE\n" +
                "    ) LATEST_STR\n" +
                "ON\n" +
                "    ISS.ID = LATEST_STR.ISSUE\n" +
                "LEFT JOIN\n" +
                "    STATUS_TRACKING STR\n" +
                "ON\n" +
                "    ISS.ID = STR.ISSUE AND LATEST_STR.MAX_STR_ID = STR.ID\n" +
                "WHERE ISS.ID IS NOT NULL" +
                " AND (((:hideExpired) = 1 AND (ISS.SLABREACHTIME IS NULL OR ISS.SLABREACHTIME >= CURRENT_TIMESTAMP)) OR ((:hideExpired) = 0)) "+
                " AND (ISS.CLIENTID IN (:clients)) " +
                " AND (STR.STATUS IN (:statuses)) " +
                " AND ((ISS.GROUPNAME IN (:groups)) OR ((:groupsEmpty) = 1)) " +
                " AND (" +
                "((ISS.CLASSIFICATION IS NULL OR ISS.CLASSIFICATION = '') AND (MC.ID IS NULL OR MC.CLASSIFICATION IS NULL OR MC.CLASSIFICATION = '')) OR " +
                "(ISS.CLASSIFICATION IN (:classifications) AND (MC.ID IS NULL OR MC.CLASSIFICATION IS NULL OR MC.CLASSIFICATION = '')) OR " +
                "(MC.CLASSIFICATION IN (:classifications)) OR " +
                "((:classificationsEmpty) = 1)" +
                ") ";
    }

    private static String getPendingFullIssueQuerySQL() {
        return "SELECT\n" +
                "    ISS.ID AS ID,\n" +
                "    ISS.TICKETID AS TICKETID,\n" +
                "    ISS.CLIENTID AS CLIENTID,\n" +
                "    ISS.ISSUETYPE AS ISSUETYPE,\n" +
                "    ISS.GROUPNAME AS GROUPNAME,\n" +
                "    ISS.SEVERITY AS SEVERITY,\n" +
                "    ISS.SPECIALFLAG AS SPECIALFLAG,\n" +
                "    ISS.SLABREACHTIME AS SLABREACHTIME,\n" +
                "    ISS.RESOLUTIONDATE AS RESOLUTIONDATE,\n" +
                "    ISS.CLASSIFICATION AS CLASSIFICATION,\n" +
                "    ISS.CLASSIFICATIONDATE AS CLASSIFICATIONDATE,\n" +
                "    MC.USERNAME AS MANUALCLASSIFICATIONUSER,\n" +
                "    MC.CLASSIFICATION AS MANUALCLASSIFICATION,\n" +
                "    MC.CREATIONDATE AS MANUALCLASSIFICATIONTIMESTAMP,\n" +
                "    ASS.USERNAME AS ASSIGNEDUSER,\n" +
                "    STR.STATUS AS STATUS  \n" +
                "FROM\n" +
                "    ISSUE ISS\n" +
                "LEFT JOIN\n" +
                "    (\n" +
                "        SELECT\n" +
                "            ISSUE,\n" +
                "            MAX(ID) AS MAX_MC_ID\n" +
                "        FROM\n" +
                "            MANUAL_CLASSIFICATION\n" +
                "        GROUP BY\n" +
                "            ISSUE\n" +
                "    ) LATEST_MC\n" +
                "ON\n" +
                "    ISS.ID = LATEST_MC.ISSUE\n" +
                "LEFT JOIN\n" +
                "    MANUAL_CLASSIFICATION MC\n" +
                "ON\n" +
                "    ISS.ID = MC.ISSUE AND LATEST_MC.MAX_MC_ID = MC.ID\n" +
                "LEFT JOIN\n" +
                "    (\n" +
                "        SELECT\n" +
                "            ISSUE,\n" +
                "            MAX(ID) AS MAX_ASS_ID\n" +
                "        FROM\n" +
                "            ASSIGNAMENT\n" +
                "        GROUP BY\n" +
                "            ISSUE\n" +
                "    ) LATEST_ASS\n" +
                "ON\n" +
                "    ISS.ID = LATEST_ASS.ISSUE\n" +
                "LEFT JOIN\n" +
                "    ASSIGNAMENT ASS\n" +
                "ON\n" +
                "    ISS.ID = ASS.ISSUE AND LATEST_ASS.MAX_ASS_ID = ASS.ID\n" +
                "LEFT JOIN\n" +
                "    (\n" +
                "        SELECT\n" +
                "            ISSUE,\n" +
                "            MAX(ID) AS MAX_STR_ID\n" +
                "        FROM\n" +
                "            STATUS_TRACKING\n" +
                "        GROUP BY\n" +
                "            ISSUE\n" +
                "    ) LATEST_STR\n" +
                "ON\n" +
                "    ISS.ID = LATEST_STR.ISSUE\n" +
                "LEFT JOIN\n" +
                "    STATUS_TRACKING STR\n" +
                "ON\n" +
                "    ISS.ID = STR.ISSUE AND LATEST_STR.MAX_STR_ID = STR.ID\n" +
                "WHERE ISS.ID IS NOT NULL" +
                " AND (ASS.USERNAME IS NULL OR ASS.USERNAME = '')"+
                " AND (STR.STATUS IS NULL OR STR.STATUS IN (:statuses))"+
                " AND (((:hideExpired = 1) AND (ISS.SLABREACHTIME IS NULL OR ISS.SLABREACHTIME >= CURRENT_TIMESTAMP)) OR (:hideExpired = 0)) "+
                " AND (ISS.CLIENTID IN (:clients)) " +
                " AND ((ISS.GROUPNAME IN (:groups)) OR ((:groupsEmpty) = 1)) " +
                " AND (" +
                "((ISS.CLASSIFICATION IS NULL OR ISS.CLASSIFICATION = '') AND (MC.ID IS NULL OR MC.CLASSIFICATION IS NULL OR MC.CLASSIFICATION = '')) OR " +
                "(ISS.CLASSIFICATION IN (:classifications) AND (MC.ID IS NULL OR MC.CLASSIFICATION IS NULL OR MC.CLASSIFICATION = '')) OR " +
                "(MC.CLASSIFICATION IN (:classifications)) OR " +
                "((:classificationsEmpty) = 1)" +
                ") ";
    }

    private static String getPagination(boolean pageRequestAscending) {
        return "ORDER BY :pageRequestSort " + (pageRequestAscending ? "ASC" : "DESC") + " OFFSET :offset ROWS " +
                "FETCH NEXT :limit ROWS ONLY\n";
    }

    private static String getFullIssuesOwnedSql() {
        return "SELECT\n" +
                "    ISS.ID AS ID,\n" +
                "    ISS.TICKETID AS TICKETID,\n" +
                "    ISS.CLIENTID AS CLIENTID,\n" +
                "    ISS.ISSUETYPE AS ISSUETYPE,\n" +
                "    ISS.GROUPNAME AS GROUPNAME,\n" +
                "    ISS.SEVERITY AS SEVERITY,\n" +
                "    ISS.SPECIALFLAG AS SPECIALFLAG,\n" +
                "    ISS.SLABREACHTIME AS SLABREACHTIME,\n" +
                "    ISS.RESOLUTIONDATE AS RESOLUTIONDATE,\n" +
                "    ISS.CLASSIFICATION AS CLASSIFICATION,\n" +
                "    ISS.CLASSIFICATIONDATE AS CLASSIFICATIONDATE,\n" +
                "    MC.USERNAME AS MANUALCLASSIFICATIONUSER,\n" +
                "    MC.CLASSIFICATION AS MANUALCLASSIFICATION,\n" +
                "    MC.CREATIONDATE AS MANUALCLASSIFICATIONTIMESTAMP,\n" +
                "    ASS.USERNAME AS ASSIGNEDUSER,\n" +
                "    STR.STATUS AS STATUS  \n" +
                "FROM\n" +
                "    ISSUE ISS\n" +
                "LEFT JOIN\n" +
                "    (\n" +
                "        SELECT\n" +
                "            ISSUE,\n" +
                "            MAX(ID) AS MAX_MC_ID\n" +
                "        FROM\n" +
                "            MANUAL_CLASSIFICATION\n" +
                "        GROUP BY\n" +
                "            ISSUE\n" +
                "    ) LATEST_MC\n" +
                "ON\n" +
                "    ISS.ID = LATEST_MC.ISSUE\n" +
                "LEFT JOIN\n" +
                "    MANUAL_CLASSIFICATION MC\n" +
                "ON\n" +
                "    ISS.ID = MC.ISSUE AND LATEST_MC.MAX_MC_ID = MC.ID\n" +
                "LEFT JOIN\n" +
                "    (\n" +
                "        SELECT\n" +
                "            ISSUE,\n" +
                "            MAX(ID) AS MAX_ASS_ID\n" +
                "        FROM\n" +
                "            ASSIGNAMENT\n" +
                "        GROUP BY\n" +
                "            ISSUE\n" +
                "    ) LATEST_ASS\n" +
                "ON\n" +
                "    ISS.ID = LATEST_ASS.ISSUE\n" +
                "LEFT JOIN\n" +
                "    ASSIGNAMENT ASS\n" +
                "ON\n" +
                "    ISS.ID = ASS.ISSUE AND LATEST_ASS.MAX_ASS_ID = ASS.ID\n" +
                "LEFT JOIN\n" +
                "    (\n" +
                "        SELECT\n" +
                "            ISSUE,\n" +
                "            MAX(ID) AS MAX_STR_ID\n" +
                "        FROM\n" +
                "            STATUS_TRACKING\n" +
                "        GROUP BY\n" +
                "            ISSUE\n" +
                "    ) LATEST_STR\n" +
                "ON\n" +
                "    ISS.ID = LATEST_STR.ISSUE\n" +
                "LEFT JOIN\n" +
                "    STATUS_TRACKING STR\n" +
                "ON\n" +
                "    ISS.ID = STR.ISSUE AND LATEST_STR.MAX_STR_ID = STR.ID\n" +
                "WHERE\n" +
                " ISS.ID = STR.ISSUE" +
                " AND ISS.ID IS NOT NULL" +
                " AND (((:hideExpired) = 1 AND (ISS.SLABREACHTIME IS NULL OR ISS.SLABREACHTIME >= CURRENT_TIMESTAMP)) OR ((:hideExpired) = 0)) "+
                " AND (ISS.CLIENTID IN (:clients)) " +
                " AND (STR.STATUS IN (:statuses)) " +
                " AND (ASS.USERNAME = (:user))" +
                " AND ((ISS.GROUPNAME IN (:groups)) OR ((:groupsEmpty) = 1)) " +
                " AND (" +
                "((ISS.CLASSIFICATION IS NULL OR ISS.CLASSIFICATION = '') AND (MC.ID IS NULL OR MC.CLASSIFICATION IS NULL OR MC.CLASSIFICATION = '')) OR " +
                "(ISS.CLASSIFICATION IN (:classifications) AND (MC.ID IS NULL OR MC.CLASSIFICATION IS NULL OR MC.CLASSIFICATION = '')) OR " +
                "(MC.CLASSIFICATION IN (:classifications)) OR " +
                "((:classificationsEmpty) = 1)" +
                ") ";
    }

    private static String getFullIssueSql() {
        return "SELECT\n" +
                "    ISS.ID AS ID,\n" +
                "    ISS.TICKETID AS TICKETID,\n" +
                "    ISS.CLIENTID AS CLIENTID,\n" +
                "    ISS.ISSUETYPE AS ISSUETYPE,\n" +
                "    ISS.GROUPNAME AS GROUPNAME,\n" +
                "    ISS.SEVERITY AS SEVERITY,\n" +
                "    ISS.SPECIALFLAG AS SPECIALFLAG,\n" +
                "    ISS.SLABREACHTIME AS SLABREACHTIME,\n" +
                "    ISS.RESOLUTIONDATE AS RESOLUTIONDATE,\n" +
                "    ISS.CLASSIFICATION AS CLASSIFICATION,\n" +
                "    ISS.CLASSIFICATIONDATE AS CLASSIFICATIONDATE,\n" +
                "    MC.USERNAME AS MANUALCLASSIFICATIONUSER,\n" +
                "    MC.CLASSIFICATION AS MANUALCLASSIFICATION,\n" +
                "    MC.CREATIONDATE AS MANUALCLASSIFICATIONTIMESTAMP,\n" +
                "    ASS.USERNAME AS ASSIGNEDUSER,\n" +
                "    STR.STATUS AS STATUS  \n" +
                "FROM\n" +
                "    ISSUE ISS\n" +
                "LEFT JOIN\n" +
                "    (\n" +
                "        SELECT\n" +
                "            ISSUE,\n" +
                "            MAX(ID) AS MAX_MC_ID\n" +
                "        FROM\n" +
                "            MANUAL_CLASSIFICATION\n" +
                "        GROUP BY\n" +
                "            ISSUE\n" +
                "    ) LATEST_MC\n" +
                "ON\n" +
                "    ISS.ID = LATEST_MC.ISSUE\n" +
                "LEFT JOIN\n" +
                "    MANUAL_CLASSIFICATION MC\n" +
                "ON\n" +
                "    ISS.ID = MC.ISSUE AND LATEST_MC.MAX_MC_ID = MC.ID\n" +
                "LEFT JOIN\n" +
                "    (\n" +
                "        SELECT\n" +
                "            ISSUE,\n" +
                "            MAX(ID) AS MAX_ASS_ID\n" +
                "        FROM\n" +
                "            ASSIGNAMENT\n" +
                "        GROUP BY\n" +
                "            ISSUE\n" +
                "    ) LATEST_ASS\n" +
                "ON\n" +
                "    ISS.ID = LATEST_ASS.ISSUE\n" +
                "LEFT JOIN\n" +
                "    ASSIGNAMENT ASS\n" +
                "ON\n" +
                "    ISS.ID = ASS.ISSUE AND LATEST_ASS.MAX_ASS_ID = ASS.ID\n" +
                "LEFT JOIN\n" +
                "    (\n" +
                "        SELECT\n" +
                "            ISSUE,\n" +
                "            MAX(ID) AS MAX_STR_ID\n" +
                "        FROM\n" +
                "            STATUS_TRACKING\n" +
                "        GROUP BY\n" +
                "            ISSUE\n" +
                "    ) LATEST_STR\n" +
                "ON\n" +
                "    ISS.ID = LATEST_STR.ISSUE\n" +
                "LEFT JOIN\n" +
                "    STATUS_TRACKING STR\n" +
                "ON\n" +
                "    ISS.ID = STR.ISSUE AND LATEST_STR.MAX_STR_ID = STR.ID\n" +
                "WHERE\n" +
                "    ISS.ID = :issueId";
    }

    private PagedResult<FullIssueViewDTO> validateFullIssueSortCol(PageRequest pageRequest) {
        final String[] validSortParams = new String[]{
                "id",
                "ticketId", "clientId",
                "issueType", "groupName",
                "severity", "specialFlag",
                "slaBreachTime", "classification",
                "classificationDate", "manualClassificationUser",
                "manualClassification", "manualClassificationTimestamp",
                "assignedUser", "status"};

        // Valida párametro de orden a enviar al Native SQL
        if (!Arrays.stream(validSortParams).anyMatch((item) -> item.equals(pageRequest.sort))) {
            PagedResult<FullIssueViewDTO> pagedResult = new PagedResult<FullIssueViewDTO>();
            pagedResult.setPage(pageRequest.page);
            pagedResult.setSize(pageRequest.size);
            return pagedResult;
        }

        return null;
    }
}
