package isom.appops.database.resourcepanache;

import isom.appops.database.entities.TroubleshootingEntity;
import io.quarkus.hibernate.orm.rest.data.panache.PanacheEntityResource;
import io.quarkus.rest.data.panache.ResourceProperties;

import jakarta.enterprise.context.ApplicationScoped;

@ApplicationScoped
@ResourceProperties(exposed = false)
public interface TroubleshootingEntityResourcePanache extends PanacheEntityResource<TroubleshootingEntity, Long> {

}