package isom.appops.database.resourcepanache;

import jakarta.enterprise.context.ApplicationScoped;

import isom.appops.database.entities.AssignamentEntity;

import io.quarkus.hibernate.orm.rest.data.panache.PanacheEntityResource;
import io.quarkus.rest.data.panache.ResourceProperties;

@ApplicationScoped
@ResourceProperties(exposed = false)
public interface AssignamentEntityResourcePanache extends PanacheEntityResource<AssignamentEntity, Long> {

}