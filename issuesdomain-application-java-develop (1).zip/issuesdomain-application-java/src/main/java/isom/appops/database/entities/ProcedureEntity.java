package isom.appops.database.entities;

import java.time.OffsetDateTime;

import jakarta.persistence.*;

import io.quarkus.hibernate.orm.panache.PanacheEntity;
import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import org.hibernate.annotations.Type;

@Entity
@Table(name = "PROCEDURES")
@NamedQueries({
    @NamedQuery(name = "ProcedureEntity.findByClassification", query = "Select pr FROM ProcedureEntity as pr WHERE pr.classification IN :classifications ORDER BY pr.creationDate DESC"),
})
public class ProcedureEntity extends PanacheEntityBase {

    @Id
    @GeneratedValue(
            strategy = GenerationType.SEQUENCE,
            generator = "seq_procedure"
    )
    @SequenceGenerator(
            name = "seq_procedure",sequenceName = "PROCEDURES_ID_SEQ", allocationSize = 1, initialValue = 1)

    private Long id;

    @Column(name = "TITLE")
    private String title;

    @Column(name = "CLIENTID")
    private String clientId;

    @Lob
    @Column(name = "DESCRIPTION")
    private String description;

    @Lob
    @Column(name = "RESPONSETEMPLATE")
    private String responseTemplate;

    @Column(name = "CREATIONDATE")
    private OffsetDateTime creationDate;

    @Column(name = "USERID")
    private String userId;

    @Column(name = "URLJOB")
    private String urlJob;

    @Column(name = "URLCOMMUNICATION")
    private String urlCommunication;

    @Column(name = "CLASSIFICATION")
    private String classification;

    @Column(name = "AUTOMATIC")
    private boolean automatic;

    @Column(name = "CONFIGFILEENVIRONMENT")
    private String configFileEnvironment;

    @Column(name = "CONFIGFILEPATH")
    private String configFilePath;

    @Column(name = "CONFIGFILEVERSION")
    private String configFileVersion;

    @Column(name = "JOBTEMPLATENAME")
    private String jobTemplateName;

    @Column(name = "JOBTEMPLATEID")
    private String jobTemplateId;

    @Column(name = "PROCEDURETYPE")
    private String procedureType;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getResponseTemplate() {
        return responseTemplate;
    }

    public void setResponseTemplate(String responseTemplate) {
        this.responseTemplate = responseTemplate;
    }

    public String getTitle() {
        return this.title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return this.description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public OffsetDateTime getCreationDate() {
        return this.creationDate;
    }

    public void setCreationDate(OffsetDateTime creationDate) {
        this.creationDate = creationDate;
    }

    public String getUserId() {
        return this.userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUrlJob() {
        return this.urlJob;
    }

    public void setUrlJob(String urlJob) {
        this.urlJob = urlJob;
    }

    public String getUrlCommunication() {
        return this.urlCommunication;
    }

    public void setUrlCommunication(String urlCommunication) {
        this.urlCommunication = urlCommunication;
    }

    public String getClassification() {
        return this.classification;
    }

    public void setClassification(String classification) {
        this.classification = classification;
    }

    public boolean isAutomatic() {
        return this.automatic;
    }

    public boolean getAutomatic() {
        return this.automatic;
    }

    public void setAutomatic(boolean automatic) {
        this.automatic = automatic;
    }

    public String getConfigFileEnvironment() {
        return configFileEnvironment;
    }

    public void setConfigFileEnvironment(String configFileEnvironment) {
        this.configFileEnvironment = configFileEnvironment;
    }

    public String getConfigFilePath() {
        return configFilePath;
    }

    public void setConfigFilePath(String configFilePath) {
        this.configFilePath = configFilePath;
    }

    public String getConfigFileVersion() {
        return configFileVersion;
    }

    public void setConfigFileVersion(String configFileVersion) {
        this.configFileVersion = configFileVersion;
    }

    public String getJobTemplateName() {
        return jobTemplateName;
    }

    public void setJobTemplateName(String jobTemplateName) {
        this.jobTemplateName = jobTemplateName;
    }

    public String getJobTemplateId() {
        return jobTemplateId;
    }

    public void setJobTemplateId(String jobTemplateId) {
        this.jobTemplateId = jobTemplateId;
    }

    public String getProcedureType() {
        return procedureType;
    }

    public void setProcedureType(String procedureType) {
        this.procedureType = procedureType;
    }
}
