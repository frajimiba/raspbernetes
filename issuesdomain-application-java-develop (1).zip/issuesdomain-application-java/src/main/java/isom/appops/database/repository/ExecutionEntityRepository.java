package isom.appops.database.repository;

import isom.appops.database.entities.ExecutionEntity;
import isom.appops.domain.model.PageRequest;
import isom.appops.quarkus.data.PagedResult;
import io.quarkus.hibernate.orm.panache.PanacheQuery;
import io.quarkus.hibernate.orm.panache.PanacheRepository;
import io.quarkus.panache.common.Page;
import io.quarkus.panache.common.Parameters;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.persistence.Query;
import java.util.List;
import java.util.UUID;

@ApplicationScoped
public class ExecutionEntityRepository implements PanacheRepository<ExecutionEntity> {

    public PagedResult<ExecutionEntity> findAllByProcedureId(Long id, PageRequest pageRequest) {
        PanacheQuery<ExecutionEntity> query = find("#ExecutionEntity.findAllByProcedureId", Parameters.with("procedureId", id));
        query.page(Page.of(pageRequest.page, pageRequest.size));
        return PagedResult.of(query);
    }

    public List<ExecutionEntity> findAllByIssueId(UUID id){
        try {
            PanacheQuery<ExecutionEntity> query = find("#ExecutionEntity.findAllByIssueId", Parameters.with("issueId", id));
            return  query.list();
        } catch (Exception exception){
            throw new RuntimeException(exception);
        }
    }

    public long deleteByProcedureId(Long id) {
        try {
            Query query = getEntityManager().createNamedQuery("ExecutionEntity.deleteParamsByProcedureId");
            query.setParameter("procedureId", id);
            query.executeUpdate();
        } catch (Exception exception){
            throw new RuntimeException(exception);
        }
        return delete("#ExecutionEntity.deleteAllByProcedureId", Parameters.with("procedureId", id));
    }

}