package isom.appops.database.repository;

import java.util.List;
import java.util.UUID;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.persistence.TypedQuery;

import isom.appops.database.entities.ManualClassificationEntity;
import isom.appops.quarkus.data.PagedResult;

import io.quarkus.hibernate.orm.panache.PanacheQuery;
import io.quarkus.hibernate.orm.panache.PanacheRepository;
import io.quarkus.panache.common.Page;

@ApplicationScoped
public class ManualClassificationEntityRepository implements PanacheRepository<ManualClassificationEntity> {
	
    public List<ManualClassificationEntity> findByAssignedUser(String userId){
        return find("#ManualClassificationEntity.findByAssignedUser", userId).list();
    }

    public PagedResult<ManualClassificationEntity> findByAssignedUser(String userId, Page page) {
        PanacheQuery<ManualClassificationEntity> query = find("#ManualClassificationEntity.findByAssignedUser", userId);       
        query.page(page);
        return PagedResult.of(query);
    }

    public List<ManualClassificationEntity> findAssignmentsByIssueId(UUID issueId) {
        try {
            TypedQuery<ManualClassificationEntity> query = getEntityManager().createNamedQuery("ManualClassificationEntity.findAssignmentsByIssueId", ManualClassificationEntity.class);
            query.setParameter("issueId", issueId);
            return query.getResultList();
        } catch (Exception exception){
            throw new RuntimeException(exception);
        }
    }
}