package isom.appops.database.repository;

import java.util.List;
import java.util.UUID;

import isom.appops.database.entities.TroubleshootingEntity;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.persistence.TypedQuery;

import isom.appops.database.entities.AssignamentEntity;
import isom.appops.quarkus.data.PagedResult;

import io.quarkus.hibernate.orm.panache.PanacheQuery;
import io.quarkus.hibernate.orm.panache.PanacheRepository;
import io.quarkus.panache.common.Page;
import io.quarkus.panache.common.Parameters;

@ApplicationScoped
public class AssignamentEntityRepository implements PanacheRepository<AssignamentEntity> {
	
    public List<AssignamentEntity> findByAssignedUser(String userId){
        return find("#AssignamentEntity.findByAssignedUser", userId).list();
    }

    public PagedResult<AssignamentEntity> findByAssignedUser(String userId, Page page) {
        PanacheQuery<AssignamentEntity> query = find("#AssignamentEntity.findByAssignedUser", userId);       
        query.page(page);
        return PagedResult.of(query);
    }

    public PagedResult<AssignamentEntity> findByAssignedUsers(List<String> userIds, Page page) {
        PanacheQuery<AssignamentEntity> query = find("#AssignamentEntity.findByAssignedUsers", Parameters.with("userNames", userIds));       
        query.page(page);
        return PagedResult.of(query);
    }

    public List<AssignamentEntity> findAssignmentsByIssueId(UUID issueId) {
        try {
            TypedQuery<AssignamentEntity> query = getEntityManager().createNamedQuery("AssignamentEntity.findAssignmentsByIssueId", AssignamentEntity.class);
            query.setParameter("issueId", issueId);
            return query.getResultList();
        } catch (Exception exception){
            throw new RuntimeException(exception);
        }
    }

    public Integer countByAssignedUser(String userId) {
        try {
            TypedQuery<Long> query = getEntityManager().createNamedQuery("AssignamentEntity.countAssignmentsByIssueId", Long.class);
            query.setParameter("userId", userId);
            return query.getSingleResult().intValue();
        } catch (Exception exception){
            throw new RuntimeException(exception);
        }
    }

    public PagedResult<AssignamentEntity> findByAssignedUsersAndStatuses(List<String> userIds, List<String> statuses,
            Page page) {
        PanacheQuery<AssignamentEntity> query = find("#AssignamentEntity.findByAssignedUsersAndStatuses", Parameters.with("userNames", userIds).and("statuses", statuses));       
        query.page(page);
        return PagedResult.of(query);
    }
}