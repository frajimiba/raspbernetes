package isom.appops.database.entities;

import java.time.OffsetDateTime;
import java.util.UUID;

import jakarta.persistence.*;

import isom.appops.domain.model.dto.FullIssueViewDTO;
import org.hibernate.annotations.Type;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;

@Entity
@Table(name = "ISSUE")
@SqlResultSetMappings({
		@SqlResultSetMapping(name="FullIssueViewQueryResult", classes = {
				@ConstructorResult(targetClass = FullIssueViewDTO.class,
						columns = {
								@ColumnResult(name = "ID", type = UUID.class),
								@ColumnResult(name = "TICKETID", type = String.class),
								@ColumnResult(name = "CLIENTID", type = String.class),
								@ColumnResult(name = "ISSUETYPE", type = String.class),
								@ColumnResult(name = "GROUPNAME", type = String.class),
								@ColumnResult(name = "SEVERITY", type = String.class),
								@ColumnResult(name = "SPECIALFLAG", type = String.class),
								@ColumnResult(name = "SLABREACHTIME", type = OffsetDateTime.class),
								@ColumnResult(name = "RESOLUTIONDATE", type = OffsetDateTime.class),
								@ColumnResult(name = "CLASSIFICATION", type = String.class),
								@ColumnResult(name = "CLASSIFICATIONDATE", type = OffsetDateTime.class),
								@ColumnResult(name = "MANUALCLASSIFICATIONUSER", type = String.class),
								@ColumnResult(name = "MANUALCLASSIFICATION", type = String.class),
								@ColumnResult(name = "MANUALCLASSIFICATIONTIMESTAMP", type = OffsetDateTime.class),
								@ColumnResult(name = "ASSIGNEDUSER", type = String.class),
								@ColumnResult(name = "STATUS", type = String.class)
						})
		})
})
public class IssueEntity extends PanacheEntityBase {

	@Id
	@JoinColumn(name = "ID", nullable = false)
	private UUID id;
	
	@Column(name = "TICKETID", nullable = false)
	private String ticketId;

	@Column(name = "CLIENTID", nullable = false)
	private String clientId;

	@Column(name = "ISSUETYPE")
	private String issueType;

	@Column(name = "GROUPNAME")
	private String groupName;

	@Column(name = "SEVERITY")
	private String severity;

	@Column(name = "SPECIALFLAG")
	private String specialFlag;

	@Column(name = "SLABREACHTIME")
	private OffsetDateTime slaBreachTime;

	@Column(name = "CLASSIFICATION")
	private String classification;

	@Column(name = "CLASSIFICATIONDATE")
	private OffsetDateTime classificationDate;

	@Column(name = "RESOLUTIONDATE")
	private OffsetDateTime resolutionDate;

	public UUID getId() {
		return this.id;
	}

	public void setId(UUID id) {
		this.id = id;
	}

	public String getTicketId() {
		return this.ticketId;
	}

	public void setTicketId(String ticketId) {
		this.ticketId = ticketId;
	}

	public String getClientId() {
		return this.clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getIssueType() {
		return this.issueType;
	}

	public void setIssueType(String issueType) {
		this.issueType = issueType;
	}

	public String getGroupName() {
		return this.groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getSeverity() {
		return this.severity;
	}

	public void setSeverity(String severity) {
		this.severity = severity;
	}

	public String getSpecialFlag() {
		return this.specialFlag;
	}

	public void setSpecialFlag(String specialFlag) {
		this.specialFlag = specialFlag;
	}

	public OffsetDateTime getSlaBreachTime() {
		return this.slaBreachTime;
	}

	public void setSlaBreachTime(OffsetDateTime slaBreachTime) {
		this.slaBreachTime = slaBreachTime;
	}

	public String getClassification() {
		return this.classification;
	}

	public void setClassification(String classification) {
		this.classification = classification;
	}

	public OffsetDateTime getClassificationDate() {
		return this.classificationDate;
	}

	public void setClassificationDate(OffsetDateTime classificationDate) {
		this.classificationDate = classificationDate;
	}

	public OffsetDateTime getResolutionDate() {
		return resolutionDate;
	}

	public void setResolutionDate(OffsetDateTime resolutionDate) {
		this.resolutionDate = resolutionDate;
	}
}
