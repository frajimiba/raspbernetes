package isom.appops.database.resourcepanache;

import java.util.UUID;

import jakarta.enterprise.context.ApplicationScoped;

import isom.appops.database.entities.IssueEntity;
import isom.appops.database.repository.IssueEntityRepository;

import io.quarkus.hibernate.orm.rest.data.panache.PanacheRepositoryResource;
import io.quarkus.rest.data.panache.ResourceProperties;

@ApplicationScoped
@ResourceProperties(exposed = false)
public interface IssueEntityResourcePanache extends PanacheRepositoryResource<IssueEntityRepository, IssueEntity, UUID> {

}