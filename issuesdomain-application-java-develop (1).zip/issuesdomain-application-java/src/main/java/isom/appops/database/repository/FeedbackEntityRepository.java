package isom.appops.database.repository;

import isom.appops.database.entities.FeedbackEntity;
import isom.appops.domain.model.PageRequest;
import isom.appops.quarkus.data.PagedResult;
import io.quarkus.hibernate.orm.panache.PanacheQuery;
import io.quarkus.hibernate.orm.panache.PanacheRepository;
import io.quarkus.panache.common.Page;
import io.quarkus.panache.common.Parameters;
import io.quarkus.panache.common.Sort;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.persistence.Query;
import jakarta.persistence.TypedQuery;
import java.util.List;

@ApplicationScoped
public class FeedbackEntityRepository implements PanacheRepository<FeedbackEntity> {

    public PagedResult<FeedbackEntity> findBy(Page page, Sort sort) {
        PanacheQuery<FeedbackEntity> query = findAll(sort);
        query.page(page);
        return PagedResult.of(query);
    }

    public PagedResult<FeedbackEntity> findAllByExecutionId(Long id, PageRequest pageRequest) {
        PanacheQuery<FeedbackEntity> query = find("#FeedbackEntity.findAllByExecutionId", Parameters.with("executionId", id));
        query.page(Page.of(pageRequest.page, pageRequest.size));
        return PagedResult.of(query);
    }

    public PagedResult<FeedbackEntity> findAllByProcedureId(Long id, PageRequest pageRequest) {
        PanacheQuery<FeedbackEntity> query = find("#FeedbackEntity.getAllByProcedureId", Parameters.with("procedureId", id));
        query.page(Page.of(pageRequest.page, pageRequest.size));
        return PagedResult.of(query);
    }

    public List<FeedbackEntity> getAllByProcedureId(Long id) {
        try {
            PanacheQuery<FeedbackEntity> query = find("#FeedbackEntity.getAllByProcedureId", Parameters.with("procedureId", id));
            return query.list();
        } catch (Exception exception){
            throw new RuntimeException(exception);
        }
    }

    public double getProcedureRating(Long id) {
        List<FeedbackEntity> feedbackEntities = getAllByProcedureId(id);
        if (null == feedbackEntities || 0 == feedbackEntities.size()){
            return 0.0;
        }
        double result = 0;
        for (int i = 0; i < feedbackEntities.size(); i++) {
            int stars = feedbackEntities.get(i).getStars();
            result += stars > 3 ? stars : 0;
        }
        return result / feedbackEntities.size();
    }

    public long deleteByProcedureId(Long id) {
        return delete("#FeedbackEntity.deleteAllByProcedureId", Parameters.with("procedureId", id));
    }

}