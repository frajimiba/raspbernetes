package isom.appops.domain.services;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Paths;

import jakarta.enterprise.context.ApplicationScoped;

import isom.appops.domain.utils.Constants;
import org.eclipse.microprofile.config.inject.ConfigProperty;

import com.fasterxml.jackson.databind.ObjectMapper;
import isom.appops.domain.model.IssueTranslations;
import isom.appops.domain.model.Translations;
import isom.appops.ticketentry.model.TicketEntry;
import isom.appops.ticketentry.model.TicketHeader;
import isom.appops.quarkus.errorhandler.exception.ApiInternalServerErrorException;

import io.quarkus.cache.CacheInvalidate;
import io.quarkus.cache.CacheResult;
import io.quarkus.runtime.configuration.ProfileManager;

@ApplicationScoped
public class TranslationsService {

	@ConfigProperty(name = "translations.path") 
	String translationsFilePath;

	/**
	 * Actualiza la información del issueEntity con la traducción a los datos de ticketData
	 * @param ticketHeader
	 * @throws ApiInternalServerErrorException
	 * @throws URISyntaxException
	 * @throws IOException
	 */
	public IssueTranslations translateToIssue(TicketHeader ticketHeader) throws ApiInternalServerErrorException, IOException, URISyntaxException {
			
		Translations translations = getTranslations();
		IssueTranslations issueTranslations = new IssueTranslations();
		
		String issueType = ticketHeader.getIssueType();
		if (null != issueType && translations.getIssueType().containsKey(issueType)){
			String translation = translations.getIssueType().get(issueType);
			issueTranslations.setIssueType(translation);
		} else {				
			throw new ApiInternalServerErrorException("invalidtranslationissuetype");
		}
		
		String severity = ticketHeader.getSeverity();
		if (null != severity && translations.getSeverity().containsKey(severity)){
			String translation = translations.getSeverity().get(severity);
			issueTranslations.setSeverity(translation);
		} else {				
			throw new ApiInternalServerErrorException("invalidtranslationseverity");
		}
		
		Boolean ticketSpecialFlag = ticketHeader.getSpecialFlag();
		String specialFlag = ticketSpecialFlag.toString(); 
		if (null != specialFlag && translations.getSpecialFlag().containsKey(specialFlag)){
			String translation = translations.getSpecialFlag().get(specialFlag);
			issueTranslations.setSpecialFlag(translation);
		} else {
			throw new ApiInternalServerErrorException("invalidtranslationspecialflag");
		}


		return issueTranslations;
	}

	/**
	 * Devuelve la traducción del campo status
	 * @param ticketEntry
	 * @throws ApiInternalServerErrorException
	 * @throws URISyntaxException
	 * @throws IOException
	 */
	public String translateStatus(TicketEntry ticketEntry) throws IOException, URISyntaxException, ApiInternalServerErrorException  {
		Translations translations = getTranslations();
		if (null == ticketEntry.getStatus() || ticketEntry.getStatus().size() == 0){
			throw new ApiInternalServerErrorException("invalidtranslationstatus");
		}
		String status = Constants.STATUS_UNASSIGNED;
		if (null != ticketEntry.getStatus() && ticketEntry.getStatus().size() > 0){
			status = ticketEntry.getStatus().get(0).getNewStatus();
			if (null != status && translations.getExternalState().containsKey(status)){
				status = translations.getExternalState().get(status);
			} else {
				throw new ApiInternalServerErrorException("invalidtranslationstatus");
			}
		}
		return status;
	}

    @CacheResult(cacheName = "translations-cache")
	public Translations getTranslations() throws IOException, URISyntaxException {
		File file;
		String activeProfile = ProfileManager.getActiveProfile();
		if ("dev".equalsIgnoreCase(activeProfile) || "local".equalsIgnoreCase(activeProfile) || "test".equalsIgnoreCase(activeProfile)){
			ClassLoader classLoader = getClass().getClassLoader();
			URL resource = classLoader.getResource(translationsFilePath);
			file = new File(resource.toURI());
		} else {
			file = Paths.get(translationsFilePath.trim()).toRealPath().toFile();
		}
		ObjectMapper mapper = new ObjectMapper();
		Translations translations = mapper.readValue(file, Translations.class);
		return translations;
	}

	@CacheInvalidate(cacheName = "translations-cache")
    public void invalidateCache() { }

}
