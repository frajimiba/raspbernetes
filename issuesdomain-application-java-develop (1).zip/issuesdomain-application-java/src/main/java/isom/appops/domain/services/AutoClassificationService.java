package isom.appops.domain.services;

import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.util.UUID;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.transaction.Transactional;

import isom.appops.database.entities.IssueEntity;
import isom.appops.domain.model.entries.AutomaticClassificationEntry;
import isom.appops.quarkus.errorhandler.exception.ApiBadRequestException;

@ApplicationScoped
public class AutoClassificationService {
    
    @Transactional
    public IssueEntity autoClassify(UUID issueId, AutomaticClassificationEntry entry) throws ApiBadRequestException {
        IssueEntity entity = IssueEntity.findById(issueId);
        if (entity == null){
			throw new ApiBadRequestException("issuenotfound");
        }
        ZoneId zoneId = ZoneId.of("Europe/Madrid");
        entity.setClassification(entry.getClassification());
        entity.setClassificationDate(OffsetDateTime.now(zoneId));
        entity.persist();
        return entity;
    }
    
}
