package isom.appops.domain.services;

import io.quarkus.panache.common.Page;
import io.quarkus.panache.common.Sort;
import isom.appops.database.entities.ExecutionTemplateEntity;
import isom.appops.database.repository.ExecutionTemplateEntityRepository;
import isom.appops.domain.mappers.ExecutionTemplateMapper;
import isom.appops.domain.model.PageRequest;
import isom.appops.domain.model.dto.ExecutionTemplateDTO;
import isom.appops.domain.model.entries.ExecutionTemplateEntry;
import isom.appops.quarkus.data.PagedResult;
import isom.appops.quarkus.errorhandler.exception.ApiBadRequestException;
import isom.appops.quarkus.errorhandler.exception.ApiInternalServerErrorException;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import org.eclipse.microprofile.jwt.JsonWebToken;

import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.util.List;
import java.util.stream.Collectors;

@ApplicationScoped
public class ExecutionTemplateService {

    @Inject
    JsonWebToken jwt;

    @Inject
    ExecutionTemplateMapper mapper;

    @Inject
    ExecutionTemplateEntityRepository repository;

    public ExecutionTemplateDTO get(Long id) {
        ExecutionTemplateEntity entity = ExecutionTemplateEntity.findById(id);
        return mapper.toDTO(entity);
    }

    @Transactional
    public void delete(Long id) {
        ExecutionTemplateEntity entity = ExecutionTemplateEntity.findById(id);
        if (null != entity) {
            entity.delete();
        }
    }

    @Transactional
    public ExecutionTemplateDTO add(ExecutionTemplateEntry entry) throws ApiBadRequestException, ApiInternalServerErrorException {

        ExecutionTemplateEntity oldEntity = repository.findByTemplateIdAndName(entry.getTemplateId(), entry.getTemplateName());
        if (null != oldEntity){
            throw new ApiInternalServerErrorException("executiontemplatealreadyexists");
        }

        ExecutionTemplateEntity entity = mapper.toEntity(entry);
        entity.setCreatedBy(jwt.getName());
        ZoneId zoneId = ZoneId.of("Europe/Madrid");
        entity.setCreationDate(OffsetDateTime.now(zoneId));
        entity.persist();
        return mapper.toDTO(entity);
    }

    @Transactional
    public ExecutionTemplateDTO update(Long id, ExecutionTemplateEntry entry) throws ApiBadRequestException, ApiInternalServerErrorException {

        ExecutionTemplateEntity oldEntity = repository.findByTemplateIdAndName(entry.getTemplateId(), entry.getTemplateName());
        ExecutionTemplateEntity entity = ExecutionTemplateEntity.findById(id);

        if (null != oldEntity && !oldEntity.equals(entity)){
            throw new ApiInternalServerErrorException("executiontemplatealreadyexists");
        }

        mapper.toEntity(entry, entity);
        entity.persist();
        return mapper.toDTO(entity);
    }

    public PagedResult<ExecutionTemplateDTO> list(PageRequest pageRequest) {
        PagedResult<ExecutionTemplateEntity> entities = repository.findBy(Page.of(pageRequest.page, pageRequest.size), Sort.by(pageRequest.sort).direction(pageRequest.ascending ? Sort.Direction.Ascending : Sort.Direction.Descending));
        PagedResult<ExecutionTemplateDTO> result = new PagedResult<ExecutionTemplateDTO>();
        List<ExecutionTemplateDTO> ticketDtos = entities.getList().stream().map((entity) -> mapper.toDTO(entity)).collect(Collectors.toList());
        result.setList(ticketDtos);
        result.setNumOfResults(entities.getNumOfResults());
        result.setPage(entities.getPage());
        result.setSize(entities.getSize());
        return result;
    }

    public ExecutionTemplateDTO findByTemplateIdAndName(String jobTemplateId, String jobTemplateName) {
        ExecutionTemplateEntity entity = repository.findByTemplateIdAndName(jobTemplateId, jobTemplateName);
        return mapper.toDTO(entity);
    }

}
