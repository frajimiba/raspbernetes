package isom.appops.domain.mappers;

import isom.appops.database.entities.ExecutionEntity;
import isom.appops.database.entities.FeedbackEntity;
import isom.appops.domain.model.dto.FeedbackDTO;
import isom.appops.domain.model.entries.FeedbackEntry;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

@Mapper(componentModel = "cdi")
public interface FeedbackMapper {

    @Mapping(target = "id", ignore = true)
    @Mapping(target = "executionRef", expression = "java(toExecutionEntity(dto.getExecutionRef()))")
    FeedbackEntity toEntity(FeedbackDTO dto);

    @Mapping(target = "id", ignore = true)
    @Mapping(target = "userId", ignore = true)
    @Mapping(target = "creationDate", ignore = true)
    @Mapping(target = "executionRef", expression = "java(toExecutionEntity(entry.getExecutionRef()))")
    FeedbackEntity toEntity(FeedbackEntry entry);

    @Mapping(target = "executionRef", expression = "java(toExecutionEntity(dto.getExecutionRef()))")
    void toEntity(FeedbackEntry dto, @MappingTarget() FeedbackEntity entity);

    @Mapping(target = "executionRef", expression = "java(toExecutionRefId(entity.getExecutionRef()))")
    FeedbackDTO toDTO(FeedbackEntity entity);

    default ExecutionEntity toExecutionEntity(Long id){
        return ExecutionEntity.findById(id);
    }

    default Long toExecutionRefId(ExecutionEntity executionEntity){
        return executionEntity.getId();
    }
    
}
