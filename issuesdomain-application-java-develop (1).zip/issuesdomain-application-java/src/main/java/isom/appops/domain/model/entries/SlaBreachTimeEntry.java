package isom.appops.domain.model.entries;

import java.time.OffsetDateTime;
import java.util.Objects;
import java.util.UUID;

public class SlaBreachTimeEntry {
    private UUID issueId;
    private OffsetDateTime slaBreachTime;

    public SlaBreachTimeEntry() {
    }

    public SlaBreachTimeEntry(UUID issueId, OffsetDateTime slaBreachTime) {
        this.issueId = issueId;
        this.slaBreachTime = slaBreachTime;
    }

    public UUID getIssueId() {
        return this.issueId;
    }

    public void setIssueId(UUID issueId) {
        this.issueId = issueId;
    }

    public OffsetDateTime getSlaBreachTime() {
        return this.slaBreachTime;
    }

    public void setSlaBreachTime(OffsetDateTime slaBreachTime) {
        this.slaBreachTime = slaBreachTime;
    }

    public SlaBreachTimeEntry issueId(UUID issueId) {
        setIssueId(issueId);
        return this;
    }

    public SlaBreachTimeEntry slaBreachTime(OffsetDateTime slaBreachTime) {
        setSlaBreachTime(slaBreachTime);
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof SlaBreachTimeEntry)) {
            return false;
        }
        SlaBreachTimeEntry slaBreachTimeEntry = (SlaBreachTimeEntry) o;
        return Objects.equals(issueId, slaBreachTimeEntry.issueId) && Objects.equals(slaBreachTime, slaBreachTimeEntry.slaBreachTime);
    }

    @Override
    public int hashCode() {
        return Objects.hash(issueId, slaBreachTime);
    }

    @Override
    public String toString() {
        return "{" +
            " issueId='" + getIssueId() + "'" +
            ", slaBreachTime='" + getSlaBreachTime() + "'" +
            "}";
    }

}
