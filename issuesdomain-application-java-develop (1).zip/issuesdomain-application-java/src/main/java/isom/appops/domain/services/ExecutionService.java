package isom.appops.domain.services;

import isom.appops.database.entities.ExecutionEntity;
import isom.appops.database.entities.FeedbackEntity;
import isom.appops.database.entities.IssueEntity;
import isom.appops.database.entities.ProcedureEntity;
import isom.appops.database.repository.ExecutionEntityRepository;
import isom.appops.database.repository.FeedbackEntityRepository;
import isom.appops.domain.mappers.ExecutionMapper;
import isom.appops.domain.mappers.FeedbackMapper;
import isom.appops.domain.model.PageRequest;
import isom.appops.domain.model.dto.ExecutionDTO;
import isom.appops.domain.model.dto.FeedbackDTO;
import isom.appops.quarkus.data.PagedResult;
import isom.appops.quarkus.errorhandler.exception.ApiBadRequestException;
import isom.appops.quarkus.errorhandler.exception.ApiInternalServerErrorException;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@ApplicationScoped
public class ExecutionService {

    @Inject
    ExecutionEntityRepository executionEntityRepository;

    @Inject
    ExecutionMapper executionMapper;

    @Inject
    FeedbackMapper feedbackMapper;

    @Inject
    FeedbackEntityRepository feedbackEntityRepository;

    @Transactional
    public ExecutionDTO updateUrlJob(Long id, String urlJob) {
        ExecutionEntity executionEntity = ExecutionEntity.findById(id);
        executionEntity.setUrlJob(urlJob);
        executionEntity.persist();
        return executionMapper.toDTO(executionEntity);
    }

    public PagedResult<FeedbackDTO> getFeedbacks(Long id, PageRequest pageRequest) {
        PagedResult<FeedbackEntity> entities = feedbackEntityRepository.findAllByExecutionId(id, pageRequest);
        PagedResult<FeedbackDTO> result = new PagedResult<FeedbackDTO>();
        List<FeedbackDTO> dtos = entities.getList().stream().map((entity) -> feedbackMapper.toDTO(entity)).collect(Collectors.toList());
        result.setList(dtos);
        result.setNumOfResults(entities.getNumOfResults());
        result.setPage(entities.getPage());
        result.setSize(entities.getSize());
        return result;
    }

    public List<ExecutionDTO> getExecutionsByIssueId(UUID id) {
        return executionEntityRepository.findAllByIssueId(id).stream().map((entity) -> executionMapper.toDTO(entity)).collect(Collectors.toList());
    }

}
