package isom.appops.domain.resource;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import jakarta.annotation.security.RolesAllowed;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;
import jakarta.ws.rs.core.SecurityContext;

import isom.appops.database.entities.IssueEntity;
import isom.appops.domain.model.PageRequest;
import isom.appops.domain.model.dto.ExecutionDTO;
import isom.appops.domain.model.entries.ManualClassificationEntry;
import isom.appops.domain.model.events.NotificationEventData;
import isom.appops.domain.services.*;
import isom.appops.ticketentry.TicketEntryUtils;
import isom.appops.openapi_ticketdetails.api.TicketsResourceApi;
import isom.appops.openapi_ticketdetails.model.TicketDTO;
import io.vertx.core.eventbus.EventBus;
import isom.appops.domain.services.*;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.enums.SchemaType;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;
import org.eclipse.microprofile.openapi.annotations.tags.Tags;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

import isom.appops.domain.model.dto.IssueDTO;
import isom.appops.ticketentry.model.TicketEntry;
import isom.appops.ticketentry.model.TicketHeader;
import isom.appops.quarkus.data.PagedResult;
import isom.appops.quarkus.errorhandler.exception.ApiBadRequestException;
import isom.appops.quarkus.errorhandler.exception.ApiInternalServerErrorException;

import io.quarkus.security.Authenticated;

import static isom.appops.domain.utils.Constants.NOTIFICATION_EVENT_NEW_ISSUE;

@Path("/issues")
@RegisterRestClient
@Authenticated
@Tags(value = @Tag( name="IssuesResource", description = "IssuesResource"))
public class IssuesResource {

	@Inject
    IssuesService issuesService;

	@Inject
    StatusTrackingService statusTrackingService;

	@Inject
    ManualClassificationService manualClassificationService;

	@Inject
    ExternalGroupService externalGroupService;

	@Inject
    ExecutionService executionService;

	@Inject
	JwtTokenService tokenService;

	@Inject
	ViewsService viewsService;

	@Inject
	TicketDetailsService ticketDetailsService;

	@Inject
	EventBus bus;

	@Operation(summary = "Get issue info")
    @APIResponse(responseCode = "200", description = "Get issue info", content = @Content(mediaType = "application/json", schema = @Schema(implementation = IssueDTO.class)))
	@APIResponse(responseCode = "400", description = "Bad request", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ApiBadRequestException.class)))
	@APIResponse(responseCode = "500", description = "Internal Server Error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ApiInternalServerErrorException.class)))
	@GET
	@Path("/{id}")
	@RolesAllowed({"ticket-ingestor", "admin", "sre", "ftr","operador","auto"})
	@Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
	public Response getIssueInfo(@PathParam("id") UUID id) {
		IssueDTO result = issuesService.get(id);
		return Response.status(Status.OK).entity(result).build();
	}
	
    @Operation(summary = "Insert an issue in the database")
    @APIResponse(responseCode = "200", description = "Not modified", content = @Content(mediaType = "application/json", schema = @Schema(implementation = IssueDTO.class)))
    @APIResponse(responseCode = "201", description = "Created", content = @Content(mediaType = "application/json", schema = @Schema(implementation = IssueDTO.class)))
    @APIResponse(responseCode = "400", description = "Bad request", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ApiBadRequestException.class)))
	@APIResponse(responseCode = "500", description = "Internal Server Error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ApiInternalServerErrorException.class)))
	@POST
	@Path("/issue")
	@RolesAllowed({"ticket-ingestor", "admin", "sre", "ftr","operador","auto"})
	@Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
	public Response insertTicketEntry(TicketEntry ticketEntry) throws ApiBadRequestException, ApiInternalServerErrorException, IOException, URISyntaxException {

		TicketHeader ticketHeader = ticketEntry.getHeader();
		if (null == ticketHeader){
			throw new ApiBadRequestException("invalidticketheader");
		}

		UUID uuid = TicketEntryUtils.getUuid(ticketEntry.getHeader());
		IssueEntity issueBeforeChange = IssueEntity.findById(uuid);

		IssueDTO issueDTO = issuesService.addOrUpdate(ticketEntry);

		IssueEntity issueEntity = IssueEntity.findById(issueDTO.getId());

		if (null != ticketEntry.getStatus() && ticketEntry.getStatus().size() > 0 && issueBeforeChange == null){
			statusTrackingService.add(issueEntity, ticketEntry);
		}

		String manualClassification = ticketEntry.getHeader().getManualClassification();

		if (manualClassification != null && !manualClassification.isEmpty()){
			ManualClassificationEntry manualClassificationEntry = new ManualClassificationEntry();
			manualClassificationEntry.setClassification(manualClassification);
			manualClassificationEntry.setUserName(ticketEntry.getHeader().getCreatedBy());
			manualClassificationService.manualClassify(issueDTO.getId(), manualClassificationEntry);
			boolean procedureExecuted = manualClassificationService.checkAndExecuteClassificationProcedure(issueDTO.getId(), manualClassificationEntry);

			if (!procedureExecuted && (issueBeforeChange == null || !issueBeforeChange.getGroupName().equalsIgnoreCase(issueDTO.getGroupName()))){
				externalGroupService.externalGroupChanged(issueDTO.getId());
			}
		}

		TicketDTO ticketDTO = ticketDetailsService.getDetails(issueDTO.getId());
		bus.publish(NOTIFICATION_EVENT_NEW_ISSUE, new NotificationEventData(issueDTO.getId(), "", ticketDTO, tokenService.getRawToken()));
		
		return Response.status(Status.CREATED).entity(issueDTO).build();
	}

    @Operation(summary = "Update an issue in the database")
    @APIResponse(responseCode = "200", description = "Created", content = @Content(mediaType = "application/json", schema = @Schema(implementation = IssueDTO.class)))
    @APIResponse(responseCode = "201", description = "Accepted", content = @Content(mediaType = "application/json", schema = @Schema(implementation = IssueDTO.class)))
    @APIResponse(responseCode = "400", description = "Bad request", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ApiBadRequestException.class)))
	@APIResponse(responseCode = "500", description = "Internal Server Error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ApiInternalServerErrorException.class)))
	@PUT
	@Path("/issue")
	@RolesAllowed({"ticket-ingestor", "admin", "sre", "ftr","operador","auto"})
	@Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
	public Response insertUpdateTicketEntry(IssueDTO issueDTO) throws ApiBadRequestException, ApiInternalServerErrorException, IOException, URISyntaxException {
		IssueDTO result = issuesService.update(issueDTO);
		return Response.status(Status.ACCEPTED).entity(result).build();
	}

    @Operation(summary = "Get all issues paginated")
    @APIResponse(responseCode = "200", description = "All issues paginated", content = @Content(mediaType = "application/json", schema = @Schema(ref = "PagedResultIssueDTO")))
	@GET
	@Path("/")
    @RolesAllowed({"ticket-ingestor", "admin", "sre", "ftr","operador","auto"})
	@Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
	public Response getIssues(@BeanParam PageRequest pageRequest) {
		PagedResult<IssueDTO> result = issuesService.getIssues(pageRequest);
		return Response.status(Status.OK).entity(result).build();
	}


	@Operation(summary = "Get all executions by issueId")
	@APIResponse(responseCode = "200", description = "All executions", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ExecutionDTO.class, type = SchemaType.ARRAY)))
	@GET
	@Path("/{id}/executions")
	@RolesAllowed({"ticket-ingestor", "admin", "sre", "ftr","operador","auto"})
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response getExecutionsByIssueId(@PathParam("id") UUID id) {
		List<ExecutionDTO> result = executionService.getExecutionsByIssueId(id);
		return Response.status(Status.OK).entity(result).build();
	}

	@Operation(summary = "Get the amount of user issues by statuses")
	@APIResponse(responseCode = "200", description = "The amount of issues assigned to the authenticated user", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Long.class)))
	@POST
	@Path("/amount/assigned-user")
	@RolesAllowed({"ticket-ingestor", "admin", "sre", "ftr","operador","auto"})
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response getAmountUserIssues(List<String> statuses, @Context SecurityContext securityContext) {
		String userId = securityContext.getUserPrincipal().getName();
		List<String> ids = new ArrayList<>();
		ids.add(userId);
		Long result = viewsService.getAmountIssuesAssignedToUsers(ids, statuses);
		return Response.status(Status.OK).entity(result).build();
	}
}
