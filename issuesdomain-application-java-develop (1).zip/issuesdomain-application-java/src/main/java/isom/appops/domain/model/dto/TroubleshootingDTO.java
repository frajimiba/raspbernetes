package isom.appops.domain.model.dto;

import java.time.OffsetDateTime;
import java.util.Objects;
import java.util.UUID;

public class TroubleshootingDTO {

    private Long id;

    private String content;

    private String userId;

    private UUID issueId;

    private OffsetDateTime creationDate;

    public TroubleshootingDTO() {
    }

    public TroubleshootingDTO(Long id, String content, String userId, UUID issueId, OffsetDateTime creationDate) {
        this.id = id;
        this.content = content;
        this.userId = userId;
        this.issueId = issueId;
        this.creationDate = creationDate;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public UUID getIssueId() {
        return issueId;
    }

    public void setIssueId(UUID issueId) {
        this.issueId = issueId;
    }

    public OffsetDateTime getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(OffsetDateTime creationDate) {
        this.creationDate = creationDate;
    }
}
