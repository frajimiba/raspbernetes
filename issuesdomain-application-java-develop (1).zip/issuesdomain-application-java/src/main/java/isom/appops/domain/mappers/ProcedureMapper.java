package isom.appops.domain.mappers;

import isom.appops.domain.model.dto.ProcedureRatingDTO;
import isom.appops.database.entities.ProcedureEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

import isom.appops.domain.model.dto.ProcedureDTO;
import isom.appops.domain.model.entries.ProcedureEntry;

@Mapper(componentModel = "cdi")
public interface ProcedureMapper {

    @Mapping(target = "id", ignore = true)
    ProcedureEntity toEntity(ProcedureDTO dto);

    ProcedureEntity toEntity(ProcedureEntry entry);

    void toEntity(ProcedureEntry dto, @MappingTarget() ProcedureEntity entity);

    ProcedureDTO toDTO(ProcedureEntity entity);

    @Mapping(target = "rating", ignore = true)
    ProcedureRatingDTO toRatingDTO(ProcedureEntity entity);
}
