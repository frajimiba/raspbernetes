package isom.appops.domain.model.dto;

public class ProcedureRatingDTO extends ProcedureDTO {

    private double rating;

    public ProcedureRatingDTO() {
        super();
    }

    public ProcedureRatingDTO(ProcedureDTO procedureDTO, double rating){
        super(
            procedureDTO.id,
            procedureDTO.title,
            procedureDTO.clientId,
            procedureDTO.description,
            procedureDTO.responseTemplate,
            procedureDTO.creationDate,
            procedureDTO.userId,
            procedureDTO.urlJob,
            procedureDTO.urlCommunication,
            procedureDTO.classification,
            procedureDTO.automatic,
            procedureDTO.configFileEnvironment,
            procedureDTO.configFilePath,
            procedureDTO.configFileVersion,
            procedureDTO.jobTemplateName,
            procedureDTO.jobTemplateId,
            procedureDTO.procedureType
        );
        this.rating = rating;
    }

    public double getRating() {
        return rating;
    }

    public void setRating(double rating) {
        this.rating = rating;
    }
}
