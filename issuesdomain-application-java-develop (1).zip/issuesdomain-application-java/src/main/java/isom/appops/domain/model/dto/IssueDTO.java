package isom.appops.domain.model.dto;

import java.time.OffsetDateTime;
import java.util.Objects;
import java.util.UUID;

public class IssueDTO {
    
    private UUID id;
    private String ticketId;
    private String clientId;
    private String issueType;
    private String groupName;
    private String severity;
    private String specialFlag;
    private OffsetDateTime slaBreachTime;
    private String classification;
    private OffsetDateTime classificationDate;
    private OffsetDateTime resolutionDate;


    public IssueDTO() {
    }

    public IssueDTO(UUID id, String ticketId, String clientId, String issueType, String groupName, String severity, String specialFlag, OffsetDateTime slaBreachTime, String classification, OffsetDateTime classificationDate, OffsetDateTime resolutionDate) {
        this.id = id;
        this.ticketId = ticketId;
        this.clientId = clientId;
        this.issueType = issueType;
        this.groupName = groupName;
        this.severity = severity;
        this.specialFlag = specialFlag;
        this.slaBreachTime = slaBreachTime;
        this.classification = classification;
        this.classificationDate = classificationDate;
        this.resolutionDate = resolutionDate;
    }

    public OffsetDateTime getResolutionDate() {
        return resolutionDate;
    }

    public void setResolutionDate(OffsetDateTime resolutionDate) {
        this.resolutionDate = resolutionDate;
    }

    public UUID getId() {
        return this.id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getTicketId() {
        return this.ticketId;
    }

    public void setTicketId(String ticketId) {
        this.ticketId = ticketId;
    }

    public String getClientId() {
        return this.clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getIssueType() {
        return this.issueType;
    }

    public void setIssueType(String issueType) {
        this.issueType = issueType;
    }

    public String getGroupName() {
        return this.groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getSeverity() {
        return this.severity;
    }

    public void setSeverity(String severity) {
        this.severity = severity;
    }

    public String getSpecialFlag() {
        return this.specialFlag;
    }

    public void setSpecialFlag(String specialFlag) {
        this.specialFlag = specialFlag;
    }

    public OffsetDateTime getSlaBreachTime() {
        return this.slaBreachTime;
    }

    public void setSlaBreachTime(OffsetDateTime slaBreachTime) {
        this.slaBreachTime = slaBreachTime;
    }

    public String getClassification() {
        return this.classification;
    }

    public void setClassification(String classification) {
        this.classification = classification;
    }

    public OffsetDateTime getClassificationDate() {
        return this.classificationDate;
    }

    public void setClassificationDate(OffsetDateTime classificationDate) {
        this.classificationDate = classificationDate;
    }

    public IssueDTO id(UUID id) {
        setId(id);
        return this;
    }

    public IssueDTO ticketId(String ticketId) {
        setTicketId(ticketId);
        return this;
    }

    public IssueDTO clientId(String clientId) {
        setClientId(clientId);
        return this;
    }

    public IssueDTO issueType(String issueType) {
        setIssueType(issueType);
        return this;
    }

    public IssueDTO groupName(String groupName) {
        setGroupName(groupName);
        return this;
    }

    public IssueDTO severity(String severity) {
        setSeverity(severity);
        return this;
    }

    public IssueDTO specialFlag(String specialFlag) {
        setSpecialFlag(specialFlag);
        return this;
    }

    public IssueDTO slaBreachTime(OffsetDateTime slaBreachTime) {
        setSlaBreachTime(slaBreachTime);
        return this;
    }

    public IssueDTO classification(String classification) {
        setClassification(classification);
        return this;
    }

    public IssueDTO classificationDate(OffsetDateTime classificationDate) {
        setClassificationDate(classificationDate);
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof IssueDTO)) {
            return false;
        }
        IssueDTO issueDTO = (IssueDTO) o;
        return Objects.equals(id, issueDTO.id) && Objects.equals(ticketId, issueDTO.ticketId) && Objects.equals(clientId, issueDTO.clientId) && Objects.equals(issueType, issueDTO.issueType) && Objects.equals(groupName, issueDTO.groupName) && Objects.equals(severity, issueDTO.severity) && Objects.equals(specialFlag, issueDTO.specialFlag) && Objects.equals(slaBreachTime, issueDTO.slaBreachTime) && Objects.equals(classification, issueDTO.classification) && Objects.equals(classificationDate, issueDTO.classificationDate);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, ticketId, clientId, issueType, groupName, severity, specialFlag, slaBreachTime, classification, classificationDate);
    }

    @Override
    public String toString() {
        return "{" +
            " id='" + getId() + "'" +
            ", ticketId='" + getTicketId() + "'" +
            ", clientId='" + getClientId() + "'" +
            ", issueType='" + getIssueType() + "'" +
            ", groupName='" + getGroupName() + "'" +
            ", severity='" + getSeverity() + "'" +
            ", specialFlag='" + getSpecialFlag() + "'" +
            ", slaBreachTime='" + getSlaBreachTime() + "'" +
            ", classification='" + getClassification() + "'" +
            ", classificationDate='" + getClassificationDate() + "'" +
            "}";
    }

}
