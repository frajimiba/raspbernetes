package isom.appops.domain.clients.awx;

import java.util.Date;

class JobResponse {
    private Date finished;

    public Date getFinished() {
        return finished;
    }

    public void setFinished(Date finished) {
        this.finished = finished;
    }
}