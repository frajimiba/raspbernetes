package isom.appops.domain.services;

import java.time.OffsetDateTime;
import java.util.UUID;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;

import isom.appops.database.entities.IssueEntity;
import isom.appops.domain.mappers.IssueMapper;
import isom.appops.domain.model.dto.IssueDTO;
import isom.appops.quarkus.errorhandler.exception.ApiBadRequestException;

@ApplicationScoped
public class SlaService {
    
    @Inject
    IssueMapper issueMapper;
    
    @Transactional
    public IssueDTO setSlaBreachTime(UUID issueId, OffsetDateTime slaBreachTime) throws ApiBadRequestException {
        IssueEntity issueEntity = IssueEntity.findById(issueId);
        if (issueEntity == null){
			throw new ApiBadRequestException("issuenotfound");
        }
        issueEntity.setSlaBreachTime(slaBreachTime);
        issueEntity.persist();
        return issueMapper.toIssueDTO(issueEntity);
    }

}
