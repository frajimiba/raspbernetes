package isom.appops.domain.services;

import java.io.IOException;
import java.net.URISyntaxException;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;

import isom.appops.database.entities.IssueEntity;
import isom.appops.database.entities.StatusTrackingEntity;
import isom.appops.database.repository.StatusTrackingEntityRepository;
import isom.appops.domain.mappers.StatusTrackingMapper;
import isom.appops.domain.model.dto.StatusTrackingDTO;
import isom.appops.ticketentry.model.TicketEntry;
import isom.appops.quarkus.errorhandler.exception.ApiInternalServerErrorException;

@ApplicationScoped
public class StatusTrackingService {
    
	@Inject
    StatusTrackingEntityRepository statusTrackingEntityRepository;

	@Inject
	TranslationsService translationsService;

    @Inject
    StatusTrackingMapper statusTrackingMapper;

    /**
     * Inserta el estado inicial del ticket ya traducido
     * @throws URISyntaxException
     * @throws IOException
     * @throws ApiInternalServerErrorException
    */
    @Transactional
    public StatusTrackingDTO add(IssueEntity issue, TicketEntry ticketEntry) throws ApiInternalServerErrorException, IOException, URISyntaxException {
        ZoneId zoneId = ZoneId.of("Europe/Madrid");     
        StatusTrackingDTO statusTrackingDTO = new StatusTrackingDTO();
        statusTrackingDTO.setIssueId(issue.getId());
        statusTrackingDTO.setTsInitial(OffsetDateTime.now(zoneId));
        statusTrackingDTO.setTsFinal(OffsetDateTime.now(zoneId));
		statusTrackingDTO.setStatus(translationsService.translateStatus(ticketEntry));
        StatusTrackingEntity entity = new StatusTrackingEntity();
        statusTrackingMapper.toEntity(statusTrackingDTO, entity);
        entity.persist();

        return statusTrackingMapper.toDTO(entity);
    }

    /**
     * Devuelve el listado de estados de un ticket ordenados por fecha
     * @param issueId
     * @return
     */
    public List<StatusTrackingDTO> getStatuses(UUID issueId) {
        List<StatusTrackingEntity> entities = statusTrackingEntityRepository.findStatusesByIssueId(issueId);
        List<StatusTrackingDTO> result = entities.stream().map((statusTrackingEntity) -> {
            StatusTrackingDTO statusTrackingDTO = new StatusTrackingDTO();
            statusTrackingMapper.toDTO(statusTrackingEntity, issueId, statusTrackingDTO);
            return statusTrackingDTO;
        }).collect(Collectors.toList());
        return result;
    }


    /**
     * Cambia el estado de la issue
    */
    @Transactional
    public StatusTrackingDTO add(UUID id, String status) {

        ZoneId zoneId = ZoneId.of("Europe/Madrid");
        OffsetDateTime dateTime = OffsetDateTime.now(zoneId);

        IssueEntity issueEntity = IssueEntity.findById(id);

        StatusTrackingEntity entity = new StatusTrackingEntity();
        entity.setIssue(issueEntity);
        entity.setStatus(status);
        entity.setTsInitial(dateTime);
        entity.setTsFinal(dateTime);
        entity.persist();

        return statusTrackingMapper.toDTO(entity);
    }
    
}
