package isom.appops.domain.mappers;

import isom.appops.database.entities.ManualClassificationEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import isom.appops.domain.model.dto.ManualClassificationDTO;
import isom.appops.domain.model.entries.ManualClassificationEntry;

@Mapper(componentModel = "cdi")
public interface ManualClassificationMapper {

    @Mapping(target = "issue", ignore = true)
    ManualClassificationEntity toEntity(ManualClassificationEntry entry);

    ManualClassificationDTO toDTO(ManualClassificationEntity entity);    
    
}
