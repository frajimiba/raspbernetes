package isom.appops.domain.model.dto;

import java.time.OffsetDateTime;
import java.util.Objects;
import java.util.UUID;

public class FullIssueViewDTO {
    
    // Issue fields
    private UUID id;
    private String ticketId;
    private String clientId;
    private String issueType;
    private String groupName;
    private String severity;
    private String specialFlag;
    private OffsetDateTime slaBreachTime;
    private String classification;
    private OffsetDateTime classificationDate;
    private OffsetDateTime resolutionDate;

    // ManualClassification fields
    private String manualClassificationUser;
    private String manualClassification;    
    private OffsetDateTime manualClassificationTimestamp;

    // Assigned user
    private String assignedUser;

    // Current status
    private String status;

    public FullIssueViewDTO() {
    }

    public FullIssueViewDTO(UUID id, String ticketId, String clientId, String issueType, String groupName, String severity, String specialFlag, OffsetDateTime slaBreachTime, OffsetDateTime resolutionDate, String classification, OffsetDateTime classificationDate, String manualClassificationUser, String manualClassification, OffsetDateTime manualClassificationTimestamp, String assignedUser, String status) {
        this.id = id;
        this.ticketId = ticketId;
        this.clientId = clientId;
        this.issueType = issueType;
        this.groupName = groupName;
        this.severity = severity;
        this.specialFlag = specialFlag;
        this.slaBreachTime = slaBreachTime;
        this.resolutionDate = resolutionDate;
        this.classification = classification;
        this.classificationDate = classificationDate;
        this.manualClassificationUser = manualClassificationUser;
        this.manualClassification = manualClassification;
        this.manualClassificationTimestamp = manualClassificationTimestamp;
        this.assignedUser = assignedUser;
        this.status = status;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getTicketId() {
        return ticketId;
    }

    public void setTicketId(String ticketId) {
        this.ticketId = ticketId;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getIssueType() {
        return issueType;
    }

    public void setIssueType(String issueType) {
        this.issueType = issueType;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getSeverity() {
        return severity;
    }

    public void setSeverity(String severity) {
        this.severity = severity;
    }

    public String getSpecialFlag() {
        return specialFlag;
    }

    public void setSpecialFlag(String specialFlag) {
        this.specialFlag = specialFlag;
    }

    public OffsetDateTime getSlaBreachTime() {
        return slaBreachTime;
    }

    public void setSlaBreachTime(OffsetDateTime slaBreachTime) {
        this.slaBreachTime = slaBreachTime;
    }

    public String getClassification() {
        return classification;
    }

    public void setClassification(String classification) {
        this.classification = classification;
    }

    public OffsetDateTime getClassificationDate() {
        return classificationDate;
    }

    public void setClassificationDate(OffsetDateTime classificationDate) {
        this.classificationDate = classificationDate;
    }

    public String getManualClassificationUser() {
        return manualClassificationUser;
    }

    public void setManualClassificationUser(String manualClassificationUser) {
        this.manualClassificationUser = manualClassificationUser;
    }

    public String getManualClassification() {
        return manualClassification;
    }

    public void setManualClassification(String manualClassification) {
        this.manualClassification = manualClassification;
    }

    public OffsetDateTime getManualClassificationTimestamp() {
        return manualClassificationTimestamp;
    }

    public void setManualClassificationTimestamp(OffsetDateTime manualClassificationTimestamp) {
        this.manualClassificationTimestamp = manualClassificationTimestamp;
    }

    public String getAssignedUser() {
        return assignedUser;
    }

    public void setAssignedUser(String assignedUser) {
        this.assignedUser = assignedUser;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public OffsetDateTime getResolutionDate() {
        return resolutionDate;
    }

    public void setResolutionDate(OffsetDateTime resolutionDate) {
        this.resolutionDate = resolutionDate;
    }
}
