package isom.appops.domain.clients.awx;

import org.apache.commons.codec.binary.Base64;
import org.eclipse.microprofile.config.inject.ConfigProperty;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientBuilder;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@ApplicationScoped
public class AWXClient {
    @ConfigProperty(name = "awx.base-url") // "https://<awx-hostname>/api/v2"
    String awxBaseUrl;
    @ConfigProperty(name = "awx.username")
    String awxUserName;
    @ConfigProperty(name = "awx.password")
    String awxPassword;

    private final Client client = ClientBuilder.newClient();

    public int submitForm(int templateId, String awxJsonForm){
        // Authenticate with AWX
        String token = getAuthorizationHeader();

        // Run the template with form data
        return runTemplate(token, templateId, awxJsonForm);
    }

    private String getAuthorizationHeader() {
        String auth = awxUserName + ":" + awxPassword;
        byte[] encodedAuth = Base64.encodeBase64(auth.getBytes());
        String authHeaderValue = "Basic " + new String(encodedAuth);
        return authHeaderValue;
    }

    private int runTemplate(String token, int templateId, String formData) {
        String url = awxBaseUrl + "/job_templates/" + templateId + "/launch/";
        Response response = client.target(url)
                .request(MediaType.APPLICATION_JSON)
                .header("Authorization", token)
                .header("Content-Type", "application/json")
                .header("Accept", "application/json")
                .post(Entity.json(new LaunchRequest(formData)));
        if (response.getStatus() != Response.Status.CREATED.getStatusCode()) {
            throw new RuntimeException("Failed to run template in AWX");
        }
        return response.readEntity(LaunchResponse.class).getJob();
    }

    private boolean isJobComplete(String token, int jobId) {
        String url = awxBaseUrl + "/jobs/" + jobId + "/";
        Response response = client.target(url)
                .request(MediaType.APPLICATION_JSON)
                .header("Authorization", token)
                .header("Content-Type", "application/json")
                .header("Accept", "application/json")
                .get();
        if (response.getStatus() != Response.Status.OK.getStatusCode()) {
            throw new RuntimeException("Failed to get job status from AWX");
        }
        return response.readEntity(JobResponse.class).getFinished() != null;
    }

}
