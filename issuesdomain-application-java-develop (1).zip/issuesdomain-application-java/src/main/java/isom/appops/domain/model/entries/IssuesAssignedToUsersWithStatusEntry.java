package isom.appops.domain.model.entries;

import java.util.List;

public class IssuesAssignedToUsersWithStatusEntry {

    List<String> userIds;
    List<String> statuses;

    public IssuesAssignedToUsersWithStatusEntry() {
    }

    public IssuesAssignedToUsersWithStatusEntry(List<String> userIds, List<String> statuses) {
        this.userIds = userIds;
        this.statuses = statuses;
    }

    public List<String> getUserIds() {
        return userIds;
    }

    public void setUserIds(List<String> userIds) {
        this.userIds = userIds;
    }

    public List<String> getStatuses() {
        return statuses;
    }

    public void setStatuses(List<String> statuses) {
        this.statuses = statuses;
    }
}
