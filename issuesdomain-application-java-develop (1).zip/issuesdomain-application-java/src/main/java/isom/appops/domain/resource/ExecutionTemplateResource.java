package isom.appops.domain.resource;

import io.quarkus.panache.common.Sort;
import io.quarkus.security.Authenticated;
import isom.appops.domain.model.PageRequest;
import isom.appops.domain.model.dto.ExecutionTemplateDTO;
import isom.appops.domain.model.entries.ExecutionTemplateEntry;
import isom.appops.domain.model.pagedresult.PagedResultExecutionTemplateDTO;
import isom.appops.domain.services.ExecutionTemplateService;
import isom.appops.quarkus.data.PagedResult;
import isom.appops.quarkus.errorhandler.exception.ApiBadRequestException;
import isom.appops.quarkus.errorhandler.exception.ApiInternalServerErrorException;
import jakarta.annotation.security.RolesAllowed;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;
import org.eclipse.microprofile.openapi.annotations.tags.Tags;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

import java.util.List;

@Path("/execution-template")
@RegisterRestClient
@Authenticated
@Tags(value = @Tag(name = "ExecutionTemplateResource", description = "ExecutionTemplateResource"))
public class ExecutionTemplateResource {


    @Inject
    ExecutionTemplateService service;

    @GET
    @Path("{id}")
    @RolesAllowed({"ticket-ingestor", "ftr", "sre", "admin", "operador", "auto"})
    @Operation(summary = "Get execution template by id")
    @APIResponse(responseCode = "200", description = "Accepted", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ExecutionTemplateDTO.class)))
    @APIResponse(responseCode = "500", description = "Internal Server Error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ApiInternalServerErrorException.class)))
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response get(@PathParam("id") Long id) {
        ExecutionTemplateDTO result = service.get(id);
        return Response.ok(result).build();
    }

    @GET
    @RolesAllowed({"ticket-ingestor", "ftr", "sre", "admin", "operador", "auto"})
    @Operation(summary = "Get all execution templates")
    @APIResponse(responseCode = "200", description = "Accepted", content = @Content(mediaType = "application/json", schema = @Schema(implementation = PagedResultExecutionTemplateDTO.class)))
    @APIResponse(responseCode = "500", description = "Internal Server Error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ApiInternalServerErrorException.class)))
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response list(@BeanParam PageRequest pageRequest) {
        PagedResult<ExecutionTemplateDTO> pagedResult = service.list(pageRequest);
        return Response.ok(pagedResult).build();
    }

    private Sort getSortFromQuery(List<String> sortQuery) {
        Sort sortObj = Sort.empty();
        sortQuery.forEach(Sort::by);
        return sortObj;
    }

    @Transactional
    @POST
    @RolesAllowed({"ticket-ingestor", "admin", "sre", "ftr", "operador", "auto"})
    @Operation(summary = "Add a new execution template")
    @APIResponse(responseCode = "200", description = "Accepted", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ExecutionTemplateDTO.class)))
    @APIResponse(responseCode = "400", description = "Bad request", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ApiBadRequestException.class)))
    @APIResponse(responseCode = "500", description = "Internal Server Error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ApiInternalServerErrorException.class)))
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response add(ExecutionTemplateEntry entry) {
        ExecutionTemplateDTO executionTemplateDTO = service.add(entry);
        return Response.ok(executionTemplateDTO).build();
    }

    @Transactional
    @PUT
    @Path("{id}")
    @RolesAllowed({"ticket-ingestor", "admin", "sre", "ftr", "operador", "auto"})
    @Operation(summary = "Update a execution template")
    @APIResponse(responseCode = "200", description = "Accepted", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ExecutionTemplateDTO.class)))
    @APIResponse(responseCode = "400", description = "Bad request", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ApiBadRequestException.class)))
    @APIResponse(responseCode = "500", description = "Internal Server Error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ApiInternalServerErrorException.class)))
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response update(@PathParam("id") Long id, ExecutionTemplateEntry entry) {
        ExecutionTemplateDTO executionTemplateDTO = service.update(id, entry);
        return Response.ok(executionTemplateDTO).build();
    }

    @Transactional
    @DELETE
    @Path("{id}")
    @RolesAllowed({"ticket-ingestor", "admin", "sre", "ftr", "operador", "auto"})
    @Operation(summary = "Delete executionTemplate by id")
    @APIResponse(responseCode = "200", description = "Accepted")
    @APIResponse(responseCode = "400", description = "Bad request", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ApiBadRequestException.class)))
    @APIResponse(responseCode = "500", description = "Internal Server Error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ApiInternalServerErrorException.class)))
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response delete(@PathParam("id") Long id) {
        service.delete(id);
        return Response.ok().build();
    }


}
