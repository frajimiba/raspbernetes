package isom.appops.domain.model.pagedresult;

import isom.appops.domain.model.dto.IssueDTO;
import isom.appops.quarkus.data.PagedResult;
import org.eclipse.microprofile.openapi.annotations.media.Schema;

@Schema(name = "PagedResultIssueDTO")
public class PagedResultIssueDTO extends PagedResult<IssueDTO> {
}
