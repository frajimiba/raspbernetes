package isom.appops.domain.model;

import java.util.Objects;

public class IssueTranslations {
    
    private String issueType;
    private String severity;
    private String specialFlag;


    public IssueTranslations() {
    }

    public IssueTranslations(String issueType, String severity, String specialFlag) {
        this.issueType = issueType;
        this.severity = severity;
        this.specialFlag = specialFlag;
    }

    public String getIssueType() {
        return this.issueType;
    }

    public void setIssueType(String issueType) {
        this.issueType = issueType;
    }

    public String getSeverity() {
        return this.severity;
    }

    public void setSeverity(String severity) {
        this.severity = severity;
    }

    public String getSpecialFlag() {
        return this.specialFlag;
    }

    public void setSpecialFlag(String specialFlag) {
        this.specialFlag = specialFlag;
    }

    public IssueTranslations issueType(String issueType) {
        setIssueType(issueType);
        return this;
    }

    public IssueTranslations severity(String severity) {
        setSeverity(severity);
        return this;
    }

    public IssueTranslations specialFlag(String specialFlag) {
        setSpecialFlag(specialFlag);
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof IssueTranslations)) {
            return false;
        }
        IssueTranslations issueTranslations = (IssueTranslations) o;
        return Objects.equals(issueType, issueTranslations.issueType) && Objects.equals(severity, issueTranslations.severity) && Objects.equals(specialFlag, issueTranslations.specialFlag);
    }

    @Override
    public int hashCode() {
        return Objects.hash(issueType, severity, specialFlag);
    }

    @Override
    public String toString() {
        return "{" +
            " issueType='" + getIssueType() + "'" +
            ", severity='" + getSeverity() + "'" +
            ", specialFlag='" + getSpecialFlag() + "'" +
            "}";
    }


}
