package isom.appops.domain.clients.awx;

class LaunchRequest {
    private String extra_vars;

    public LaunchRequest(String extra_vars) {
        this.extra_vars = extra_vars;
    }

    public String getExtra_vars() {
        return extra_vars;
    }

    public void setExtra_vars(String extra_vars) {
        this.extra_vars = extra_vars;
    }
}