package isom.appops.domain.services;

import java.util.List;
import java.util.UUID;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

import isom.appops.database.repository.FullIssuesViewsRepository;
import isom.appops.database.repository.ViewsRepository;
import isom.appops.domain.model.PageRequest;
import isom.appops.domain.model.dto.*;
import isom.appops.domain.model.dto.ExecutionDTO;
import isom.appops.domain.model.dto.FullIssueViewDTO;
import isom.appops.domain.model.dto.ProcedureDTO;
import isom.appops.domain.model.dto.ProcedureRatingDTO;
import isom.appops.domain.model.entries.FullIssueEntry;
import isom.appops.quarkus.data.PagedResult;

@ApplicationScoped
public class ViewsService {

    @Inject
    FullIssuesViewsRepository fullIssuesViewsRepository;

    @Inject
    ViewsRepository viewsRepository;

    public Long getAmountIssuesAssignedToUsers(List<String> userIds, List<String> statuses) {
        return viewsRepository.getAmountIssuesAssignedToUsers(userIds, statuses);
    }

    public PagedResult<ProcedureDTO> getProceduresByClassifications(List<String> classifications, PageRequest pageRequest) {
        return viewsRepository.getProceduresByClassifications(classifications, pageRequest);
    }

    public PagedResult<ProcedureRatingDTO> getProceduresByClassificationsWithRating(List<String> classifications, PageRequest pageRequest) {
        return viewsRepository.getProceduresByClassificationsWithRating(classifications, pageRequest);
    }

    public PagedResult<ExecutionDTO> getExecutionsByIssueId(UUID issueId, PageRequest pageRequest) {
        return viewsRepository.getExecutionsByIssueId(issueId, pageRequest);
    }

    public FullIssueViewDTO getFullIssue(UUID issueId) {
        return fullIssuesViewsRepository.getFullIssue(issueId);
    }

    public PagedResult<FullIssueViewDTO> getFullIssuesOwned(String userId, FullIssueEntry fullIssueEntry, PageRequest pageRequest) {
        return fullIssuesViewsRepository.getFullIssuesOwned(userId, fullIssueEntry, pageRequest);
    }

    public PagedResult<FullIssueViewDTO> getFullIssuesPending(FullIssueEntry fullIssueEntry, PageRequest pageRequest) {
        return fullIssuesViewsRepository.getFullIssuesPending(fullIssueEntry, pageRequest);
    }

    public PagedResult<FullIssueViewDTO> getFullIssuesGroups(FullIssueEntry fullIssueEntry, PageRequest pageRequest) {
        return fullIssuesViewsRepository.getFullIssuesGroups(fullIssueEntry, pageRequest);
    }

    public ProcedureDTO getProcedureByClassification(String classification) {
        return viewsRepository.getFirstProcedureByClassification(classification);
    }
}
