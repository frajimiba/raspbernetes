package isom.appops.domain.model.dto;

import java.time.OffsetDateTime;
import java.util.Objects;
import java.util.UUID;

public class StatusTrackingDTO {

    private Long id;
    private String status;
    private UUID issueId;
    private OffsetDateTime tsInitial;
    private OffsetDateTime tsFinal;

    public StatusTrackingDTO() {
    }

    public StatusTrackingDTO(Long id, String status, UUID issueId, OffsetDateTime tsInitial, OffsetDateTime tsFinal) {
        this.id = id;
        this.status = status;
        this.issueId = issueId;
        this.tsInitial = tsInitial;
        this.tsFinal = tsFinal;
    }

    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getStatus() {
        return this.status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public UUID getIssueId() {
        return this.issueId;
    }

    public void setIssueId(UUID issueId) {
        this.issueId = issueId;
    }

    public OffsetDateTime getTsInitial() {
        return this.tsInitial;
    }

    public void setTsInitial(OffsetDateTime tsInitial) {
        this.tsInitial = tsInitial;
    }

    public OffsetDateTime getTsFinal() {
        return this.tsFinal;
    }

    public void setTsFinal(OffsetDateTime tsFinal) {
        this.tsFinal = tsFinal;
    }

    public StatusTrackingDTO id(Long id) {
        setId(id);
        return this;
    }

    public StatusTrackingDTO status(String status) {
        setStatus(status);
        return this;
    }

    public StatusTrackingDTO issueId(UUID issueId) {
        setIssueId(issueId);
        return this;
    }

    public StatusTrackingDTO tsInitial(OffsetDateTime tsInitial) {
        setTsInitial(tsInitial);
        return this;
    }

    public StatusTrackingDTO tsFinal(OffsetDateTime tsFinal) {
        setTsFinal(tsFinal);
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof StatusTrackingDTO)) {
            return false;
        }
        StatusTrackingDTO statusTrackingDTO = (StatusTrackingDTO) o;
        return Objects.equals(id, statusTrackingDTO.id) && Objects.equals(status, statusTrackingDTO.status) && Objects.equals(issueId, statusTrackingDTO.issueId) && Objects.equals(tsInitial, statusTrackingDTO.tsInitial) && Objects.equals(tsFinal, statusTrackingDTO.tsFinal);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, status, issueId, tsInitial, tsFinal);
    }

    @Override
    public String toString() {
        return "{" +
            " id='" + getId() + "'" +
            ", status='" + getStatus() + "'" +
            ", issueId='" + getIssueId() + "'" +
            ", tsInitial='" + getTsInitial() + "'" +
            ", tsFinal='" + getTsFinal() + "'" +
            "}";
    }

}
