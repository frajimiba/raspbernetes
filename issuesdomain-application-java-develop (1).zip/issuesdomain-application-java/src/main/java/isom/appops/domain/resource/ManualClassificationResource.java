package isom.appops.domain.resource;

import java.util.UUID;

import jakarta.annotation.security.RolesAllowed;
import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;

import isom.appops.domain.services.*;
import isom.appops.domain.services.ManualClassificationService;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;
import org.eclipse.microprofile.openapi.annotations.tags.Tags;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

import isom.appops.domain.model.entries.ManualClassificationEntry;
import isom.appops.quarkus.errorhandler.exception.ApiBadRequestException;
import isom.appops.quarkus.errorhandler.exception.ApiInternalServerErrorException;

import io.quarkus.security.Authenticated;

@Path("/issues/{id}/classification/manual")
@RegisterRestClient
@Authenticated
@Tags(value = @Tag( name="ManualClassificationResource", description = "ManualClassificationResource"))
public class ManualClassificationResource {

	@Inject
    ManualClassificationService classificationService;

    @Operation(summary = "Manual classify an issue")
    @APIResponse(responseCode = "202", description = "Accepted")
	@APIResponse(responseCode = "400", description = "Bad request", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ApiBadRequestException.class)))
	@APIResponse(responseCode = "500", description = "Internal Server Error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ApiInternalServerErrorException.class)))
	@POST
	@RolesAllowed({"ticket-ingestor", "admin", "sre", "ftr","operador","auto"})
	@Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
	public Response manualClassifyIssue(@PathParam("id") UUID id, ManualClassificationEntry entry) throws ApiBadRequestException, ApiInternalServerErrorException {
		classificationService.manualClassify(id, entry);
		classificationService.checkAndExecuteClassificationProcedure(id, entry);
		return Response.status(Status.ACCEPTED).build();
	}

}
