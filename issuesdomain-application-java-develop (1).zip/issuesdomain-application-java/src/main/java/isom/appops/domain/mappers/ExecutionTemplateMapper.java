package isom.appops.domain.mappers;

import isom.appops.database.entities.ExecutionTemplateEntity;
import isom.appops.domain.model.dto.ExecutionTemplateDTO;
import isom.appops.domain.model.entries.ExecutionTemplateEntry;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

@Mapper(componentModel = "cdi")
public interface ExecutionTemplateMapper {

    ExecutionTemplateEntity toEntity(ExecutionTemplateDTO dto);

    @Mapping(target = "id", ignore = true)
    @Mapping(target = "createdBy", ignore = true)
    @Mapping(target = "creationDate", ignore = true)
    ExecutionTemplateEntity toEntity(ExecutionTemplateEntry entry);

    void toEntity(ExecutionTemplateEntry dto, @MappingTarget() ExecutionTemplateEntity entity);

    ExecutionTemplateDTO toDTO(ExecutionTemplateEntity entity);

}
