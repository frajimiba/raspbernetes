package isom.appops.domain.services;

import isom.appops.database.entities.IssueEntity;
import isom.appops.domain.model.events.NotificationEventData;
import isom.appops.openapi_notification.api.NotificationResourceApi;
import isom.appops.openapi_notification.model.NotificationPayloadDTO;
import isom.appops.openapi_notification.model.NotificationReceiverDTO;
import isom.appops.openapi_notification.model.NotificationReceiversEntry;
import isom.appops.openapi_ticketdetails.model.TicketDTO;
import io.quarkus.vertx.ConsumeEvent;
import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.jboss.logging.Logger;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientBuilder;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static isom.appops.domain.utils.Constants.*;

@ApplicationScoped
public class NotificationService {

    private static final Logger LOGGER = Logger.getLogger(NotificationService.class.getName());

    @ConfigProperty(name = "notifications.spa-url")
    String url;

    @ConfigProperty(name = "quarkus.rest-client.openapi_notification_yaml.url")
    String notificationUrl;

    @ConsumeEvent(value = NOTIFICATION_EVENT_NEW_ISSUE, blocking = true)
    public void sendNewIssueNotification(NotificationEventData event) {
        IssueEntity issueEntity = IssueEntity.findById(event.getIssueId());

        NotificationReceiversEntry notificationReceiversEntry = new NotificationReceiversEntry();
        notificationReceiversEntry.setId(NOTIFICATION_EVENT_NEW_ISSUE);

        notificationReceiversEntry.setNotificationReceivers(Arrays.asList(
                generateGroupReceiver("ftr", issueEntity.getGroupName()),
                generateGroupReceiver("operador", issueEntity.getGroupName()),
                generateGroupReceiver("auto", issueEntity.getGroupName()),
                generateGroupReceiver("sre", issueEntity.getGroupName())
        ));

        notificationReceiversEntry.setNotificationPayloads(setCommonIssuePayload(issueEntity, event.getTicketDTO()));
        buildApiAsyncCall(notificationReceiversEntry, event.getAuthToken());
    }

    @ConsumeEvent(value = NOTIFICATION_EVENT_ASSIGNAMENT_ISSUE, blocking = true)
    public void sendAssignamentNotification(NotificationEventData event) {
        IssueEntity issueEntity = IssueEntity.findById(event.getIssueId());

        NotificationReceiversEntry notificationReceiversEntry = new NotificationReceiversEntry();
        notificationReceiversEntry.setId(NOTIFICATION_EVENT_ASSIGNAMENT_ISSUE);

        NotificationReceiverDTO notificationReceiver = new NotificationReceiverDTO();
        notificationReceiver.setType("user");
        notificationReceiver.setRole("ftr");
        notificationReceiver.setValue(event.getUserName());
        notificationReceiversEntry.setNotificationReceivers(Collections.singletonList(notificationReceiver));

        notificationReceiversEntry.setNotificationPayloads(setCommonIssuePayload(issueEntity, event.getTicketDTO()));
        buildApiAsyncCall(notificationReceiversEntry, event.getAuthToken());
    }

    @ConsumeEvent(value = NOTIFICATION_EVENT_ASSIGNAMENT_GROUP_ISSUE, blocking = true)
    public void sendAssignamentGroupNotification(NotificationEventData event) {
        IssueEntity issueEntity = IssueEntity.findById(event.getIssueId());

        NotificationReceiversEntry notificationReceiversEntry = new NotificationReceiversEntry();
        notificationReceiversEntry.setId(NOTIFICATION_EVENT_ASSIGNAMENT_GROUP_ISSUE);

        notificationReceiversEntry.setNotificationReceivers(Arrays.asList(
                generateGroupReceiver("ftr", issueEntity.getGroupName()),
                generateGroupReceiver("operador", issueEntity.getGroupName()),
                generateGroupReceiver("auto", issueEntity.getGroupName()),
                generateGroupReceiver("sre", issueEntity.getGroupName())
        ));

        notificationReceiversEntry.setNotificationPayloads(setCommonIssuePayload(issueEntity, event.getTicketDTO()));
        buildApiAsyncCall(notificationReceiversEntry, event.getAuthToken());
    }

    @ConsumeEvent(value = NOTIFICATION_EVENT_CLOSE_ISSUE, blocking = true)
    public void sendCloseIssueNotification(NotificationEventData event) {
        IssueEntity issueEntity = IssueEntity.findById(event.getIssueId());

        NotificationReceiversEntry notificationReceiversEntry = new NotificationReceiversEntry();
        notificationReceiversEntry.setId(NOTIFICATION_EVENT_CLOSE_ISSUE);

        notificationReceiversEntry.setNotificationReceivers(Arrays.asList(
                generateGroupReceiver("ftr", issueEntity.getGroupName()),
                generateGroupReceiver("operador", issueEntity.getGroupName()),
                generateGroupReceiver("auto", issueEntity.getGroupName()),
                generateGroupReceiver("sre", issueEntity.getGroupName())
        ));

        notificationReceiversEntry.setNotificationPayloads(setCommonIssuePayload(issueEntity, event.getTicketDTO()));
        buildApiAsyncCall(notificationReceiversEntry, event.getAuthToken());
    }

    public List<NotificationPayloadDTO> setCommonIssuePayload(IssueEntity issueEntity, TicketDTO ticketDTO) {
        NotificationPayloadDTO payloadTicketTitle = new NotificationPayloadDTO();
        payloadTicketTitle.setValue(ticketDTO.getTitle());
        payloadTicketTitle.setKey("title");
        NotificationPayloadDTO payloadTicketDescription = new NotificationPayloadDTO();
        payloadTicketDescription.setKey("description");
        payloadTicketDescription.setValue(ticketDTO.getDescription());
        NotificationPayloadDTO payloadTicketId = new NotificationPayloadDTO();
        payloadTicketId.setKey("ticketId");
        payloadTicketId.setValue(issueEntity.getTicketId());
        NotificationPayloadDTO payloadClient = new NotificationPayloadDTO();
        payloadClient.setKey("clientId");
        payloadClient.setValue(issueEntity.getClientId());
        NotificationPayloadDTO payloadAssignedGroup = new NotificationPayloadDTO();
        payloadAssignedGroup.setKey("assignedGroup");
        payloadAssignedGroup.setValue(issueEntity.getGroupName());
        NotificationPayloadDTO payloadSeverity = new NotificationPayloadDTO();
        payloadSeverity.setKey("severity");
        payloadSeverity.setValue(issueEntity.getSeverity());
        NotificationPayloadDTO payloadIssueUrl = new NotificationPayloadDTO();
        payloadIssueUrl.setKey("issueUrl");
        String issueUrl = url + "/issues/issue?id=" + issueEntity.getId();
        payloadIssueUrl.setValue(issueUrl);
        return Arrays.asList(payloadTicketId,
                payloadTicketTitle,
                payloadTicketDescription,
                payloadClient,
                payloadAssignedGroup,
                payloadIssueUrl,
                payloadSeverity);
    }

    private NotificationReceiverDTO generateGroupReceiver(String role, String groupName) {
        NotificationReceiverDTO notificationReceiver = new NotificationReceiverDTO();
        notificationReceiver.setType("group");
        notificationReceiver.setRole(role);
        notificationReceiver.setValue(groupName);
        return notificationReceiver;
    }

    private void buildApiAsyncCall(NotificationReceiversEntry notificationReceiversEntry, String authToken) {
        Client client = ClientBuilder.newClient();
        WebTarget target = client.target(notificationUrl + "/appops/notification/v0/notification/send");
        target.request()
                .header("Authorization", "Bearer "  + authToken)
                .post(Entity.entity(notificationReceiversEntry, MediaType.APPLICATION_JSON_TYPE));
    }

}
