package isom.appops.domain.utils;

public class Constants {

    public static final String EMPTY = "";
    public static String ZONE_ID = "Europe/Madrid";

    public static String STATUS_ASSIGNED = "Assigned";
    public static String STATUS_UNASSIGNED = "Unassigned";
    public static String STATUS_IN_PROGRESS = "In Progress";
    public static String STATUS_RESOLVED = "Resolved";
    public static String STATUS_PENDING = "Pending";
    public static String STATUS_FAILED = "Failed";


    public static final String NOTIFICATION_EVENT_NEW_ISSUE = "new-issue";
    public static final String NOTIFICATION_EVENT_ASSIGNAMENT_ISSUE = "assignament-issue";
    public static final String NOTIFICATION_EVENT_ASSIGNAMENT_GROUP_ISSUE = "assignament-group-issue";
    public static final String NOTIFICATION_EVENT_CLOSE_ISSUE = "close-issue";

}
