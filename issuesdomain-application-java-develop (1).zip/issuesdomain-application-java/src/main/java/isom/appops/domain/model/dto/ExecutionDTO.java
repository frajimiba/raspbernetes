package isom.appops.domain.model.dto;

import java.util.List;
import java.util.Objects;
import java.util.UUID;

public class ExecutionDTO {

    private Long id;

    private UUID issueRef;
    private Long procedureRef;

    private String urlJob;
    private String userId;
    private List<String> parameters;

    public ExecutionDTO() {
    }

    public ExecutionDTO(Long id, UUID issueRef, Long procedureRef, String urlJob, String userId, List<String> parameters) {
        this.id = id;
        this.issueRef = issueRef;
        this.procedureRef = procedureRef;
        this.urlJob = urlJob;
        this.userId = userId;
        this.parameters = parameters;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getProcedureRef() {
        return procedureRef;
    }

    public void setProcedureRef(Long procedureRef) {
        this.procedureRef = procedureRef;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public List<String> getParameters() {
        return parameters;
    }

    public void setParameters(List<String> parameters) {
        this.parameters = parameters;
    }

    public UUID getIssueRef() {
        return issueRef;
    }

    public void setIssueRef(UUID issueRef) {
        this.issueRef = issueRef;
    }

    public String getUrlJob() {
        return urlJob;
    }

    public void setUrlJob(String urlJob) {
        this.urlJob = urlJob;
    }
}
