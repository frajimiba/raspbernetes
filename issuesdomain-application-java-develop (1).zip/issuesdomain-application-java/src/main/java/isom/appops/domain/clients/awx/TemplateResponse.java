package isom.appops.domain.clients.awx;

import java.util.List;

class TemplateResponse {
    private List<TemplateResult> results;

    public List<TemplateResult> getResults() {
        return results;
    }

    public void setResults(List<TemplateResult> results) {
        this.results = results;
    }
}