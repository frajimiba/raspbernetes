package isom.appops.domain.resource;

import isom.appops.domain.model.PageRequest;
import isom.appops.domain.model.dto.ExecutionDTO;
import isom.appops.domain.model.dto.FeedbackDTO;
import isom.appops.domain.model.pagedresult.PagedResultFeedbackDTO;
import isom.appops.domain.services.ExecutionService;
import isom.appops.domain.services.ViewsService;
import isom.appops.quarkus.data.PagedResult;
import isom.appops.quarkus.errorhandler.exception.ApiBadRequestException;
import isom.appops.quarkus.errorhandler.exception.ApiInternalServerErrorException;
import io.quarkus.security.Authenticated;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;
import org.eclipse.microprofile.openapi.annotations.tags.Tags;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

import jakarta.annotation.security.RolesAllowed;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.UUID;

@Path("/executions")
@RegisterRestClient
@Authenticated
@Tags(value = @Tag( name="ExecutionResource", description = "ExecutionResource"))
public class ExecutionResource {

    @Inject
    ExecutionService service;

    @Inject
    ViewsService viewsService;

    @GET
    @RolesAllowed({"ticket-ingestor", "admin", "sre", "ftr","operador","auto"})
    @Path("/{id}/feedbacks")
    @Operation(summary = "Get execution feedbacks")
    @APIResponse(responseCode = "200", description = "Accepted", content = @Content(mediaType = "application/json", schema = @Schema(implementation = PagedResultFeedbackDTO.class)))
    @APIResponse(responseCode = "400", description = "Bad request", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ApiBadRequestException.class)))
    @APIResponse(responseCode = "500", description = "Internal Server Error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ApiInternalServerErrorException.class)))
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response getFeedbacks(@PathParam("id") Long id, @BeanParam PageRequest pageRequest) {
        PagedResult<FeedbackDTO> feedbackDTO = service.getFeedbacks(id, pageRequest);
        return Response.ok(feedbackDTO).build();
    }

    @Operation(summary = "Get executions by issueId")
    @APIResponse(responseCode = "200", description = "Get all executions by issueId", content = @Content(mediaType = "application/json", schema = @Schema(ref = "PagedResultExecutionDTO")))
    @GET
    @Path("/by-issue/{issueId}")
    @RolesAllowed({"ticket-ingestor", "admin", "sre", "ftr","operador","auto"})
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response getIssuesAssignedToAuthUser(@BeanParam PageRequest pageRequest, @PathParam("issueId") UUID issueId) {
        PagedResult<ExecutionDTO> result = viewsService.getExecutionsByIssueId(issueId, pageRequest);
        return Response.status(Response.Status.OK).entity(result).build();
    }

}
