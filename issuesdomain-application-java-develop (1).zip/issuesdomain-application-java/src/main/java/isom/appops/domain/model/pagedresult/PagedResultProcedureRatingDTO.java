package isom.appops.domain.model.pagedresult;


import isom.appops.domain.model.dto.ProcedureRatingDTO;
import isom.appops.quarkus.data.PagedResult;
import org.eclipse.microprofile.openapi.annotations.media.Schema;

@Schema(name = "PagedResultProcedureRatingDTO")
public class PagedResultProcedureRatingDTO extends PagedResult<ProcedureRatingDTO> {}