package isom.appops.domain.mappers;

import java.util.UUID;

import isom.appops.database.entities.AssignamentEntity;
import isom.appops.database.entities.IssueEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

import isom.appops.domain.model.dto.AssignamentDTO;
import isom.appops.domain.model.entries.AssignmentEntry;

@Mapper(componentModel = "cdi")
public interface AssignamentMapper {
    
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "issue", expression = "java(getIssueEntity(dto))")
    AssignamentEntity toEntity(AssignamentDTO dto);
    
    @Mapping(target = "issue", expression = "java(getIssueEntity(dto))")
    void toEntity(AssignamentDTO dto, @MappingTarget AssignamentEntity entity);    

    @Mapping(target = "issue", expression = "java(getIssueEntity(issueId))")
    @Mapping(target = "userName", source = "entry.userName")
    @Mapping(target = "groupName", source = "entry.groupName")
    @Mapping(target = "text", source = "entry.text")
    void toEntity(UUID issueId, AssignmentEntry entry, @MappingTarget AssignamentEntity entity);

    @Mapping(target = "issueId", source = "entity.issue.id")
    AssignamentDTO toDTO(AssignamentEntity entity);

    @Mapping(target = "userName", source = "entity.userName")
    @Mapping(target = "groupName", source = "entity.groupName")
    @Mapping(target = "tsInitial", source = "entity.tsInitial")
    @Mapping(target = "tsFinal", source = "entity.tsFinal")
    @Mapping(target = "text", source = "entity.text")
    @Mapping(target = "issueId", source = "issueId")
    void toDTO(AssignamentEntity entity, UUID issueId, @MappingTarget AssignamentDTO dto);
    
    default IssueEntity getIssueEntity(AssignamentDTO dto){
        return IssueEntity.findById(dto.getIssueId());
    }

    default IssueEntity getIssueEntity(UUID issueId){
        return IssueEntity.findById(issueId);
    }
    
}
