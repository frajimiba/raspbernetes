package isom.appops.domain.services;

import com.offbytwo.jenkins.JenkinsServer;
import com.offbytwo.jenkins.model.JobWithDetails;
import isom.appops.database.entities.ProcedureEntity;
import isom.appops.domain.model.entries.JobEntry;
import isom.appops.domain.utils.Constants;
import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.jboss.logging.Logger;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@ApplicationScoped
public class JenkinsService {

    private static final Logger LOGGER = Logger.getLogger(JenkinsService.class.getName());

    @ConfigProperty(name = "jenkins.url")
    String url;
    @ConfigProperty(name = "jenkins.username")
    String username;
    @ConfigProperty(name = "jenkins.password")
    String password;
    @ConfigProperty(name = "jenkins.jobnameautomatic")
    String jobnameAutomatic;
    @ConfigProperty(name = "jenkins.jobnameautomaticunattended")
    String jobnameAutomaticUnattended;
    @ConfigProperty(name = "jenkins.issuesdomainbaseurl")
    String issuesDomainBaseUrl;
    @Inject
    JwtTokenService jwtTokenService;

    public String executeJenkinsJob(String jobname, Map<String, String> params) throws IOException, URISyntaxException {
        JenkinsServer jenkinsServer = new JenkinsServer(new URI(this.url), this.username, this.password);
        JobWithDetails job = jenkinsServer.getJob(jobname);
        int nextBuildNumber = job.getNextBuildNumber();
        job.build(params);
        return job.getUrl() + nextBuildNumber + "/";
    }

    public String execute(Long procedureId, UUID issueId, boolean isAutomaticUnattended) {
        ProcedureEntity procedureEntity = ProcedureEntity.findById(procedureId);

        if (procedureEntity.getJobTemplateId() != null){
            return Constants.EMPTY;
        }

        JobEntry jobEntry = new JobEntry();
        jobEntry.setOrganization(procedureEntity.getClientId());
        jobEntry.setEnv(procedureEntity.getConfigFileEnvironment());
        jobEntry.setVersion(procedureEntity.getConfigFileVersion());
        jobEntry.setRepository(procedureEntity.getConfigFilePath());

        if (isAutomaticUnattended){
            jobEntry.setJobName(jobnameAutomaticUnattended);
        } else {
            jobEntry.setJobName(jobnameAutomatic);
        }

        try {

            HashMap<String, String> params = new HashMap<>();
            params.put("ENV", jobEntry.getEnv());
            params.put("ORGANIZATION", jobEntry.getOrganization());
            params.put("REPOSITORY", jobEntry.getRepository());
            params.put("VERSION", jobEntry.getVersion());

            if (isAutomaticUnattended){
                params.put("TOKEN", jwtTokenService.getRawToken());
                params.put("BASE_URL", issuesDomainBaseUrl);
                params.put("ISSUE", issueId.toString());
            }

            String reference = executeJenkinsJob(jobEntry.getJobName(), params);

            return reference;
        } catch (IOException | URISyntaxException e) {
            // LOGGER.error(e);
        }

        return Constants.EMPTY;
    }
	
	
	/* public BuildWithDetails getBuildDetails(String jobName, QueueReference queueRef) throws IOException, InterruptedException {

		QueueItem queueItem = this.jenkinsServer.getQueueItem(queueRef);
		JobWithDetails job = this.jenkinsServer.getJob(jobName);
		this.jenkinsServer.getBuild(queueItem);
		Long retryInterval = 220L;
		while (!queueItem.isCancelled() && job.isInQueue()) {
            Thread.sleep(retryInterval);
            job = this.jenkinsServer.getJob(jobName);
            queueItem = this.jenkinsServer.getQueueItem(queueRef);
        }
		
		Build build = this.jenkinsServer.getBuild(queueItem);
        if (queueItem.isCancelled()) {
            return build.details();
        }

        boolean isBuilding = build.details().isBuilding();
        while (isBuilding) {
            Thread.sleep(retryInterval);
            isBuilding = build.details().isBuilding();
        }
        
        return build.details();

	}*/

}