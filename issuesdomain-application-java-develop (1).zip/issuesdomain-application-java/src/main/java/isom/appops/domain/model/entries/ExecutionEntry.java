package isom.appops.domain.model.entries;

import java.util.List;
import java.util.Objects;
import java.util.UUID;

public class ExecutionEntry {

    private UUID issueId;

    private List<String> parameters;


    public ExecutionEntry() {
    }

    public ExecutionEntry(UUID issueId, List<String> parameters) {
        this.issueId = issueId;
        this.parameters = parameters;
    }

    public List<String> getParameters() {
        return this.parameters;
    }

    public void setParameters(List<String> parameters) {
        this.parameters = parameters;
    }

    public UUID getIssueId() {
        return issueId;
    }

    public void setIssueId(UUID issueId) {
        this.issueId = issueId;
    }

    public ExecutionEntry parameters(List<String> parameters) {
        setParameters(parameters);
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof ExecutionEntry)) {
            return false;
        }
        ExecutionEntry executionEntry = (ExecutionEntry) o;
        return Objects.equals(parameters, executionEntry.parameters);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(parameters);
    }

    @Override
    public String toString() {
        return "{" +
            " parameters='" + getParameters() + "'" +
            "}";
    }
   

    
}
