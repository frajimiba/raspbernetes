package isom.appops.domain.services;

import isom.appops.database.entities.IssueEntity;
import isom.appops.database.entities.ManualClassificationEntity;
import isom.appops.domain.mappers.ManualClassificationMapper;
import isom.appops.domain.model.dto.ExecutionDTO;
import isom.appops.domain.model.dto.ManualClassificationDTO;
import isom.appops.domain.model.dto.ProcedureDTO;
import isom.appops.domain.model.entries.AssignmentEntry;
import isom.appops.domain.model.entries.ExecutionEntry;
import isom.appops.domain.model.entries.ManualClassificationEntry;
import isom.appops.openapi_ticketdetails.api.TicketsResourceApi;
import isom.appops.openapi_ticketdetails.model.TicketDTO;
import isom.appops.quarkus.errorhandler.exception.ApiBadRequestException;
import org.eclipse.microprofile.config.inject.ConfigProperty;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.util.List;
import java.util.UUID;

import static isom.appops.domain.utils.Constants.ZONE_ID;

@ApplicationScoped
public class ManualClassificationService {

    @Inject
    ManualClassificationMapper mapper;

    @Inject
    AssignmentsService assignmentsService;

    @Inject
    ProcedureService procedureService;

    @Inject
    ViewsService viewsService;

    @Inject
    RundeckService rundeckService;

    @Inject
    ExecutionService executionService;

    @ConfigProperty(name = "manualclassification.tcuser")
    String tcUser;

    @ConfigProperty(name = "manualclassification.tcgroup")
    String tcGroup;

    @Transactional
    public ManualClassificationDTO manualClassify(UUID id, ManualClassificationEntry entry) {

        IssueEntity issueEntity = IssueEntity.findById(id);
        if (issueEntity == null) {
            throw new ApiBadRequestException("issuenotfound");
        }

        ZoneId zoneId = ZoneId.of(ZONE_ID);

        ManualClassificationEntity entity = mapper.toEntity(entry);
        entity.setCreationDate(OffsetDateTime.now(zoneId));
        entity.setIssue(issueEntity);
        entity.persist();

        return mapper.toDTO(entity);
    }

    /**
     * Comprueba si hay algún procedimiento automático desatendido y ejecuta dicho procedimiento
     * @param id - uuid de la entidad
     * @param entry - clasificación manual asignada
     * @return Si se ha lanzado la ejecución o no
     */
    public boolean checkAndExecuteClassificationProcedure(UUID id, ManualClassificationEntry entry) {
        ProcedureDTO procedureDTO = viewsService.getProcedureByClassification(entry.getClassification());
        if (null != procedureDTO && procedureService.isAutomaticUnnattendedProcedure(procedureDTO)){
            ExecutionDTO executionDTO = registerExecution(id, procedureDTO);
            String url = rundeckService.execute(procedureDTO.getId(), id, true);
            registerExecutionState(id, executionDTO, url);
            return true;
        }
        return false;
    }

    // @Transactional
    private ExecutionDTO registerExecution(UUID id, ProcedureDTO procedureDTO) {
        ExecutionEntry executionEntry = new ExecutionEntry(id, List.of());
        ExecutionDTO executionDTO = procedureService.execute(procedureDTO.getId(), executionEntry);
        return executionDTO;
    }

    // @Transactional
    private void registerExecutionState(UUID id, ExecutionDTO executionDTO, String url) {
        executionService.updateUrlJob(executionDTO.getId(), url);
        assignmentsService.assignIssueToUser(id, new AssignmentEntry(tcGroup, tcUser, "", id));
    }

}
