package isom.appops.domain.services;

import org.eclipse.microprofile.jwt.JsonWebToken;
import org.eclipse.microprofile.rest.client.annotation.RegisterClientHeaders;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.json.Json;
import jakarta.json.JsonArray;
import jakarta.json.JsonObject;
import jakarta.json.JsonString;
import java.util.List;
import java.util.stream.Collectors;

@ApplicationScoped
@RegisterClientHeaders
public class JwtTokenService {

    @Inject
    JsonWebToken jwt;

    public String getRawToken() {
        return jwt.getRawToken();
    }

    public List<String> getGrupos() {
        if (jwt.containsClaim("grupos")) {
            return ((List<JsonString>) jwt.getClaim("grupos")).stream().map((item) -> item.getString()).collect(Collectors.toList());
        }
        return List.of();
    }

    public List<String> getFilteredClients(List<String> filterClients, List<String> grupos) {
        var availableGroups = grupos.stream().filter((item) -> item.toString().lastIndexOf("/") == 0).map((item) -> item.toString().substring(1)).collect(Collectors.toList());
        final List<String> queryGroups = filterClients.isEmpty() ? availableGroups : availableGroups.stream().filter((item) -> filterClients.contains(item)).collect(Collectors.toList());
        return queryGroups;
    }

    public List<String> getFilteredClassifications(List<String> filterClassifications, List<String> grupos) {
        var availableClassifications = grupos.stream().map((item) -> item.toString()).collect(Collectors.toList());
        final List<String> queryClassifications = filterClassifications.isEmpty() ? availableClassifications : availableClassifications.stream().filter((item) -> filterClassifications.contains(item)).collect(Collectors.toList());
        return queryClassifications;
    }

    public List<String> getFilteredGroups(List<String> filterGroups, List<String> grupos) {
        var availableGroups = grupos.stream().filter((item) -> item.split("/").length == 3).map((item) -> item.substring(item.lastIndexOf("/")+1)).collect(Collectors.toList());
        final List<String> queryGroups = filterGroups.isEmpty() ? availableGroups : availableGroups.stream().filter((item) -> filterGroups.contains(item)).collect(Collectors.toList());
        return queryGroups;
    }

    public List<String> getRoles() {
        JsonArray jsonRoles = null;
        JsonObject realmAccess = jwt.getClaim("realm_access");
        if (realmAccess != null){
            jsonRoles = realmAccess.getJsonArray("roles");
        }
        if (null == jsonRoles){
            jsonRoles = Json.createArrayBuilder().build();
        }

        List<String> roles = jsonRoles.stream().map((item) -> ((JsonString) item).getString()).collect(Collectors.toList());
        return roles;
    }
}
