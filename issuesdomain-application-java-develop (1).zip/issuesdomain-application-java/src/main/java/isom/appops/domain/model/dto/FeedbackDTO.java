package isom.appops.domain.model.dto;

import java.time.OffsetDateTime;

public class FeedbackDTO {

    private Long id;
    private int stars;
    private String comments;
    private String userId;
    private OffsetDateTime creationDate;
    private Long executionRef;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public int getStars() {
        return stars;
    }

    public void setStars(int stars) {
        this.stars = stars;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public OffsetDateTime getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(OffsetDateTime creationDate) {
        this.creationDate = creationDate;
    }

    public Long getExecutionRef() {
        return executionRef;
    }

    public void setExecutionRef(Long executionRef) {
        this.executionRef = executionRef;
    }
}
