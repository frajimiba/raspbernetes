package isom.appops.domain.resource;

import isom.appops.domain.mappers.ProcedureMapper;
import isom.appops.domain.model.PageRequest;
import isom.appops.domain.model.dto.ExecutionDTO;
import isom.appops.domain.model.dto.ProcedureDTO;
import isom.appops.domain.model.dto.ProcedureRatingDTO;
import isom.appops.domain.model.entries.ExecutionEntry;
import isom.appops.domain.model.entries.ProcedureEntry;
import isom.appops.domain.model.entries.ProceduresByClassificationsEntry;
import isom.appops.domain.model.pagedresult.PagedResultProcedureRatingDTO;
import isom.appops.domain.services.*;
import isom.appops.quarkus.data.PagedResult;
import isom.appops.quarkus.errorhandler.exception.ApiBadRequestException;
import isom.appops.quarkus.errorhandler.exception.ApiInternalServerErrorException;
import io.quarkus.security.Authenticated;
import isom.appops.domain.services.ExecutionService;
import isom.appops.domain.services.JenkinsService;
import isom.appops.domain.services.ProcedureService;
import isom.appops.domain.services.ViewsService;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;
import org.eclipse.microprofile.openapi.annotations.tags.Tags;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;
import org.jboss.logging.Logger;

import jakarta.annotation.security.RolesAllowed;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;

@Path("/procedures")
@RegisterRestClient
@Authenticated
@Tags(value = @Tag(name = "ProcedureResource", description = "ProcedureResource"))
public class ProcedureResource {

    private static final Logger LOGGER = Logger.getLogger(ProcedureResource.class.getName());

    @Inject
    ProcedureService procedureService;

    @Inject
    JenkinsService jenkinsService;

    @Inject
    ViewsService viewsService;

    @Inject
    ExecutionService executionService;

    @Inject
    RundeckService rundeckService;


    @GET
    @Path("{id}")
    @RolesAllowed({"ticket-ingestor", "admin", "sre", "ftr","operador","auto"})
    @Operation(summary = "Get procedure by id")
    @APIResponse(responseCode = "200", description = "Accepted", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ProcedureDTO.class)))
    @APIResponse(responseCode = "500", description = "Internal Server Error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ApiInternalServerErrorException.class)))
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response get(@PathParam("id") Long id) {
        ProcedureDTO result = procedureService.get(id);
        return Response.ok(result).build();
    }

    @GET
    @RolesAllowed({"ticket-ingestor", "admin", "sre", "ftr","operador","auto"})
    @Operation(summary = "Get all procedures")
    @APIResponse(responseCode = "200", description = "Accepted", content = @Content(mediaType = "application/json", schema = @Schema(ref = "PagedResultProcedureDTO")))
    @APIResponse(responseCode = "500", description = "Internal Server Error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ApiInternalServerErrorException.class)))
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response list(@BeanParam PageRequest pageRequest) {
        PagedResult<ProcedureDTO> pagedResult = procedureService.list(pageRequest);
        return Response.ok(pagedResult).build();
    }

    @Transactional
    @POST
    @RolesAllowed({"ticket-ingestor", "admin", "sre", "ftr","operador","auto"})
    @Operation(summary = "Add a new procedure")
    @APIResponse(responseCode = "200", description = "Accepted", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ProcedureDTO.class)))
    @APIResponse(responseCode = "400", description = "Bad request", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ApiBadRequestException.class)))
    @APIResponse(responseCode = "500", description = "Internal Server Error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ApiInternalServerErrorException.class)))
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response add(ProcedureEntry entry) {
        ProcedureDTO procedureDTO = procedureService.add(entry);
        return Response.ok(procedureDTO).build();
    }

    @POST
    @RolesAllowed({"ticket-ingestor", "admin", "sre", "ftr","operador","auto"})
    @Path("/{id}/jenkins-execute")
    @Operation(summary = "Executes a Jenkins procedure")
    @APIResponse(responseCode = "200", description = "Accepted", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ExecutionDTO.class)))
    @APIResponse(responseCode = "400", description = "Bad request", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ApiBadRequestException.class)))
    @APIResponse(responseCode = "500", description = "Internal Server Error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ApiInternalServerErrorException.class)))
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response execute(@PathParam("id") Long id, ExecutionEntry entry) {
        // LOGGER.infof("Get Executions By Issue Id for issue: %s", entry.getIssueId().toString());
        List<ExecutionDTO> dtos = executionService.getExecutionsByIssueId(entry.getIssueId());
        ExecutionDTO dto = dtos.get(dtos.size() - 1);
        String url = jenkinsService.execute(id, entry.getIssueId(), false);
        dto = executionService.updateUrlJob(dto.getId(), url);
        return Response.ok(dto).build();
    }


    @POST
    @RolesAllowed({"ticket-ingestor", "admin", "sre", "ftr","operador","auto"})
    @Path("/{id}/rundeck-execute")
    @Operation(summary = "Executes a Rundeck procedure")
    @APIResponse(responseCode = "200", description = "Accepted", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ExecutionDTO.class)))
    @APIResponse(responseCode = "400", description = "Bad request", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ApiBadRequestException.class)))
    @APIResponse(responseCode = "500", description = "Internal Server Error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ApiInternalServerErrorException.class)))
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response executeRunDeck(@PathParam("id") Long id, ExecutionEntry entry) {
        // LOGGER.infof("Get Executions By Issue Id for issue: %s", entry.getIssueId().toString());
        String url = rundeckService.execute(id, entry.getIssueId(), false);
        List<ExecutionDTO> dtos = executionService.getExecutionsByIssueId(entry.getIssueId());
        ExecutionDTO dto = dtos.get(dtos.size() - 1);
        dto = executionService.updateUrlJob(dto.getId(), url);
        return Response.ok(dto).build();
    }

    @POST
    @RolesAllowed({"ticket-ingestor", "admin", "sre", "ftr","operador","auto"})
    @Path("/{id}/finish-execution")
    @Operation(summary = "Finish execution a procedure")
    @APIResponse(responseCode = "200", description = "Accepted", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ExecutionDTO.class)))
    @APIResponse(responseCode = "400", description = "Bad request", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ApiBadRequestException.class)))
    @APIResponse(responseCode = "500", description = "Internal Server Error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ApiInternalServerErrorException.class)))
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response finishExecution(@PathParam("id") Long id, ExecutionEntry entry) {
        ExecutionDTO dto = procedureService.execute(id, entry);
        return Response.ok(dto).build();
    }

    @GET
    @RolesAllowed({"ticket-ingestor", "admin", "sre", "ftr","operador","auto"})
    @Path("/{id}/rating")
    @Operation(summary = "Get procedure rating")
    @APIResponse(responseCode = "200", description = "Accepted", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Double.class)))
    @APIResponse(responseCode = "400", description = "Bad request", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ApiBadRequestException.class)))
    @APIResponse(responseCode = "500", description = "Internal Server Error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ApiInternalServerErrorException.class)))
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response getRating(@PathParam("id") Long id) {
        double result = procedureService.getRating(id);
        return Response.ok(result).build();
    }

    @GET
    @RolesAllowed({"ticket-ingestor", "admin", "sre", "ftr","operador","auto"})
    @Path("/{id}/executions")
    @Operation(summary = "Get procedure executions")
    @APIResponse(responseCode = "200", description = "Accepted", content = @Content(mediaType = "application/json", schema = @Schema(ref = "PagedResultExecutionDTO")))
    @APIResponse(responseCode = "400", description = "Bad request", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ApiBadRequestException.class)))
    @APIResponse(responseCode = "500", description = "Internal Server Error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ApiInternalServerErrorException.class)))
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response getExecutions(@PathParam("id") Long id, @BeanParam PageRequest pageRequest) {
        PagedResult<ExecutionDTO> executionDTO = procedureService.getExecutions(id, pageRequest);
        return Response.ok(executionDTO).build();
    }

    @Transactional
    @PUT
    @Path("{id}")
    @RolesAllowed({"ticket-ingestor", "admin", "sre", "ftr","operador","auto"})
    @Operation(summary = "Update a procedure")
    @APIResponse(responseCode = "200", description = "Accepted", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ProcedureDTO.class)))
    @APIResponse(responseCode = "400", description = "Bad request", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ApiBadRequestException.class)))
    @APIResponse(responseCode = "500", description = "Internal Server Error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ApiInternalServerErrorException.class)))
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response update(@PathParam("id") Long id, ProcedureEntry entry) {
        ProcedureDTO procedureDTO = procedureService.update(id, entry);
        return Response.ok(procedureDTO).build();
    }

    @Transactional
    @DELETE
    @Path("{id}")
    @RolesAllowed({"ticket-ingestor", "sre", "admin"})
    @Operation(summary = "Delete procedure by id")
    @APIResponse(responseCode = "200", description = "Accepted")
    @APIResponse(responseCode = "400", description = "Bad request", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ApiBadRequestException.class)))
    @APIResponse(responseCode = "500", description = "Internal Server Error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ApiInternalServerErrorException.class)))
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response delete(@PathParam("id") Long id) {
        procedureService.delete(id);
        return Response.ok().build();
    }

    @Operation(summary = "Get procedures by classifications")
    @APIResponse(responseCode = "200", description = "Get all procedures by classification", content = @Content(schema = @Schema(ref = "PagedResultProcedureDTO")))
    @POST
    @Path("/by-classification")
    @RolesAllowed({"ticket-ingestor", "admin", "sre", "ftr","operador","auto"})
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response getProceduresByClassifications(ProceduresByClassificationsEntry entry, @BeanParam PageRequest pageRequest) {
        PagedResult<ProcedureDTO> result = viewsService.getProceduresByClassifications(entry.getClassifications(), pageRequest);
        return Response.status(Response.Status.OK).entity(result).build();
    }

    @Operation(summary = "Get procedures by classifications with rating")
    @APIResponse(responseCode = "200", description = "Get all procedures by classification with rating", content = @Content(schema = @Schema(implementation = PagedResultProcedureRatingDTO.class)))
    @POST
    @Path("/by-classification-with-rating")
    @RolesAllowed({"ticket-ingestor", "admin", "sre", "ftr","operador","auto"})
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response getProceduresByClassificationsWithRating(ProceduresByClassificationsEntry entry, @BeanParam PageRequest pageRequest) {
        PagedResult<ProcedureRatingDTO> result = viewsService.getProceduresByClassificationsWithRating(entry.getClassifications(), pageRequest);
        return Response.status(Response.Status.OK).entity(result).build();
    }


}
