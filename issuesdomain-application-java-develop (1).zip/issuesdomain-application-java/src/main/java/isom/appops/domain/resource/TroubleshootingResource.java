package isom.appops.domain.resource;

import isom.appops.database.entities.IssueEntity;
import isom.appops.domain.model.dto.TroubleshootingDTO;
import isom.appops.domain.model.entries.TroubleshootingEntry;
import isom.appops.domain.services.TroubleshootingService;
import isom.appops.quarkus.errorhandler.exception.ApiBadRequestException;
import isom.appops.quarkus.errorhandler.exception.ApiInternalServerErrorException;
import io.quarkus.security.Authenticated;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.enums.SchemaType;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;
import org.eclipse.microprofile.openapi.annotations.tags.Tags;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

import jakarta.annotation.security.RolesAllowed;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;
import java.util.List;
import java.util.UUID;

@Path("/issues/{id}/troubleshootings")
@RegisterRestClient
@Authenticated
@Tags(value = @Tag(name = "TroubleshootingResource", description = "TroubleshootingResource"))
public class TroubleshootingResource {

    @Inject
    TroubleshootingService troubleshootingService;

    @Operation(summary = "Get troubleshootings")
    @APIResponse(responseCode = "200", description = "Get all troubleshootings", content = @Content(mediaType = "application/json", schema = @Schema(type = SchemaType.ARRAY, implementation = TroubleshootingDTO.class)))
    @GET
    @RolesAllowed({"ticket-ingestor", "admin", "sre", "ftr","operador","auto"})
    @Path("/")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response get(@PathParam("id") UUID id) {
		IssueEntity issueEntity = IssueEntity.findById(id);
		if (issueEntity == null) {
			throw new ApiBadRequestException("issuenotfound");
		}
        List<TroubleshootingDTO> result = troubleshootingService.getTroubleshootings(id);
        return Response.status(Status.OK).entity(result).build();
    }

    @Transactional
    @Operation(summary = "Add troubleshooting")
    @APIResponse(responseCode = "202", description = "Accepted", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TroubleshootingDTO.class)))
    @APIResponse(responseCode = "400", description = "Bad request", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ApiBadRequestException.class)))
    @APIResponse(responseCode = "500", description = "Internal Server Error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ApiInternalServerErrorException.class)))
    @POST
    @RolesAllowed({"ticket-ingestor", "admin", "sre", "ftr","operador","auto"})
    @Path("/")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response add(@PathParam("id") UUID id, TroubleshootingEntry troubleshootingEntry) throws ApiBadRequestException, ApiInternalServerErrorException {
		IssueEntity issueEntity = IssueEntity.findById(id);
		if (issueEntity == null) {
			throw new ApiBadRequestException("issuenotfound");
		}
        TroubleshootingDTO troubleshootingDTO = troubleshootingService.add(id, troubleshootingEntry);
        return Response.status(Status.ACCEPTED).entity(troubleshootingDTO).build();
    }


    @Transactional
    @Operation(summary = "Update troubleshooting")
    @APIResponse(responseCode = "202", description = "Accepted", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TroubleshootingDTO.class)))
    @APIResponse(responseCode = "400", description = "Bad request", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ApiBadRequestException.class)))
    @APIResponse(responseCode = "500", description = "Internal Server Error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ApiInternalServerErrorException.class)))
    @PUT
    @RolesAllowed({"ticket-ingestor", "admin", "sre", "ftr","operador","auto"})
    @Path("/{tId}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response update(@PathParam("id") UUID id, @PathParam("tId") Long troubleshootingId, TroubleshootingEntry entry) throws ApiBadRequestException, ApiInternalServerErrorException {
        IssueEntity issueEntity = IssueEntity.findById(id);
        if (issueEntity == null) {
            throw new ApiBadRequestException("issuenotfound");
        }
        TroubleshootingDTO troubleshootingDTO = troubleshootingService.update(troubleshootingId, entry);
        return Response.status(Status.ACCEPTED).entity(troubleshootingDTO).build();
    }

    @Transactional
    @Operation(summary = "Delete troubleshooting")
    @DELETE
    @Path("/{tId}")
    @RolesAllowed({"ticket-ingestor", "sre", "admin", "ftr","operador","auto"})
    @APIResponse(responseCode = "200", description = "Accepted")
    @APIResponse(responseCode = "400", description = "Bad request", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ApiBadRequestException.class)))
    @APIResponse(responseCode = "500", description = "Internal Server Error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ApiInternalServerErrorException.class)))
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response delete(@PathParam("id") UUID id, @PathParam("tId") Long troubleshootingId) {
		IssueEntity issueEntity = IssueEntity.findById(id);
		if (issueEntity == null) {
			throw new ApiBadRequestException("issuenotfound");
		}
        troubleshootingService.delete(troubleshootingId);
        return Response.ok().build();
    }
}
