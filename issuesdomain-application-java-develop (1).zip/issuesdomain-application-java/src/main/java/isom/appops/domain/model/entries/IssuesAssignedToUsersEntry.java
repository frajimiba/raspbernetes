package isom.appops.domain.model.entries;

import java.util.List;

public class IssuesAssignedToUsersEntry {

    List<String> userIds;

    public IssuesAssignedToUsersEntry() {
    }

    public IssuesAssignedToUsersEntry(List<String> userIds) {
        this.userIds = userIds;
    }

    public List<String> getUserIds() {
        return userIds;
    }

    public void setUserIds(List<String> userIds) {
        this.userIds = userIds;
    }
}
