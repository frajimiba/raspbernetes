package isom.appops.domain.services;

import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.util.List;
import java.util.stream.Collectors;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;

import isom.appops.database.entities.ExecutionEntity;
import isom.appops.database.entities.IssueEntity;
import isom.appops.database.entities.ProcedureEntity;
import isom.appops.database.repository.ExecutionEntityRepository;
import isom.appops.database.repository.FeedbackEntityRepository;
import isom.appops.database.repository.ProcedureEntityRepository;
import isom.appops.domain.mappers.ExecutionMapper;
import isom.appops.domain.mappers.ProcedureMapper;
import isom.appops.domain.model.PageRequest;
import isom.appops.domain.model.dto.ExecutionDTO;
import isom.appops.domain.model.dto.ProcedureDTO;
import isom.appops.domain.model.entries.ExecutionEntry;
import isom.appops.domain.model.entries.ProcedureEntry;
import isom.appops.domain.utils.Constants;
import isom.appops.quarkus.data.PagedResult;
import isom.appops.quarkus.errorhandler.exception.ApiBadRequestException;
import isom.appops.quarkus.errorhandler.exception.ApiInternalServerErrorException;

import io.quarkus.panache.common.Page;
import io.quarkus.panache.common.Sort;
import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.eclipse.microprofile.jwt.JsonWebToken;

import static isom.appops.domain.utils.Constants.ZONE_ID;

@ApplicationScoped
public class ProcedureService {

    @Inject
    JsonWebToken jwt;

    @Inject
    ProcedureMapper mapper;

    @Inject
    ProcedureEntityRepository repository;

    @Inject
    ExecutionMapper executionMapper;

    @Inject
    ExecutionEntityRepository executionEntityRepository;

    @Inject
    FeedbackEntityRepository feedbackEntityRepository;

    @Inject
    StatusTrackingService statusTrackingService;

    @ConfigProperty(name = "executions.awx-url")
    String awxUrl;

    public ProcedureDTO get(Long id) {
        ProcedureEntity entity = ProcedureEntity.findById(id);
        return mapper.toDTO(entity);
    }

    @Transactional
    public void delete(Long id) {
        feedbackEntityRepository.deleteByProcedureId(id);
        executionEntityRepository.deleteByProcedureId(id);
        ProcedureEntity entity = ProcedureEntity.findById(id);
        if (null != entity){
            entity.delete();
        }
    }

    @Transactional
    public ProcedureDTO add(ProcedureEntry entry) throws ApiBadRequestException, ApiInternalServerErrorException {        
        ProcedureEntity entity = mapper.toEntity(entry);
        entity.setUserId(jwt.getName());
        ZoneId zoneId = ZoneId.of(ZONE_ID);
        entity.setCreationDate(OffsetDateTime.now(zoneId));
        entity.persist();
        return mapper.toDTO(entity);
    }

    @Transactional
    public ProcedureDTO update(Long id, ProcedureEntry entry) throws ApiBadRequestException, ApiInternalServerErrorException {
        ProcedureEntity entity = ProcedureEntity.findById(id);
        mapper.toEntity(entry, entity);
        entity.persist();
        return mapper.toDTO(entity);
    }

    public PagedResult<ProcedureDTO> list(PageRequest pageRequest) {
        PagedResult<ProcedureEntity> entities = repository.findBy(Page.of(pageRequest.page, pageRequest.size), Sort.by(pageRequest.sort).direction(pageRequest.ascending ? Sort.Direction.Ascending : Sort.Direction.Descending));
        PagedResult<ProcedureDTO> result = new PagedResult<ProcedureDTO>();
        List<ProcedureDTO> ticketDtos = entities.getList().stream().map((entity) -> mapper.toDTO(entity)).collect(Collectors.toList());
        result.setList(ticketDtos);
        result.setNumOfResults(entities.getNumOfResults());
        result.setPage(entities.getPage());
        result.setSize(entities.getSize());
        return result;
    }

    @Transactional
    public ExecutionDTO execute(Long id, ExecutionEntry entry) {

        ProcedureEntity procedureEntity = ProcedureEntity.findById(id);
        IssueEntity issueEntity = IssueEntity.findById(entry.getIssueId());

        ExecutionEntity executionEntity = new ExecutionEntity();
        ZoneId zoneId = ZoneId.of(ZONE_ID);

        executionMapper.toExecutionEntity(entry, executionEntity);
        executionEntity.setProcedureRef(procedureEntity);
        executionEntity.setIssueRef(issueEntity);
        executionEntity.setParameters(entry.getParameters());
        executionEntity.setUserId(jwt.getName());
        executionEntity.setExecutionDate(OffsetDateTime.now(zoneId));
        executionEntity.persist();

        statusTrackingService.add(issueEntity.getId(), Constants.STATUS_IN_PROGRESS);

        return executionMapper.toDTO(executionEntity);
    }

    public PagedResult<ExecutionDTO> getExecutions(Long id, PageRequest pageRequest) {
        PagedResult<ExecutionEntity> entities = executionEntityRepository.findAllByProcedureId(id, pageRequest);
        PagedResult<ExecutionDTO> result = new PagedResult<ExecutionDTO>();
        List<ExecutionDTO> dtos = entities.getList().stream().map((entity) -> executionMapper.toDTO(entity)).collect(Collectors.toList());
        result.setList(dtos);
        result.setNumOfResults(entities.getNumOfResults());
        result.setPage(entities.getPage());
        result.setSize(entities.getSize());
        return result;
    }

    public double getRating(Long id) {
        return feedbackEntityRepository.getProcedureRating(id);
    }

    public boolean isAutomaticUnnattendedProcedure(ProcedureDTO procedureDTO) {
        String type = procedureDTO.getProcedureType();
        if ((type != null && "automatic".compareTo(type) == 0) ||
            (type == null &&
                        procedureDTO.isAutomatic() &&
                        procedureDTO.getConfigFileEnvironment() != null &&
                        procedureDTO.getConfigFilePath() != null &&
                        procedureDTO.getConfigFileVersion() != null)){
            return true;
        }
        return false;
    }
}
