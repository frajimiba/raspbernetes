package isom.appops.domain.mappers;

import java.util.UUID;

import isom.appops.database.entities.IssueEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

import isom.appops.domain.model.dto.IssueDTO;
import isom.appops.ticketentry.TicketEntryUtils;
import isom.appops.ticketentry.model.TicketHeader;

@Mapper(componentModel = "cdi")
public interface IssueMapper {

    @Mapping(target = "id", expression = "java(getUUID(issueDTO))")
    IssueEntity toIssueEntity(IssueDTO issueDTO);
    
    void toIssueEntity(IssueDTO issueDTO, @MappingTarget IssueEntity issueEntity);    

    IssueDTO toIssueDTO(IssueEntity issueEntity);

    @Mapping(target = "ticketId", source = "ticketId")
    @Mapping(target = "clientId", source = "clientId")
    @Mapping(target = "groupName", source = "assignedGroup")
    IssueDTO toIssueDTO(TicketHeader ticketHeader);

    default UUID getUUID(IssueDTO issueDTO){
        return TicketEntryUtils.getUuid(issueDTO.getTicketId(), issueDTO.getClientId());
    }

}
