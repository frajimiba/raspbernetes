package isom.appops.domain.model.dto;

import java.time.OffsetDateTime;
import java.util.Objects;
import java.util.UUID;

public class ManualClassificationDTO {

    private String userName;
    private String classification;    
    private OffsetDateTime creationDate;
    private UUID issueId;



    public ManualClassificationDTO() {
    }

    public ManualClassificationDTO(String userName, String classification, OffsetDateTime creationDate, UUID issueId) {
        this.userName = userName;
        this.classification = classification;
        this.creationDate = creationDate;
        this.issueId = issueId;
    }

    public String getUserName() {
        return this.userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getClassification() {
        return this.classification;
    }

    public void setClassification(String classification) {
        this.classification = classification;
    }

    public OffsetDateTime getCreationDate() {
        return this.creationDate;
    }

    public void setCreationDate(OffsetDateTime creationDate) {
        this.creationDate = creationDate;
    }

    public UUID getIssueId() {
        return this.issueId;
    }

    public void setIssueId(UUID issueId) {
        this.issueId = issueId;
    }

    public ManualClassificationDTO userName(String userName) {
        setUserName(userName);
        return this;
    }

    public ManualClassificationDTO classification(String classification) {
        setClassification(classification);
        return this;
    }

    public ManualClassificationDTO creationDate(OffsetDateTime creationDate) {
        setCreationDate(creationDate);
        return this;
    }

    public ManualClassificationDTO issueId(UUID issueId) {
        setIssueId(issueId);
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof ManualClassificationDTO)) {
            return false;
        }
        ManualClassificationDTO manualClassificationDTO = (ManualClassificationDTO) o;
        return Objects.equals(userName, manualClassificationDTO.userName) && Objects.equals(classification, manualClassificationDTO.classification) && Objects.equals(creationDate, manualClassificationDTO.creationDate) && Objects.equals(issueId, manualClassificationDTO.issueId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(userName, classification, creationDate, issueId);
    }

    @Override
    public String toString() {
        return "{" +
            " userName='" + getUserName() + "'" +
            ", classification='" + getClassification() + "'" +
            ", creationDate='" + getCreationDate() + "'" +
            ", issueId='" + getIssueId() + "'" +
            "}";
    }

}
