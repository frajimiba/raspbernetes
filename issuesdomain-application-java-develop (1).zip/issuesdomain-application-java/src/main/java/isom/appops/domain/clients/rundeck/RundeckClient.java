package isom.appops.domain.clients.rundeck;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import isom.appops.domain.utils.Constants;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.json.Json;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientBuilder;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.apache.commons.codec.binary.Base64;
import org.eclipse.microprofile.config.inject.ConfigProperty;

@ApplicationScoped
public class RundeckClient {
    @ConfigProperty(name = "rundeck.base-url")
    String rundeckBaseUrl;
    @ConfigProperty(name = "rundeck.token")
    String rundeckToken;

    private final Client client = ClientBuilder.newClient();

    public String runTemplate(String clientId, String templateId, String formData) {

        try {

            String url = rundeckBaseUrl + "/api/19/job/" + templateId + "/run";
            Response response = client.target(url)
                    .request(MediaType.APPLICATION_JSON)
                    .header("X-Rundeck-Auth-Token", rundeckToken)
                    .header("Content-Type", "application/json")
                    .header("Accept", "application/json")
                    .post(Entity.json(formData));
            if (response.getStatus() != Response.Status.OK.getStatusCode()) {
                throw new RuntimeException("Failed to run template in Rundeck");
            }

            String jsonContent = response.readEntity(String.class);
            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode jsonNode = objectMapper.readTree(jsonContent);
            String result = jsonNode.get("permalink").asText();

            return result;

        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }

}
