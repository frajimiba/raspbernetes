package isom.appops.domain.model.entries;

import java.time.OffsetDateTime;
import java.util.Objects;

public class ProcedureEntry {

    private String title;
    private String description;
    private String clientId;
    private String responseTemplate;
    private String urlJob;
    private String urlCommunication;
    private String classification;
    private boolean automatic;
    private String configFileEnvironment;
    private String configFilePath;
    private String configFileVersion;
    private String jobTemplateName;
    private String jobTemplateId;
    private String procedureType;

    public ProcedureEntry() {
    }

    public ProcedureEntry(String title, String description, String clientId, String responseTemplate, String urlJob, String urlCommunication, String classification, boolean automatic, String configFileEnvironment, String configFilePath, String configFileVersion, String jobTemplateName, String jobTemplateId, String procedureType) {
        this.title = title;
        this.description = description;
        this.clientId = clientId;
        this.responseTemplate = responseTemplate;
        this.urlJob = urlJob;
        this.urlCommunication = urlCommunication;
        this.classification = classification;
        this.automatic = automatic;
        this.configFileEnvironment = configFileEnvironment;
        this.configFilePath = configFilePath;
        this.configFileVersion = configFileVersion;
        this.jobTemplateName = jobTemplateName;
        this.jobTemplateId = jobTemplateId;
        this.procedureType = procedureType;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getResponseTemplate() {
        return responseTemplate;
    }

    public void setResponseTemplate(String responseTemplate) {
        this.responseTemplate = responseTemplate;
    }

    public String getUrlJob() {
        return urlJob;
    }

    public void setUrlJob(String urlJob) {
        this.urlJob = urlJob;
    }

    public String getUrlCommunication() {
        return urlCommunication;
    }

    public void setUrlCommunication(String urlCommunication) {
        this.urlCommunication = urlCommunication;
    }

    public String getClassification() {
        return classification;
    }

    public void setClassification(String classification) {
        this.classification = classification;
    }

    public boolean isAutomatic() {
        return automatic;
    }

    public void setAutomatic(boolean automatic) {
        this.automatic = automatic;
    }

    public String getConfigFileEnvironment() {
        return configFileEnvironment;
    }

    public void setConfigFileEnvironment(String configFileEnvironment) {
        this.configFileEnvironment = configFileEnvironment;
    }

    public String getConfigFilePath() {
        return configFilePath;
    }

    public void setConfigFilePath(String configFilePath) {
        this.configFilePath = configFilePath;
    }

    public String getConfigFileVersion() {
        return configFileVersion;
    }

    public void setConfigFileVersion(String configFileVersion) {
        this.configFileVersion = configFileVersion;
    }

    public String getJobTemplateName() {
        return jobTemplateName;
    }

    public void setJobTemplateName(String jobTemplateName) {
        this.jobTemplateName = jobTemplateName;
    }

    public String getJobTemplateId() {
        return jobTemplateId;
    }

    public void setJobTemplateId(String jobTemplateId) {
        this.jobTemplateId = jobTemplateId;
    }

    public String getProcedureType() {
        return procedureType;
    }

    public void setProcedureType(String procedureType) {
        this.procedureType = procedureType;
    }
}
