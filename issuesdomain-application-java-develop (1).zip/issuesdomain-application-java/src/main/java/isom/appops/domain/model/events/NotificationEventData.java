package isom.appops.domain.model.events;

import isom.appops.openapi_ticketdetails.model.TicketDTO;

import java.util.UUID;

public class NotificationEventData {

    private UUID issueId;
    private String userName;
    private TicketDTO ticketDTO;
    private String authToken;

    public NotificationEventData() {
    }

    public NotificationEventData(UUID issueId, String userName, TicketDTO ticketDTO, String authToken) {
        this.issueId = issueId;
        this.userName = userName;
        this.ticketDTO = ticketDTO;
        this.authToken = authToken;
    }

    public UUID getIssueId() {
        return issueId;
    }

    public void setIssueId(UUID issueId) {
        this.issueId = issueId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public TicketDTO getTicketDTO() {
        return ticketDTO;
    }

    public void setTicketDTO(TicketDTO ticketDTO) {
        this.ticketDTO = ticketDTO;
    }

    public String getAuthToken() {
        return authToken;
    }

    public void setAuthToken(String authToken) {
        this.authToken = authToken;
    }
}