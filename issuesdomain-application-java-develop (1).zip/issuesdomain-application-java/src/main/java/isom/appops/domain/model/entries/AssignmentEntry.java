package isom.appops.domain.model.entries;

import java.util.Objects;
import java.util.UUID;

public class AssignmentEntry {

    private String groupName;
    private String userName;
    private String text;

    public AssignmentEntry() {
    }

    public AssignmentEntry(String groupName, String userName, String text, UUID issueId) {
        this.groupName = groupName;
        this.userName = userName;
        this.text = text;
    }

    public String getGroupName() {
        return this.groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getUserName() {
        return this.userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getText() {
        return this.text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public AssignmentEntry groupId(String groupId) {
        setGroupName(groupId);
        return this;
    }

    public AssignmentEntry userId(String userId) {
        setUserName(userId);
        return this;
    }

    public AssignmentEntry text(String text) {
        setText(text);
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof AssignmentEntry)) {
            return false;
        }
        AssignmentEntry assignmentEntry = (AssignmentEntry) o;
        return Objects.equals(groupName, assignmentEntry.groupName) && Objects.equals(userName, assignmentEntry.userName) && Objects.equals(text, assignmentEntry.text);
    }

    @Override
    public int hashCode() {
        return Objects.hash(groupName, userName, text);
    }

    @Override
    public String toString() {
        return "{" +
            " groupId='" + getGroupName() + "'" +
            ", userId='" + getUserName() + "'" +
            ", text='" + getText() + "'" +
            "}";
    }
    

}
