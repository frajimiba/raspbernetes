package isom.appops.domain.model.pagedresult;

import isom.appops.domain.model.dto.ProcedureDTO;
import isom.appops.quarkus.data.PagedResult;
import org.eclipse.microprofile.openapi.annotations.media.Schema;

@Schema(name = "PagedResultProcedureDTO")
public class PagedResultProcedureDTO extends PagedResult<ProcedureDTO> {}