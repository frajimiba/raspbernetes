package isom.appops.domain.mappers;

import java.util.UUID;

import isom.appops.database.entities.IssueEntity;
import isom.appops.database.entities.StatusTrackingEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

import isom.appops.domain.model.dto.StatusTrackingDTO;

@Mapper(componentModel = "cdi")
public interface StatusTrackingMapper {
    
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "issue", expression = "java(getIssueEntity(dto))")
    StatusTrackingEntity toEntity(StatusTrackingDTO dto);
    
    @Mapping(target = "issue", expression = "java(getIssueEntity(dto))")
    void toEntity(StatusTrackingDTO dto, @MappingTarget StatusTrackingEntity entity);    

    @Mapping(target = "issueId", source = "entity.issue.id")
    StatusTrackingDTO toDTO(StatusTrackingEntity entity);

    @Mapping(target = "status", source = "entity.status")
    @Mapping(target = "tsInitial", source = "entity.tsInitial")
    @Mapping(target = "tsFinal", source = "entity.tsFinal")
    @Mapping(target = "issueId", source = "issueId")
    void toDTO(StatusTrackingEntity entity, UUID issueId, @MappingTarget StatusTrackingDTO dto);
    
    default IssueEntity getIssueEntity(StatusTrackingDTO dto){
        return IssueEntity.findById(dto.getIssueId());
    }

}
