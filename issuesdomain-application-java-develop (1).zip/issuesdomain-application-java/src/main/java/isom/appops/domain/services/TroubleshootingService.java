package isom.appops.domain.services;

import isom.appops.database.entities.TroubleshootingEntity;
import isom.appops.database.repository.TroubleshootingEntityRepository;
import isom.appops.domain.mappers.TroubleshootingMapper;
import isom.appops.domain.model.dto.TroubleshootingDTO;
import isom.appops.domain.model.entries.TroubleshootingEntry;
import isom.appops.ticketentry.model.TicketEntry;
import isom.appops.quarkus.errorhandler.exception.ApiBadRequestException;
import isom.appops.quarkus.errorhandler.exception.ApiInternalServerErrorException;
import org.eclipse.microprofile.jwt.JsonWebToken;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import static isom.appops.domain.utils.Constants.ZONE_ID;

@ApplicationScoped
public class TroubleshootingService {
    
	@Inject
    TroubleshootingEntityRepository troubleshootingEntityRepository;

    @Inject
    TroubleshootingMapper troubleshootingMapper;

    @Inject
    JsonWebToken jwt;

    public List<TroubleshootingDTO> getTroubleshootings(UUID issueId) {
        List<TroubleshootingEntity> entities = troubleshootingEntityRepository.findByIssueId(issueId);
        List<TroubleshootingDTO> result = entities.stream().map((troubleshootingEntity) -> {
            TroubleshootingDTO troubleshootingDTO = new TroubleshootingDTO();
            troubleshootingMapper.toDTO(troubleshootingEntity, issueId, troubleshootingDTO);
            return troubleshootingDTO;
        }).collect(Collectors.toList());
        return result;
    }

    @Transactional
    public TroubleshootingDTO add(UUID issueId, TroubleshootingEntry troubleshootingEntry) throws ApiInternalServerErrorException {
        ZoneId zoneId = ZoneId.of(ZONE_ID);

        TroubleshootingDTO troubleshootingDTO = new TroubleshootingDTO();
        troubleshootingDTO.setIssueId(issueId);
        troubleshootingDTO.setContent(troubleshootingEntry.getContent());
        troubleshootingDTO.setCreationDate(OffsetDateTime.now(zoneId));
		troubleshootingDTO.setUserId(jwt.getName());

        TroubleshootingEntity entity = new TroubleshootingEntity();
        troubleshootingMapper.toEntity(troubleshootingDTO, entity);
        entity.persist();

        return troubleshootingMapper.toDTO(entity);
    }

    public TroubleshootingDTO update(Long troubleshootingId, TroubleshootingEntry troubleshootingEntry) {
        TroubleshootingEntity entity = TroubleshootingEntity.findById(troubleshootingId);
        entity.setContent(troubleshootingEntry.getContent());
        entity.persist();

        return troubleshootingMapper.toDTO(entity);
    }

    public void delete(Long troubleshootingId) {
        TroubleshootingEntity entity = TroubleshootingEntity.findById(troubleshootingId);
        if (entity != null){
            entity.delete();
        }
    }
}
