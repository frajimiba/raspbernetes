package isom.appops.domain.services;

import isom.appops.domain.model.events.NotificationEventData;
import isom.appops.domain.utils.Constants;
import isom.appops.openapi_ticketdetails.model.TicketDTO;
import io.vertx.core.eventbus.EventBus;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import java.util.UUID;

import static isom.appops.domain.utils.Constants.NOTIFICATION_EVENT_ASSIGNAMENT_GROUP_ISSUE;

@ApplicationScoped
public class ExternalGroupService {

    @Inject
    StatusTrackingService statusTrackingService;

    @Inject
    AssignmentsService assignmentsService;

    @Inject
    TicketDetailsService ticketDetailsService;

    @Inject
    EventBus bus;

    @Inject
    JwtTokenService tokenService;

    public void externalGroupChanged(UUID id) {
        registerUnnasignedUserToIssue(id);
        notifyAssignamentGroup(id);
    }

    // @Transactional
    private void registerUnnasignedUserToIssue(UUID id) {
        statusTrackingService.add(id, Constants.STATUS_UNASSIGNED);
        assignmentsService.assignEmptyUser(id);
    }

    private void notifyAssignamentGroup(UUID id) {
        TicketDTO ticketDTO = ticketDetailsService.getDetails(id);
        bus.publish(NOTIFICATION_EVENT_ASSIGNAMENT_GROUP_ISSUE, new NotificationEventData(id, "", ticketDTO, tokenService.getRawToken()));
    }


}
