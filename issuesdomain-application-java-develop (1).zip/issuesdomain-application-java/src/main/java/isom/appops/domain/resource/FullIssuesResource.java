package isom.appops.domain.resource;

import isom.appops.domain.model.PageRequest;
import isom.appops.domain.model.dto.*;
import isom.appops.domain.model.entries.*;
import isom.appops.domain.model.dto.FullIssueViewDTO;
import isom.appops.domain.model.entries.FullIssueEntry;
import isom.appops.domain.model.pagedresult.PagedResultFullIssueViewDTO;
import isom.appops.domain.services.JwtTokenService;
import isom.appops.domain.services.ViewsService;
import isom.appops.quarkus.data.PagedResult;
import isom.appops.quarkus.errorhandler.exception.ApiInternalServerErrorException;
import io.quarkus.security.Authenticated;
import org.eclipse.microprofile.jwt.JsonWebToken;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;
import org.eclipse.microprofile.openapi.annotations.tags.Tags;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

import jakarta.annotation.security.RolesAllowed;
import jakarta.inject.Inject;
import jakarta.json.JsonString;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;
import jakarta.ws.rs.core.SecurityContext;
import java.util.List;
import java.util.UUID;

@Path("/full-issues")
@RegisterRestClient
@Authenticated
@Tags(value = @Tag( name="FullIssuesResource", description = "FullIssuesResource"))
public class FullIssuesResource {

    @Inject
    ViewsService viewsService;

	@Inject
	JsonWebToken jwt;

	@Inject
    JwtTokenService jwtTokenService;

	@Operation(summary = "Get full issue filtered by id")
	@APIResponse(responseCode = "200", description = "Get full issue with classification, group and status", content = @Content(schema = @Schema(implementation = FullIssueViewDTO.class)))
	@GET
	@Path("/{issueId}")
	@RolesAllowed({"ticket-ingestor", "admin", "sre", "ftr","operador","auto"})
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response getFullIssue(@PathParam("issueId") UUID issueId) {
		FullIssueViewDTO result = viewsService.getFullIssue(issueId);
		return Response.status(Status.OK).entity(result).build();
	}

	@Operation(summary = "Get full issues filtered by classifications / groups with status")
    @APIResponse(responseCode = "200", description = "Get all issues by classification or groups with status", content = @Content(schema = @Schema(implementation = PagedResultFullIssueViewDTO.class)))
	@POST
	@Path("/admin/groups")
	@RolesAllowed({"ticket-ingestor", "admin"})
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response getFullIssuesByAdminGroup(FullIssueEntry entry, @BeanParam PageRequest pageRequest) {
		List<String> grupos = jwtTokenService.getGrupos();
		final List<String> queryClients = jwtTokenService.getFilteredClients(entry.getClients(), grupos);
		entry.setClients(queryClients);
		PagedResult<FullIssueViewDTO> result = viewsService.getFullIssuesGroups(entry, pageRequest);
		return Response.status(Status.OK).entity(result).build();
	}

	@Operation(summary = "Get full issues")
	@APIResponse(responseCode = "200", description = "Filtered by classification or groups with status", content = @Content(schema = @Schema(implementation = PagedResultFullIssueViewDTO.class)))
	@POST
	@Path("/pending")
	@RolesAllowed({"ticket-ingestor", "admin", "sre", "ftr","operador","auto"})
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response getFullIssuesPending(FullIssueEntry entry, @BeanParam PageRequest pageRequest) {

		List<String> grupos = jwtTokenService.getGrupos();

		final List<String> queryClients = jwtTokenService.getFilteredClients(entry.getClients(), grupos);
		final List<String> queryGroups = jwtTokenService.getFilteredGroups(entry.getGroups(), grupos);

		entry.setClients(queryClients);
		entry.setGroups(queryGroups);

		PagedResult<FullIssueViewDTO> result = viewsService.getFullIssuesPending(entry, pageRequest);
		return Response.status(Status.OK).entity(result).build();
	}

	@Operation(summary = "Get full issues")
	@APIResponse(responseCode = "200", description = "Filtered by classification or groups with status", content = @Content(schema = @Schema(implementation = PagedResultFullIssueViewDTO.class)))
	@POST
	@Path("/owned")
	@RolesAllowed({"ticket-ingestor", "admin", "sre", "ftr","operador","auto"})
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response getFullIssuesOwned(FullIssueEntry entry, @BeanParam PageRequest pageRequest) {
		String preferredUsername = jwt.getClaim("preferred_username");

		List<String> grupos = jwtTokenService.getGrupos();

		final List<String> queryClients = jwtTokenService.getFilteredClients(entry.getClients(), grupos);
		final List<String> queryGroups = jwtTokenService.getFilteredGroups(entry.getGroups(), grupos);

		entry.setClients(queryClients);
		entry.setGroups(queryGroups);

		PagedResult<FullIssueViewDTO> result = viewsService.getFullIssuesOwned(preferredUsername, entry, pageRequest);
		return Response.status(Status.OK).entity(result).build();
	}

	@Operation(summary = "Get full issues")
	@APIResponse(responseCode = "200", description = "Filtered by classification or groups with status", content = @Content(schema = @Schema(implementation = PagedResultFullIssueViewDTO.class)))
	@POST
	@Path("/groups")
	@RolesAllowed({"ticket-ingestor", "admin", "sre", "ftr","operador","auto"})
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response getFullIssuesGroups(FullIssueEntry entry, @BeanParam PageRequest pageRequest) {

		List<String> grupos = jwtTokenService.getGrupos();

		final List<String> queryClients = jwtTokenService.getFilteredClients(entry.getClients(), grupos);
		final List<String> queryGroups = jwtTokenService.getFilteredGroups(entry.getGroups(), grupos);

		entry.setClients(queryClients);
		entry.setGroups(queryGroups);

		PagedResult<FullIssueViewDTO> result = viewsService.getFullIssuesGroups(entry, pageRequest);
		return Response.status(Status.OK).entity(result).build();
	}

}
