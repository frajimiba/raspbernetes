package isom.appops.domain.services;

import isom.appops.domain.clients.awx.AWXClient;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@ApplicationScoped
public class SelfServiceService {

    @Inject
    AWXClient awxClient;

    public int submitForm(int templateId, String jsonForm) {
        return awxClient.submitForm(templateId, jsonForm);
    }

}
