package isom.appops.domain.mappers;

import isom.appops.database.entities.ExecutionEntity;
import isom.appops.database.entities.IssueEntity;
import isom.appops.database.entities.ProcedureEntity;
import isom.appops.domain.model.dto.ExecutionDTO;
import isom.appops.domain.model.entries.ExecutionEntry;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

import java.util.UUID;

@Mapper(componentModel = "cdi")
public interface ExecutionMapper {
      
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "procedureRef", ignore = true)
    @Mapping(target = "issueRef", ignore = true)
    ExecutionEntity toEntity(ExecutionEntry entry);

    @Mapping(target = "procedureRef", expression = "java(toProcedureRefId(entity.getProcedureRef()))")
    @Mapping(target = "issueRef", expression = "java(toIssueRefId(entity.getIssueRef()))")
    ExecutionDTO toDTO(ExecutionEntity entity);

    @Mapping(target = "procedureRef", ignore = true)
    @Mapping(target = "issueRef", ignore = true)
    void toExecutionEntity(ExecutionEntry entry, @MappingTarget ExecutionEntity entity);

    default Long toProcedureRefId(ProcedureEntity procedureEntity){
        return procedureEntity.getId();
    }

    default UUID toIssueRefId(IssueEntity issueEntity){
        return issueEntity.getId();
    }

}
