package isom.appops.domain.model.dto;

import java.time.OffsetDateTime;

public class ExecutionTemplateDTO {

    private Long id;
    private String templateName;
    private String templateType;
    private String templateId;
    private String templateConfig;
    private String createdBy;
    private OffsetDateTime creationDate;

    public ExecutionTemplateDTO() {
    }

    public ExecutionTemplateDTO(Long id, String templateName, String templateType, String templateId, String templateConfig, String createdBy, OffsetDateTime creationDate) {
        this.id = id;
        this.templateName = templateName;
        this.templateType = templateType;
        this.templateId = templateId;
        this.templateConfig = templateConfig;
        this.createdBy = createdBy;
        this.creationDate = creationDate;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTemplateName() {
        return templateName;
    }

    public void setTemplateName(String templateName) {
        this.templateName = templateName;
    }

    public String getTemplateType() {
        return templateType;
    }

    public void setTemplateType(String templateType) {
        this.templateType = templateType;
    }

    public String getTemplateId() {
        return templateId;
    }

    public void setTemplateId(String templateId) {
        this.templateId = templateId;
    }

    public String getTemplateConfig() {
        return templateConfig;
    }

    public void setTemplateConfig(String templateConfig) {
        this.templateConfig = templateConfig;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public OffsetDateTime getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(OffsetDateTime creationDate) {
        this.creationDate = creationDate;
    }
}
