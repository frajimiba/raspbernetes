package isom.appops.domain.resource;

import isom.appops.domain.model.events.NotificationEventData;
import isom.appops.domain.model.dto.AssignamentDTO;
import isom.appops.domain.model.entries.AssignmentEntry;
import isom.appops.domain.services.*;
import isom.appops.domain.utils.Constants;
import isom.appops.openapi_ticketdetails.api.TicketsResourceApi;
import isom.appops.openapi_ticketdetails.model.TicketDTO;
import isom.appops.quarkus.errorhandler.exception.ApiBadRequestException;
import isom.appops.quarkus.errorhandler.exception.ApiInternalServerErrorException;
import io.quarkus.security.Authenticated;
import io.vertx.core.eventbus.EventBus;
import isom.appops.domain.services.*;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.enums.SchemaType;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;
import org.eclipse.microprofile.openapi.annotations.tags.Tags;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;
import org.jboss.logging.Logger;

import jakarta.annotation.security.RolesAllowed;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;
import java.util.List;
import java.util.UUID;

import static isom.appops.domain.utils.Constants.NOTIFICATION_EVENT_ASSIGNAMENT_GROUP_ISSUE;
import static isom.appops.domain.utils.Constants.NOTIFICATION_EVENT_ASSIGNAMENT_ISSUE;

@Path("/issues/{id}/assignments")
@RegisterRestClient
@Authenticated
@Tags(value = @Tag(name = "AssignmentsResource", description = "AssignmentsResource"))
public class AssignmentsResource {

    private static final Logger LOGGER = Logger.getLogger(AssignmentsResource.class.getName());

    @Inject
    AssignmentsService assignmentsService;

    @Inject
    StatusTrackingService statusTrackingService;

    @Inject
    IssuesService issuesService;

    @Inject
    JwtTokenService tokenService;

    @Inject
    TicketDetailsService ticketDetailsService;

    @Inject
    EventBus bus;

    @Operation(summary = "Get issue assignaments")
    @APIResponse(responseCode = "200", description = "Get all ticket assignaments", content = @Content(mediaType = "application/json",
            schema = @Schema(type = SchemaType.ARRAY, implementation = AssignamentDTO.class)))
    @GET
    @RolesAllowed({"ticket-ingestor", "admin", "sre", "ftr","operador","auto"})
    @Path("/")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAssignaments(@PathParam("id") UUID id) {
        List<AssignamentDTO> result = assignmentsService.getAssignaments(id);
        return Response.status(Response.Status.OK).entity(result).build();
    }

    @Operation(summary = "Assign an issue to the user")
    @APIResponse(responseCode = "202", description = "Accepted", content = @Content(mediaType = "application/json", schema = @Schema(implementation = AssignamentDTO.class)))
    @APIResponse(responseCode = "400", description = "Bad request", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ApiBadRequestException.class)))
    @APIResponse(responseCode = "500", description = "Internal Server Error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ApiInternalServerErrorException.class)))
    @POST
    @Path("/assign")
    @RolesAllowed({"ticket-ingestor", "admin", "sre", "ftr","operador","auto"})
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response assignIssueToUser(@PathParam("id") UUID id, AssignmentEntry entry) throws ApiBadRequestException {
        AssignamentDTO assignamentDTO = assignmentsService.assignIssueToUser(id, entry);
        issuesService.updateIssueGroupName(id, entry.getGroupName());
        if (entry.getUserName().isEmpty()){
            statusTrackingService.add(id, Constants.STATUS_UNASSIGNED);
            issuesService.updateResolutionDate(id, null);
            notifyGroupAssignament(id);
        } else {
            statusTrackingService.add(id, Constants.STATUS_ASSIGNED);
            notifyAssignament(id, entry);
        }
        return Response.status(Status.ACCEPTED).entity(assignamentDTO).build();
    }

    private void notifyGroupAssignament(UUID id) {
        TicketDTO ticketDTO = ticketDetailsService.getDetails(id);
        bus.publish(NOTIFICATION_EVENT_ASSIGNAMENT_GROUP_ISSUE,  new NotificationEventData(id, "", ticketDTO, tokenService.getRawToken()));
    }

    private void notifyAssignament(UUID id, AssignmentEntry entry) {
        TicketDTO ticketDTO = ticketDetailsService.getDetails(id);
        bus.publish(NOTIFICATION_EVENT_ASSIGNAMENT_ISSUE, new NotificationEventData(id, entry.getUserName(), ticketDTO, tokenService.getRawToken()));
    }

}
