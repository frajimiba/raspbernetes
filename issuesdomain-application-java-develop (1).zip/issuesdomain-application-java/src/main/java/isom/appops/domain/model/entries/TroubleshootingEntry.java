package isom.appops.domain.model.entries;

import java.util.List;
import java.util.Objects;
import java.util.UUID;

public class TroubleshootingEntry {

    private String content;

    public TroubleshootingEntry() {
    }

    public TroubleshootingEntry(UUID issueId, String content) {
        this.content = content;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
