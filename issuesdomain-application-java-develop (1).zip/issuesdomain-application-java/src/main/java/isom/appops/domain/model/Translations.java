package isom.appops.domain.model;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.MapSerializer;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Translations {
    @JsonSerialize(keyUsing = MapSerializer.class)
    private Map<String, String> externalState;
    
    @JsonSerialize(keyUsing = MapSerializer.class)
    private Map<String, String> issueType;

    @JsonSerialize(keyUsing = MapSerializer.class)
    private Map<String, String> severity;

    @JsonSerialize(keyUsing = MapSerializer.class)
    private Map<String, String> specialFlag;

    @JsonProperty("externalState")
    public Map<String, String> getExternalState() { return externalState; }

    public void setExternalState(Map<String, String> value) { this.externalState = value; }

    @JsonProperty("issueType")
    public Map<String, String> getIssueType() { return issueType; }
    
    public void setIssueType(Map<String, String> value) { this.issueType = value; }

    @JsonProperty("severity")
    public Map<String, String> getSeverity() { return severity; }
    
    public void setSeverity(Map<String, String> value) { this.severity = value; }

    @JsonProperty("specialFlag")
    public Map<String, String> getSpecialFlag() { return specialFlag; }
    
    public void setSpecialFlag(Map<String, String> value) { this.specialFlag = value; }
}
