package isom.appops.domain.resource;

import isom.appops.domain.services.SelfServiceService;
import isom.appops.quarkus.errorhandler.exception.ApiBadRequestException;
import isom.appops.quarkus.errorhandler.exception.ApiInternalServerErrorException;
import io.quarkus.security.Authenticated;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;
import org.eclipse.microprofile.openapi.annotations.tags.Tags;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

import jakarta.annotation.security.RolesAllowed;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/self-service")
@RegisterRestClient
@Authenticated
@Tags(value = @Tag(name = "SelfServiceResource", description = "SelfServiceResource"))
public class SelfServiceResource {

    @Inject
    SelfServiceService selfServiceService;

    @Operation(summary = "Submit self-service data to run")
    @APIResponse(responseCode = "202", description = "Accepted", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Integer.class)))
    @APIResponse(responseCode = "400", description = "Bad request", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ApiBadRequestException.class)))
    @APIResponse(responseCode = "500", description = "Internal Server Error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ApiInternalServerErrorException.class)))
    @Path("/submit/{templateId}")
    @POST()
    @RolesAllowed({"ticket-ingestor", "admin", "sre", "ftr", "dev", "operador","auto"})
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response submitForm(@PathParam("templateId") int templateId, String form) throws ApiBadRequestException, ApiInternalServerErrorException {
        int result = selfServiceService.submitForm(templateId, form);
        return Response.accepted(result).build();
    }

}
