package isom.appops.domain.model.entries;

import java.time.OffsetDateTime;

public class FeedbackEntry {

    private int stars;
    private String comments;
    private Long executionRef;

    public FeedbackEntry() {
    }

    public FeedbackEntry(int stars, String comments, Long executionRef) {
        this.stars = stars;
        this.comments = comments;
        this.executionRef = executionRef;
    }

    public int getStars() {
        return stars;
    }

    public void setStars(int stars) {
        this.stars = stars;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public Long getExecutionRef() {
        return executionRef;
    }

    public void setExecutionRef(Long executionRef) {
        this.executionRef = executionRef;
    }
}
