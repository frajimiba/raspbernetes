package isom.appops.domain.clients.awx;

class AuthRequest {
    private String username;
    private String secured;

    public AuthRequest(String username, String secured) {
        this.username = username;
        this.secured = secured;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getSecured() {
        return secured;
    }

    public void setSecured(String secured) {
        this.secured = secured;
    }
}