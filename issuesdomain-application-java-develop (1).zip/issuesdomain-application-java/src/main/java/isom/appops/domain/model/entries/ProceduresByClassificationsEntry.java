package isom.appops.domain.model.entries;

import java.util.List;

public class ProceduresByClassificationsEntry {

    int pageIndex;
    int pageSize;
    List<String> classifications;

    public ProceduresByClassificationsEntry() {
    }

    public ProceduresByClassificationsEntry(int pageIndex, int pageSize, List<String> classifications) {
        this.pageIndex = pageIndex;
        this.pageSize = pageSize;
        this.classifications = classifications;
    }

    public int getPageIndex() {
        return pageIndex;
    }

    public void setPageIndex(int pageIndex) {
        this.pageIndex = pageIndex;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public List<String> getClassifications() {
        return classifications;
    }

    public void setClassifications(List<String> classifications) {
        this.classifications = classifications;
    }
}
