package isom.appops.domain.services;

import isom.appops.database.entities.IssueEntity;
import isom.appops.database.repository.IssueEntityRepository;
import isom.appops.domain.mappers.IssueMapper;
import isom.appops.domain.model.IssueTranslations;
import isom.appops.domain.model.PageRequest;
import isom.appops.domain.model.dto.IssueDTO;
import isom.appops.ticketentry.TicketEntryUtils;
import isom.appops.ticketentry.model.TicketEntry;
import isom.appops.quarkus.data.PagedResult;
import isom.appops.quarkus.errorhandler.exception.ApiBadRequestException;
import isom.appops.quarkus.errorhandler.exception.ApiInternalServerErrorException;
import io.quarkus.panache.common.Page;
import io.quarkus.panache.common.Sort;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import java.io.IOException;
import java.net.URISyntaxException;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@ApplicationScoped
public class IssuesService {

    @Inject
    IssueMapper issueMapper;

    @Inject
    IssueEntityRepository issueEntityRepository;

    @Inject
    TranslationsService translationsService;

    public IssueDTO get(UUID id) {
        IssueEntity issueEntity = issueEntityRepository.findById(id);
        return issueMapper.toIssueDTO(issueEntity);
    }

    @Transactional
    public IssueDTO addOrUpdate(TicketEntry ticketEntry) throws ApiBadRequestException, ApiInternalServerErrorException, IOException, URISyntaxException {

        UUID uuid = TicketEntryUtils.getUuid(ticketEntry.getHeader());
        IssueEntity issueEntity = IssueEntity.findById(uuid);

        IssueDTO issueDto = issueMapper.toIssueDTO(ticketEntry.getHeader());

        IssueTranslations issueTranslations = translationsService.translateToIssue(ticketEntry.getHeader());
        issueDto.setIssueType(issueTranslations.getIssueType());
        issueDto.setSeverity(issueTranslations.getSeverity());
        issueDto.setSpecialFlag(issueTranslations.getSpecialFlag());

        if (null != issueEntity) {
            issueEntity.setIssueType(issueDto.getIssueType());
            issueEntity.setSeverity(issueDto.getSeverity());
            issueEntity.setSpecialFlag(issueDto.getSpecialFlag());
            issueEntity.persist();

            return issueMapper.toIssueDTO(issueEntity);
        }

        issueEntity = issueMapper.toIssueEntity(issueDto);
        issueEntity.persist();

        return issueMapper.toIssueDTO(issueEntity);
    }

    @Transactional
    public IssueDTO update(IssueDTO issueDTO) throws ApiBadRequestException, ApiInternalServerErrorException, IOException, URISyntaxException {

        IssueEntity issueEntity = IssueEntity.findById(issueDTO.getId());
        if (issueEntity == null) {
            throw new ApiBadRequestException("issuenotfound");
        }

        issueMapper.toIssueEntity(issueDTO, issueEntity);
        issueEntity.persist();

        return issueMapper.toIssueDTO(issueEntity);
    }

    public PagedResult<IssueDTO> getIssues(PageRequest pageRequest) {
        PagedResult<IssueEntity> entities = issueEntityRepository.findBy(Page.of(pageRequest.page, pageRequest.size), Sort.by(pageRequest.sort).direction(pageRequest.ascending ? Sort.Direction.Ascending : Sort.Direction.Descending));
        PagedResult<IssueDTO> result = new PagedResult<IssueDTO>();
        List<IssueDTO> ticketDtos = entities.getList().stream().map((issueEntity) -> issueMapper.toIssueDTO(issueEntity)).collect(Collectors.toList());
        result.setList(ticketDtos);
        result.setNumOfResults(entities.getNumOfResults());
        result.setPage(entities.getPage());
        result.setSize(entities.getSize());
        return result;
    }

    @Transactional
    public IssueEntity updateIssueGroupName(UUID id, String groupName) {
        IssueEntity issue = IssueEntity.findById(id);
        issue.setGroupName(groupName);
        issue.persist();
        return issue;
    }

    @Transactional
    public IssueEntity updateResolutionDate(UUID id, OffsetDateTime dateTime) {
        IssueEntity issue = IssueEntity.findById(id);
        issue.setResolutionDate(dateTime);
        issue.persist();
        return issue;
    }

}
