package isom.appops.domain.model.dto;

import java.time.OffsetDateTime;
import java.util.Objects;
import java.util.UUID;

public class AssignamentDTO {

    private String userName;
    private String groupName;
    private OffsetDateTime tsInitial;
    private OffsetDateTime tsFinal;
    private String text;
    private UUID issueId;

    public AssignamentDTO() {
    }

    public AssignamentDTO(String userName, String groupName, OffsetDateTime tsInitial, OffsetDateTime tsFinal, String text, UUID issueId) {
        this.userName = userName;
        this.groupName = groupName;
        this.tsInitial = tsInitial;
        this.tsFinal = tsFinal;
        this.text = text;
        this.issueId = issueId;
    }

    public String getUserName() {
        return this.userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getGroupName() {
        return this.groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public OffsetDateTime getTsInitial() {
        return this.tsInitial;
    }

    public void setTsInitial(OffsetDateTime tsInitial) {
        this.tsInitial = tsInitial;
    }

    public OffsetDateTime getTsFinal() {
        return this.tsFinal;
    }

    public void setTsFinal(OffsetDateTime tsFinal) {
        this.tsFinal = tsFinal;
    }

    public String getText() {
        return this.text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public UUID getIssueId() {
        return this.issueId;
    }

    public void setIssueId(UUID issueId) {
        this.issueId = issueId;
    }

    public AssignamentDTO userName(String userName) {
        setUserName(userName);
        return this;
    }

    public AssignamentDTO groupName(String groupName) {
        setGroupName(groupName);
        return this;
    }

    public AssignamentDTO tsInitial(OffsetDateTime tsInitial) {
        setTsInitial(tsInitial);
        return this;
    }

    public AssignamentDTO tsFinal(OffsetDateTime tsFinal) {
        setTsFinal(tsFinal);
        return this;
    }

    public AssignamentDTO text(String text) {
        setText(text);
        return this;
    }

    public AssignamentDTO issueId(UUID issueId) {
        setIssueId(issueId);
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof AssignamentDTO)) {
            return false;
        }
        AssignamentDTO assignamentDTO = (AssignamentDTO) o;
        return Objects.equals(userName, assignamentDTO.userName) && Objects.equals(groupName, assignamentDTO.groupName) && Objects.equals(tsInitial, assignamentDTO.tsInitial) && Objects.equals(tsFinal, assignamentDTO.tsFinal) && Objects.equals(text, assignamentDTO.text) && Objects.equals(issueId, assignamentDTO.issueId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(userName, groupName, tsInitial, tsFinal, text, issueId);
    }

    @Override
    public String toString() {
        return "{" +
            " userName='" + getUserName() + "'" +
            ", groupName='" + getGroupName() + "'" +
            ", tsInitial='" + getTsInitial() + "'" +
            ", tsFinal='" + getTsFinal() + "'" +
            ", text='" + getText() + "'" +
            ", issueId='" + getIssueId() + "'" +
            "}";
    }
    
}
