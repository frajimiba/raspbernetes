package isom.appops.domain.model;

import io.quarkus.panache.common.Sort;

import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.QueryParam;

public class PageRequest {

	@QueryParam("page")
    @DefaultValue("0")
    public int page;
 
    @QueryParam("size")
    @DefaultValue("10")
    public int size;

    @QueryParam("sort")
    @DefaultValue("id")
    public String sort;

    @QueryParam("ascending")
    @DefaultValue("false")
    public boolean ascending;

    public PageRequest() {
    }

    public PageRequest(int page, int size, String sort, boolean ascending) {
        this.page = page;
        this.size = size;
        this.sort = sort;
        this.ascending = ascending;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public String getSort() {
        return sort;
    }

    public void setSort(String sort) {
        this.sort = sort;
    }

    public boolean isAscending() {
        return ascending;
    }

    public void setAscending(boolean ascending) {
        this.ascending = ascending;
    }
}
