package isom.appops.domain.services;

import isom.appops.openapi_ticketdetails.api.TicketsResourceApi;
import isom.appops.openapi_ticketdetails.model.TicketDTO;
import org.eclipse.microprofile.rest.client.inject.RestClient;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.ProcessingException;
import jakarta.ws.rs.WebApplicationException;
import java.util.UUID;

@ApplicationScoped
public class TicketDetailsService {

    @Inject
    @RestClient
    TicketsResourceApi ticketsResourceApi;

    public TicketDTO getDetails(UUID id){
        TicketDTO ticketDTO;
        try {
            ticketDTO = ticketsResourceApi.appopsTicketdetailsV0TicketsIdGet(id);
        } catch (ProcessingException exception){
            ticketDTO = new TicketDTO();
            ticketDTO.setTitle("");
            ticketDTO.setDescription("");
        }
        return ticketDTO;
    }

}
