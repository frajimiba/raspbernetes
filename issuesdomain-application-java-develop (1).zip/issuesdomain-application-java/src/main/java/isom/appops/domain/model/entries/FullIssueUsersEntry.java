package isom.appops.domain.model.entries;

import java.util.List;

public class FullIssueUsersEntry {


    List<String> users;

    List<String> statuses;

    public FullIssueUsersEntry() {
    }

    public FullIssueUsersEntry(List<String> users, List<String> statuses) {
        this.users = users;
        this.statuses = statuses;
    }

    public List<String> getUsers() {
        return users;
    }

    public void setUsers(List<String> users) {
        this.users = users;
    }

    public List<String> getStatuses() {
        return statuses;
    }

    public void setStatuses(List<String> statuses) {
        this.statuses = statuses;
    }
}
