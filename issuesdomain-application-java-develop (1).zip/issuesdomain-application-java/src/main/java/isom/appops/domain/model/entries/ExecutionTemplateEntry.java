package isom.appops.domain.model.entries;

import java.time.OffsetDateTime;

public class ExecutionTemplateEntry {

    private String templateName;
    private String templateType;
    private String templateId;
    private String templateConfig;

    public ExecutionTemplateEntry() {
    }

    public ExecutionTemplateEntry(String templateName, String templateType, String templateId, String templateConfig) {
        this.templateName = templateName;
        this.templateType = templateType;
        this.templateId = templateId;
        this.templateConfig = templateConfig;
    }

    public String getTemplateName() {
        return templateName;
    }

    public void setTemplateName(String templateName) {
        this.templateName = templateName;
    }

    public String getTemplateType() {
        return templateType;
    }

    public void setTemplateType(String templateType) {
        this.templateType = templateType;
    }

    public String getTemplateId() {
        return templateId;
    }

    public void setTemplateId(String templateId) {
        this.templateId = templateId;
    }

    public String getTemplateConfig() {
        return templateConfig;
    }

    public void setTemplateConfig(String templateConfig) {
        this.templateConfig = templateConfig;
    }
}
