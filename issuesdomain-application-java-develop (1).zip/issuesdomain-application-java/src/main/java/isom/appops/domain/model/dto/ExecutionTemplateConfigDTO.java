package isom.appops.domain.model.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Map;

public class ExecutionTemplateConfigDTO {

    @JsonProperty
    private String argString;
    @JsonProperty
    private String loglevel;
    @JsonProperty
    private String asUser;
    @JsonProperty
    private String filter;
    @JsonProperty
    private String runAtTime;
    @JsonProperty
    private Map<String, Object> options;

    public ExecutionTemplateConfigDTO() {
    }

    public ExecutionTemplateConfigDTO(String argString, String loglevel, String asUser, String filter, String runAtTime, Map<String, Object> options) {
        this.argString = argString;
        this.loglevel = loglevel;
        this.asUser = asUser;
        this.filter = filter;
        this.runAtTime = runAtTime;
        this.options = options;
    }

    public String getArgString() {
        return argString;
    }

    public void setArgString(String argString) {
        this.argString = argString;
    }

    public String getLoglevel() {
        return loglevel;
    }

    public void setLoglevel(String loglevel) {
        this.loglevel = loglevel;
    }

    public String getAsUser() {
        return asUser;
    }

    public void setAsUser(String asUser) {
        this.asUser = asUser;
    }

    public String getFilter() {
        return filter;
    }

    public void setFilter(String filter) {
        this.filter = filter;
    }

    public String getRunAtTime() {
        return runAtTime;
    }

    public void setRunAtTime(String runAtTime) {
        this.runAtTime = runAtTime;
    }

    public Map<String, Object> getOptions() {
        return options;
    }

    public void setOptions(Map<String, Object> options) {
        this.options = options;
    }
}
