package isom.appops.domain.clients.awx;

class LaunchResponse {
    private int job;

    public int getJob() {
        return job;
    }

    public void setJob(int job) {
        this.job = job;
    }
}