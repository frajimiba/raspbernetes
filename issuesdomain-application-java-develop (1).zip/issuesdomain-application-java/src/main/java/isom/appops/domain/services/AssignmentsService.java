package isom.appops.domain.services;

import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import jakarta.annotation.security.RolesAllowed;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import isom.appops.database.entities.AssignamentEntity;
import isom.appops.database.entities.IssueEntity;
import isom.appops.database.repository.AssignamentEntityRepository;
import isom.appops.domain.mappers.AssignamentMapper;
import isom.appops.domain.model.dto.AssignamentDTO;
import isom.appops.domain.model.entries.AssignmentEntry;
import isom.appops.quarkus.errorhandler.exception.ApiBadRequestException;

@ApplicationScoped
public class AssignmentsService {

    @Inject
    AssignamentEntityRepository assignamentEntityRepository;

    @Inject
    AssignamentMapper assignamentMapper;


    @Transactional
    public AssignamentDTO assignIssueToUser(UUID id, AssignmentEntry entry) throws ApiBadRequestException {
        IssueEntity issue = IssueEntity.findById(id);
        if (issue == null){
			throw new ApiBadRequestException("issuenotfound");
        }
        
        ZoneId zoneId = ZoneId.of("Europe/Madrid");

        OffsetDateTime ts = OffsetDateTime.now(zoneId);

        AssignamentEntity entity = new AssignamentEntity();
        assignamentMapper.toEntity(id, entry, entity);
        entity.setTsInitial(ts);
        entity.setTsFinal(ts);
        entity.persistAndFlush();

        return assignamentMapper.toDTO(entity);
    }

    @Transactional
    public AssignamentDTO assignEmptyUser(UUID id) {
        IssueEntity issue = IssueEntity.findById(id);
        if (issue == null){
            throw new ApiBadRequestException("issuenotfound");
        }

        ZoneId zoneId = ZoneId.of("Europe/Madrid");

        OffsetDateTime ts = OffsetDateTime.now(zoneId);

        AssignamentEntity entity = new AssignamentEntity();
        entity.setIssue(issue);
        entity.setGroupName(issue.getGroupName());
        entity.setUserName("");
        entity.setText("");
        entity.setTsInitial(ts);
        entity.setTsFinal(ts);
        entity.persist();

        return assignamentMapper.toDTO(entity);
    }

    public List<AssignamentDTO> getAssignaments(UUID id) {
        List<AssignamentEntity> entities = assignamentEntityRepository.findAssignmentsByIssueId(id);
        return entities.stream().map((entity) -> assignamentMapper.toDTO(entity)).collect(Collectors.toList());
    }

}
