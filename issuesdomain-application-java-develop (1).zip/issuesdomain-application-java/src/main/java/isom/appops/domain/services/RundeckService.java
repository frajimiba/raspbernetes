package isom.appops.domain.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import isom.appops.database.entities.ProcedureEntity;
import isom.appops.domain.clients.rundeck.RundeckClient;
import isom.appops.domain.model.dto.ExecutionTemplateConfigDTO;
import isom.appops.domain.model.dto.ExecutionTemplateDTO;
import isom.appops.domain.utils.Constants;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.jboss.logging.Logger;

import java.util.UUID;

@ApplicationScoped
public class RundeckService {

    private static final Logger LOGGER = Logger.getLogger(RundeckService.class.getName());
    @Inject
    RundeckClient rundeckClient;
    @Inject
    ExecutionTemplateService executionTemplateService;
    @Inject
    JwtTokenService jwtTokenService;
    @ConfigProperty(name = "rundeck.issuesdomainbaseurl")
    String issuesDomainBaseUrl;

    public String execute(Long procedureId, UUID issueId, boolean isAutomaticUnattended) {
        ProcedureEntity procedureEntity = ProcedureEntity.findById(procedureId);

        String jobTemplateId = procedureEntity.getJobTemplateId();
        String jobTemplateName = procedureEntity.getJobTemplateName();

        ExecutionTemplateDTO executionTemplateEntity = executionTemplateService.findByTemplateIdAndName(jobTemplateId, jobTemplateName);

        ObjectMapper objectMapper = new ObjectMapper();
        String requestTemplateConfig = executionTemplateEntity.getTemplateConfig();
        try {
            ExecutionTemplateConfigDTO templateConfigDTO = objectMapper.readValue(executionTemplateEntity.getTemplateConfig(), ExecutionTemplateConfigDTO.class);
            templateConfigDTO.getOptions().put("ISSUE", issueId);
            templateConfigDTO.getOptions().put("TOKEN", jwtTokenService.getRawToken());
            templateConfigDTO.getOptions().put("BASE_URL", issuesDomainBaseUrl);
            requestTemplateConfig = objectMapper.writeValueAsString(templateConfigDTO);
        } catch (JsonProcessingException e) {
            // LOGGER.error(e);
        }

        return rundeckClient.runTemplate(procedureEntity.getClientId(), jobTemplateId, requestTemplateConfig);
    }

}
