package isom.appops.domain.services;

import isom.appops.database.entities.FeedbackEntity;
import isom.appops.database.repository.FeedbackEntityRepository;
import isom.appops.domain.mappers.FeedbackMapper;
import isom.appops.domain.model.PageRequest;
import isom.appops.domain.model.dto.FeedbackDTO;
import isom.appops.domain.model.entries.FeedbackEntry;
import isom.appops.quarkus.data.PagedResult;
import isom.appops.quarkus.errorhandler.exception.ApiBadRequestException;
import isom.appops.quarkus.errorhandler.exception.ApiInternalServerErrorException;
import io.quarkus.panache.common.Page;
import io.quarkus.panache.common.Sort;
import org.eclipse.microprofile.jwt.JsonWebToken;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.SecurityContext;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.util.List;
import java.util.stream.Collectors;

@ApplicationScoped
public class FeedbackService {

    @Inject
    JsonWebToken jwt;

    @Inject
    FeedbackMapper mapper;

    @Inject
    FeedbackEntityRepository repository;

    public FeedbackDTO get(Long id) {
        FeedbackEntity entity = FeedbackEntity.findById(id);
        return mapper.toDTO(entity);
    }

    @Transactional
    public void delete(Long id) {
        FeedbackEntity entity = FeedbackEntity.findById(id);
        if (null != entity){
            entity.delete();
        }
    }

    @Transactional
    public FeedbackDTO add(FeedbackEntry entry) throws ApiBadRequestException, ApiInternalServerErrorException {
        FeedbackEntity entity = mapper.toEntity(entry);
        entity.setUserId(jwt.getName());
        ZoneId zoneId = ZoneId.of("Europe/Madrid");
        entity.setCreationDate(OffsetDateTime.now(zoneId));
        entity.persist();
        return mapper.toDTO(entity);
    }

    @Transactional
    public FeedbackDTO update(Long id, FeedbackEntry entry) throws ApiBadRequestException, ApiInternalServerErrorException {
        FeedbackEntity entity = FeedbackEntity.findById(id);
        mapper.toEntity(entry, entity);
        entity.persist();
        return mapper.toDTO(entity);
    }

    public PagedResult<FeedbackDTO> list(PageRequest pageRequest) {
        PagedResult<FeedbackEntity> entities = repository.findBy(Page.of(pageRequest.page, pageRequest.size), Sort.by(pageRequest.sort).direction(pageRequest.ascending ? Sort.Direction.Ascending : Sort.Direction.Descending));
        PagedResult<FeedbackDTO> result = new PagedResult<FeedbackDTO>();
        List<FeedbackDTO> ticketDtos = entities.getList().stream().map((entity) -> mapper.toDTO(entity)).collect(Collectors.toList());
        result.setList(ticketDtos);
        result.setNumOfResults(entities.getNumOfResults());
        result.setPage(entities.getPage());
        result.setSize(entities.getSize());
        return result;
    }

    public PagedResult<FeedbackDTO> listByProcedureId(PageRequest pageRequest, Long procedureId) {
        PagedResult<FeedbackEntity> entities = repository.findAllByProcedureId(procedureId, pageRequest);
        PagedResult<FeedbackDTO> result = new PagedResult<FeedbackDTO>();
        List<FeedbackDTO> ticketDtos = entities.getList().stream().map((entity) -> mapper.toDTO(entity)).collect(Collectors.toList());
        result.setList(ticketDtos);
        result.setNumOfResults(entities.getNumOfResults());
        result.setPage(entities.getPage());
        result.setSize(entities.getSize());
        return result;
    }
}
