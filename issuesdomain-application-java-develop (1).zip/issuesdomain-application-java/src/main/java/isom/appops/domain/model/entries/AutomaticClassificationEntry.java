package isom.appops.domain.model.entries;

import java.util.Objects;


public class AutomaticClassificationEntry {

    private String classification;


    public AutomaticClassificationEntry() {
    }

    public AutomaticClassificationEntry(String classification) {
        this.classification = classification;
    }

    public String getClassification() {
        return this.classification;
    }

    public void setClassification(String classification) {
        this.classification = classification;
    }

    public AutomaticClassificationEntry classification(String classification) {
        setClassification(classification);
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof AutomaticClassificationEntry)) {
            return false;
        }
        AutomaticClassificationEntry automaticClassificationEntry = (AutomaticClassificationEntry) o;
        return Objects.equals(classification, automaticClassificationEntry.classification);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(classification);
    }

    @Override
    public String toString() {
        return "{" +
            " classification='" + getClassification() + "'" +
            "}";
    }


}