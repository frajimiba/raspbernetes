package isom.appops.domain.mappers;

import isom.appops.database.entities.IssueEntity;
import isom.appops.database.entities.TroubleshootingEntity;
import isom.appops.domain.model.dto.TroubleshootingDTO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

import java.util.UUID;

@Mapper(componentModel = "cdi")
public interface TroubleshootingMapper {
    
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "issue", expression = "java(getIssueEntity(dto))")
    TroubleshootingEntity toEntity(TroubleshootingDTO dto);
    
    @Mapping(target = "issue", expression = "java(getIssueEntity(dto))")
    void toEntity(TroubleshootingDTO dto, @MappingTarget TroubleshootingEntity entity);

    @Mapping(target = "issueId", source = "entity.issue.id")
    TroubleshootingDTO toDTO(TroubleshootingEntity entity);

    @Mapping(target = "content", source = "entity.content")
    @Mapping(target = "creationDate", source = "entity.creationDate")
    @Mapping(target = "userId", source = "entity.userId")
    @Mapping(target = "issueId", source = "issueId")
    void toDTO(TroubleshootingEntity entity, UUID issueId, @MappingTarget TroubleshootingDTO dto);
    
    default IssueEntity getIssueEntity(TroubleshootingDTO dto){
        return IssueEntity.findById(dto.getIssueId());
    }

}
