package isom.appops.domain.resource;

import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.util.List;
import java.util.UUID;

import jakarta.annotation.security.RolesAllowed;
import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;

import isom.appops.domain.model.events.NotificationEventData;
import isom.appops.domain.services.*;
import isom.appops.domain.utils.Constants;
import isom.appops.openapi_ticketdetails.api.TicketsResourceApi;
import isom.appops.openapi_ticketdetails.model.TicketDTO;
import io.vertx.core.eventbus.EventBus;
import isom.appops.domain.services.IssuesService;
import isom.appops.domain.services.JwtTokenService;
import isom.appops.domain.services.StatusTrackingService;
import isom.appops.domain.services.TicketDetailsService;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.enums.SchemaType;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;
import org.eclipse.microprofile.openapi.annotations.tags.Tags;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

import isom.appops.domain.model.dto.StatusTrackingDTO;
import isom.appops.quarkus.errorhandler.exception.ApiBadRequestException;
import isom.appops.quarkus.errorhandler.exception.ApiInternalServerErrorException;

import io.quarkus.security.Authenticated;

import static isom.appops.domain.utils.Constants.NOTIFICATION_EVENT_CLOSE_ISSUE;

@Path("/issues/{id}/statuses")
@RegisterRestClient
@Authenticated
@Tags(value = @Tag( name="StatusTrackingResource", description = "StatusTrackingResource"))
public class StatusTrackingResource {
    
	@Inject
    StatusTrackingService statusService;

	@Inject
    IssuesService issuesService;

	@Inject
    TicketDetailsService ticketDetailsService;

	@Inject
    JwtTokenService tokenService;

	@Inject
	EventBus bus;

    @Operation(summary = "Get issues statuses")
    @APIResponse(responseCode = "200", description = "Get all ticket statuses", content = @Content(mediaType = "application/json", schema = @Schema(type = SchemaType.ARRAY, implementation = StatusTrackingDTO.class)))
	@GET
	@RolesAllowed({"ticket-ingestor", "admin", "sre", "ftr","operador","auto"})
	@Path("/")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response getStatuses(@PathParam("id") UUID id) {
		List<StatusTrackingDTO> result = statusService.getStatuses(id);
		return Response.status(Status.OK).entity(result).build();
	}

    @Operation(summary = "Add a new status for the issue")
    @APIResponse(responseCode = "202", description = "Accepted", content = @Content(mediaType = "application/json", schema = @Schema(implementation = StatusTrackingDTO.class)))
    @APIResponse(responseCode = "400", description = "Bad request", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ApiBadRequestException.class)))
	@APIResponse(responseCode = "500", description = "Internal Server Error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ApiInternalServerErrorException.class)))
	@POST
	@RolesAllowed({"ticket-ingestor", "admin", "sre", "ftr","operador","auto"})
	@Path("/status")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response addNewStatus(@PathParam("id") UUID id, String status) throws ApiBadRequestException, ApiInternalServerErrorException {
		StatusTrackingDTO statusTrackingDTO = statusService.add(id, status);
		if (status.equalsIgnoreCase(Constants.STATUS_RESOLVED)){
			ZoneId zoneId = ZoneId.of("Europe/Madrid");
			OffsetDateTime dateTime = OffsetDateTime.now(zoneId);
			issuesService.updateResolutionDate(id, dateTime);
			TicketDTO ticketDTO = ticketDetailsService.getDetails(id);
			bus.publish(NOTIFICATION_EVENT_CLOSE_ISSUE, new NotificationEventData(id, "", ticketDTO, tokenService.getRawToken()));
		}
		return Response.status(Status.ACCEPTED).entity(statusTrackingDTO).build();
	}
}
