package isom.appops.domain.model.entries;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public class FullIssueEntry {

    @JsonProperty(required = true)
    List<String> clients;
    @JsonProperty(required = true)
    List<String> groups;
    @JsonProperty(required = true)
    List<String> classifications;
    @JsonProperty(required = true)
    List<String> statuses;
    @JsonProperty(required = true)
    boolean hideExpired;

    public FullIssueEntry() {
    }

    public List<String> getClients() {
        return clients;
    }

    public List<String> getGroups() {
        return groups;
    }

    public List<String> getClassifications() {
        return classifications;
    }

    public List<String> getStatuses() {
        return statuses;
    }

    public void setClients(List<String> clients) {
        this.clients = clients;
    }

    public void setGroups(List<String> groups) {
        this.groups = groups;
    }

    public void setClassifications(List<String> classifications) {
        this.classifications = classifications;
    }

    public void setStatuses(List<String> statuses) {
        this.statuses = statuses;
    }

    public boolean getHideExpired() {
        return hideExpired;
    }

    public void setHideExpired(boolean hideExpired) {
        this.hideExpired = hideExpired;
    }
}
