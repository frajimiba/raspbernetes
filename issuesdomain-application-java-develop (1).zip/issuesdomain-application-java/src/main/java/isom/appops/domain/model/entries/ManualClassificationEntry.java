package isom.appops.domain.model.entries;

import java.util.Objects;

public class ManualClassificationEntry {

    private String classification;
    private String userName;


    public ManualClassificationEntry() {
    }

    public ManualClassificationEntry(String classification, String userName) {
        this.classification = classification;
        this.userName = userName;
    }

    public String getClassification() {
        return this.classification;
    }

    public void setClassification(String classification) {
        this.classification = classification;
    }

    public String getUserName() {
        return this.userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public ManualClassificationEntry classification(String classification) {
        setClassification(classification);
        return this;
    }

    public ManualClassificationEntry userName(String userName) {
        setUserName(userName);
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof ManualClassificationEntry)) {
            return false;
        }
        ManualClassificationEntry manualClassificationEntry = (ManualClassificationEntry) o;
        return Objects.equals(classification, manualClassificationEntry.classification) && Objects.equals(userName, manualClassificationEntry.userName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(classification, userName);
    }

    @Override
    public String toString() {
        return "{" +
            " classification='" + getClassification() + "'" +
            ", userName='" + getUserName() + "'" +
            "}";
    }
    


}