package isom.appops.domain.model.entries;

public class JobEntry {

    String jobName; // deploy

    String env; // configFileEnvironment [no tiene que ser un combo sino un campo de texto libre]

    String organization; // viene del cliente

    String repository; // configFilePath - nombre del repositorio [awxhelloworld-job-config]

    String version; // configFileVersion - https://semver.org/lang/es/

    public JobEntry() {
    }

    public JobEntry(String jobName, String env, String organization, String repository, String version) {
        this.jobName = jobName;
        this.env = env;
        this.organization = organization;
        this.repository = repository;
        this.version = version;
    }

    public String getJobName() {
        return jobName;
    }

    public void setJobName(String jobName) {
        this.jobName = jobName;
    }

    public String getEnv() {
        return env;
    }

    public void setEnv(String env) {
        this.env = env;
    }

    public String getOrganization() {
        return organization;
    }

    public void setOrganization(String organization) {
        this.organization = organization;
    }

    public String getRepository() {
        return repository;
    }

    public void setRepository(String repository) {
        this.repository = repository;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }
}
